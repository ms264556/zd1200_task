#!/bin/sh
#          beforeconf.sh
# Run this to reconfigure after unpacking the tarball, 
# before running ./configure
#
am_files="mkinstalldirs missing"
am_dir=`ls -d /usr/share/automake* |tail -n1`
lt_files="ltmain.sh config.guess config.sub"
lt_dir=/usr/share/libtool
my_dir=`pwd`

#ltver=`rpm -q libtool |cut -f2 -d'-'`
ltver=`libtool --version | head -n1 |awk '{ print $4 }'`
ltv1=`echo $ltver |cut -f1 -d'.'`
if [ "$ltv1" != "1" ]
then
   # many distros have libtool-2.x.x
   lt_dir="/usr/share/libtool/config"
   lt_files="compile config.guess config.sub depcomp install-sh ltmain.sh missing"
   cp -f /usr/bin/libtool $my_dir
fi
if [ -d $am_dir ]
then
  cd $am_dir
  cp -f ${am_files} $my_dir
fi
if [ -d $lt_dir ]
then
  cd $lt_dir
  cp -f ${lt_files} $my_dir
fi

cd $my_dir
rm -rf autom4te.cache
aclocal
autoconf 
automake

