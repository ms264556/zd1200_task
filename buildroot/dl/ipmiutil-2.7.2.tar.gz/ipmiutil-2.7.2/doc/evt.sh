#!/bin/sh
#      evt.sh
# A sample script to use via ipmiutil getevt -s -r /path/evt.sh
#
evtdesc=$1
log=/var/log/ipmi_evt.log

echo "$0 got IPMI event `date`"  >>$log
# Check SEVerity for anything other than INFormational.
echo $evtdesc |grep -v INF >/dev/null 2>&1
if [ $? -eq 0 ]; then
   echo "*** Event requiring attention below: ***" >>$log
   # Could take other specific actions here, like snmptrap, or other alert.
fi
echo "$evtdesc"     >>$log

