/*
 * ipmi_sample.c
 *
 * A sample IPMI utility, to which more commands can be added.
 *
 * 02/27/06 Andy Cress - created 
 */
/*M*
Copyright (c) 2007, Kontron America, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

  a.. Redistributions of source code must retain the above copyright notice, 
      this list of conditions and the following disclaimer. 
  b.. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation 
      and/or other materials provided with the distribution. 
  c.. Neither the name of Kontron America, Inc. nor the names of its contributors 
      may be used to endorse or promote products derived from this software 
      without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *M*/
#ifdef WIN32
#include <windows.h>
#include <stdio.h>
#include "getopt.h"
#else
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <getopt.h>
#endif
#include <string.h>
#include "ipmicmd.h"
 
/*
 * Global variables 
 */
static char * progname  = "ipmi_sample";
static char * progver   = "0.2";
static char   fdebug    = 0;
static char   fset_mc  = 0;
static uchar  g_bus  = PUBLIC_BUS;
static uchar  g_sa   = BMC_SA;
static uchar  g_lun  = BMC_LUN;
static uchar  g_addrtype = ADDR_SMI;

#ifdef WIN32
int __cdecl
#else
int
#endif
main(int argc, char **argv)
{
   int ret = 0;
   char c;
   uchar devrec[16];
   uchar cc;
   int i, sresp;
   char *s1;

   printf("%s ver %s\n", progname,progver);

   while ( (c = getopt( argc, argv,"m:xEF:N:P:R:T:U:V:YZ:?")) != EOF ) 
      switch(c) {
          case 'm': /* specific IPMB MC, 3-byte address, e.g. "409600" */
                    g_bus = htoi(&optarg[0]);  /*bus/channel*/
                    g_sa  = htoi(&optarg[2]);  /*device slave address*/
                    g_lun = htoi(&optarg[4]);  /*LUN*/
                    g_addrtype = ADDR_IPMB;
                    if (optarg[6] == 's') {
                             g_addrtype = ADDR_SMI;  s1 = "SMI";
                    } else { g_addrtype = ADDR_IPMB; s1 = "IPMB"; }
                    fset_mc = 1;
                    ipmi_set_mc(g_bus,g_sa,g_lun,g_addrtype);
                    printf("Use MC at %s bus=%x sa=%x lun=%x\n",
                            s1,g_bus,g_sa,g_lun);
                    break;
          case 'x': fdebug = 1;     break;  /* debug messages */
          case 'N':    /* nodename */
          case 'U':    /* remote username */
          case 'P':    /* remote password */
          case 'R':    /* remote password */
          case 'E':    /* get password from IPMI_PASSWORD environment var */
          case 'F':    /* force driver type */
          case 'T':    /* auth type */
          case 'V':    /* priv level */
          case 'Y':    /* prompt for remote password */
          case 'Z':    /* set local MC address */
                parse_lan_options(c,optarg,fdebug);
                break;
	  default:
                printf("Usage: %s [-mx -NUPREFTVY]\n", progname);
                printf(" where -x       show eXtra debug messages\n");
		printf("       -m002000 specific MC (bus 00,sa 20,lun 00)\n");
		print_lan_opt_usage();
                exit(1);
      }
   /* Rather than parse_lan_options above, the set_lan_options function 
    * could be used if the program already knows the nodename, etc. */

   ret = ipmi_getdeviceid(devrec,16,fdebug);
   if (ret != 0) {
	printf("Cannot do ipmi_getdeviceid, ret = %d\n",ret);
	goto do_exit;
   } else {  /*success*/
       uchar ipmi_maj, ipmi_min;
       ipmi_maj = devrec[4] & 0x0f;
       ipmi_min = devrec[4] >> 4;
       show_devid( devrec[2],  devrec[3], ipmi_maj, ipmi_min);
   }

do_exit:
   show_outcome(progname,ret);
   ipmi_close_();
   exit (ret);
}  /* end main()*/

/* end ipmi_sample.c */
