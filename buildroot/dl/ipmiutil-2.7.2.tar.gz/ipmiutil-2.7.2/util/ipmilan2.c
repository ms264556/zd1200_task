/*M*
//  PVCS:
//      $Workfile:   ipmilan2.c  $
//      $Revision:   1.0  $
//      $Modtime:   21 Nov 2006 08:42:14  $
//      $Author:   arcress at users.sourceforge.net  $  
//
//  This implements support for the IPMI LAN 2.0 (RMCP+) interface natively.
// 
//  11/21/06 ARC - created from ipmilan.c, incomplete.
//  01/09/07 ARC - not used, see ipmilanplus.c instead
//                 this is only used for standalone builds without lanplus
 *M*/
/*----------------------------------------------------------------------*
The BSD License 

Copyright (c) 2005-2006, Intel Corporation
Copyright (c) 2009 Kontron America, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

  a.. Redistributions of source code must retain the above copyright notice, 
      this list of conditions and the following disclaimer. 
  b.. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation 
      and/or other materials provided with the distribution. 
  c.. Neither the name of Intel Corporation nor the names of its contributors 
      may be used to endorse or promote products derived from this software 
      without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *----------------------------------------------------------------------*/

#ifdef WIN32
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <winsock.h>
#include <io.h>
#include <signal.h>

#define INET_ADDRSTRLEN 16
#define MSG_NONE     0x000 
#define MSG_WAITALL  0x100   /* Wait for a full request */ 
#define uint32   unsigned int
#define uchar       unsigned char
typedef unsigned int socklen_t;
#define RECV_MSG_FLAGS  MSG_NONE

#elif defined(DOS)
#include <dos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#else   /* Linux */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <netdb.h>
#include <sys/time.h>
#include <signal.h>
#define RECV_MSG_FLAGS  MSG_WAITALL
#endif

#include "ipmicmd.h"
#include "ipmilan2.h"

#ifdef DOS
#define UNSUP_MSG "IPMI lanplus is not supported under DOS.\n"
#else
#define UNSUP_MSG "IPMI lanplus is not supported in the standalone build.\n"
#endif

int   verbose = 0;
char  fdbglog = 0;

int _ipmilan2_cmd(int sockfd, struct sockaddr *hostaddr, int hostaddr_len,
     uchar cmd, uchar netfn, uchar lun, uchar sa, 
     uchar *sdata, int slen, uchar *rdata, int *rlen, int fdebugcmd)
{ return(LAN_ERR_INVPARAM); }


int rmcp_ping2(int sfd, struct sockaddr *saddr, int saddr_len, int foutput)
{ return(LAN_ERR_INVPARAM); }

int ipmi_open_lan2(char *node, char *user, char *pswd, int fdebugcmd)
{ printf(UNSUP_MSG); return(LAN_ERR_INVPARAM); }

int ipmi_close_lan2(char *node)
{ printf(UNSUP_MSG); return(LAN_ERR_INVPARAM); }
 
int ipmicmd_lan2(char *node, uchar cmd, uchar netfn, uchar lun, uchar sa,
		uchar *pdata, uchar sdata, uchar *presp, int *sresp, 
		uchar *pcc, char fdebugcmd)
{ printf(UNSUP_MSG); return(LAN_ERR_INVPARAM); }

int ipmi_cmdraw_lan2(char *node, uchar cmd, uchar netfn, uchar lun, uchar sa,
		uchar bus, uchar *pdata, uchar sdata, 
		uchar *presp, int *sresp, uchar *pcc, char fdebugcmd)
{ printf(UNSUP_MSG); return(LAN_ERR_INVPARAM); }

int ipmi_cmd_lan2(char *node, ushort cmd, uchar *pdata, uchar sdata,
                uchar *presp, int *sresp, uchar *pcc, char fdebugcmd)
{ printf(UNSUP_MSG); return(LAN_ERR_INVPARAM); }

int lan2_send_sol( uchar *payload, int len, void *rsp)
{ return(LAN_ERR_INVPARAM); }
int lan2_recv_sol( void *rsp )
{ return(LAN_ERR_INVPARAM); }
int lan2_keepalive(int type, void *rsp)
{ return(LAN_ERR_INVPARAM); }
void lan2_recv_handler( void *rs )
{ return; }
void lan2_set_sol_data(int insize, int outsize, int port, void *handler,
                        char esc_char)
{ return; }
int lan2_get_fd(void) { return(1); }
void lanplus_set_recvdelay( int delay ) { return; }
long lan2_get_latency( void ) { return(1); }
int lan2_send_break( void *rsp) { return(LAN_ERR_INVPARAM); }

/* end ipmilan2.c */
