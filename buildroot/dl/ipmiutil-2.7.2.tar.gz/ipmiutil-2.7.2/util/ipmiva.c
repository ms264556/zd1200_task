/*M*
//  PVCS:
//      $Workfile:   ipmiva.c  $
//      $Revision:   1.02  $
//      $Modtime:   06 Jul 2006 11:24:14  $
//      $Author:   arcress at users.sourceforge.net  $  
//
//  Define the ipmi_cmd routines for the valinux IPMI driver.
//     /dev/ipmikcs /dev/ipmi/kcs = valinux driver by San Mehat
// 
//  07/06/06 ARC - created from ipmicmd.c
//  07/25/07 ARC - added VAOK compile flags
//  08/13/08 ARC - moved _va routines to ipmiva.h
 *M*/
/*----------------------------------------------------------------------*
The BSD License 

Copyright (c) 2002-2008, Intel Corporation
Copyright (c) 2009 Kontron America, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

  a.. Redistributions of source code must retain the above copyright notice, 
      this list of conditions and the following disclaimer. 
  b.. Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation 
      and/or other materials provided with the distribution. 
  c.. Neither the name of Intel Corporation nor the names of its contributors 
      may be used to endorse or promote products derived from this software 
      without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *----------------------------------------------------------------------*/
#undef VAOK
#ifdef LINUX

#if defined(ALLOW_GNU) 
#define VAOK  1
#endif

#ifdef WIN32
#include <windows.h>
#else
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#endif
#include <stdio.h>

#include "ipmicmd.h" 

#ifdef VAOK
/*
 * The ipmi_ioctls.h contains GPL code that may not be desired in some cases.
 * If GPL is not desired, the ipmi_ioctls.h can be deleted without affecting
 * the configure/make process.
 * If GPL is ok, then "configure --enable-gpl" should be used. 
 */
#include "ipmi_ioctls.h"   /* for ipmi_cmd_va() */
#include "ipmiva.h"        /* has actual *_va routines */
#else 

/* define stubs for *_va routines */
int ipmi_open_va(char fdebugcmd)
{
    return(-2);
}
int ipmi_close_va(void)
{
    return(0);
}
int ipmi_cmdraw_va(uchar cmd, uchar netfn, uchar lun, uchar sa, uchar bus,
		uchar *pdata, uchar sdata, uchar *presp, 
		int *sresp, uchar *pcc, char fdebugcmd)
{
    return(-2);
}
int ipmi_cmd_va(ushort cmd, uchar *pdata, uchar sdata, uchar *presp, 
		int *sresp, uchar *pcc, char fdebugcmd)
{
    return(-2);
}
#endif

#endif
/* end ipmiva.c */
