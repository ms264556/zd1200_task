/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	ProgFunc.c

Description:	Implementation of the Tool4TPM functions

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifdef UEFI_X64
#include <Library/UefiRuntimeServicesTableLib.h>	// because of Time
#ifdef UEFI_I2C
#include "LowLevIO.h"
#endif
#else
#ifdef linux
#include <unistd.h>
#endif //linux
#include <stdarg.h>
#include <time.h>
#include <ctype.h>
#endif //UEFI_X64

//#include "ASN1pars.h"
#include "Console.h"
#include "FileIO.h"
//#include "Hash.h"
#include "ProgFunc.h"
//#include "RSA.h"
#include "TPM_Cmds.h"
#include "TPM_Func.h"

/*++
dwSwitchEndian16/32

Description:
Cast little endian formated Word/Double/Quadruple Word to big endian or vice versa

Arguments:
[in]	UINT16/32	wNum/dwNum	Input Word/Double/Quadruple Word

Return value:
	Return						Meaning
	======						=======
	UINT16/32/TPM_UINT64		output Word/Double/Quadruple Word

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT16 wSwitchEndian16(UINT16 wNum)
{
	return (((wNum << 8) & 0xff00) | ((wNum >> 8) & 0x00ff));
}

UINT32 dwSwitchEndian32(UINT32 dwNum)
{
	return (((dwNum << 24) & 0xff000000)
		| ((dwNum << 8) & 0x00ff0000) | ((dwNum >> 8) & 0x0000ff00) | ((dwNum >> 24) & 0x000000ff));
}

/*++
SwitchEndian16/32/64ByteArray

Description:
Convert little endian formated byte array to big endian or vice versa in place

Arguments:
[in/out]	BYTE *	pbArray		Input Byte Array/Output Byte Array

Return value:
	Return				Meaning
	======				=======
	BYTE pbArray[2/4]	output Byte Array

Author:		H. Obermeier	2008/08/04
--*/
void SwitchEndian16ByteArray(BYTE pbArray[2])
{
	UINT16 wHelp;

	wHelp = ((pbArray[0]) << 8) | (pbArray[1]);
	pbArray[0] = (BYTE) wHelp;
	pbArray[1] = (BYTE) (wHelp >> 8);
}

void SwitchEndian32ByteArray(BYTE pbArray[4])
{
	UINT32 dwHelp;

	dwHelp = (pbArray[0] << 24) | (pbArray[1] << 16) | (pbArray[2] << 8) | (pbArray[3]);
	pbArray[0] = (BYTE)dwHelp;
	pbArray[1] = (BYTE)(dwHelp >> 8);
	pbArray[2] = (BYTE)(dwHelp >> 16);
	pbArray[3] = (BYTE)(dwHelp >> 24);
}

void SwitchEndian64ByteArray(TPM_UINT64 * qwNum)
{
	BYTE bHelp;

	bHelp = qwNum->bUINT64[0];
	qwNum->bUINT64[0] = qwNum->bUINT64[7];
	qwNum->bUINT64[7] = bHelp;

	bHelp = qwNum->bUINT64[1];
	qwNum->bUINT64[1] = qwNum->bUINT64[6];
	qwNum->bUINT64[6] = bHelp;

	bHelp = qwNum->bUINT64[2];
	qwNum->bUINT64[2] = qwNum->bUINT64[5];
	qwNum->bUINT64[5] = bHelp;

	bHelp = qwNum->bUINT64[3];
	qwNum->bUINT64[3] = qwNum->bUINT64[4];
	qwNum->bUINT64[4] = bHelp;
}

/*++
Dump

Description:
Hex or String dump to file and/or screen

Arguments:
[in]	BYTE	target	Output target: TG_FILE or TG_SCREEN or TG_BOTH
[in]	BYTE	mode	Output mode: MD_HEX or MD_STR
[in]	BYTE	*data	Pointer to dumped data
[in]	BYTE	len		Length of dumped data

Return value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void Dump(BYTE target, BYTE mode, BYTE * data, UINT32 len)
{
	UINT32 i, k;
	BYTE tempDebug = bDebug;
	UINT32 dwBufferSize = 0;
	char *pcBuffer = NULL;
	char *pcPos = NULL;

	if (target == TG_FILE && bDebug < 2) {
		return; // no dump needed
	}

	if (mode == MD_STR) {
		dwBufferSize = (len / 80) * 81 + len % 80 + 1;
		if (CALLOC(pcBuffer, dwBufferSize)) {
			pcPos = pcBuffer;
			for (i = 0; i < len; i++, pcPos++) {
				if ((i % 80) == 0 && i > 0) {
					*pcPos = '\n';
					pcPos++;
				}
				*pcPos = *(data + i);
			}
		}
	}
	else if (mode == MD_HEX) {
		// len * 3 = Bytes + whitespaces
		// ((len + 15) / 16) * (8 + 1) = number of lines times the length of the index (8) plus the newline char
		// +1 = final \0
		dwBufferSize = len*3 + ((len+15) / 16) * (8 + 1) + 1;
		if (CALLOC(pcBuffer, dwBufferSize)) {
			i = 0;
			pcPos = pcBuffer;
			while(i < len && pcPos < pcBuffer + dwBufferSize) {
				if (i + 16 <= len) {
					// we can write a complete line at once
					FormatString(pcPos,
						(UINT32)(dwBufferSize - (pcPos - pcBuffer)),
						"%.8X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X %.2X",
						i, *(data + i), *(data + i + 1), *(data + i + 2), *(data + i + 3),
						*(data + i + 4), *(data + i + 5), *(data + i + 6), *(data + i + 7),
						*(data + i + 8), *(data + i + 9), *(data + i + 10), *(data + i + 11),
						*(data + i + 12), *(data + i + 13), *(data + i + 14), *(data + i + 15));
					pcPos += 56; // 8 + 16 * 3
					i += 16;
				}
				else {
					// write the index
					FormatString(pcPos, dwBufferSize, "%.8X", i);
					pcPos += 8;
					// write the bytes
					for (k = 0; k < 16 && i < len; k++, i++) {
						// buffer size 4 = 3 chars + \0
						FormatString(pcPos, 4, " %.2X", *(data + i));
						pcPos += 3;
					}
				}
				// new line
				*pcPos = '\n';
				pcPos++;
			}
		}
	}

	switch (target) {
		case TG_FILE:
			DetLogToFile(pcBuffer);
			break;
		case TG_SCREEN:
			bDebug = 0;
		case TG_BOTH:
			Log(pcBuffer);
			break;
	}

	SAFE_FREE(pcBuffer);

	bDebug = tempDebug;
}

/*++
Log

Description:
Print formatted data to screen (and to log file if log, detaillog or debug mode is on)

Arguments:
[in]	char	*pcFormat		String format
[in]	...					optional arguments

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void Log(char *pcFormat, ...)
{
	va_list pcArguments;
	char *pcBuffer;
	UINT32 dwBufferSize;

	va_start(pcArguments, pcFormat);
	dwBufferSize = GetFormattedBufferSizev(pcFormat, pcArguments);	
	va_end(pcArguments);
	va_start(pcArguments, pcFormat);
	if (CALLOC(pcBuffer, dwBufferSize)) {
		FormatStringv(pcBuffer, dwBufferSize, pcFormat, pcArguments);
		ConsoleWrite(pcBuffer);	
		if (bDebug) {
			FileWriteString(pvLogFileHandle, pcBuffer);
		}
	}
	va_end(pcArguments);

	SAFE_FREE(pcBuffer);
}

/*++
GetFormattedBufferSize

Description:
Gets the buffer size needed to store the formatted string

Arguments:
[in]	char	*pcFormat		String format
[in]	...						optional arguments

Return Value:
	Return				Meaning
	======				=======
	UINT32				The buffer size in bytes, needed to store the formatted string

Author:		Viktor Wallner	2013/03/14
--*/
UINT32 GetFormattedBufferSize(char *pcFormat, ...)
{
	va_list pcArguments;
	UINT32 dwBufferSize = 0;

	va_start(pcArguments, pcFormat);
	dwBufferSize = GetFormattedBufferSizev(pcFormat, pcArguments);
	va_end(pcArguments);

	return dwBufferSize;
}

/*++
GetFormattedBufferSizev

Description:
Gets the buffer size needed to store the formatted string

Arguments:
[in]	char	*pcFormat		String format
[in]	va_list	 pcArguments	Argument list

	Return				Meaning
	======				=======
	UINT32				The buffer size in bytes, needed to store the formatted string

Author:		Viktor Wallner	2013/03/14
--*/
UINT32 GetFormattedBufferSizev(char *pcFormat, va_list pcArgumentsOrig)
{
	UINT32 dwFormatLength = 0, dwBufferSize = 0;
	UINT16 i = 0, k = 0;
	char *pcBuffer = NULL, *pcFormatFragment = NULL;
	UINT32 dwFragmentLength = 0, dwStringWidth = 0, dwStringLength = 0;
	va_list pcArguments;

	va_copy(pcArguments, pcArgumentsOrig);
	dwFormatLength = (UINT32)strlen(pcFormat);
	dwBufferSize = (UINT32)strlen(pcFormat) + 1;
	if (CALLOC(pcBuffer, 1024) && CALLOC(pcFormatFragment, 1024)) {
		for (i = 0; i < dwFormatLength; i++) {
			if (pcFormat[i] == '%' && pcFormat[i+1] != '%') {
				dwFragmentLength = 0;
				while (i < dwFormatLength) {
					pcFormatFragment[dwFragmentLength++] = pcFormat[i];
					if (strchr("diuoxXfFeEgGaAcspn", pcFormat[i])) {
						break; // we reached the end of the format fragment
					}
					i++;
				}
				pcFormatFragment[dwFragmentLength] = '\0';

				dwBufferSize -= dwFragmentLength;
				switch(pcFormatFragment[dwFragmentLength-1]) {
					case 's':
					case 'a':
						//lets see if there's a width for the string in our format fragment
						dwStringWidth = 0;
						k = 1;
						while(k < dwFragmentLength && strchr("-+ #0", pcFormatFragment[k])) { k++; }; // skip flags
						while(k < dwFragmentLength && strchr("0123456789*", pcFormatFragment[k])) {
							if (pcFormatFragment[k] == '*') {
								dwStringWidth = va_arg(pcArguments, int);
								break;
							}
							else {
								dwStringWidth = dwStringWidth * 10 + pcFormatFragment[k] - 0x30;
								k++;
							}
						}						
						dwStringLength = (UINT32)strlen(va_arg(pcArguments, char*));
						dwBufferSize += max(dwStringWidth, dwStringLength);
						break;
					case 'c':
						va_arg(pcArguments, int);
					    dwBufferSize += 1;
						break;
					default:
						FormatString(pcBuffer, 1024, pcFormatFragment, va_arg(pcArguments, int));
						dwBufferSize += (UINT32)strlen(pcBuffer);
						break;
				}
			}
			if (pcFormat[i] == '\n') {
				dwBufferSize += 1;
			}
		}
	}

	SAFE_FREE(pcBuffer);
	SAFE_FREE(pcFormatFragment);

	return dwBufferSize;
}

/*++
FormatString

Description:
Formats a string

Arguments:
[out]	char	*pcBuffer		The output buffer
[in]	UINT32	 dwBufferSize	The size of the output buffer
[in]	char	*pcFormat		String format
[in]	...						optional arguments

Return Value:
none

Author:		Viktor Wallner	2013/02/21
--*/
void FormatString(char *pcBuffer, UINT32 dwBufferSize, char *pcFormat, ...)
{
	va_list pcArguments;
	va_start(pcArguments, pcFormat);
	FormatStringv(pcBuffer, dwBufferSize, pcFormat, pcArguments);
	va_end(pcArguments);
}

/*++
FormatStringv

Description:
Formats a string using an argument list

Arguments:
[out]	char	*pcBuffer		The output buffer
[in]	UINT32	 dwBufferSize	The size of the output buffer
[in]	char	*pcFormat		String format
[in]	va_list	 pcArguments	optional arguments

Return Value:
none

Author:		Viktor Wallner	2013/02/21
--*/
void FormatStringv(char *pcBuffer, UINT32 dwBufferSize, char *pcFormat, va_list pcArguments)
{
	#ifdef UEFI_X64
	va_list pcArgumentsStart;
	CHAR8 *pcFormatStart;
	CHAR8 *bArg;
	CHAR16 *wArg;
	UINTN bCnt, wCnt;
	UINTN FormatMask;
	UINTN Character, NextCharacter, PrevCharacter;

	pcArgumentsStart = pcArguments;
	pcFormatStart = pcFormat;
	FormatMask = 0xff;
	PrevCharacter = 0;
	Character = (*pcFormat | (*(pcFormat + 1) << 8)) & FormatMask;
	while (Character != 0) {
		wCnt = bCnt = 0;
		pcFormat++;
		NextCharacter = (*pcFormat | (*(pcFormat + 1) << 8)) & FormatMask;
		if (Character == '%' ) {
			if (NextCharacter == 's' || NextCharacter == 'S') {
				bArg = (CHAR8 *)va_arg (pcArguments, CHAR8 *);
				wArg = (CHAR16 *)bArg;
				while (bArg[bCnt++] != '\0') { }
				while (wArg[wCnt++] != '\0') { }
				if ((AsciiStrLen(bArg) == 1 && AsciiStrLen(bArg) == (bCnt-1) && wCnt > bCnt) ||
							(AsciiStrLen(bArg) > 1 && AsciiStrLen(bArg) == (bCnt-1)) )		// its an ascii string -> replace %s with %a 
					*pcFormat = 0x61;	
			}
			else if (NextCharacter != '%' && PrevCharacter != '%'){
				(CHAR8 *)va_arg (pcArguments, CHAR8 *);									// consume argument				
			}
		}
		else {
		}
		PrevCharacter = Character;
		Character = NextCharacter;
	}
	AsciiVSPrint(pcBuffer, dwBufferSize, pcFormatStart, pcArgumentsStart);
	#else
	vsprintf(pcBuffer, pcFormat, pcArguments);	
	#endif	
}

/*++
LogToFile

Description:
Print formatted data exclusively to log file

Arguments:
[in]	char	*format		String format
[in]	...					optional arguments

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void LogToFile(char *pcFormat, ...)
{
	va_list pcArguments;

	if (bDebug >= 1) {
		va_start(pcArguments, pcFormat);
		FileWriteStringvf(pvLogFileHandle, pcFormat, pcArguments);
		va_end(pcArguments);
	}
}

/*++
DetLogToFile

Description:
Print formatted data exclusively to log file (if detaillog or debug mode is on)

Arguments:
[in]	char	*format		String format
[in]	...					optional arguments

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void DetLogToFile(char *pcFormat, ...)
{
	va_list pcArguments;

	if (bDebug >= 2) {
		va_start(pcArguments, pcFormat);
		FileWriteStringvf(pvLogFileHandle, pcFormat, pcArguments);
		va_end(pcArguments);
	}
}

/*++
DebugToFile

Description:
Print formatted data exclusively to log file (if debug mode is on)

Arguments:
[in]	char	*format		String format
[in]	...					optional arguments

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void DebugToFile(char *pcFormat, ...)
{
	va_list pcArguments;

	if (bDebug >= 3) {
		va_start(pcArguments, pcFormat);
		FileWriteStringvf(pvLogFileHandle, pcFormat, pcArguments);
		va_end(pcArguments);
	}
}

/*++
Sleep_ms

Description:
Sleep routine, waits the time specified in milliseconds

Arguments:
UINT16		wTime	Time in milliseconds

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/

void Sleep_ms(UINT16 wTime)
{
#ifdef UEFI_X64
#if DISABLE_SLEEPS == 0
	Sleep_us(wTime * 1000);
#endif
#else
#ifdef linux
#if DISABLE_SLEEPS == 0
	usleep(wTime * 1000);
#endif
#else
#ifdef DJGPP
	delay(wTime);
#else
	clock_t goal, wait;

	//wait = ( (CLOCKS_PER_SEC==91) ? (wTime/10) : ((wTime*CLOCKS_PER_SEC)/1000) );
	wait = wTime;
	goal = wait + clock();
	while (goal > clock()) ;
#endif
#endif
#endif
}

/*++
Sleep_us

Description:
Sleep routine, waits the time specified in microseconds

Arguments:
UINT32		dwTime	Time in microseconds

Return Value:
none

Author:		Peter Huewe	2011/11/14
--*/

void Sleep_us(UINT32 dwTime)
{
#ifdef UEFI_X64
#if DISABLE_SLEEPS == 0
	gBS->Stall(dwTime);
#endif
#else
#ifdef linux
#if DISABLE_SLEEPS == 0
	usleep(dwTime);
#endif
#else
#ifdef DJGPP
	uclock_t start;
	UINT32 dwWaitTime;
	if (dwTime < 1000) {
		start = uclock();
		while (uclock() < start + (UCLOCKS_PER_SEC / 10000000)*dwTime)
		; // DO NOTHING!
	} 
	else  {
		dwWaitTime = (dwTime + 999) / 1000; //round up
		if (dwWaitTime == 0) // if less than 1000 micro seconds
			dwWaitTime = 1; // wait atleast 1 millisecond
		delay(dwWaitTime);
	}
#else
	clock_t goal, wait;

	//wait = ( (CLOCKS_PER_SEC==91) ? (wTime/10) : ((wTime*CLOCKS_PER_SEC)/1000) );
	wait = (dwTime + 999) / 1000; //round up
	if (wait == 0) // if less than 1000 micro seconds
		wait = 1; // wait atleast 1 millisecond
	goal = wait + clock();
	while (goal > clock()) ;
#endif
#endif
#endif
}

/*++
WaitForAnyKey

Description:
Keyboard polling

Arguments:
none

Return Value:
	Return				Meaning
	======				=======
	char				key pressed

Author:		Markus Schmoelzer	2007/02/23
--*/
char WaitForAnyKey(void)
{
	char cKeyPressed = 0;
	
	ConsoleWrite("Press any key to continue...");
	#ifdef linux
	fflush(stdout);
	#endif
	
	init_keyboard();
	cKeyPressed = WaitForKey();
	FlushInputBuffer();
	close_keyboard();

	ConsoleWrite("\n");

	return cKeyPressed;
}

/*++
SetLoggingLevel

Description:
Set the log/debug level according to the specified value in the config file

Arguments:
none

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void SetLoggingLevel(void)
{
	UINT32 dwRCVal;
	UINT32 dwValue;

	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[LOGGING_LEVEL]", "LEVEL", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		bDebug = (BYTE) dwValue;
	else
		bDebug = 0;	// By default do not log anything
}

/*++
GetScreenMode

Description:
Get the console screen mode from config file

Arguments:
none

Return Value:
	Return				Meaning
	======				=======
	BYTE				DOS console screen mode (0 or 1, that is to be 80x25 or 80x50)

Author:		Markus Schmoelzer	2007/02/23
--*/

BYTE GetScreenMode(void)
{
	UINT32 dwRCVal;

	BYTE bMode;
	UINT32 dwValue;

	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[CONSOLE]", "80x50_MODE", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		bMode = (BYTE) dwValue;
	else
		bMode = 0;	// By default do not set 80x50mode

	return bMode;
}

#ifdef UEFI_I2C
/*++
GetI2cSpeed

Description:
Get the I2C communication frequency[Hz]

Arguments:
none

Return Value:
none

Author:		Christopher unterweger	2012/12/18
--*/
void GetI2cSpeed(void)
{
	UINT32 dwRCVal;
	UINT32 dwValue;

	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[I2C]", "FREQUENCY_HZ", &dwValue);

	if (dwRCVal == RC_SUCCESS)
		SetI2cFrequency(dwValue);
}
#endif
