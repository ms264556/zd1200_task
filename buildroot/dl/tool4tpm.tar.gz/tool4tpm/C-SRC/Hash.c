/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Hash.c

Description:	Source file for the implementation of the SHA-1 and the HMAC

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:			See header file for further information

--*/

#include "Hash.h"

// Internal SHA-1 function prototypes -----------------------------------------------------------
// Preprocess input message
static void Preprocess(const BYTE * const pbMessage, const UINT16 wMsgSize, BYTE * const M, const UINT16 N);

// Compute SHA-1 hash value of the preprocessed input message
static void Compute(const BYTE * const M, const UINT16 N, UINT32 * const H);

// Compute the message schedule W[t] for the i-th message block
static void compW(const BYTE * const M, UINT32 * const W, const BYTE t, const UINT16 i);

// Rotate input data n bits to the left and return the result
static UINT32 dwROTL(const BYTE n, const UINT32 dwData);

// Execute t-dependent bitwise functions on the input data and return the result
static UINT32 dw_f(const BYTE t, const UINT32 x, const UINT32 y, const UINT32 z);

// Determine the appropriate t-dependent constant value and return it
static UINT32 dwGetK(const BYTE t);

//-----------------------------------------------------------------------------------------------

/*++
HMAC_Func

Description:
Create a SHA-1 HMAC for the input text.
The program procedure is divided into 10 steps according to FIPS PUB 198.
Due to the fixed parameter sizes, steps 1, 2 and 10 are not implemented.

Arguments:
[in]	BYTE	*pbInpMsg			Input message
[in]	UINT32	wInpSize			Input message size in Bytes
[in]	BYTE	bKey[HASH_BLEN]		Message authentification key
[out]	BYTE	bHMAC[HASH_BLEN]	HMAC value (non-truncated SHA-1 hash value)

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			Operation successfully completed
	RC_E_INVALID_PARAM	Invalid parameters for the HMAC or the underlying SHA-1
	RC_E_NO_MEMORY		Not enough memory in Heap available

Author:		Markus Schmoelzer	2007/02/23
--*/
DISABLE_OPTIMIZATION // because of memset optimization of loops 
UINT32 UNOPTIMIZED HMAC_Func(const BYTE * const pbInpMsg, UINT16 wInpSize, const BYTE bKey[HASH_LEN], BYTE bHMAC[HASH_LEN])
{
	UINT32 dwRCVal = RC_SUCCESS;

	BYTE K0[64] = { 0 };	// Variable for the preprocessed 64 Byte key
	BYTE *step5tmp = NULL;	// Temporary Byte array pointer for step 5
	BYTE step8tmp[84];	// Temporary Byte array pointer for step 8
	UINT16 i;		// Index variable

	do {
		if (wInpSize > MAX_HMAC_INP_SZ)	// Input size limitation regarding SHA-1 limitations
			dwRCVal = RC_E_INVALID_PARAM;
		else {
			// Memory allocation for the temporary array
			wInpSize += 64;
			SAFE_CALLOC(step5tmp, wInpSize, &dwRCVal);

			// Preprocess key according to step 3
			for (i = 0; i < 20; i++)
				K0[i] = bKey[i];

			// Compute and concatenate temporary values according to step 4 and 5
			for (i = 0; i < wInpSize; i++)
				if (i < 64)
					step5tmp[i] = K0[i] ^ 0x36;
				else
					step5tmp[i] = pbInpMsg[i - 64];

			// Compute SHA-1 hash according to step 6
			dwRCVal = SHA1_Func(step5tmp, wInpSize, bHMAC);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}			

			// Compute and concatenate temporary values according to step 7 and 8
			for (i = 0; i < 84; i++)
				if (i < 64)
					step8tmp[i] = K0[i] ^ 0x5c;
				else
					step8tmp[i] = bHMAC[i - 64];

			// Compute SHA-1 hash according to step 9
			dwRCVal = SHA1_Func(step8tmp, 84, bHMAC);
		}
	} while (FALSE);

	SAFE_FREE(step5tmp);

	return (dwRCVal);
}
ENABLE_OPTIMIZATION

/*++
SHA1_Func

Description:
Create a SHA-1 hash for the input message.
The virtual scheme for the processed message is:
UINT32 M[<block index>][<DoubleWord index>]
That means, each 512 Bit message block is divided into 16 DoubleWords to be processed.
Thus, <block index> is between "1" and "N-1" and <DoubleWord index> is between "0"
and "15" (see FIPS PUB 180-2).
Due to easier implementation reasons, the implemented processed message array is a 
simple Byte array and the specified structure is provided by appropriate index
calculations.

Arguments:
[in]	BYTE	*pbInpMsg		Input message
[in]	UINT32	wInpSize		Input message size in Bytes
[out]	BYTE	bSHA1[HASH_LEN]	SHA-1 value

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			Operation successfully completed
	RC_E_INVALID_PARAM	Invalid parameters, i. e. wInpSize > MAX_SHA1_INP_SZ
	RC_E_NO_MEMORY		Not enough memory in Heap available

Author:		Markus Schmoelzer	2007/02/23
--*/
DISABLE_OPTIMIZATION	// because of memset optimization of loops 
UINT32 UNOPTIMIZED SHA1_Func(const BYTE * const pbInpMsg, const UINT16 wInpSize, BYTE bSHA1[HASH_LEN])
{
	UINT32 dwRCVal = RC_SUCCESS;

	BYTE *M = NULL;		// Temporary Byte array pointer for the processed message
	UINT16 N;		// Number of message blocks (see FIPS PUB 180-2)
	UINT32 H[5] = { 0 };	// Temporary DoubleWord array for the hash value

	BYTE hInd;

	do {
		if (wInpSize > MAX_SHA1_INP_SZ)
			dwRCVal = RC_E_INVALID_PARAM;
		else {
			// Relation between block number and message size accomplishing the processing rules:
			// N*512 > wInpSize*8+65        (65 = 1 (for appending '1') + 64 (for the message size))
			N = (wInpSize * 8 + 65) / 512 + 1;	// N <= 1023 for wInpSize <= 65463

			// Memory allocation for the message block array
			SAFE_CALLOC(M, N * 64, &dwRCVal);	// Because of malloc() limitation to 64 KB, N must NOT be > 1023

			// Preprocess input message
			Preprocess(pbInpMsg, wInpSize, M, N);

			// Compute SHA-1 hash value of the preprocessed input message
			Compute(M, N, H);

			// Copy the result from the UINT32 array H[5] to the BYTE array bSHA1[20]
			for (hInd = 0; hInd < HASH_LEN; hInd++)
				bSHA1[hInd] = (BYTE) (H[hInd / 4] >> (8 * (3 - hInd % 4)));
		}
	} while (FALSE);

	SAFE_FREE(M);

	return (dwRCVal);
}
ENABLE_OPTIMIZATION

// Preprocess input message ---------------------------------------------------------------------
static void Preprocess(const BYTE * const pbMessage, const UINT16 wMsgSize, BYTE * const M, const UINT16 N)
{
	// Index variable of unprocessed message
	UINT16 i = 0;

	// Copy message data
	while (i < wMsgSize) {
		M[i] = pbMessage[i];
		i++;
	}

	// Append '1' to the message
	M[i] = 0x80;
	i++;

	// Append zero bits
	while (i < N * 64 - 4) {
		M[i] = 0;
		i++;
	}

	// Append message size in Bit to the end of the last block
	M[i] = (BYTE) ((wMsgSize * 8) >> 24);
	M[i + 1] = (BYTE) ((wMsgSize * 8) >> 16);
	M[i + 2] = (BYTE) ((wMsgSize * 8) >> 8);
	M[i + 3] = (BYTE) (wMsgSize * 8);
}

// Compute SHA-1 hash value of the preprocessed input message -----------------------------------
static void Compute(const BYTE * const M, const UINT16 N, UINT32 * const H)
{
	BYTE t;			// Index variable of message schedule
	UINT16 i;		// Index variable of message block
	UINT32 a, b, c, d, e;	// Working variables for SHA-1 computation
	UINT32 T, W[80];	// Temporary variable and message schedule array

	// Initialize partial hash values for the first cycle
	H[0] = 0x67452301;
	H[1] = 0xefcdab89;
	H[2] = 0x98badcfe;
	H[3] = 0x10325476;
	H[4] = 0xc3d2e1f0;

	// Compute the hash value blockwise in N successive cycles
	for (i = 1; i <= N; i++) {
		a = H[0];
		b = H[1];
		c = H[2];
		d = H[3];
		e = H[4];

		// Compute working variables
		for (t = 0; t < 80; t++) {
			// Compute the message schedule W[t] for the i-th message block
			compW(M, W, t, i);
			T = dwROTL(5, a) + dw_f(t, b, c, d) + e + dwGetK(t) + W[t];
			e = d;
			d = c;
			c = dwROTL(30, b);
			b = a;
			a = T;
		}

		H[0] = a + H[0];
		H[1] = b + H[1];
		H[2] = c + H[2];
		H[3] = d + H[3];
		H[4] = e + H[4];
	}
}

// Compute the message schedule W[t] for the i-th message block ---------------------------------
static void compW(const BYTE * const M, UINT32 * const W, const BYTE t, const UINT16 i)
{
	if (t <= 15)
		W[t] = ((UINT32) (M[((i - 1) * 16 + t) * 4]) << 24)
		    + ((UINT32) (M[((i - 1) * 16 + t) * 4 + 1]) << 16)
		    + ((UINT32) (M[((i - 1) * 16 + t) * 4 + 2]) << 8)
		    + ((UINT32) (M[((i - 1) * 16 + t) * 4 + 3]));
	else if (t <= 79)
		W[t] = dwROTL(1, W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16]);
	else
		W[t] = 0;
}

// Rotate dwData n bits to the left and return the result ---------------------------------------
static UINT32 dwROTL(const BYTE n, const UINT32 dwData)
{
	if (n < 32)
		return ((dwData << n) | (dwData >> (32 - n)));
	else
		return (0);
}

// Execute t-dependent bitwise functions on the input data and return the result ----------------
static UINT32 dw_f(const BYTE t, const UINT32 x, const UINT32 y, const UINT32 z)
{
	UINT32 res;

	if (t <= 19)
		res = (x & y) ^ ((~x) & z);
	else if (t <= 39)
		res = x ^ y ^ z;
	else if (t <= 59)
		res = (x & y) ^ (x & z) ^ (y & z);
	else if (t <= 79)
		res = x ^ y ^ z;
	else
		res = 0;

	return (res);
}

// Determine the appropriate t-dependent constant value and return it ---------------------------
static UINT32 dwGetK(const BYTE t)
{
	UINT32 K;

	if (t <= 19)
		K = 0x5a827999;
	else if (t <= 39)
		K = 0x6ed9eba1;
	else if (t <= 59)
		K = 0x8f1bbcdc;
	else if (t <= 79)
		K = 0xca62c1d6;
	else
		K = 0;

	return (K);
}
