/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	ASN1pars.c

Description:	Implementation of the Abstract Syntax Notation One parser

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "ASN1pars.h"
#include "ProgFunc.h"

static short firstTime;
static long keylen;
static char *keybuf;

//-------------------------------------------------------------------------------
static long asn1_get_length(unsigned char **pp, long *inf, long *rl, long max)
{
	unsigned char *p = *pp;
	unsigned long ret = 0;
	long i;

	if (max-- < 1)
		return (0);

	if (*p == 0x80) {
		*inf = 1;
		ret = 0;
		p++;
	} else {
		*inf = 0;
		i = (*p) & 0x7f;
		if (*(p++) & 0x80) {
			if (i > sizeof(long) || max-- == 0)
				return (0);

			while (i-- > 0) {
				ret <<= 8L;
				ret |= *(p++);
				if (max-- == 0)
					return (0);
			}
		} else
			ret = i;
	}
	if (ret > MAX_NUM_LEN)
		return (0);

	*pp = p;
	*rl = (long)ret;

	return (1);
}

//-------------------------------------------------------------------------------
static long ASN1_get_object(unsigned char **pp, long *plength, long *ptag, long *pclass, long omax)
{
	long i, ret;
	long l;
	unsigned char *p = *pp;
	long tag, xclass, inf;
	long max = omax;

	if (!max)
		return (0x80);

	ret = (*p & V_ASN1_CONSTRUCTED);
	xclass = (*p & V_ASN1_PRIVATE);
	i = *p & V_ASN1_PRIMITIVE_TAG;
	if (i == V_ASN1_PRIMITIVE_TAG)	// high-tag
	{
		p++;
		if (--max == 0)
			return (0x80);

		l = 0;
		while (*p & 0x80) {
			l <<= 7L;
			l |= *(p++) & 0x7f;
			if (--max == 0 || l > (MAX_NUM_LEN >> 7L))
				return (0x80);
		}
		l <<= 7L;
		l |= *(p++) & 0x7f;
		tag = (long)l;
		if (--max == 0)
			return (0x80);
	} else {
		tag = i;
		p++;
		if (--max == 0)
			return (0x80);
	}
	*ptag = tag;
	*pclass = xclass;
	if (!asn1_get_length(&p, &inf, plength, (long)max))
		return (0x80);

#ifdef WIN32			//--------WIN32-----------

	// Only possible under Windows due to near/far pointer collisions under DOS
#pragma warning(disable : 4311)
	DebugToFile("p=%d + *plength=%ld > omax=%ld + *pp=%d  (%d > %d)\n",
		    (long)p, *plength, omax, (long)*pp, (long)(p + *plength), (long)(omax + *pp));
#pragma warning(default : 4311)

#endif //-------DOS/WIN----------

	if (*plength > (omax - (p - *pp)))
		ret |= 0x80;

	*pp = p;
	return (ret | inf);
}

//-------------------------------------------------------------------------------
static long asn1_parse2(unsigned char **pp, long length, long offset, long depth)
{
	unsigned char *p, *ep, *tot, *op;
	long len, addr;
	long tag, xclass;
	long nl, hl, j, r;

	p = *pp;
	tot = p + length;
	op = p - 1;
	while ((p < tot) && (op < p)) {
		op = p;
		j = ASN1_get_object(&p, &len, &tag, &xclass, length);
		if (j & 0x80) {
			Log("Encoding error !!!\n");
			*pp = p;
			return (0);
		}
DISABLE_WARNING(4244)
		hl = (p - op);
RESTORE_WARNING(4244)
		length -= hl;
		addr = (long)offset + (long)(op - *pp);

		DebugToFile("%5ld:", addr);

		if (j != (V_ASN1_CONSTRUCTED | 1))
			DebugToFile("d=%-2d hl=%ld l=%4ld ", depth, (long)hl, len);
		else
			DebugToFile("d=%-2d hl=%ld l=inf  ", depth, (long)hl);
		if (j & V_ASN1_CONSTRUCTED) {
			ep = p + len;
			DebugToFile("\n");
			if (len > length) {
				DebugToFile("Length is greater than %ld\n", length);
				*pp = p;
				return (0);
			}
			if ((j == 0x21) && (len == 0)) {
				while (TRUE) {
					r = asn1_parse2(&p, (long)(tot - p), offset + (long)(p - *pp), depth + 1);
					if (r == 0) {
						*pp = p;
						return (0);
					}
					if ((r == 2) || (p >= tot))
						break;
				}
			} else
				while (p < ep) {
					r = asn1_parse2(&p, (long)len, offset + (long)(p - *pp), depth + 1);
					if (r == 0) {
						*pp = p;
						return (0);
					}
				}
		} else if (xclass != 0)
			p += len;
		else {
			nl = 0;
			switch (tag) {
			case V_ASN1_BIT_STRING:
				if (firstTime) {
					firstTime = 0;
					keylen = (long)(len - 15);
					keybuf = (char *)(p + 10);

					DebugToFile("\n");
					Log("\nPublic Key from EK Certificate:\n"
					    "  Offset: 0x%04lX (Decimal: %ld)\n"
					    "  Length: %d\n", addr + 10 + 5, addr + 10 + 5, keylen);
					Dump(TG_BOTH, MD_HEX, keybuf, keylen);
				}

			case V_ASN1_PRINTABLESTRING:
			case V_ASN1_T61STRING:
			case V_ASN1_IA5STRING:
			case V_ASN1_VISIBLESTRING:
			case V_ASN1_UTCTIME:
			case V_ASN1_GENERALIZEDTIME:
			case V_ASN1_OBJECT:
			case V_ASN1_BOOLEAN:
			case V_ASN1_BMPSTRING:
			case V_ASN1_OCTET_STRING:
			case V_ASN1_INTEGER:
			case V_ASN1_ENUMERATED:
				break;

			default:
				if (len > 0) {
					if (!nl)
						DebugToFile("\n");
					nl = 1;
				}
			}
			if (!nl)
				DebugToFile("\n");
			p += len;
			if ((tag == V_ASN1_EOC) && (xclass == 0)) {	// End of sequence
				*pp = p;
				return (2);
			}
		}
		length -= len;
	}
	*pp = p;
	return (1);
}

//-------------------------------------------------------------------------------
long ASN1parser(unsigned char *pp, char **key, long len)
{
	DetLogToFile("\n");
	DebugToFile("-> ASN1parser\n");
	firstTime = 1;
	keylen = 0;
	keybuf = NULL;
	asn1_parse2(&pp, len, 0, 0);
	*key = keybuf;
	DebugToFile("<- ASN1parser\n\n");
	return keylen;
}
