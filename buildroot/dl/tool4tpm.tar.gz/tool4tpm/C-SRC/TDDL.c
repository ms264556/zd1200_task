/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TDDL.c

Description:	Implementation of the TPM Device Driver Layer (TDDL)

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "FileIO.h"
#include "ProgFunc.h"
#include "LowLevIO.h"
#include "LPC_Comm.h"
#include "TPM_TIS.h"
#include "TDDL.h"
#include "TPM_Cmds.h"

static TPM_INFO_STRUCTURE sTPMInfo;	// TPM info structure
static TDDL_CAP sTddlCaps;	// TDDL Capabilities structure

/*++
FillCapabilities:

Description:
Fill the TDDL Capabilities structure from the submitted FID-Info
(ReadFID() must have been called before this function is used.)

Arguments:
[in]	TPM_RD_FID_RSP	*psFid	FID info structure

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
#ifndef UEFI_X64
#ifndef TVICDRV
static void FillCapabilities(TPM_RD_FID_RSP * psFid)
{
	BYTE i = 2;
	BYTE j;

	// Fill in driver version info
	sTddlCaps.Ver_Drv.major = 0;
	sTddlCaps.Ver_Drv.minor = 0;
	sTddlCaps.Ver_Drv.revMajor = 5;
	sTddlCaps.Ver_Drv.revMinor = 0;

	// Fill in manufacturer name
	j = 0;
	while (psFid->abDATA[i] != 0x5C) {
		sTddlCaps.Manufacturer[i] = psFid->abDATA[i];
		i++;
		j++;
	}
	sTddlCaps.Size_Manufacturer = j;

	i++;			// Next element: Module type

	// Fill in module type
	j = 0;
	while (psFid->abDATA[i] != 0x5C) {
		sTddlCaps.ModuleType[j] = psFid->abDATA[i];
		i++;
		j++;
	}
	sTddlCaps.Size_ModuleType = j;

	i++;			// Next element: Serial number

	while (psFid->abDATA[i] != 0x5C)
		i++;		// Skip

	i++;			// Next element: FW version

	// Fill in firmware version info (regarding little endian)
	sTddlCaps.Ver_Fw.major = 0;
	sTddlCaps.Ver_Fw.minor = psFid->abDATA[i++];
	sTddlCaps.Ver_Fw.revMajor = 0;
	sTddlCaps.Ver_Fw.revMinor = psFid->abDATA[i++];

	i++;			// Next element: FW version

	// Fill in firmware date info from FID04[25,26 and 27]
	sTddlCaps.FwDate[0] = psFid->abDATA[i++];
	sTddlCaps.FwDate[1] = psFid->abDATA[i++];
	sTddlCaps.FwDate[2] = psFid->abDATA[i++];

	i++;			// Next element: Miscellaneous info, first IFSD

	// Fill in the maximum data size for one transmission block
	sTddlCaps.wIFSD = (psFid->abDATA[i++]) << 8;
	sTddlCaps.wIFSD |= psFid->abDATA[i++];

	i = i + 3;		// Next sub-element: TPM state (skip IF speed)

	// Fill in global state of the firmware
	sTddlCaps.GlobalState = psFid->abDATA[i++];

	i = i + 3;		// Next sub-element: TPM state (skip sub-state, prot. versions)

	// Fill in the ROM CRC of the TPM
	sTddlCaps.wROMCRC = (psFid->abDATA[i++]) << 8;
	sTddlCaps.wROMCRC |= psFid->abDATA[i++];
}
#endif
#endif

/*++
InitTPMInfoStruct

Description:
Initialize the interface parameters of the TPM info structure
with the given configuration data or the default values

Arguments:
none

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INV_FILE_SPEC	file or path not found
	RC_E_INVALID_PARAM	parameter not acceptable

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 InitTPMInfoStruct(void)
{
	UINT32 dwRCVal;

	BYTE abStrValue[MAX_VAL_LEN];
	// Use also for output size returned by GetCfgString(), because size is not needed anyway
	UINT32 dwValue;

	// IO Addresses -----------------------------------------------------------------
	// IO Base Address
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[BASE_ADDRESS]", "IO_BASE", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		sTPMInfo.wTPM_IO_BaseAdr = (UINT16) dwValue;
	else
		sTPMInfo.wTPM_IO_BaseAdr = TPM_IO_BASE;

	// Configuration Base Address
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[BASE_ADDRESS]", "CFG_BASE", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		sTPMInfo.wTPMConfigAdr = (UINT16) dwValue;
	else
		sTPMInfo.wTPMConfigAdr = TPM_CFG_BASE;

	// Timeouts ---------------------------------------------------------------------
	// BWT
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[TIMEOUT]", "BWT", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		sTPMInfo.bTPMBwtTimeOut = (BYTE) dwValue;
	else
		sTPMInfo.bTPMBwtTimeOut = TPM_LPC_BWT;

	// CWT
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[TIMEOUT]", "CWT", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		sTPMInfo.bTPMCwtTimeOut = (BYTE) dwValue;
	else
		sTPMInfo.bTPMCwtTimeOut = TPM_LPC_CWT;

	// Interrupt handling -----------------------------------------------------------
	// Interrupt number
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[INTERRUPT]", "IRQ_NUMBER", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		sTPMInfo.bTPMIrqNr = (BYTE) dwValue;
	else
		sTPMInfo.bTPMIrqNr = TPM_IRQ_NUM;

	// Interrupt control
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[INTERRUPT]", "IRQ_CONTROL", &dwValue);
	if (dwRCVal == RC_SUCCESS)
		sTPMInfo.bTPMIrqCtrl = (BYTE) dwValue;
	else
		sTPMInfo.bTPMIrqCtrl = TPM_IRQ_CTRL;

	// Access mode ------------------------------------------------------------------
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[ACCESS_MODE]", "USE_LEGACY", &dwValue);
#ifdef TVICDRV							//  I/O Access Functions no longer supported since TVic-driver
	if (dwRCVal != RC_SUCCESS)	// parameter is allowed to be absent in this case 
	{
		dwRCVal = RC_SUCCESS;
		dwValue = OFF;
	}
	if (dwRCVal == RC_SUCCESS && dwValue != OFF)	// if parameter exists it must be OFF
	{
		dwValue = OFF;
		Log("USE_LEGACY ignored, using memaccess!\n" );
	}
#endif

	if (dwRCVal == RC_SUCCESS && dwValue == OFF) {
		dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[ACCESS_MODE]", "LOCALITY", &dwValue);
		if (dwRCVal == RC_SUCCESS && dwValue >= LOCALITY_0 && dwValue <= LOCALITY_4)
			sTPMInfo.bTPMLocality = (BYTE) dwValue;
		else
			sTPMInfo.bTPMLocality = LOCALITY_0;
	} else
		sTPMInfo.bTPMLocality = LOCALITY_LEGACY;

	// Startup behaviour ------------------------------------------------------------------
	dwRCVal = GetCfgString(CFG_FILE_NAME, "[TPM_STARTUP]", "ST_TYPE", &dwValue, abStrValue);
	sTPMInfo.wTPMStartupType = TPM_ST_CLEAR; // if the config file doesn't contain a valid value, we do a startup clear
	if (dwRCVal == RC_SUCCESS) {
		if (!strcmp(abStrValue, "TPM_ST_STATE"))
			sTPMInfo.wTPMStartupType = TPM_ST_STATE;
		else if (!strcmp(abStrValue, "TPM_ST_DEACTIVATED"))
			sTPMInfo.wTPMStartupType = TPM_ST_DEACTIVATED;
	}
	// Do startup
	dwRCVal = GetCfgBinaryValue(CFG_FILE_NAME, "[TPM_STARTUP]", "DO_STARTUP", &dwValue);
	if (dwRCVal == RC_SUCCESS) {
		sTPMInfo.bTPMDoStartup = (BYTE) dwValue;
	} else {
		sTPMInfo.bTPMDoStartup = TRUE;	// TPM_Startup will be executed by default
		dwRCVal = RC_SUCCESS;
	}

	return dwRCVal;
}

/*++
LoopTest

Description:
Perform loop test of LPC register

Arguments:
[in]	UINT32          dwRegister			Looptest register address
[in]	BYTE            bData               Looptest data to write
[in]	UINT16          wNumber             Looptest number of cycles
[in]	BYTE            bEvalResponse       Looptest evaluation mode

Return Value:
none

Author:		H. Obermeier	2008/06/18
--*/
void LoopTest(UINT32 dwRegister, BYTE bData, UINT16 wNumber, BOOL bEvalResponse)
{
	UINT16 wLoop = 0;
	BYTE bResponseData;

	Log("Looptest register: 0x%X data: 0x%X number: %d\n", dwRegister, bData, wNumber);
	Log("Looptest evaluate response: %s\n", bEvalResponse ? "TRUE" : "FALSE");
	if (sTPMInfo.bTPMLocality == LOCALITY_LEGACY) {
#ifndef TVICDRV		//  I/O Access Functions no longer supported since TVic-driver
		for (wLoop = 1; wLoop <= wNumber; wLoop++) {
			OutByte((UINT16) dwRegister, bData);
			bResponseData = InpByte((UINT16) dwRegister);
			Log("Looptest current loopcount: %d\n", wLoop);
			if (bEvalResponse) {
				if (bResponseData != bData) {
					Log("Looptest failed: loop counter: %d read value: %d\n", wLoop, bResponseData);
					break;
				}
			}
		}
#else
		Log("Looptest failed: I/O Access Functions no longer supported\n");
#endif
	} else {
		for (wLoop = 1; wLoop <= wNumber; wLoop++) {
			MemAccessWriteByte(dwRegister, bData);
			bResponseData = MemAccessReadByte(dwRegister);
			Log("Looptest current loopcount: %d\n", wLoop);
			if (bEvalResponse) {
				if (bResponseData != bData) {
					Log("Looptest failed: loop counter: %d read value: %d\n", wLoop, bResponseData);
					break;
				}
			}
		}
	}
	if (wLoop > wNumber)
		Log("Looptest succeeded\n");
}

/*++
Read_TPM_FID

Description:
Transmit the Application Protocol Data Unit (APDU) READ_DATA to read the field-identifier FID

Arguments:
[out]	TPM_RD_FID_RSP	*psRdFidRsp			Pointer to Read_TPM_FID response structure
[out]	UINT16			*pwRdFidRspSize		Size of Read_TPM_FID response structure

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_BUFFER2SMALL	buffer size insufficient
	RC_E_INVALID_DATA	TPM sent corrupted data
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_NAKRECEIVED	TPM received corrupted data
	RC_E_NO_MEMORY		not enough memory in Heap available
	RC_E_TIMEOUT		timeout
	RC_E_WTXABORT		command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED	TPM received WTX request

Author:		Markus Schmoelzer	2007/02/23
--*/
#ifndef UEFI_X64
#ifndef TVICDRV
static UINT32 Read_TPM_FID(TPM_RD_FID_RSP * psRdFidRsp, UINT16 * pwRdFidRspSize)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_RD_FID_RQU *psRdFidRqu;

	DebugToFile("\n-> Read_TPM_FID\n");

	do {
		// Initialize the command request structure
		SAFE_CALLOC(psRdFidRqu, sizeof(TPM_RD_FID_RQU), &dwRCVal);

		psRdFidRqu->bVERS = VEND_PROT_VERS;
		psRdFidRqu->bCHA = VEND_PROT_CHA_CTRL;
		// APDU data size is size of psRdFidRqu minus Bytes needed for the Vendor Layer
		psRdFidRqu->dwLEN = dwSwitchEndian32(sizeof(TPM_RD_FID_RQU) - VEND_LAYER_SZ);
		psRdFidRqu->bCLA = READ_DATA_CLA;
		psRdFidRqu->bINS = READ_DATA_INS;
		psRdFidRqu->bDLNG = READ_FID_DATA_LEN;
		psRdFidRqu->bDATA = READ_FID_DATA_TAG;

		DetLogToFile("---------- Read_TPM_FID: Sending:  TxLen = %3d ----------\n", sizeof(TPM_RD_FID_RQU));
		Dump(TG_FILE, MD_HEX, (BYTE *) psRdFidRqu, sizeof(TPM_RD_FID_RQU));
		DetLogToFile("---------------------------------------------------------\n");

		// Send command request and receive command response
		dwRCVal = TPM_Transceive(&sTPMInfo,
					 (BYTE *) psRdFidRqu, sizeof(TPM_RD_FID_RQU), (BYTE *) psRdFidRsp, pwRdFidRspSize);

		DetLogToFile("---------- Read_TPM_FID: Received: RxLen = %3d ----------\n", *pwRdFidRspSize);
		if (*pwRdFidRspSize) {
			Dump(TG_FILE, MD_HEX, (BYTE *) psRdFidRsp, *pwRdFidRspSize);
			DetLogToFile("---------------------------------------------------------\n");
		}
	} while (FALSE);

	SAFE_FREE(psRdFidRqu);	// Free command request structure

	DebugToFile("<- Read_TPM_FID\n\n");

	return dwRCVal;
}
#endif
#endif

#ifndef UEFI_X64
#ifndef TVICDRV		//  I/O Access Functions no longer supported since TVic-driver
/*++
Open_IO_Connection

Description:
Open the I/O communication channel to the TPM

Arguments:
none

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 Open_IO_Connection(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_RD_FID_RSP *psRdFidRx;
	BYTE bTimeOut;
	UINT16 wRxLen;

	DebugToFile("\n-> Open_IO_Connection");

	do {
		SAFE_CALLOC(psRdFidRx, sizeof(TPM_RD_FID_RSP), &dwRCVal);

		bTimeOut = sTPMInfo.bTPMBwtTimeOut;
		wRxLen = sizeof(TPM_RD_FID_RSP);

		Log("\nInitialize TPM...\n");

		// Clear the loop bit
		dwRCVal = TPM_CMD_RegAccess(sTPMInfo.wTPM_IO_BaseAdr, TPM_CMD_LP, OFF);
		if (dwRCVal != RC_SUCCESS)
			break;

		// If there is an interrupt number then enable it
		if (sTPMInfo.bTPMIrqNr > 0)
			dwRCVal = TPM_CMD_RegAccess(sTPMInfo.wTPM_IO_BaseAdr, TPM_CMD_DIS, OFF);
		else
			dwRCVal = TPM_CMD_RegAccess(sTPMInfo.wTPM_IO_BaseAdr, TPM_CMD_DIS, ON);

		if (dwRCVal != RC_SUCCESS)
			break;

		// Wait for FW ready
		do {
			if (TPM_ReadStatusReg(sTPMInfo.wTPM_IO_BaseAdr) & TPM_STAT_FOK) {
				Sleep_ms(100);
				bTimeOut--;
			} else
				break;
		} while (bTimeOut > 0);

		if (TPM_ReadStatusReg(sTPMInfo.wTPM_IO_BaseAdr) & TPM_STAT_RDA)
			TPM_ClearFIFO(&sTPMInfo);

		// Read FID
		dwRCVal = Read_TPM_FID(psRdFidRx, &wRxLen);
		if (dwRCVal == RC_SUCCESS) {
			if ((psRdFidRx->bCHA) == VEND_PROT_CHA_CTRL)
				FillCapabilities(psRdFidRx);
			else
				dwRCVal = RC_E_FAILURE;
		}
	} while (FALSE);

	SAFE_FREE(psRdFidRx);

	DebugToFile("<- Open_IO_Connection\n\n");

	return dwRCVal;
}
#endif
#endif

/*++
TDDL_Open

Description:
Connect to the TPM

Arguments:
none

Return Value:

	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INV_FILE_SPEC		file or path not found
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TDDL_Open(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	BOOL bFlag;
	UINT16 wVendorID, wDeviceID;
	BYTE *pbResp = NULL;
	BYTE bTPM_Startup[] = TPM_STARTUP_CLEAR;
	UINT32 dwRespSize;
	UINT16 wTemp;

	DebugToFile("\n-> TDDL_Open");

	DetLogToFile("\nConnecting to TPM...\n");

	do {
		// Initialize global TPM info structure
		dwRCVal = InitTPMInfoStruct();
		if (dwRCVal != RC_SUCCESS)
			break;

		LowLevelInit(sTPMInfo.bTPMLocality);
#if USE_DRIVER == 2
		Log("\n\tUsing Linux TPM driver access routines\n");
		bChipDetected = TPM1_2;
#else
		if (sTPMInfo.bTPMLocality == LOCALITY_LEGACY) {
 #ifndef TVICDRV		// No legacy / port access since Tvicdrv
			Log("\nUsing I/O access routines");
			Log("\nLooking for Infineon TPM device at the LPC Bus...\n");
			Sleep_ms(500);

			dwRCVal = TPM_CheckDefaultConfig(sTPMInfo.wTPMConfigAdr);
			if (dwRCVal != RC_SUCCESS) {
				Log("Warning: No Infineon TPM found at 0x%.4X config address space\n",
				    sTPMInfo.wTPMConfigAdr);

				if (sTPMInfo.wTPMConfigAdr == TPM_CFG_BASE)
					sTPMInfo.wTPMConfigAdr = TPM_CFG_BASE_ALT;
				else
					sTPMInfo.wTPMConfigAdr = TPM_CFG_BASE;

				// Check alternative configuration address
				dwRCVal = TPM_CheckDefaultConfig(sTPMInfo.wTPMConfigAdr);
				if (dwRCVal != RC_SUCCESS) {
					Log("Warning: No Infineon TPM found at 0x%.4X config address space\n",
					    sTPMInfo.wTPMConfigAdr);
					break;
				}
			}

			Log("Infineon TPM found at 0x%.4X config address space\n", sTPMInfo.wTPMConfigAdr);

			switch (bChipDetected) {
			case TPM1_1:
				Log("Chip ID: 0x%.2X, TPM 1.1B found\n", bChipDetected);
				break;
			case TPM1_2:
				Log("Chip ID: 0x%.2X, TPM 1.2 found\n", bChipDetected);
				break;
			default:
				Log("Chip ID: 0x%.2X, unknown TPM version !!!\n", bChipDetected);
				dwRCVal = RC_E_FAILURE;
			}

			if (dwRCVal != RC_SUCCESS)
				break;

			Log("Using Configuration Base Address 0x%.2X and IO Base Address 0x%04X\n", sTPMInfo.wTPMConfigAdr,
			    sTPMInfo.wTPM_IO_BaseAdr);

			TPM_ON_OFF_Data(sTPMInfo.wTPMConfigAdr, ON);
			TPM_Set_IO_BaseAdr(sTPMInfo.wTPMConfigAdr, sTPMInfo.wTPM_IO_BaseAdr);
			TPM_SetIRQ(sTPMInfo.wTPMConfigAdr, sTPMInfo.bTPMIrqNr, sTPMInfo.bTPMIrqCtrl);
			TPM_SetDAR(sTPMInfo.wTPMConfigAdr, ON);
			TPM_ON_OFF_Data(sTPMInfo.wTPMConfigAdr, OFF);

			// Init TPM and open communication channel
			dwRCVal = Open_IO_Connection();
			if (dwRCVal != RC_SUCCESS)
				break;
  #endif 
		} else {

			Log("\n\tUsing memory access routines\n");
			Log("\tUsing Locality: %d\n", sTPMInfo.bTPMLocality);

			// Check the presence of a TPM first
			// Check whether TPM.ACCESS.VALID
			dwRCVal = TIS_IsAccessValid(sTPMInfo.bTPMLocality, &bFlag);
			if (dwRCVal != RC_SUCCESS)
				break;

			if (!bFlag) {
				dwRCVal = RC_E_NOT_READY;
				break;
			}
			// Read Vendor ID and check whether its IFX
			dwRCVal = TIS_GetVendorID(&wVendorID);
			if (dwRCVal != RC_SUCCESS)
				break;

			if (wVendorID != TIS_TPM_VID_IFX) {
				dwRCVal = RC_E_COMPONENT_NOT_FOUND;
				Log("No TPM found or unknown TPM version !!!\n");
				break;
			}
			// Read Device ID and check whether its TPM12
			dwRCVal = TIS_GetDeviceID(&wDeviceID);
			if (dwRCVal != RC_SUCCESS)
				break;

			DebugToFile("Vendor/Device ID %04x/%04x\n",wVendorID,wDeviceID);

			bChipDetected = TPM1_2;

		}
#endif // USE_DRIVER == 2
		// Perform a TPM Startup per the config file setting
		if (sTPMInfo.bTPMDoStartup) {
			dwRespSize = 10;
			SAFE_CALLOC(pbResp, 10, &dwRCVal);
			wTemp = (sTPMInfo.wTPMStartupType >> 8) + (sTPMInfo.wTPMStartupType << 8);
			memcpy(&bTPM_Startup[10], &wTemp, sizeof(UINT16));
			// Transmit the TPM_StartupClear
			dwRCVal = TDDL_TransmitData(&bTPM_Startup[0], sizeof(bTPM_Startup), pbResp, &dwRespSize);
		}

	} while (FALSE);

	SAFE_FREE(pbResp);

	if (dwRCVal == RC_SUCCESS)
		DetLogToFile("\nConnected to TPM\n");

	DebugToFile("<- TDDL_Open\n\n");

	if (bDebug)
		Sleep_ms(100);

	return dwRCVal;
}

/*++
TDDL_Close

Description:
Disconnect from the TPM

Arguments:
none

	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TDDL_Close(void)
{
	UINT32 dwRCVal = RC_SUCCESS;

	DebugToFile("\n-> TDDL_Close");

	DetLogToFile("\nDisconnecting from TPM...\n");
#if USE_DRIVER != 2
	if (sTPMInfo.bTPMLocality == LOCALITY_LEGACY) {
  #ifndef TVICDRV		//  I/O Access Functions no longer supported since TVic-driver
		// Disable the interrupt
		dwRCVal = TPM_CMD_RegAccess(sTPMInfo.wTPM_IO_BaseAdr, TPM_CMD_DIS, ON);
		if (dwRCVal == RC_SUCCESS) {
			// Clear the loop bit
			dwRCVal = TPM_CMD_RegAccess(sTPMInfo.wTPM_IO_BaseAdr, TPM_CMD_LP, OFF);
			if (dwRCVal == RC_SUCCESS) {
				TPM_ON_OFF_Data(sTPMInfo.wTPMConfigAdr, ON);
				TPM_SetDAR(sTPMInfo.wTPMConfigAdr, OFF);
				TPM_SetIRQ(sTPMInfo.wTPMConfigAdr, TPM_IRQ_NUM, TPM_IRQ_CTRL);
				TPM_Set_IO_BaseAdr(sTPMInfo.wTPMConfigAdr, 0);
			}
		}
		TPM_ON_OFF_Data(sTPMInfo.wTPMConfigAdr, OFF);
  #endif
	}
#endif
	LowLevelUninit(sTPMInfo.bTPMLocality);

	if (dwRCVal == RC_SUCCESS)
		DetLogToFile("\nDisconnected from TPM\n");

	DebugToFile("<- TDDL_Close\n");

	return dwRCVal;
}

/*++
TDDL_TransmitData

Description:
Send the TPM Application Protocol Data Unit (APDU) to the TPM and return the response APDU

Arguments:
[in]		BYTE	*pbTransmitBuf		Transmit data buffer
[in]		UINT32	dwTransmitBufLen	Transmit data buffer size
[out]		BYTE	*pbReceiveBuf		Receive data buffer
[in/out]	UINT32	*pdwReceiveBufLen	Receive data buffer size

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_BUFFER2SMALL	buffer size insufficient
	RC_E_INVALID_DATA	TPM sent corrupted data
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_NAKRECEIVED	TPM received corrupted data
	RC_E_NO_MEMORY		not enough memory in Heap available
	RC_E_TIMEOUT		timeout
	RC_E_WTXABORT		command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED	TPM received WTX request

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TDDL_TransmitData(BYTE * pbTransmitBuf, UINT32 dwTransmitBufLen, BYTE * pbReceiveBuf, UINT32 * pdwReceiveBufLen)
{
	UINT32 dwRCVal = RC_E_FAILURE;

#ifndef TVICDRV
	BYTE *pbTxApdu, *pbRxApdu;
	UINT16 wRxLen, wTxLen;
#endif

	do {
		DetLogToFile("------- TDDL_TransmitData: Sending:  TxLen = %4d -------\n", dwTransmitBufLen);
		Dump(TG_FILE, MD_HEX, pbTransmitBuf, dwTransmitBufLen);
		DetLogToFile("---------------------------------------------------------\n");

#if USE_DRIVER == 2
		dwRCVal = TpmTransmit(pbTransmitBuf, dwTransmitBufLen, pbReceiveBuf, pdwReceiveBufLen);
		if (dwRCVal != RC_SUCCESS) {
			Log("Transmission of data via Linux TPM Driver failed !!!\n");
			break;
		}
#else
		if (sTPMInfo.bTPMLocality == LOCALITY_LEGACY) {
  #ifndef TVICDRV		//  I/O Access Functions no longer supported since TVic-driver
			// Check the size of the command including the Vendor Layer
			wTxLen = (UINT16) (dwTransmitBufLen + VEND_LAYER_SZ);
			if (wTxLen > sTddlCaps.wIFSD) {
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			}
			// Build the command and response buffer
			wRxLen = sTddlCaps.wIFSD;
			pbTxApdu = malloc((size_t) wTxLen);
			pbRxApdu = malloc((size_t) wRxLen);
			if (pbTxApdu == NULL || pbRxApdu == NULL) {
				dwRCVal = RC_E_NO_MEMORY;
				SAFE_FREE(pbTxApdu);
				SAFE_FREE(pbRxApdu);
				break;
			}
			// Create Vendor Layer of the LPC Protocol
			pbTxApdu[0] = VEND_PROT_VERS;
			pbTxApdu[1] = VEND_PROT_CHA_TPM;
			pbTxApdu[2] = (BYTE) (dwTransmitBufLen >> 24);	// Endian conversion is...
			pbTxApdu[3] = (BYTE) (dwTransmitBufLen >> 16);	// ...taken into account while...
			pbTxApdu[4] = (BYTE) (dwTransmitBufLen >> 8);	// ...concatenating command...
			pbTxApdu[5] = (BYTE) dwTransmitBufLen;	// ...length to transmit buffer.
			memcpy((pbTxApdu + VEND_LAYER_SZ), pbTransmitBuf, (size_t) dwTransmitBufLen);

			// Send the command and receive the response
			dwRCVal = TPM_Transceive(&sTPMInfo, pbTxApdu, wTxLen, pbRxApdu, &wRxLen);
			if (dwRCVal != RC_SUCCESS) {
				SAFE_FREE(pbTxApdu);
				SAFE_FREE(pbRxApdu);
				break;
			}

			if ((wRxLen - VEND_LAYER_SZ) > (UINT16) (*pdwReceiveBufLen)) {
				SAFE_FREE(pbTxApdu);
				SAFE_FREE(pbRxApdu);
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			}
			// Return received data length
			*pdwReceiveBufLen = wRxLen - VEND_LAYER_SZ;

			// Return the TPM response
			memcpy(pbReceiveBuf, (pbRxApdu + VEND_LAYER_SZ), (size_t) (wRxLen - VEND_LAYER_SZ));

			SAFE_FREE(pbTxApdu);
			SAFE_FREE(pbRxApdu);
  #endif
		} else {
			dwRCVal = TIS_TransceiveLPC(sTPMInfo.bTPMLocality,
						    pbTransmitBuf,
						    (UINT16) dwTransmitBufLen, pbReceiveBuf, (UINT16 *) pdwReceiveBufLen);

			if (dwRCVal != RC_SUCCESS) {
				Log("Transmission of data via TIS failed !!!\n");
				break;
			}
		}
#endif //USE_DRIVER == 2

		DetLogToFile("------- TDDL_TransmitData: Received: RxLen = %4d -------\n", *pdwReceiveBufLen);
		if (*pdwReceiveBufLen) {
			Dump(TG_FILE, MD_HEX, pbReceiveBuf, *pdwReceiveBufLen);
			DetLogToFile("---------------------------------------------------------\n");
		}
	} while (FALSE);
	if (dwRCVal != RC_SUCCESS)
		DetLogToFile("-------- TDDL_TransmitData: Operation failed !!! --------\n");

	return dwRCVal;
}

/*++
TDDL_GetCapability:

Description:
Return the requested capability of the TPM or the driver
(FillCapabilities() must have been called before this function is used.)

Arguments:
[in]		UINT32	dwCapArea			Capability area
[in]		UINT32	dwSubCap			Sub capability
[out]		BYTE	*pbReceiveBuf		Receive data buffer
[in/out]	UINT32	*pdwReceiveBufLen	Receive data buffer size

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_PARAM		wrong parameters

Author:		Markus Schmoelzer	2007/02/23
--*/
DISABLE_OPTIMIZATION	// because of memcpy optimization of loops 
UINT32 UNOPTIMIZED TDDL_GetCapability(UINT32 dwCapArea, UINT32 dwSubCap, BYTE * pbReceiveBuf, UINT32 * pdwReceiveBufLen)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE i;

	if (sTPMInfo.bTPMLocality == LOCALITY_LEGACY) {
		switch (dwCapArea) {
		case TDDL_CAP_VERSION:
			switch (dwSubCap) {
			case TDDL_CAP_VER_DRV:
				if (sizeof(sTddlCaps.Ver_Drv) > *pdwReceiveBufLen) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				pbReceiveBuf[0] = sTddlCaps.Ver_Drv.major;
				pbReceiveBuf[1] = sTddlCaps.Ver_Drv.minor;
				pbReceiveBuf[2] = sTddlCaps.Ver_Drv.revMajor;
				pbReceiveBuf[3] = sTddlCaps.Ver_Drv.revMinor;
				*pdwReceiveBufLen = 4;

				dwRCVal = RC_SUCCESS;
				break;

			case TDDL_CAP_VER_FW:
				if (sizeof(sTddlCaps.Ver_Fw) > *pdwReceiveBufLen) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				pbReceiveBuf[0] = sTddlCaps.Ver_Fw.major;
				pbReceiveBuf[1] = sTddlCaps.Ver_Fw.minor;
				pbReceiveBuf[2] = sTddlCaps.Ver_Fw.revMajor;
				pbReceiveBuf[3] = sTddlCaps.Ver_Fw.revMinor;
				*pdwReceiveBufLen = 4;

				dwRCVal = RC_SUCCESS;
				break;

			case TDDL_CAP_VER_FW_DATE:
				if (sizeof(sTddlCaps.FwDate) > *pdwReceiveBufLen) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				pbReceiveBuf[0] = sTddlCaps.FwDate[0];
				pbReceiveBuf[1] = sTddlCaps.FwDate[1];
				pbReceiveBuf[2] = sTddlCaps.FwDate[2];
				*pdwReceiveBufLen = 3;

				dwRCVal = RC_SUCCESS;
				break;

			case TDDL_CAP_VER_ROM_CRC:
				if (sizeof(sTddlCaps.wROMCRC) > *pdwReceiveBufLen) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				pbReceiveBuf[0] = (BYTE) ((sTddlCaps.wROMCRC) >> 8);
				pbReceiveBuf[1] = (BYTE) (sTddlCaps.wROMCRC);
				*pdwReceiveBufLen = 2;

				dwRCVal = RC_SUCCESS;
				break;

			default:
				dwRCVal = RC_E_INVALID_PARAM;
			}
			break;

		case TDDL_CAP_PROPERTY:
			switch (dwSubCap) {
			case TDDL_CAP_PROP_MANUFACTURER:
				if (sTddlCaps.Size_Manufacturer > *pdwReceiveBufLen) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				for (i = 0; i < 8; i++)
					pbReceiveBuf[i] = sTddlCaps.Manufacturer[i];

				*pdwReceiveBufLen = sTddlCaps.Size_Manufacturer;

				dwRCVal = RC_SUCCESS;
				break;

			case TDDL_CAP_PROP_MODULE_TYPE:
				if (sTddlCaps.Size_ModuleType > *pdwReceiveBufLen) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				for (i = 0; i < sTddlCaps.Size_ModuleType; i++)
					pbReceiveBuf[i] = sTddlCaps.ModuleType[i];

				*pdwReceiveBufLen = sTddlCaps.Size_ModuleType;

				dwRCVal = RC_SUCCESS;
				break;

			case TDDL_CAP_PROP_GLOBAL_STATE:
				if (*pdwReceiveBufLen < 1) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				*pbReceiveBuf = sTddlCaps.GlobalState;
				*pdwReceiveBufLen = sizeof(sTddlCaps.GlobalState);
				dwRCVal = RC_SUCCESS;
				break;

			case TDDL_CAP_PROP_IFSD:
				if (*pdwReceiveBufLen < 2) {
					dwRCVal = RC_E_BUFFER2SMALL;
					break;
				}

				pbReceiveBuf[0] = (BYTE) ((sTddlCaps.wIFSD) >> 8);
				pbReceiveBuf[1] = (BYTE) (sTddlCaps.wIFSD);
				*pdwReceiveBufLen = 2;
				dwRCVal = RC_SUCCESS;
				break;

			default:
				dwRCVal = RC_E_INVALID_PARAM;
			}
			break;

		default:
			dwRCVal = RC_E_INVALID_PARAM;
		}
	}

	return dwRCVal;
}
ENABLE_OPTIMIZATION
