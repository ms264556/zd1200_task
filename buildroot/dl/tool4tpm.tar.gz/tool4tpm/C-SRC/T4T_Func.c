/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Menu.c

Description:	Implementation of the Tool4TPM menu

Author:			Viktor Wallner	2013/03/12

Environment:	16-Bit DOS, 32-Bit/64-Bit Windows, 32-Bit/64-Bit Linux/ARM, 64-Bit UEFI

Revision History:

Notes:

--*/

#include "ASN1pars.h"
#include "Console.h"
#include "FileIO.h"
#include "ProgFunc.h"
#include "TPM_Cmds.h"
#include "TPM_Func.h"
#include "Sealtest.h"
#include "T4T_Func.h"

#if !defined _DEBUG && defined TOOL4TPM_TEST
#pragma message ("!! Release with TPM_TEST-features !!")
#endif

/*++
PollMenu

Description:
Execute the menu driven TPM evaluation

Arguments:
[in/out]	BYTE	bCycle		Step-by-step indicator

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 PollMenu(BYTE bCycle)
{
	UINT32 dwRCVal = RC_SUCCESS;
#ifdef UEFI_X64
	char cMenuSel = '0';
#else
	signed short cMenuSel = '0';
#endif


	do {
		ClrScr();
		ShowMenu();

		do {
			init_keyboard();

			cMenuSel = WaitForKey();
			if ((cMenuSel == 0xe0) || (cMenuSel == 0x5b) || (cMenuSel == 0x00)) { 
				// Arrow key was pressed - reported as two key strokes. 
				// Return codes for arrow keys are 0xe0 on Windows 0x5b on Linux, 0x00 on Dos
				FlushInputBuffer(); // flush the input buffer to get rid of the second keystroke
			}
			close_keyboard();
#ifndef TOOL4TPM_TEST
DISABLE_WARNING(4244)
			cMenuSel = toupper(cMenuSel);
RESTORE_WARNING(4244)
#endif //TOOL4TPM_TEST
		} while ((cMenuSel < 'A' || cMenuSel > 'Z') &&
			 (cMenuSel < 'a' || cMenuSel > 'z') && (cMenuSel < '1' || cMenuSel > '9'));

		if (cMenuSel != 'Q' && cMenuSel != 'q') {
			init_keyboard();
			do {
				dwRCVal = RC_SUCCESS;
				ClrScr();

				dwRCVal = MenuSelect(cMenuSel, bCycle);	// Select and process the menu item
				if (dwRCVal != RC_SUCCESS)
					PrintErrorMessage(dwRCVal);

				//Sleep_ms(250);
			} while (bCycle && dwRCVal == RC_SUCCESS && !ESC_IS_PRESSED);
			close_keyboard();
			Log("\n");
			WaitForAnyKey();
		}

	} while (cMenuSel != 'Q' && cMenuSel != 'q');
	ClrScr();

	return dwRCVal;
}

/*++
MenuSelect

Description:
Process the the select item in menu driven TPM evaluation

Arguments:
[in]		short	cMenuSel	Menu selection
[in/out]	BYTE	bCycle		Step-by-step indicator

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 MenuSelect(short cMenuSel, BYTE bCycle)
{
#define RANDOMSIZE 20

	UINT32 dwRCVal = RC_SUCCESS;

	BYTE i, flag;
	BYTE bSha1TestValue[HASH_LEN], bSha1TestVector[] = SHA1_TEST_VALUE;
	BYTE bTestResult[ST_EL_SML_SZ];
	UINT32 dwSize, dwCount;
	UINT32 dwKeyLen = 0, dwCertSize = 0;
	UINT32 dwGetRandomSize;
	BYTE bGetRandom[RANDOMSIZE];
	BYTE *pbCert = NULL, *pbHashData = NULL, *pbKey = NULL;
	char *pCertKey = NULL;
	long cnt;
	long klen;

	switch (cMenuSel) {
//-------------------------------------------------------------------------------
	case MENU_1_ENABLE_CMD_SET_PP:
		Log("\n\nEnable Physical Presence TPM Command\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwRCVal = TSC_PhysicalPresence(0);
		else
#endif // TOOL4TPM_TEST
			dwRCVal = TSC_PhysicalPresence(TPM_PHYSICAL_PRESENCE_CMD_ENABLE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tPhysical Presence TPM Command enabled\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_2_ENABLE_HARDWARE_SIGNAL_PP:
		Log("\n\nEnable Physical Presence TPM Hardware Signal\n");
		dwRCVal = TSC_PhysicalPresence(TPM_PHYSICAL_PRESENCE_HW_ENABLE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tPhysical Presence TPM Hardware Signal enabled\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_3_SET_PP:
		Log("\n\nSet Physical Presence\n");
		dwRCVal = TSC_PhysicalPresence(TPM_PHYSICAL_PRESENCE_PRESENT);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tPhysical Presence set\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_4_CLEAR_PP:
		Log("\n\nClear Physical Presence\n");
		dwRCVal = TSC_PhysicalPresence(TPM_PHYSICAL_PRESENCE_NOTPRESENT);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tPhysical Presence cleared\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_5_LOCK_PP:
		Log("\n\nLock Physical Presence TPM configuration until next reboot\n");
		dwRCVal = TSC_PhysicalPresence(TPM_PHYSICAL_PRESENCE_LOCK);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tPhysical Presence TPM configuration locked\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_6_ENABLE_TPM:
		Log("\n\nEnable TPM\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFF);
		else
#endif // TOOL4TPM_TEST
			dwRCVal = TPM_SimpleCommand(TPM_ORD_PhysicalEnable);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM enabled under Physical Presence\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_7_DISABLE_TPM:
		Log("\n\nDisable TPM\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFF);
		else
#endif // TOOL4TPM_TEST
			dwRCVal = TPM_SimpleCommand(TPM_ORD_PhysicalDisable);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM disabled under Physical Presence\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_8_ACTIVATE_TPM:
		Log("\n\nActivate TPM\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwRCVal = TPM_PhysicalSetDeactivated(0xFF);
		else
#endif // TOOL4TPM_TEST
			dwRCVal = TPM_PhysicalSetDeactivated(OFF);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM_SetDeactivate flag cleared\n" "\tPlease reboot the system to complete the operation\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_9_DEACTIVATE_TPM:
		Log("\n\nDeactivate TPM\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwRCVal = TPM_PhysicalSetDeactivated(0xFF);
		else
#endif // TOOL4TPM_TEST
			dwRCVal = TPM_PhysicalSetDeactivated(ON);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM_SetDeactivate flag set\n" "\tPlease reboot the system to complete the operation\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_C_CLEAR_OWNER_UNDER_PP:
		Log("\n\nClear TPM Ownership under Physical Presence\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFF);
		else
#endif // TOOL4TPM_TEST
			dwRCVal = TPM_SimpleCommand(TPM_ORD_ForceClear);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM Ownership cleared under Physical Presence\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_O_TAKE_OWNER_WITH_PASSWORD:
		Log("\n\nTake TPM Ownership\n");
		dwRCVal = TakeOwnership();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM Ownership taken\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_P_READ_PUBLIC_EK:
		dwKeyLen = KEY_LEN;

		Log("\n\nRead Public EK\n");
		if (bNegativeTest)
			dwKeyLen = 0;

		if (CALLOC(pbKey, KEY_LEN)) {
			dwRCVal = TPM_ReadPubek(&dwKeyLen, pbKey);
		}
		else {
			dwRCVal = RC_E_NO_MEMORY;
			break;
		}
		if (dwRCVal == RC_SUCCESS && dwKeyLen > 0) {
			Log("\nPublic EK:\n");
			Dump(TG_BOTH, MD_HEX, pbKey, dwKeyLen);
			if (!bCycle) {
				SaveToFile(B_EK_FILE_NAME, pbKey, dwKeyLen, MD_BIN);
				SaveToFile(H_EK_FILE_NAME, pbKey, dwKeyLen, MD_HEX);
				Log("\n\tPublic EK saved to \"%s\" (binary) and \"%s\" (hex)\n",
				    B_EK_FILE_NAME, H_EK_FILE_NAME);
			}
		} else
			Log("\n\tOperation TPM_ReadPubek failed !!!\n");

		SAFE_FREE(pbKey);
		break;
//-------------------------------------------------------------------------------
	case MENU_E_READ_EK_CERTIFICATE:
		Log("\n\nRead EK Certificate\n");

		if (CALLOC(pbCert, MAX_CERT_SIZE)) {
			dwRCVal = ReadEKCertificate(pbCert, &dwCertSize);
		}
		else {
			dwRCVal = RC_E_NO_MEMORY;
			break;
		}
		if (dwRCVal == RC_SUCCESS && dwCertSize > 0) {
			DetLogToFile("EK Certificate:\n");
			Dump(TG_FILE, MD_HEX, pbCert, dwCertSize);
			ASN1parser(pbCert, &pCertKey, dwCertSize);
			if (!bCycle) {
				SaveToFile(CERT_FILE_NAME, pbCert, dwCertSize, MD_BIN);
				Log("\n\tEK Certificate saved to \"%s\"\n", CERT_FILE_NAME);
			}
		} else
			Log("\n\tOperation TPM_ReadEKCertificate failed !!!\n");

		SAFE_FREE(pbCert);
		break;
//-------------------------------------------------------------------------------
	case MENU_F_READ_COMPARE_PUBLIC_EKS:
		dwKeyLen = KEY_LEN;
		dwCertSize = MAX_CERT_SIZE;

		Log("\n\nRead and compare Public EKs\n");
		if (CALLOC(pbCert, MAX_CERT_SIZE) && CALLOC(pbKey, KEY_LEN)) {
			dwRCVal = TPM_ReadPubek(&dwKeyLen, pbKey);
		}
		else {
			dwRCVal = RC_E_NO_MEMORY;
			break;
		}
		if (dwRCVal == RC_SUCCESS) {
			if (dwKeyLen) {
				Log("\nPublic EK:\n");
				Dump(TG_BOTH, MD_HEX, pbKey, dwKeyLen);
			}
			Log("\n");
			dwRCVal = ReadEKCertificate(pbCert, &dwCertSize);
			if (dwRCVal == RC_SUCCESS) {
				klen = ASN1parser(pbCert, &pCertKey, dwCertSize);
				for (cnt = 0; cnt < (klen) - 1; cnt++)
					if ((BYTE) (pCertKey[cnt]) != pbKey[cnt])
						break;
				if (cnt == (klen) - 1)
					Log("\n\tPublic EKs match\n");
				else {
					Log("\n\tPublic EKs mismatch at 0x%.4X !\n", cnt);
					dwRCVal = RC_E_FAILURE;
				}
			} else
				Log("\n\tOperation TPM_ReadEKCertificate failed !!!\n");
		} else
			Log("\n\tOperation TPM_ReadPubek failed !!!\n");

		SAFE_FREE(pbCert);
		SAFE_FREE(pbKey);
		break;
//-------------------------------------------------------------------------------
#ifdef TOOL4TPM_TEST
	case MENU_K_CREATE_EKS:
		Log("\n\nCreate EK pair\n");
		dwRCVal = CreateEndorsementKeyPair();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tCreate EK pair completed successfully\n");
		break;
#endif //TOOL4TPM_TEST
//-------------------------------------------------------------------------------
	case MENU_I_TPM_INFORMATION:
		// Read Chip Info
		if (bChipDetected == TPM1_1)
			dwRCVal = ShowTPM11info();
		if (bChipDetected == TPM1_2)
			dwRCVal = ShowTPM12info();
		break;
//-------------------------------------------------------------------------------
#ifdef TOOL4TPM_TEST
	case MENU_Y_TPM_SET_CAPABILITY_W_AUTH:
		Log("\n\nTPM set capability with authorization\n");
		dwRCVal = SetCapability(TRUE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tSet TPM capability completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_J_TPM_SET_CAPABILITY_WO_AUTH:
		Log("\n\nTPM set capability without authorization\n");
		dwRCVal = SetCapability(FALSE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tSet TPM capability completed successfully\n");
		break;
#endif //TOOL4TPM_TEST
//-------------------------------------------------------------------------------
	case MENU_T_FULL_SELFTEST:
		Log("\n\nPerform full TPM selftest\n");
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFFFFFFFF);
		else
			dwRCVal = TPM_SimpleCommand(TPM_ORD_SelfTestFull);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tFull TPM selftest completed successfully\n");
		break;
//-------------------------------------------------------------------------------
#ifdef TOOL4TPM_TEST
	case MENU_L_TPM_CONTINUE_SELF_TEST:
		Log("\n\nTPM continue self test\n");
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFFFFFFFF);
		else
			dwRCVal = TPM_SimpleCommand(TPM_ORD_ContinueSelfTest);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM continue self test completed successfully\n");
		break;
#endif //TOOL4TPM_TEST
//-------------------------------------------------------------------------------
	case MENU_R_GET_TESTRESULTS:
		Log("\n\nGet test results of the TPM_SelfTestFull\n");
		if (bNegativeTest)
			dwSize = 1;
		else
			dwSize = sizeof(bTestResult);
		dwRCVal = TPM_GetTestResult(&dwSize, &bTestResult[0]);
		if (dwRCVal == RC_SUCCESS) {
			Log("\tTPM_GetTestResult returned the TPM test state: ");
			for (dwCount = 0; dwCount < dwSize; dwCount++) {
				Log("%.2X", bTestResult[dwCount]);
			}
			Log("\n\n");
		} else
			Log("\n\tOperation TPM_GetTestResult failed !!!\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_S_SHA1_TEST:
		Log("\n\nSHA-1 test with %d Bytes of data:\n", MAX_HASH_DATA);
		if (CALLOC(pbHashData, MAX_HASH_DATA)) {
			// Create Hash input data
			for (cnt = 0; cnt < MAX_HASH_DATA; cnt++)
				pbHashData[cnt] = (BYTE) (cnt & 0xFF);
			dwRCVal = SHA1test(MAX_HASH_DATA, pbHashData, bSha1TestValue);
		}
		else {
			dwRCVal = RC_E_NO_MEMORY;
			break;
		}
		if (dwRCVal == RC_SUCCESS) {
			// Print the result and compare SHA-1 result
			Log("\nSHA-1 operation completed, hash value:\n\t");
			flag = 0;
			for (i = 0; i < 20; i++) {
				Log("%.2X ", bSha1TestValue[i]);
				if (bSha1TestVector[i] != bSha1TestValue[i])
					flag = i + 1;
			}
			Log("\n");
			if (flag > 0) {
				Log("\nIncorrect SHA-1 operation result, must be:\n\t");
				for (i = 0; i < 20; i++)
					Log("%.2X ", bSha1TestVector[i]);
				Log("\n");
			} else
				Log("\nSHA-1 operation result is correct\n");
		} else
			Log("\n\tOperation SHA1test failed !!!\n");

		SAFE_FREE(pbHashData);
		break;
//-------------------------------------------------------------------------------
	case MENU_A_READ_SHOW_TICKCOUNTER:
		Log("\n\nTPM get ticks\n");
		dwRCVal = GetTicks();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM get ticks completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_B_SAFE_STATE_TO_NVM:
		Log("\n\nTPM save state\n");
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFFFFFFFF);
		else
			dwRCVal = TPM_SimpleCommand(TPM_ORD_SaveState);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM save state completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_G_GET_RANDOM_NUMBER:
		Log("\n\nTPM get random\n");
#ifdef TOOL4TPM_TEST
		if (bNegativeTest)
			dwGetRandomSize = 0;
		else
#endif // TOOL4TPM_TEST
			dwGetRandomSize = RANDOMSIZE;
		dwRCVal = TPM_GetRandom(&dwGetRandomSize, bGetRandom);
		if (dwRCVal == RC_SUCCESS) {
			Log("\n\tTPM get random completed successfully, the result is:\n");
			Dump(TG_BOTH, MD_HEX, bGetRandom, dwGetRandomSize);
		}
		break;
//-------------------------------------------------------------------------------
#ifdef TOOL4TPM_TEST
	case MENU_m_SHA1_COMPLETE:
		Log("\n\nTPM SHA1 complete\n");

		if (CALLOC(pbHashData, MAX_HASH_DATA)) {
			// Create Hash input data
			for (cnt = 0; cnt < MAX_HASH_DATA; cnt++)
				pbHashData[cnt] = (BYTE) (cnt & 0xFF);

			dwRCVal = SHA1Complete(MAX_HASH_DATA, pbHashData, bSha1TestValue);
		}
		else {
			dwRCVal = RC_E_NO_MEMORY;
			break;
		}
		if (dwRCVal == RC_SUCCESS) {
			// Print the result and compare SHA-1 result
			Log("\nSHA-1 operation completed, hash value:\n\t");
			flag = 0;
			for (i = 0; i < 20; i++) {
				Log("%.2X ", bSha1TestValue[i]);
				if (bSha1TestVector[i] != bSha1TestValue[i])
					flag = i + 1;
			}
			Log("\n");
			if (flag > 0) {
				Log("\nIncorrect SHA-1 operation result, must be:\n\t");
				for (i = 0; i < 20; i++)
					Log("%.2X ", bSha1TestVector[i]);
				Log("\n");
			} else
				Log("\nSHA-1 operation result is correct\n");
		} else
			Log("\n\tOperation SHA1Complete failed !!!\n");

		SAFE_FREE(pbHashData);
		break;
//-------------------------------------------------------------------------------
	case MENU_x_SHA1_COMPLETE_EXTEND:
		Log("\n\nTPM SHA1 complete extend\n");
		dwRCVal = SHA1CompleteExtend();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM SHA1 complete extend completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_U_TPM_STARTUP_CLEAR:
		Log("\n\nTPM Startup (clear)\n");
		if (bNegativeTest)
			dwRCVal = TPM_Startup(0xFFFF);
		else
			dwRCVal = TPM_Startup(TPM_ST_CLEAR);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM Startup completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_W_TPM_SET_OWNER_INSTALL_ON:
		Log("\n\nTPM set owner install ON\n");
		if (bNegativeTest)
			dwRCVal = TPM_SetOwnerInstall(0xFF);
		else
			dwRCVal = TPM_SetOwnerInstall(ON);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM set owner install set to ON\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_N_TPM_SET_OWNER_INSTALL_OFF:
		Log("\n\nTPM set owner install OFF\n");
		dwRCVal = TPM_SetOwnerInstall(OFF);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM set owner install set to OFF\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_D_TPM_OWNER_SET_DISABLE:
		Log("\n\nTPM owner set disable\n");
		dwRCVal = OwnerSetDisable();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM successfully disabled under owner authorization\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_M_TPM_TMP_DEACTIVATE_W_AUTH:
		Log("\n\nTPM set temporary deactivated with authorization\n");
		dwRCVal = SetTempDeactivated(TRUE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM temporarily deactivated\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_Z_TPM_TMP_DEACTIVATE_WO_AUTH:
		Log("\n\nTPM set temporary deactivated without authorization\n");
		dwRCVal = SetTempDeactivated(FALSE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM temporarily deactivated\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_t_TPM_SET_OPERATOR_AUTH:
		Log("\n\nTPM set operator authentication\n");
		dwRCVal = SetOperatorAuth();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM operator authentication successfully set\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_c_TPM_OWNER_CLEAR:
		Log("\n\nTPM owner clear\n");
		dwRCVal = OwnerClear();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM owner cleared successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_b_TPM_RESET_ESTABLISHMENT_BIT:
		Log("\n\nTSC reset establishment bit\n");
		if (bNegativeTest)
			dwRCVal = TPM_SimpleCommand(0xFF);
		else
			dwRCVal = TPM_SimpleCommand(TSC_ORD_ResetEstablishmentBit);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tEstablishment bit reset successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_s_TPM_SEAL_DATA:
		Log("\n\nTPM seal data\n");
		dwRCVal = Seal();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM seal data completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_u_TPM_UNSEAL_DATA:
		Log("\n\nTPM Unseal data\n");
		dwRCVal = Unseal();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM unseal data completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_v_TPM_SEAL_TEST:
		Log("\n\nPerform TPM Sealtest\n");
		dwRCVal = TPMSealTest();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tFull TPM selftest completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_a_TPM_CREATE_WRAP_KEY:
		Log("\n\nTPM create wrap key\n");
		dwRCVal = CreateWrapKey();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM create wrap key completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_l_TPM_LOAD_KEY_2:
		Log("\n\nTPM load key 2\n");
		dwRCVal = LoadKey2();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM load key 2 completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_g_TPM_GET_PUBLIC_KEY_W_AUTH:
		Log("\n\nTPM get public key with authorization\n");
		dwRCVal = GetPubKey(TRUE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM get public key completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_p_TPM_GET_PUBLIC_KEY_WO_AUTH:
		Log("\n\nTPM get public key without authorization\n");
		dwRCVal = GetPubKey(FALSE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM get public key completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_X_TPM_EXTEND:
		Log("\n\nTPM extend\n");
		dwRCVal = Extend();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM extend completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_r_TPM_PCR_READ:
		Log("\n\nTPM PCR read\n");
		dwRCVal = PCRRead();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM PCR read completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_e_TPM_PCR_RESET:
		Log("\n\nTPM PCR reset\n");
		dwRCVal = PCR_Reset();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM PCR reset completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_o_TPM_OSAP:
		Log("\n\nTPM OSAP\n");
		dwRCVal = OSAP();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM OSAP completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_d_TPM_DEFINE_SPACE_W_AUTH:
		Log("\n\nTPM NV define space with authorization\n");
		dwRCVal = NV_DefineSpace(TRUE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM NV define space completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_h_TPM_DEFINE_SPACE_WO_AUTH:
		Log("\n\nTPM NV define space without authorization\n");
		dwRCVal = NV_DefineSpace(FALSE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM NV define space completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_w_TPM_WRITE_VALUE_W_AUTH:
		Log("\n\nTPM NV write value with authorization \n");
		dwRCVal = NV_WriteValue(TRUE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM NV write value completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_z_TPM_READ_VALUE_W_AUTH:
		Log("\n\nTPM NV read value with authorization \n");
		dwRCVal = NV_ReadValue();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM NV read value completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_y_TPM_WRITE_VALUE_WO_AUTH:
		Log("\n\nTPM NV write value without authorization\n");
		dwRCVal = NV_WriteValue(FALSE);
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM NV write value completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_f_TPM_FLUSH_SPECIFIC:
		Log("\n\nTPM flush specific\n");
		dwRCVal = FlushSpecific();
		if (dwRCVal == RC_SUCCESS)
			Log("\n\tTPM flush specific completed successfully\n");
		break;
//-------------------------------------------------------------------------------
	case MENU_H_TOGGLE_POS_NEG_TEST:
		Log("\n\nToggle positive/negative test\n");
		if (bNegativeTest == FALSE) {
			bNegativeTest = TRUE;
			Log("\n\tNegative testing is activated\n");
		} else {
			bNegativeTest = FALSE;
			Log("\n\tPositive testing is activated\n");
		}
		break;
#endif //TOOL4TPM_TEST
//-------------------------------------------------------------------------------
	default:
		Log("\nUnknown selection: %c\n", cMenuSel);
	}

	return dwRCVal;
}

/*++
  ShowMenu

Description:
Show the menu of the program

Arguments:
none

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void ShowMenu(void)
{
	char *pcMenulabel = NULL;
	UINT32 dwMenuCount = 0, i = 0;

	char pcMenuItems[] = { 
		MENU_1_ENABLE_CMD_SET_PP, 
		MENU_2_ENABLE_HARDWARE_SIGNAL_PP, 
		MENU_3_SET_PP,
		MENU_4_CLEAR_PP,
		MENU_5_LOCK_PP,
		MENU_6_ENABLE_TPM,
		MENU_7_DISABLE_TPM,
		MENU_8_ACTIVATE_TPM,
		MENU_9_DEACTIVATE_TPM,
		MENU_C_CLEAR_OWNER_UNDER_PP,
		MENU_O_TAKE_OWNER_WITH_PASSWORD,
		MENU_P_READ_PUBLIC_EK,
		MENU_E_READ_EK_CERTIFICATE,
		MENU_F_READ_COMPARE_PUBLIC_EKS,
#ifdef TOOL4TPM_TEST
		MENU_K_CREATE_EKS,
#endif
		MENU_I_TPM_INFORMATION,
		MENU_T_FULL_SELFTEST,
		MENU_R_GET_TESTRESULTS,
		MENU_S_SHA1_TEST,
		MENU_A_READ_SHOW_TICKCOUNTER,
		MENU_B_SAFE_STATE_TO_NVM,
		MENU_G_GET_RANDOM_NUMBER,
#ifdef TOOL4TPM_TEST
		MENU_m_SHA1_COMPLETE,
		MENU_x_SHA1_COMPLETE_EXTEND,
		MENU_U_TPM_STARTUP_CLEAR,
		MENU_L_TPM_CONTINUE_SELF_TEST,
		MENU_W_TPM_SET_OWNER_INSTALL_ON,
		MENU_N_TPM_SET_OWNER_INSTALL_OFF,
		MENU_D_TPM_OWNER_SET_DISABLE,
		MENU_M_TPM_TMP_DEACTIVATE_W_AUTH,
		MENU_Z_TPM_TMP_DEACTIVATE_WO_AUTH,
		MENU_t_TPM_SET_OPERATOR_AUTH,
		MENU_c_TPM_OWNER_CLEAR,
		MENU_b_TPM_RESET_ESTABLISHMENT_BIT,
		MENU_Y_TPM_SET_CAPABILITY_W_AUTH,
		MENU_J_TPM_SET_CAPABILITY_WO_AUTH,
		MENU_s_TPM_SEAL_DATA,
		MENU_u_TPM_UNSEAL_DATA,
		MENU_v_TPM_SEAL_TEST,
		MENU_a_TPM_CREATE_WRAP_KEY,
		MENU_l_TPM_LOAD_KEY_2,
		MENU_g_TPM_GET_PUBLIC_KEY_W_AUTH,
		MENU_p_TPM_GET_PUBLIC_KEY_WO_AUTH,
		MENU_X_TPM_EXTEND,
		MENU_r_TPM_PCR_READ,
		MENU_e_TPM_PCR_RESET,
		MENU_o_TPM_OSAP,
		MENU_d_TPM_DEFINE_SPACE_W_AUTH,
		MENU_h_TPM_DEFINE_SPACE_WO_AUTH,
		MENU_w_TPM_WRITE_VALUE_W_AUTH,
		MENU_y_TPM_WRITE_VALUE_WO_AUTH,
		MENU_z_TPM_READ_VALUE_W_AUTH,
		MENU_f_TPM_FLUSH_SPECIFIC,
#endif
		MENU_Q_Exit
#ifdef TOOL4TPM_TEST
		, MENU_H_TOGGLE_POS_NEG_TEST
#endif
	};

	dwMenuCount = sizeof(pcMenuItems)/sizeof(pcMenuItems[0]);

	ConsoleWritef("\n");
	// 80c: 12345678901234567890123456789012345678901234567890123456789012345678901234567890
	ConsoleWritef("   **************************************************************************\n");
	ConsoleWritef("   *        Infineon Technologies   %s %s    Ver %s", PROGNAME, PLATFORM, VERSION);

	// UEFI doesn't understand string truncations like %-15.15s, so align the right asterisk manually
	if (strlen(PROGNAME) + strlen(PLATFORM) + strlen(VERSION) < 31) {
		for (i = 0; i < 31 - strlen(PROGNAME) - strlen(PLATFORM) - strlen(VERSION); i++) {
			ConsoleWrite(" ");
		}
	}
	ConsoleWrite("*\n");
	ConsoleWritef("   **************************************************************************\n");
	ConsoleWritef("\n");

	if (CALLOC(pcMenulabel, 512)) {
		for (i = 0; i < dwMenuCount; i++) {
			MenuCodeToLabel(pcMenuItems[i], pcMenulabel, 512);
			ConsoleWritef("       [%c] %s\n",  pcMenuItems[i], pcMenulabel);
		}
	}
	SAFE_FREE(pcMenulabel);

	printf("\n");
#ifdef TOOL4TPM_TEST
	if (bNegativeTest == FALSE)
		printf("       Performing positive tests\n\n");
	else
		printf("       Performing negative tests\n\n");
#endif // TOOL4TPM_TEST
		printf("     Press the key corresponding to the desired menu item:");
#ifdef linux
	fflush(stdout);
#endif
}

/*++
  MenuCodeToLabel

Description:
Returns the string label for a given menu code

Arguments:
[in]	UINT32	 dwMenuCode		Menu Code
[out]	char	*pcMenuLabel	Pointer to the menu label
[in]	UINT32	 dwMaxLength	Size of the buffer for the error message

Return Value:
none

Author:		Viktor	Wallner	2013/02/20
--*/
void MenuCodeToLabel(UINT32 dwMenuCode, char *pcMenuLabel, UINT32 dwMaxLength) {
	char *pcLabel = NULL;
	UINT32 dwLabelLen;

	switch (dwMenuCode) {
		case MENU_1_ENABLE_CMD_SET_PP:				pcLabel = "Enable TPM command to set Physical Presence"; break;
		case MENU_2_ENABLE_HARDWARE_SIGNAL_PP:		pcLabel = "Enable TPM hardware signal indicating Physical Presence"; break;
		case MENU_3_SET_PP:							pcLabel = "Set Physical Presence"; break;
		case MENU_4_CLEAR_PP:						pcLabel = "Clear Physical Presence"; break;
		case MENU_5_LOCK_PP:						pcLabel = "Lock TPM Physical Presence configuration until next reboot"; break;
		case MENU_6_ENABLE_TPM:						pcLabel = "Enable TPM"; break;
		case MENU_7_DISABLE_TPM:					pcLabel = "Disable TPM"; break;
		case MENU_8_ACTIVATE_TPM:					pcLabel = "Activate TPM"; break;
		case MENU_9_DEACTIVATE_TPM:					pcLabel = "Deactivate TPM"; break;
		case MENU_C_CLEAR_OWNER_UNDER_PP:			pcLabel = "Clear TPM Ownership under Physical Presence"; break;
		case MENU_O_TAKE_OWNER_WITH_PASSWORD:		pcLabel = "Take TPM Ownership with owner password from config file"; break;
		case MENU_P_READ_PUBLIC_EK:					pcLabel = "Read Public EK"; break;
		case MENU_E_READ_EK_CERTIFICATE:			pcLabel = "Read EK Certificate"; break;
		case MENU_F_READ_COMPARE_PUBLIC_EKS:		pcLabel = "Read and compare Public EKs"; break;
		case MENU_I_TPM_INFORMATION:				pcLabel = "TPM information and capabilities"; break;
		case MENU_T_FULL_SELFTEST:					pcLabel = "Perform a full TPM selftest"; break;
		case MENU_R_GET_TESTRESULTS:				pcLabel = "Get test results of the TPM selftest"; break;
		case MENU_S_SHA1_TEST:						pcLabel = "SHA-1 test"; break;
		case MENU_A_READ_SHOW_TICKCOUNTER:			pcLabel = "Read and show the current Tickcounter value"; break;
		case MENU_B_SAFE_STATE_TO_NVM:				pcLabel = "Save the current state of the TPM into the NVM"; break;
		case MENU_G_GET_RANDOM_NUMBER:				pcLabel = "Get a 20 Byte Random Number from the TPM"; break;
		case MENU_Q_Exit:							pcLabel = "Exit"; break;
#ifdef TOOL4TPM_TEST
		case MENU_K_CREATE_EKS:						pcLabel = "Create EKs"; break;
		case MENU_m_SHA1_COMPLETE:					pcLabel = "SHA-1 complete"; break;
		case MENU_x_SHA1_COMPLETE_EXTEND:			pcLabel = "SHA-1 complete extend"; break;
		case MENU_U_TPM_STARTUP_CLEAR:				pcLabel = "TPM startup (clear)"; break;
		case MENU_L_TPM_CONTINUE_SELF_TEST:			pcLabel = "TPM continue self test"; break;
		case MENU_W_TPM_SET_OWNER_INSTALL_ON:		pcLabel = "TPM set owner install ON"; break;
		case MENU_N_TPM_SET_OWNER_INSTALL_OFF:		pcLabel = "TPM set owner install OFF"; break;
		case MENU_D_TPM_OWNER_SET_DISABLE:			pcLabel = "TPM owner set disable"; break;
		case MENU_M_TPM_TMP_DEACTIVATE_W_AUTH:		pcLabel = "TPM set temporary deactivated with authorization"; break;
		case MENU_Z_TPM_TMP_DEACTIVATE_WO_AUTH:		pcLabel = "TPM set temporary deactivated without authorization"; break;
		case MENU_t_TPM_SET_OPERATOR_AUTH:			pcLabel = "TPM set operator authentication"; break;
		case MENU_c_TPM_OWNER_CLEAR:				pcLabel = "TPM owner clear"; break;
		case MENU_b_TPM_RESET_ESTABLISHMENT_BIT:	pcLabel = "TPM reset establishment bit"; break;
		case MENU_Y_TPM_SET_CAPABILITY_W_AUTH:		pcLabel = "TPM set capability with authorization"; break;
		case MENU_J_TPM_SET_CAPABILITY_WO_AUTH:		pcLabel = "TPM set capability without authorization"; break;
		case MENU_s_TPM_SEAL_DATA:					pcLabel = "TPM seal data"; break;
		case MENU_u_TPM_UNSEAL_DATA:				pcLabel = "TPM unseal data"; break;
		case MENU_v_TPM_SEAL_TEST:					pcLabel = "TPM Sealtest"; break;
		case MENU_a_TPM_CREATE_WRAP_KEY:			pcLabel = "TPM create wrap key"; break;
		case MENU_l_TPM_LOAD_KEY_2:					pcLabel = "TPM load key 2"; break;
		case MENU_g_TPM_GET_PUBLIC_KEY_W_AUTH:		pcLabel = "TPM get public key with authorization"; break;
		case MENU_p_TPM_GET_PUBLIC_KEY_WO_AUTH:		pcLabel = "TPM get public key without authorization"; break;
		case MENU_X_TPM_EXTEND:						pcLabel = "TPM extend"; break;
		case MENU_r_TPM_PCR_READ:					pcLabel = "TPM PCR read"; break;
		case MENU_e_TPM_PCR_RESET:					pcLabel = "TPM PCR reset"; break;
		case MENU_o_TPM_OSAP:						pcLabel = "TPM OSAP"; break;
		case MENU_d_TPM_DEFINE_SPACE_W_AUTH:		pcLabel = "TPM NV define space with authorization"; break;
		case MENU_h_TPM_DEFINE_SPACE_WO_AUTH:		pcLabel = "TPM NV define space without authorization"; break;
		case MENU_w_TPM_WRITE_VALUE_W_AUTH:			pcLabel = "TPM NV write value with authorization"; break;
		case MENU_y_TPM_WRITE_VALUE_WO_AUTH:		pcLabel = "TPM NV write value without authorization"; break;
		case MENU_z_TPM_READ_VALUE_W_AUTH:			pcLabel = "TPM NV read value with authorization"; break;
		case MENU_f_TPM_FLUSH_SPECIFIC:				pcLabel = "TPM flush specific"; break;
		case MENU_H_TOGGLE_POS_NEG_TEST:			pcLabel = "Toggle positive/negative test"; break;
#endif
	}

	dwLabelLen = (UINT32)strlen(pcLabel);
	if (dwLabelLen > dwMaxLength - 1) {
		memcpy(pcMenuLabel, pcLabel, dwMaxLength - 1);
		pcMenuLabel[dwMaxLength - 1] = '\0';
	}
	else {
		memcpy(pcMenuLabel, pcLabel, dwLabelLen + 1);
	}
}

/*++
  ShowHelp

Description:
Show the help text of the program

Arguments:
none

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void ShowHelp(void)
{
	// 80c: 12345678901234567890123456789012345678901234567890123456789012345678901234567890
	printf("   Call: tool4tpm [option] [option] ...\n");
	printf("\n");
	printf("   Options:\n");
	printf("     -automenu <menu_section>\n");
	printf("      Select and process the menu item(s) in the command line\n");
	printf("      Argument format: nnn...n (n is the selected item, e. g. -automenu 1368\n");
	printf("\n");
	printf("     -commandfile <cmdfile> <rspfile>\n");
	printf("      Transmits the TPM command from <cmdfile> and saves the TPM response in\n");
	printf("      <rspfile>. Set <rspfile> to '..' to save the response in \"" RSP_FILE_NAME "\".\n");
	printf("\n");
	printf("     -integrationtest\n");
	printf("      Performs a step-by-step test of the TPM hardware\n");
	printf("\n");
	printf("     -productiontest\n");
	printf("      Performs a continuous test of the TPM hardware\n");
	printf("\n");
	printf("     -cycle\n");
	printf("      Cycles command entered in menu or in production test ('ESC' aborts).\n");
	printf("\n");
	printf("     -looptest <register_address> <data_to_write> <number_of_loops> [<evaluate_response>]\n");
	printf("      A loop test of a single selected LPC interface register (Ctrl-C aborts).\n");
	printf("\n");
	printf("     -sealtest \n");
	printf("      Perform a test for the TPM to verify the ability to seal and unseal data \n");
	printf("      with a comparison of the data whether the process was ok.\n");
	printf("\n");
	printf("     -flagcheck <flagcheck_text>\n");
	printf("      A reference file specifies the flags and values to be checked.\n");
#ifdef UEFI_X64
	Exit(EFI_SUCCESS);
#else
	exit(1);
#endif
}

BOOL T4T_ErrorCodeToMessage(UINT32 dwErrorCode, char *pcErrorMessage, UINT32 dwMaxLength)
{
	char *pcMessage = NULL;

	switch (dwErrorCode) {
		case RC_E_SEALTESTERROR:			pcMessage = "Error during the Sealtest"; break;
	}

	if (pcMessage != NULL) {
		memcpy(pcErrorMessage, pcMessage, min(dwMaxLength - 1, (UINT32)strlen(pcMessage) + 1));
		pcErrorMessage[dwMaxLength - 1] = '\0';
	}

	return (pcMessage != NULL);
}