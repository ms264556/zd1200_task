/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Func.c

Description:	Implementation of the TPM control functions

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "FileIO.h"
#include "Console.h"
#include "Hash.h"
#include "ProgFunc.h"
#include "RSA.h"
#include "TDDL.h"
#include "TPM_Cmds.h"
#include "TPM_Func.h"

BOOL bNegativeTest = FALSE;

// Global buffer for input data to seal
BYTE abSealInputData[] = "TPM_Seal Data";
UINT32 dwSealInputDataSize = sizeof(abSealInputData);
// buffer data from Seal out data to Unseal in data
UINT32 dwSealedDataSize = DEFAULT_BUFFERSIZE;
BYTE abSealedData[DEFAULT_BUFFERSIZE];

// buffer data from CreateWrapKey out data to LoadKey2 in data
static UINT32 dwCreateWrapKeySize = DEFAULT_BUFFERSIZE;
static BYTE abCreateWrapKey[DEFAULT_BUFFERSIZE];
static TPM_KEY_HANDLE dwLoadKey2Handle = 0;

/*++
GetTPMCmdFromFile

Description:
Send the content from CmdFile to the TPM and receive the response into RspFile

Arguments:
[in]	char	*pcCmdFileName	Command file name
[in]	char	*pcRspFileName	Response file name

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 GetTPMCmdFromFile(char *pcCmdFileName, char *pcRspFileName)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE *pbTxBuffer = NULL, *pbRxBuffer = NULL;
	BYTE bMaxSize[2];
	UINT16 wTxSize = 0, wMaxSize = 0;
	UINT32 dwRxSize = 0;

	DetLogToFile("--------------------TPM_CmdFile----------------------\n");

	do {
		dwRxSize = sizeof(bMaxSize);
		// Check maximum command size depending on the used access mode
		dwRCVal = TDDL_GetCapability(TDDL_CAP_PROPERTY, TDDL_CAP_PROP_IFSD, bMaxSize, &dwRxSize);
		if (dwRCVal == RC_SUCCESS)
			wMaxSize = (bMaxSize[0] << 8) | bMaxSize[1];
		else
			wMaxSize = 0xFFFF;

		SAFE_CALLOC(pbTxBuffer, wMaxSize, &dwRCVal);
		SAFE_CALLOC(pbRxBuffer, wMaxSize, &dwRCVal);

		dwRxSize = wTxSize = wMaxSize;
		
		dwRCVal = ReadBufferFromHexFile(pcCmdFileName, pbTxBuffer, &wTxSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = TDDL_TransmitData(pbTxBuffer, (UINT32) wTxSize, pbRxBuffer, &dwRxSize);
		if (dwRCVal != TPM_SUCCESS)
			break;

		dwRCVal = WriteBuffer2HexFile(pcRspFileName, pbRxBuffer, (UINT16) dwRxSize);
	} while (FALSE);

	SAFE_FREE(pbTxBuffer);
	SAFE_FREE(pbRxBuffer);

	return dwRCVal;
}

/*++
CreateEndorsementKeyPair

Description:
This command creates the TPM endorsement key.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier	2008/04/23
--*/
UINT32 CreateEndorsementKeyPair(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwKeyInfoSize = 0;	// The size of information about key to be created, this includes all algorithm parameters
	// TPM_KEY_PARMS   *psKeyInfo;     // Information about key to be created, this includes all algorithm parameters
	UINT32 dwKeySize = KEY_LEN;	// The size of the public endorsement key
	TPM_PUBKEY *psPubEndorsementKey = NULL;	// The public endorsement key

	do {
		TPM_KEY_PARMS parms = { TPM_ALG_RSA,	// algorithmID 0x00000001
			TPM_ES_RSAESOAEP_SHA1_MGF1,	// encScheme 0x0003,
			TPM_SS_NONE,	// sigScheme 0x0001
			0x0000000C,	// parmSize
			{	// parms
			 0x00000800,	// parms.keyLength
			 0x00000002,	// parms.numPrimes
			 0x00000000,	// parms.exponentSize
			 }
		};
		dwKeyInfoSize = sizeof(TPM_KEY_PARMS);

		// Allocate memory for temporary variables
		SAFE_CALLOC(psPubEndorsementKey, dwKeySize, &dwRCVal);

		// Perform TPM_CreateEndorsementKeyPair
		dwRCVal = TPM_CreateEndorsementKeyPair(dwKeyInfoSize,
						       (TPM_KEY_PARMS *) & parms, &dwKeySize, psPubEndorsementKey);
		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, (BYTE *) psPubEndorsementKey, dwKeySize);
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tCreateEndorsementKeyPair failed !!!\n");

	SAFE_FREE(psPubEndorsementKey);

	return dwRCVal;
}

/*++
ReadEKCertificate

Description:
Read the Endorsement Key Certificate

Arguments:
[in]	BYTE	*pCert			Pointer to EK Certificate
[out]	UINT32	*pdwCertSize	EK Certificate length in Bytes

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 ReadEKCertificate(BYTE * pCert, UINT32 * pdwCertSize)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_PERMANENT_FLAGS_12_103 *psPermFlags = NULL;
	TPM_NV_DATA_PUBLIC *psNvDataPub = NULL;
	BYTE *pbCertPortion = NULL;
	BYTE bIndex = 0, bMaxIndex = 0;
	UINT16 i = 0;
	UINT32 dwPortionLen = 0, dwNvDataPubLen = 0, dwCertStructSize = 0;
	UINT32 dwEndian = 0;
	UINT32 dwInfoLen = 0;
	BOOL bIsTPMOwned = FALSE;
	BOOL bNeedAuth = FALSE;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value
	TPM_AUTHHANDLE dwAuthHandle = 0;	// The authorization session handle used for TPM Owner
	TPM_NONCE *psNonceEven = NULL;	// Even nonce newly generated by TPM to cover outputs
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle


	switch (bChipDetected) {
		case TPM1_1:
			DetLogToFile("-------------- ReadEKCertificate (TPM 1.1) --------------\n");

			*pdwCertSize = 0;
			bIndex = 0;
			dwPortionLen = MAX_CERT_SIZE;
			SAFE_CALLOC(pbCertPortion, MAX_CERT_SIZE, &dwRCVal);

			do {
				// Send TPM 1.1 command to read the EK Certificate
				dwRCVal = TPM_11_ReadEKCert(bIndex, &bMaxIndex, pbCertPortion, &dwPortionLen);
				if (dwRCVal == RC_SUCCESS) {
					memcpy(pCert + *pdwCertSize, pbCertPortion, (size_t) dwPortionLen);
					*pdwCertSize += dwPortionLen;
				}
			} while (bIndex++ < bMaxIndex && dwRCVal == RC_SUCCESS);
			
			break;

		case TPM1_2:
			DetLogToFile("-------------- ReadEKCertificate (TPM 1.2) --------------\n");

			dwNvDataPubLen = sizeof(TPM_NV_DATA_PUBLIC);
			SAFE_CALLOC(psNvDataPub, sizeof(TPM_NV_DATA_PUBLIC), &dwRCVal);
			SAFE_CALLOC(psPermFlags, sizeof(TPM_PERMANENT_FLAGS_12_103), &dwRCVal);

			dwInfoLen = sizeof(TPM_PERMANENT_FLAGS_12_103);
			// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
			// Argument 3: was UINT32, now BYTE *
			dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_PERMANENT);
			dwRCVal =
				TPM_GetCapability(TPM_CAP_FLAG, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen, (BYTE *) (psPermFlags));
			if (dwRCVal != RC_SUCCESS)
				break;

			bIsTPMOwned = IsTPMOwned();
			if (bIsTPMOwned && (psPermFlags->nvLocked))
				bNeedAuth = TRUE;

			// Get EK Certificate struct length by reading the TPM NV index "TPM_NV_INDEX_EKCert"
			// Argument 3: was UINT32, now BYTE *
			dwEndian = dwSwitchEndian32(TPM_NV_INDEX_EKCert);
			// Boundary check for buffer size
			if (bNegativeTest)
				dwNvDataPubLen--;
			dwRCVal = TPM_GetCapability(TPM_CAP_NV_INDEX,
					sizeof(TPM_NV_INDEX),
					(BYTE *) & dwEndian, &dwNvDataPubLen, (BYTE *) psNvDataPub);

			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwCertStructSize = dwSwitchEndian32(psNvDataPub->dataSize);
			SAFE_FREE(psNvDataPub);

			if (bNeedAuth) {
					SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
					SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);

					// Get owner password, hash it and encrypt the result
					dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
					if (dwRCVal != RC_SUCCESS)
						break;

					dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
					if (dwRCVal != RC_SUCCESS)
						break;

					SAFE_CALLOC(psNonceEven, sizeof(TPM_NONCE), &dwRCVal);

					// Get Authorization Session handle and even nonce
					dwRCVal = TPM_OIAP(&dwAuthHandle, psNonceEven);
					if (dwRCVal != RC_SUCCESS)
						break;
			}

			// Read the first 249 Bytes the EK Certificate
			// WARNING: No endian conversion of the results is supplied in TPM_NV_ReadValue!
			dwPortionLen = 0x100;
			// Perform TPM_NV_ReadValue
			// WARNING: No endian conversion of the results is supplied in TPM_NV_ReadValue!
			dwRCVal = TPM_NV_ReadValue(TPM_NV_INDEX_EKCert,	0, &dwPortionLen, 
						dwAuthHandle, psNonceEven, bContinueAuthSession, 
						(TPM_AUTHDATA *) pbOwnerPWHash, pCert);
			if (dwRCVal != TPM_SUCCESS)
				break;

			// Get EK Certificate length
			*pdwCertSize = wSwitchEndian16(((TPM_STORED_CERT *) pCert)->certSize) - 2;

			// Delete the first 7 Bytes of TPM_STORED_CERT and displace data Bytes accordingly
			for (i = 0; i < dwPortionLen; i++)
				pCert[i] = pCert[i + 7];

			// Read the rest of the EK Certificate
			// WARNING: No endian conversion of the results is supplied in TPM_NV_ReadValue!
			for (i = 0x100; i <= (dwCertStructSize / 0x100) * 0x100; i += 0x100) {
				if (i == (dwCertStructSize / 0x100) * 0x100)
					dwPortionLen = dwCertStructSize % 0x100;
				if (bNeedAuth) {
					bContinueAuthSession = FALSE;
					//calc continue auth session handle
					dwRCVal = TPM_OIAP(&dwAuthHandle, psNonceEven);
					if (dwRCVal != RC_SUCCESS)
						break;
				}

				dwRCVal = TPM_NV_ReadValue(TPM_NV_INDEX_EKCert, i, &dwPortionLen, dwAuthHandle,	psNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash, (pCert + i - 7));
				if (dwRCVal != TPM_SUCCESS)
					break;
			}

			break;

		default:
			Log("No TPM found or unknown TPM version !!!\n\n");
	}

	SAFE_FREE(pbCertPortion);
	SAFE_FREE(psNvDataPub);
	SAFE_FREE(psNonceEven);
	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);
	SAFE_FREE(psPermFlags);
	return dwRCVal;
}

/*++
SHA1test

Description:
Perform a SHA-1 digest

Arguments:
[in]	UINT32	dwHashDataSize	Number of Bytes in pbHashData
[in]	BYTE	*pbHashData		Bytes to be hashed
[out]	BYTE	*pbHashValue	Resulting digest of the SHA-1 process

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 SHA1test(UINT32 dwHashDataSize, BYTE * pbHashData, BYTE * pbHashValue)
{
	UINT32 dwRCVal = 0, dwMaxBlockSize = 0, dwSize = 0;

	dwRCVal = TPM_SHA1Start(&dwMaxBlockSize);

	if (dwRCVal == RC_SUCCESS) {
		Log("\nMaximum hash data block size: %d\n", dwMaxBlockSize);

		while ((dwRCVal == RC_SUCCESS) && (dwHashDataSize >= dwMaxBlockSize)) {
			dwRCVal = TPM_SHA1Update(dwMaxBlockSize, pbHashData);
			dwHashDataSize -= dwMaxBlockSize;
			pbHashData += dwMaxBlockSize;
		}

		if ((dwRCVal == RC_SUCCESS) && (dwHashDataSize >= 64)) {
			dwSize = (dwHashDataSize / 64) * 64;
			if (bNegativeTest) {
				// Supply value bigger than max. data hash size (1216)
				dwRCVal = TPM_SHA1Update(2048, pbHashData);
			} else
				dwRCVal = TPM_SHA1Update(dwSize, pbHashData);
			dwHashDataSize -= dwSize;
			pbHashData += dwSize;
		}

		if (dwRCVal == RC_SUCCESS)
			dwRCVal = TPM_SHA1Complete(dwHashDataSize, pbHashData, pbHashValue);
		else
			TPM_SHA1Complete(dwHashDataSize, pbHashData, pbHashValue);
	}
	return dwRCVal;
}

/*++
SHA1Complete

Description:
Perform a SHA-1 digest

Arguments:
[in]	UINT32	dwHashDataSize	Number of Bytes in pbHashData
[in]	BYTE	*pbHashData		Bytes to be hashed
[out]	BYTE	*pbHashValue	Resulting digest of the SHA-1 process

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier	2008/08/13
--*/
UINT32 SHA1Complete(UINT32 dwHashDataSize, BYTE * pbHashData, BYTE * pbHashValue)
{
	UINT32 dwRCVal = 0, dwMaxBlockSize = 0, dwSize = 0;

	dwRCVal = TPM_SHA1Start(&dwMaxBlockSize);

	if (dwRCVal == RC_SUCCESS) {
		Log("\nMaximum hash data block size: %d\n", dwMaxBlockSize);

		while ((dwRCVal == RC_SUCCESS) && (dwHashDataSize >= dwMaxBlockSize)) {
			dwRCVal = TPM_SHA1Update(dwMaxBlockSize, pbHashData);
			dwHashDataSize -= dwMaxBlockSize;
			pbHashData += dwMaxBlockSize;
		}

		if ((dwRCVal == RC_SUCCESS) && (dwHashDataSize >= 64)) {
			dwSize = (dwHashDataSize / 64) * 64;
			dwRCVal = TPM_SHA1Update(dwSize, pbHashData);
			dwHashDataSize -= dwSize;
			pbHashData += dwSize;
		}

		if (dwRCVal == RC_SUCCESS) {
			if (bNegativeTest)
				dwRCVal = TPM_SHA1Complete(dwHashDataSize, NULL, pbHashValue);
			else
				dwRCVal = TPM_SHA1Complete(dwHashDataSize, pbHashData, pbHashValue);
		} else
			TPM_SHA1Complete(dwHashDataSize, pbHashData, pbHashValue);
	}
	return dwRCVal;
}

/*++
SHA1CompleteExtend

Description:
This capability terminates a pending SHA-1 calculation and EXTENDS the result into a
Platform Configuration Register using a SHA-1 hash process.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier	2008/04/23
--*/
UINT32 SHA1CompleteExtend(void)
{
	UINT32 dwHashDataSize = HASH_LEN;
	BYTE bHashData[] = SHA1_TEST_VALUE;
	BYTE *pbHashData = bHashData;
	BYTE bHashValue[20];
	BYTE *pbHashValue = bHashValue;
	UINT32 dwRCVal = 0, dwMaxBlockSize = 0, dwSize = 0, dwPCRIndex = 0;
	TPM_DIGEST sOutDigest;

	dwRCVal = TPM_SHA1Start(&dwMaxBlockSize);

	if (dwRCVal == RC_SUCCESS) {
		Log("\nMaximum hash data block size: %d\n", dwMaxBlockSize);

		while ((dwRCVal == RC_SUCCESS) && (dwHashDataSize >= dwMaxBlockSize)) {
			dwRCVal = TPM_SHA1Update(dwMaxBlockSize, pbHashData);
			dwHashDataSize -= dwMaxBlockSize;
			pbHashData += dwMaxBlockSize;
		}

		if ((dwRCVal == RC_SUCCESS) && (dwHashDataSize >= 64)) {
			dwSize = (dwHashDataSize / 64) * 64;
			dwRCVal = TPM_SHA1Update(dwSize, pbHashData);
			dwHashDataSize -= dwSize;
			pbHashData += dwSize;
		}

		if (bNegativeTest)
			dwPCRIndex = 24;
		else
			dwPCRIndex = 9;
		if (dwRCVal == RC_SUCCESS)
			dwRCVal =
			    TPM_SHA1CompleteExtend(dwPCRIndex, dwHashDataSize, pbHashData, (TPM_DIGEST *) pbHashValue,
						   &sOutDigest);
		else
			TPM_SHA1Complete(dwHashDataSize, pbHashData, pbHashValue);
	}
	return dwRCVal;
}

/*++
ShowTPM11info

Description:
Show TPM1.1 info and capabilities

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 ShowTPM11info(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	IFX_FIELDUPGRADEINFO *psFUInfo = NULL;
	BYTE *pInfo = NULL;
	UINT32 dwInfoLen = 0;
	UINT32 dwEndian = 0;
	TPM_CAP sTpmCaps;

	dwInfoLen = ST_EL_BIG_SZ;

	do
	{
		SAFE_CALLOC(pInfo, ST_EL_BIG_SZ, &dwRCVal);
		SAFE_CALLOC(psFUInfo, sizeof(IFX_FIELDUPGRADEINFO), &dwRCVal);

		Log("\n\nTPM information (TDDL_GetCapability):\n"
			"=========================================================\n");
		dwInfoLen = ST_EL_BIG_SZ;
		TDDL_GetCapability(TDDL_CAP_VERSION, TDDL_CAP_VER_DRV, pInfo, &dwInfoLen);
		Log("  TPM driver version:   %X.%X.%X.%X\n", pInfo[0], pInfo[1], pInfo[2], pInfo[3]);

		dwInfoLen = ST_EL_BIG_SZ;
		TDDL_GetCapability(TDDL_CAP_PROPERTY, TDDL_CAP_PROP_MANUFACTURER, pInfo, &dwInfoLen);
		Log("  TPM manufacturer:     ");
		Dump(TG_BOTH, MD_STR, pInfo, dwInfoLen);

		dwInfoLen = sizeof(sTpmCaps.abFWVers);
		TDDL_GetCapability(TDDL_CAP_VERSION, TDDL_CAP_VER_FW, sTpmCaps.abFWVers, &dwInfoLen);
		Log("  Firmware version:     %.2X.%.2X.%.2X.%.2X\n",
			sTpmCaps.abFWVers[0], sTpmCaps.abFWVers[1], sTpmCaps.abFWVers[2], sTpmCaps.abFWVers[3]);

		dwInfoLen = sizeof(sTpmCaps.abFWDate);
		TDDL_GetCapability(TDDL_CAP_VERSION, TDDL_CAP_VER_FW_DATE, sTpmCaps.abFWDate, &dwInfoLen);
		Log("  Firmware date:        %.2X.%.2X.%.2X\n", sTpmCaps.abFWDate[0], sTpmCaps.abFWDate[1],
			sTpmCaps.abFWDate[2]);

		dwInfoLen = ST_EL_BIG_SZ;
		TDDL_GetCapability(TDDL_CAP_PROPERTY, TDDL_CAP_PROP_MODULE_TYPE, pInfo, &dwInfoLen);
		Log("  TPM type:             ");
		Dump(TG_BOTH, MD_STR, pInfo, dwInfoLen);

		dwInfoLen = ST_EL_BIG_SZ;
		TDDL_GetCapability(TDDL_CAP_PROPERTY, TDDL_CAP_PROP_GLOBAL_STATE, pInfo, &dwInfoLen);
		Log("  TPM global state:     %.2X\n\n", pInfo[0]);

		//---------------------------------------------------------------------------

		Log("TPM information (TPM_GetCapability):\n" "=========================================================\n");
		dwInfoLen = ST_EL_BIG_SZ;
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_PROP_MANUFACTURER);
		dwRCVal = TPM_GetCapability(5, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen, pInfo);
		if (dwRCVal == RC_SUCCESS && dwInfoLen)
			Log("  Manufacturer:         %s\n", pInfo);
		else
			Log("TPM_GetCapability (manufacturer) error !!!\n");

		dwInfoLen = ST_EL_BIG_SZ;
		dwRCVal = TPM_GetCapability(TPM_CAP_VERSION, 0, 0, &dwInfoLen, pInfo);
		if (dwRCVal == RC_SUCCESS && dwInfoLen)
			Log("  Version:              %X.%X.%X.%X\n\n", pInfo[0], pInfo[1], pInfo[2], pInfo[3]);
		else
			Log("TPM_GetCapability (version) error !!!\n\n");

		//---------------------------------------------------------------------------

		dwInfoLen = ST_EL_BIG_SZ;
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_PERMANENT);
		dwRCVal = TPM_GetCapability(4, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen, pInfo);
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			Log("Persistent flags: %.2X %.2X %.2X %.2X\n"
				"---------------------------------------------------------\n",
				pInfo[4], pInfo[5], pInfo[6], pInfo[7]);

			Log("  disable:              %s (TPM is %s)\n", SHOWBIT(pInfo[7], 0x01),
				(pInfo[7] & 0x01) ? "disabled" : "enabled");
			Log("  ownership:            %s (%s TakeOwnership)\n", SHOWBIT(pInfo[7], 0x02),
				(pInfo[7] & 0x02) ? "Allow" : "Do not allow");
			Log("  deactivated:          %s (TPM is %s)\n", SHOWBIT(pInfo[7], 0x04),
				(pInfo[7] & 0x04) ? "deactivated" : "activated");
			Log("  readPubek:            %s (%s reading the PUBEK without owner auth)\n",
				SHOWBIT(pInfo[7], 0x08), (pInfo[7] & 0x08) ? "Allow" : "Do not allow");
			Log("  disableOwnerClear:    %s (%s owner authorized clear commands)\n", SHOWBIT(pInfo[7], 0x10),
				(pInfo[7] & 0x10) ? "Do not allow" : "Allow");
			Log("  allowMaintenance:     %s (%s creating a maintenance archive)\n", SHOWBIT(pInfo[7], 0x20),
				(pInfo[7] & 0x20) ? "Allow" : "Do not allow");
			Log("  physPresLifetimeLock: %s (%s)\n", SHOWBIT(pInfo[7], 0x40),
				(pInfo[7] & 0x40) ? "physPresHWEnable/physPresCMDEnable locked" : "Not set");
			Log("  physPresHWEnable:     %s (HW signal indicating Physical Presence %s)\n",
				SHOWBIT(pInfo[7], 0x80), (pInfo[7] & 0x80) ? "enable" : "disabled");
			Log("  physPresCMDEnable:    %s (CMD signal indicating Physical Presence %s)\n",
				SHOWBIT(pInfo[6], 0x01), (pInfo[6] & 0x01) ? "enable" : "disabled");
			Log("  CEKPUsed:             %s (EK created using %s)\n", SHOWBIT(pInfo[6], 0x02),
				(pInfo[6] & 0x02) ? "TPM_CreateEndorsementKeyPair" : "manufacturer process");
			Log("  TPMpost:              %s (TPM %s successfully complete SelfTestFull)\n",
				SHOWBIT(pInfo[6], 0x04), (pInfo[6] & 0x04) ? "MUST" : "needs not to");
			Log("  TPMpostLock:          %s (%s)\n\n", SHOWBIT(pInfo[6], 0x08),
				(pInfo[6] & 0x08) ? "TPMpost is Locked" : "Not set");
		} else
			Log("TPM_GetCapability (persistent flags) error !!!\n\n");

		//---------------------------------------------------------------------------

		dwInfoLen = ST_EL_BIG_SZ;
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_VOLATILE);
		dwRCVal = TPM_GetCapability(4, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen, pInfo);
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			Log("Volatile flags: %.2X %.2X %.2X %.2X\n"
				"---------------------------------------------------------\n",
				pInfo[4], pInfo[5], pInfo[6], pInfo[7]);

			Log("  deactivated:          %s (TPM is %s)\n", SHOWBIT(pInfo[7], 0x01),
				(pInfo[7] & 0x01) ? "temporary deactived" : "activated");
			Log("  disableForceClear:    %s (TPM_ForceClear command %s)\n", SHOWBIT(pInfo[7], 0x02),
				(pInfo[7] & 0x02) ? "disabled" : "enabled");
			Log("  physicalPresence:     %s (TPM is%s under Physical Presence)\n", SHOWBIT(pInfo[7], 0x04),
				(pInfo[7] & 0x04) ? "" : " not");
			Log("  physicalPresenceLock: %s (Physical Presence%s locked)\n", SHOWBIT(pInfo[7], 0x08),
				(pInfo[7] & 0x08) ? "" : " not");
			Log("  postInitialise:       %s\n\n", SHOWBIT(pInfo[6], 0x01));
		} else
			Log("TPM_GetCapability (volatile flags) error !!!\n\n");

		//---------------------------------------------------------------------------

		Log("TPM information (TPM_FieldUpgradeInfoRequest):\n"
			"=========================================================\n");
		dwRCVal = TPM_FieldUpgradeInfoRequest(psFUInfo);
		switch (dwRCVal) {
		case RC_SUCCESS:
			Log("  Firmware date:        %.2X.%.2X.%.2X\n",
				psFUInfo->date[0], psFUInfo->date[1], psFUInfo->date[2]);
			Log("  ROM CRC:              %.4X\n", psFUInfo->romCRC);
			Log("  TPM owner:            %sset\n", (psFUInfo->flagsFieldUpgrade & 1) ? "" : "NOT ");
			break;
		case TPM_E_IFX_RETRY:
		case TPM_E_IFX_NEEDS_SELFTEST:
		case TPM_E_IFX_DOING_SELFTEST:
		case TPM_E_IFX_DEFEND_LOCK_RUNNING:
		case TPM_E_IFX_DEACTIVATED:
		case TPM_E_IFX_DISABLED:
			break;
		default:
			Log("TPM_FieldUpgradeInfoRequest error !!!\n");
		}
	} while (FALSE);

	SAFE_FREE(pInfo);
	SAFE_FREE(psFUInfo);

	return dwRCVal;
}

/*++
ShowTPM12info

Description:
Show TPM1.2 info and capabilities

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 ShowTPM12info(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_CAP_VERSION_INFO *psCapVerInf = NULL;
	TPM_PERMANENT_FLAGS_12_103 *psPermFlags = NULL;
	TPM_STCLEAR_FLAGS *psStClFlags = NULL;
	IFX_FIELDUPGRADEINFO *psFUInfo = NULL;
	UINT32 dwInfoLen = 0;
	UINT32 dwEndian = 0;
	UINT16 wSize = 0, i = 0;

	do {
		SAFE_CALLOC(psCapVerInf, sizeof(TPM_CAP_VERSION_INFO), &dwRCVal);
		SAFE_CALLOC(psPermFlags, sizeof(TPM_PERMANENT_FLAGS_12_103), &dwRCVal);
		SAFE_CALLOC(psStClFlags, sizeof(TPM_STCLEAR_FLAGS), &dwRCVal);
		SAFE_CALLOC(psFUInfo, sizeof(IFX_FIELDUPGRADEINFO), &dwRCVal);
		
		Log("\n\nTPM information (TPM_GetCapability):\n"
		    "=========================================================\n");

		//---------------------------------------------------------------------------

		dwInfoLen = sizeof(TPM_CAP_VERSION_INFO);
		// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
		dwRCVal = TPM_GetCapability(TPM_CAP_VERSION_VAL, 0, 0, &dwInfoLen, (BYTE *) (psCapVerInf));
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			Log("TPM_STRUCTURE_TAG: %.4X (TPM_TAG_CAP_VERSION_INFO)\n"
			    "---------------------------------------------------------\n",
			    wSwitchEndian16(psCapVerInf->tag));

			Log(" version:              %.2d.%.2d.%.2d.%.2d\n",
			    psCapVerInf->version.major,
			    psCapVerInf->version.minor, psCapVerInf->version.revMajor, psCapVerInf->version.revMinor);
			Log(" specLevel:            %2d\n", wSwitchEndian16(psCapVerInf->specLevel));
			Log(" specLetter:           %.2X\n", psCapVerInf->specLetter);
			Log(" tpmVendorID:          %c%c%c%c",
			    psCapVerInf->tpmVendorID[0],
			    psCapVerInf->tpmVendorID[1], psCapVerInf->tpmVendorID[2], psCapVerInf->tpmVendorID[3]);
			wSize = wSwitchEndian16(psCapVerInf->vendorSpecificSize);
			Log ("\n");
			Log(" vendorSpecificSize:   %2d\n", wSize);
			if (wSize > 0) {
				Log(" vendorSpecific:       ");
				for (i = 0; i < wSize; i++)
					Log("%.2X", psCapVerInf->vendorSpecific[i]);
				Log("\n\n");
			}
		} else
			Log("TPM_GetCapability (TPM_CAP_VERSION_VAL) error !!!\n\n");

		//---------------------------------------------------------------------------

		dwInfoLen = sizeof(TPM_PERMANENT_FLAGS_12_103);
		// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_PERMANENT);
		dwRCVal =
		    TPM_GetCapability(TPM_CAP_FLAG, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen, (BYTE *) (psPermFlags));
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			Log("TPM_STRUCTURE_TAG: %.4X (TPM_TAG_PERMANENT_FLAGS)\n"
			    "---------------------------------------------------------\n",
			    wSwitchEndian16(psPermFlags->tag));

			Log(" disable:                %X (TPM is %s)\n", psPermFlags->disable,
			    (psPermFlags->disable) ? "disabled" : "enabled");
			Log(" ownership:              %X (%s TakeOwnership)\n", psPermFlags->ownership,
			    (psPermFlags->ownership) ? "Allow" : "Do not allow");
			Log(" deactivated:            %X (TPM is %s)\n", psPermFlags->deactivated,
			    (psPermFlags->deactivated) ? "deactivated" : "activated");
			Log(" readPubek:              %X (%s reading the PUBEK without owner auth)\n",
			    psPermFlags->readPubek, (psPermFlags->readPubek) ? "Allow" : "Do not allow");
			Log(" disableOwnerClear:      %X (%s owner authorized clear commands)\n",
			    psPermFlags->disableOwnerClear, (psPermFlags->disableOwnerClear) ? "Do not allow" : "Allow");
			Log(" allowMaintenance:       %X (%s creating a maintenance archive)\n",
			    psPermFlags->allowMaintenance, (psPermFlags->allowMaintenance) ? "Allow" : "Do not allow");
			Log(" physPresLifetimeLock:   %X (%s)\n", psPermFlags->physicalPresenceLifetimeLock,
			    (psPermFlags->physicalPresenceLifetimeLock) ? "physPresHWEnable/physPresCMDEnable locked" :
			    "Not set");
			Log(" physPresHWEnable:       %X (HW signal indicating Physical Presence %s)\n",
			    psPermFlags->physicalPresenceHWEnable,
			    (psPermFlags->physicalPresenceHWEnable) ? "enabled" : "disabled");
			Log(" physPresCMDEnable:      %X (CMD signal indicating Physical Presence %s)\n",
			    psPermFlags->physicalPresenceCMDEnable,
			    (psPermFlags->physicalPresenceCMDEnable) ? "enabled" : "disabled");
			Log(" CEKPUsed:               %X (EK created using %s)\n", psPermFlags->CEKPUsed,
			    (psPermFlags->CEKPUsed) ? "TPM_CreateEndorsementKeyPair" : "manufacturer process");
			Log(" TPMpost:                %X (ContinueSelftest %s executed as SelfTestFull)\n",
			    psPermFlags->TPMpost, (psPermFlags->TPMpost) ? "is" : "is not");
			Log(" TPMpostLock:            %X (%s)\n", psPermFlags->TPMpostLock,
			    (psPermFlags->TPMpostLock) ? "TPMpost is Locked" : "Not set");
			Log(" FIPS:                   %X (TPM does%s operate in FIPS mode)\n", psPermFlags->FIPS,
			    (psPermFlags->FIPS) ? "" : " not");
			Log(" operator:               %X (AuthData value is %s)\n", psPermFlags->bOperator,
			    (psPermFlags->bOperator) ? "valid" : "not set");
			Log(" enableRevokeEK:         %X (TPM_RevokeTrust command is %s)\n", psPermFlags->enableRevokeEK,
			    (psPermFlags->enableRevokeEK) ? "active" : "inactive");
			Log(" nvLocked:               %X (%s)\n", psPermFlags->nvLocked,
			    (psPermFlags->nvLocked) ? "All NV area auth checks are active" :
			    "No NV area auth check is active");
			Log(" readSRKPub:             %X (GetPubKey will%s return SRK)\n", psPermFlags->readSRKPub,
			    (psPermFlags->readSRKPub) ? "" : " not");
			Log(" tpmEstablished:         %X (TPM_HASH_START has%s been executed)\n",
			    psPermFlags->tpmEstablished, (psPermFlags->tpmEstablished) ? "" : " not");
			Log(" maintenanceDone:        %X (Maintenance archive%s created)\n", psPermFlags->maintenanceDone,
			    (psPermFlags->maintenanceDone) ? "" : " not");
			if (psCapVerInf->specLetter == 0x02) {
				Log(" disableFullDALogicInfo: %X (Report of the DA Logic Info is%s limited)\n",
				    psPermFlags->disableFullDALogicInfo,
				    (psPermFlags->disableFullDALogicInfo) ? "" : " not");
			}
			Log("\n");
		} else
			Log("TPM_GetCapability (persistent flags) error !!!\n\n");

		//---------------------------------------------------------------------------

		dwInfoLen = sizeof(TPM_STCLEAR_FLAGS);
		// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_VOLATILE);
		dwRCVal =
		    TPM_GetCapability(TPM_CAP_FLAG, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen, (BYTE *) (psStClFlags));
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			Log("TPM_STRUCTURE_TAG: %.4X (TPM_TAG_STCLEAR_FLAGS)\n"
			    "---------------------------------------------------------\n",
			    wSwitchEndian16(psStClFlags->tag));

			Log(" deactivated:          %X (TPM is %s)\n", psStClFlags->deactivated,
			    (psStClFlags->deactivated) ? "temporary deactived" : "activated");
			Log(" disableForceClear:    %X (TPM_ForceClear command %s)\n", psStClFlags->disableForceClear,
			    (psStClFlags->disableForceClear) ? "disabled" : "enabled");
			Log(" physicalPresence:     %X (TPM is%s under Physical Presence)\n", psStClFlags->physicalPresence,
			    (psStClFlags->physicalPresence) ? "" : " not");
			Log(" physicalPresenceLock: %X (Physical Presence%s locked)\n", psStClFlags->physicalPresenceLock,
			    (psStClFlags->physicalPresenceLock) ? "" : " not");
			Log(" bGlobalLock:          %X (TPM%s locked)\n\n", psStClFlags->bGlobalLock,
			    (psStClFlags->bGlobalLock) ? "" : " not");
		} else
			Log("TPM_GetCapability (volatile flags) error !!!\n\n");

		//---------------------------------------------------------------------------

		Log("TPM information (TPM_FieldUpgradeInfoRequest):\n"
		    "=========================================================\n");
		dwRCVal = TPM_FieldUpgradeInfoRequest(psFUInfo);
		switch (dwRCVal) {
		case RC_SUCCESS:
			Log(" Firmware date:        %.2X.%.2X.%.2X\n",
			    psFUInfo->date[0], psFUInfo->date[1], psFUInfo->date[2]);
			Log(" ROM CRC:              %.4X\n", psFUInfo->romCRC);
			Log(" TPM owner:            %sset\n", (psFUInfo->flagsFieldUpgrade & 1) ? "" : "NOT ");
			break;
			// Do not consider TPM warnings as errors
		case TPM_E_IFX_RETRY:
		case TPM_E_IFX_NEEDS_SELFTEST:
		case TPM_E_IFX_DOING_SELFTEST:
		case TPM_E_IFX_DEFEND_LOCK_RUNNING:
		case TPM_E_IFX_DEACTIVATED:
		case TPM_E_IFX_DISABLED:
			break;
		default:
			Log("TPM_FieldUpgradeInfoRequest error !!!\n");
		}
	} while (FALSE);

	SAFE_FREE(psCapVerInf);
	SAFE_FREE(psPermFlags);
	SAFE_FREE(psStClFlags);
	SAFE_FREE(psFUInfo);

	return dwRCVal;
}

/*++
FlagCheck

Description:
Provide a configurable TPM status check function

Arguments:
[in]    char *pcFlagCheckFileName   Flag check configuration file name

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 FlagCheck(char *pcFlagCheckFileName)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_CAP_VERSION_INFO *psCapVerInf = NULL;
	TPM_PERMANENT_FLAGS_12_103 *psPermFlags = NULL;
	TPM_STCLEAR_FLAGS *psStClFlags = NULL;
	IFX_FIELDUPGRADEINFO *psFUInfo = NULL;
	UINT32 dwInfoLen = 0;
	UINT32 dwEndian = 0;
	BYTE abStrValue[ST_EL_BIG_SZ];
	BYTE abFileStrValue[ST_EL_BIG_SZ];
	// Use also for output size returned by GetCfgString(), because size is not needed anyway
	UINT32 dwFileValue = 0;

	do {
		Log("\n\nTPM flag check:\n");
		
		SAFE_CALLOC(psCapVerInf, sizeof(TPM_CAP_VERSION_INFO), &dwRCVal);
		SAFE_CALLOC(psPermFlags, sizeof(TPM_PERMANENT_FLAGS_12_103), &dwRCVal);
		SAFE_CALLOC(psStClFlags, sizeof(TPM_STCLEAR_FLAGS), &dwRCVal);
		SAFE_CALLOC(psFUInfo, sizeof(IFX_FIELDUPGRADEINFO), &dwRCVal);

		dwInfoLen = sizeof(TPM_CAP_VERSION_INFO);
		// Get Version Info from the TPM
		// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
		dwRCVal = TPM_GetCapability(TPM_CAP_VERSION_VAL, 0, 0, &dwInfoLen, (BYTE *) (psCapVerInf));
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			// Get reference version from the file
			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[VERSION]", "FIRMWARE", &dwFileValue, abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.2d.%.2d.%.2d.%.2d",
					psCapVerInf->version.major,
					psCapVerInf->version.minor,
					psCapVerInf->version.revMajor, psCapVerInf->version.revMinor);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the Firmware version detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;
		} else
			Log("TPM_GetCapability (TPM_CAP_VERSION_VAL) error !!!\n\n");

		dwInfoLen = sizeof(TPM_PERMANENT_FLAGS_12_103);
		// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_PERMANENT);
		dwRCVal =
			TPM_GetCapability(TPM_CAP_FLAG, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen,
					    (BYTE *) (psPermFlags));
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "Disable", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->disable);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"disable\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "Ownership", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->ownership);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"ownership\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "Deactivated", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->deactivated);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"deactivated\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "ReadPubek", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->readPubek);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"readPubek\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "DisableOwnerClear",
						&dwFileValue, abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->disableOwnerClear);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"disableOwnerClear\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "PhysPresLifetimeLock",
						&dwFileValue, abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->physicalPresenceLifetimeLock);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"physicalPresenceLifetimeLock\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "PhysPresHWEnable", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->physicalPresenceHWEnable);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"physicalPresenceHWEnable\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "PhysPresCMDEnable",
						&dwFileValue, abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->physicalPresenceCMDEnable);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"physicalPresenceCMDEnable\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "operator", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->bOperator);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"operator\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "nvLocked", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->nvLocked);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"nvLocked\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "readSRKPub", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->readSRKPub);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"readSRKPub\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Persistent_flags]", "tpmEstablished", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psPermFlags->tpmEstablished);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the permanent flag \"tpmEstablished\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;
		} else
			Log("TPM_GetCapability (persistent flags) error !!!\n\n");

		//---------------------------------------------------------------------------

		dwInfoLen = sizeof(TPM_STCLEAR_FLAGS);
		// WARNING: No endian conversion of the results is supplied in TPM_GetCapability!
		// Argument 3: was UINT32, now BYTE *
		dwEndian = dwSwitchEndian32(TPM_CAP_FLAG_VOLATILE);
		dwRCVal =
			TPM_GetCapability(TPM_CAP_FLAG, sizeof(UINT32), (BYTE *) & dwEndian, &dwInfoLen,
					    (BYTE *) (psStClFlags));
		if (dwRCVal == RC_SUCCESS && dwInfoLen) {
			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Volatile_flags]", "Deactivated", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psStClFlags->deactivated);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the st_clear flag \"deactivated\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Volatile_flags]", "DisableForceClear", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psStClFlags->disableForceClear);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the st_clear flag \"disableForceClear\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Volatile_flags]", "PhysicalPresence", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psStClFlags->physicalPresence);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the st_clear flag \"physicalPresence\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Volatile_flags]", "PhysicalPresenceLock",
						&dwFileValue, abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psStClFlags->physicalPresenceLock);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the st_clear flag \"physicalPresenceLock\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal =
				GetCfgString(pcFlagCheckFileName, "[Volatile_flags]", "GlobalLock", &dwFileValue,
						abFileStrValue);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (abFileStrValue[0] != 'X') {
				sprintf(abStrValue, "%.1d", psStClFlags->bGlobalLock);
				if (!strcmp(abFileStrValue, abStrValue))
					dwRCVal = RC_SUCCESS;
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					Log("Mismatch of the st_clear flag \"bGlobalLock\" detected\n\n");
					break;
				}
			}
			if (dwRCVal != RC_SUCCESS)
				break;

		} else
			Log("TPM_GetCapability (volatile flags) error !!!\n\n");

		dwRCVal = TPM_FieldUpgradeInfoRequest(psFUInfo);
		switch (dwRCVal) {
			case RC_SUCCESS:
				dwRCVal =
					GetCfgString(pcFlagCheckFileName, "[VERSION]", "ROMCRC", &dwFileValue, abFileStrValue);
				if (dwRCVal != RC_SUCCESS)
					break;
				if (abFileStrValue[0] != 'X') {
					sprintf(abStrValue, "%.4X", psFUInfo->romCRC);
					if (!strcmp(abFileStrValue, abStrValue))
						dwRCVal = RC_SUCCESS;
					else {
						dwRCVal = RC_E_INVALID_PARAM;
						Log("Mismatch of the ROM-CRC detected\n\n");
						break;
					}
				}
				if (dwRCVal != RC_SUCCESS)
					break;
				// Do not consider TPM warnings as errors
			case TPM_E_IFX_RETRY: 
			case TPM_E_IFX_NEEDS_SELFTEST:
			case TPM_E_IFX_DOING_SELFTEST:
			case TPM_E_IFX_DEFEND_LOCK_RUNNING: 
				break;
			case TPM_E_IFX_DEACTIVATED:
				Log("Could not perform ROM-CRC check as TPM is deactivated\n");
				dwRCVal = RC_SUCCESS;
				break;
			case TPM_E_IFX_DISABLED:
				Log("Could not perform ROM-CRC check as TPM is disabled\n");
				dwRCVal = RC_SUCCESS;
				break;
			default:
				Log("TPM_FieldUpgradeInfoRequest error !!!\n");
		}
		Log("\n");

	} while (FALSE);

	SAFE_FREE(psCapVerInf);
	SAFE_FREE(psPermFlags);
	SAFE_FREE(psStClFlags);
	SAFE_FREE(psFUInfo);

	return dwRCVal;
}

/*++
TestTPM

Description:
Perform a test of the TPM step-by-step or continuous

Arguments:
[in]	BYTE	bTestType	ATTENDED = step-by-step, UNATTENDED = continuous

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TestTPM(BYTE bTestType)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bTestResult[10];
	UINT32 dwSize = 0, i = 0;

	do {
		// Perform TPM_SelfTestFull
		Log("\nPerforming a TPM_SelfTestFull\n");
		dwRCVal = TPM_SimpleCommand(TPM_ORD_SelfTestFull);
		if (dwRCVal == TPM_E_IFX_FAILEDSELFTEST) {
			// Perform TPM_GetTestResult
			Log("\nGet test results of the TPM_SelfTestFull\n\n");
			dwSize = sizeof(bTestResult);
			dwRCVal = TPM_GetTestResult(&dwSize, &bTestResult[0]);
			if (dwRCVal != RC_SUCCESS)
				Log("\tOperation TPM_GetTestResult failed !!!\n\n");
			else {
				Log("\tTPM_GetTestResult returned the TPM test state: ");
				for (i = 0; i < dwSize; i++) {
					Log("%.2X", bTestResult[i]);
				}
				Log("\n\n");
				if (bTestType == ATTENDED) {
					WaitForAnyKey();
					printf("\n\n\n");
				}
			}
			break;
		}

		if (dwRCVal != RC_SUCCESS) {
			Log("\tOperation TPM_SelfTestFull failed !!!\n\n");
			break;
		}

		Log("\n\tFull TPM selftest completed successfully\n\n");
		if (bTestType == ATTENDED) {
			WaitForAnyKey();
			printf("\n\n");
		}
		// Get the TPM Info
		if (bChipDetected == TPM1_1)
			dwRCVal = ShowTPM11info();
		if (bChipDetected == TPM1_2)
			dwRCVal = ShowTPM12info();
		if (dwRCVal != RC_SUCCESS)
			break;

		Log("\nTests of the TPM hardware finished, no errors\n\n");
	} while (FALSE);

	return dwRCVal;
}

/*++
OwnerSetDisable

Description:
The TPM owner sets the PERMANENT disable flag

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 OwnerSetDisable(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value

	BYTE bDisableState = ON;	// Value for disable state - enable if TRUE
	TPM_AUTHHANDLE dwAuthHandle = 0;	// The authorization session handle used for owner authentication.
	TPM_NONCE *psAuthLastNonceEven = NULL;	// Even nonce previously generated by TPM to cover inputs
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle

	do {
		// Allocate memory for temporary variables

		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;

		if (bNegativeTest)
			bDisableState = 0xFF;

		// Perform TPM_OwnerSetDisable
		dwRCVal = TPM_OwnerSetDisable(bDisableState,
					      dwAuthHandle,
					      psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tThe TPM owner sets the PERMANENT disable flag failed !!!\n");

	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);
	SAFE_FREE(psAuthLastNonceEven);

	return dwRCVal;
}

/*++
SetTempDeactivated

Description:
This command allows the operator of the platform to deactivate the TPM until the next boot
of the platform.

Arguments:
[in]	BOOL	bWithAuth	Specify whether command is with authentication or physical presence

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 SetTempDeactivated(BOOL bWithAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i;

	BYTE *pbOperatorAuth = NULL;

	TPM_AUTHHANDLE dwAuthHandle = 0;	// Auth handle for operation validation. Session type MUST be OIAP
	TPM_NONCE *psAuthLastNonceEven = NULL;	// Even nonce previously generated by TPM to cover inputs
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(pbOperatorAuth, HASH_LEN, &dwRCVal);
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		for (i = 0; i < HASH_LEN; i++)
			pbOperatorAuth[i] = (BYTE) i;

		if (!bWithAuth)
			dwAuthHandle = 0;
		else {
			// Get Authorization Session handle and even nonce
			dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (bNegativeTest)
				memset(psAuthLastNonceEven, 0, sizeof(TPM_NONCE));
		}
		// Perform TPM_OwnerSetDisable
		dwRCVal = TPM_SetTempDeactivated(dwAuthHandle,
						 psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOperatorAuth);
		if (dwRCVal != RC_SUCCESS)
			break;

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tThe TPM is set temporary deactivated failed !!!\n");

	SAFE_FREE(pbOperatorAuth);
	SAFE_FREE(psAuthLastNonceEven);

	return dwRCVal;
}

/*++
SetOperatorAuth

Description:
This command allows the setting of the operator AuthData value.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 SetOperatorAuth(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	TPM_SECRET *psOperatorAuth = NULL;	// HMAC key: operatorAuth

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psOperatorAuth, sizeof(TPM_AUTHDATA), &dwRCVal);

		// bNegativeTest doesn't work
		for (i = 0; i < sizeof(TPM_AUTHDATA); i++)
			psOperatorAuth->authdata[i] = (BYTE) i;

		// Perform TPM_SetOperatorAuth
		dwRCVal = TPM_SetOperatorAuth(psOperatorAuth);
		if (dwRCVal != RC_SUCCESS)
			break;

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tThe TPM set operator authentication failed !!!\n");

	SAFE_FREE(psOperatorAuth);

	return dwRCVal;
}

/*++
TakeOwnership

Description:
Take TPM Ownership with owner password from config file

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Markus Schmoelzer	2007/02/23
--*/
DISABLE_OPTIMIZATION	// because of memset optimization of loops 
UINT32 UNOPTIMIZED TakeOwnership(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value
	BYTE *pbEncOA = NULL;	// Encrypted owner authentication value
	UINT16 wEncOASize = KEY_LEN;	// Encrypted owner authentication value size

	BYTE abSrkHash[] = SRK_HASH;	// Storage Root Key hash value = SRK authentication value
	BYTE *pbEncSA = NULL;	// Encrypted SRK authentication value
	UINT16 wEncSASize = KEY_LEN;	// Encrypted SRK authentication value size

	BYTE *pbPublicEk = NULL;	// Public Endorsement Key
	UINT32 dwPublicEkLen = 0;	// Public Endorsement Key length

	TPM_AUTHHANDLE dwAuthHandle = 0;	// Authorization session handle
	TPM_NONCE *psAuthLastNonceEven = NULL;	// Even nonce to be generated by TPM prior TPM_TakeOwnership

	TPM_KEY_TKOWN_RQU *psSrkParms = NULL;	// SRK parameters (pubKey.keyLength and encSize are both 0!)

	UINT32 dwKeySize = 0;	// New SRK length
	BYTE *psSrkPub = NULL;	// New SRK

	do {
		// Allocate memory for temporary variables
		dwPublicEkLen = KEY_LEN;
		dwKeySize = KEY_LEN;

		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);
		SAFE_CALLOC(pbEncOA, KEY_LEN, &dwRCVal);
		SAFE_CALLOC(pbEncSA, KEY_LEN, &dwRCVal);
		SAFE_CALLOC(pbPublicEk, KEY_LEN, &dwRCVal);
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psSrkParms, sizeof(TPM_KEY_TKOWN_RQU), &dwRCVal);
		SAFE_CALLOC(psSrkPub, KEY_LEN, &dwRCVal);

		// Get Public Endorsement Key
		dwRCVal = TPM_ReadPubek(&dwPublicEkLen, pbPublicEk);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = RSA_Encrypt(pbOwnerPWHash, HASH_LEN, pbEncOA, &wEncOASize, pbPublicEk, NULL);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Encrypt SRK authentication data
		dwRCVal = RSA_Encrypt(abSrkHash, HASH_LEN, pbEncSA, &wEncSASize, pbPublicEk, NULL);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Set SRK parameters
		psSrkParms->ver.major = 1;
		psSrkParms->ver.minor = 1;
		psSrkParms->ver.revMajor = 0;
		psSrkParms->ver.revMinor = 0;
		if (bNegativeTest)
			psSrkParms->keyUsage = 0;
		else
			psSrkParms->keyUsage = wSwitchEndian16(TPM_KEY_STORAGE);
		psSrkParms->keyFlags = 0;
		psSrkParms->authDataUsage = TPM_AUTH_ALWAYS;
		psSrkParms->algorithmParms.algorithmID = dwSwitchEndian32(0x00000001);
		psSrkParms->algorithmParms.encScheme = wSwitchEndian16(TPM_ES_RSAESOAEP_SHA1_MGF1);
		psSrkParms->algorithmParms.sigScheme = wSwitchEndian16(TPM_SS_NONE);
		psSrkParms->algorithmParms.parmSize = dwSwitchEndian32(sizeof(TPM_RSA_KEY_PARMS));
		psSrkParms->algorithmParms.parms.keyLength = dwSwitchEndian32(0x800);
		psSrkParms->algorithmParms.parms.numPrimes = dwSwitchEndian32(2);
		psSrkParms->algorithmParms.parms.exponentSize = 0;
		psSrkParms->PCRInfoSize = 0;
		psSrkParms->pubKey.keyLength = 0;
		psSrkParms->encSize = 0;

		// Perform TPM_TakeOwnership
		dwRCVal = TPM_TakeOwnership(KEY_LEN,
					    pbEncOA,
					    KEY_LEN,
					    pbEncSA,
					    (TPM_KEY *) psSrkParms,
					    dwAuthHandle,
					    psAuthLastNonceEven,
					    FALSE, (TPM_AUTHDATA *) pbOwnerPWHash, &dwKeySize, psSrkPub);
		if (dwRCVal != RC_SUCCESS || dwKeySize == 0)
			break;

		// Print and save new SRK
		Log("\nPublic SRK:\n");
		Dump(TG_BOTH, MD_HEX, psSrkPub, dwKeySize);

/*
		SaveToFile(B_SRK_FILE_NAME, psSrkPub, dwKeySize, MD_BIN);
		SaveToFile(H_SRK_FILE_NAME, psSrkPub, dwKeySize, MD_HEX);
		Log("\n\tPublic SRK saved to \"%s\" (binary) and \"%s\" (hex)\n",
			B_SRK_FILE_NAME, H_SRK_FILE_NAME);
*/

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tOperation TakeOwnership failed !!!\n");
	else {
		// After a successful Takeownership enable the readout of the PubEK without owner auth
		// Get Authorization Session handle and even nonce
		Log("\nEnable the readout of the PubEK without owner auth\n");
		dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
		if (dwRCVal == RC_SUCCESS) {
			// Prepare and execute to set the TPM_PF_READPUBEK
			UINT32 dwCapArea = TPM_SET_PERM_FLAGS;
			UINT32 dwSubCapSize = sizeof(UINT32);
			UINT32 dwSubCap = dwSwitchEndian32(TPM_PF_READPUBEK);
			UINT32 dwSetValueSize = sizeof(BYTE);
			BYTE bSetValue = TRUE;
			BYTE bContinueAuthSession = FALSE;

			// Perform TPM_SetCapability
			dwRCVal = TPM_SetCapability(dwCapArea,
						    dwSubCapSize,
						    (BYTE *) & dwSubCap,
						    dwSetValueSize,
						    (BYTE *) & bSetValue,
						    dwAuthHandle,
						    psAuthLastNonceEven,
						    bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash);
		}
		if (dwRCVal != RC_SUCCESS)
			Log("\n\tEnabling the readout of the PubEK without owner auth failed !!!\n");
	}

	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);
	SAFE_FREE(pbEncOA);
	SAFE_FREE(pbEncSA);
	SAFE_FREE(pbPublicEk);
	SAFE_FREE(psAuthLastNonceEven);
	SAFE_FREE(psSrkParms);
	SAFE_FREE(psSrkPub);

	return dwRCVal;
}
ENABLE_OPTIMIZATION

/*++
OwnerClear

Description:
The TPM_OwnerClear command performs the clear operation under Owner authentication.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 OwnerClear(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value

	TPM_AUTHHANDLE dwAuthHandle = 0;	// The authorization session handle used for owner authentication.
	TPM_NONCE *psAuthLastNonceEven = NULL;	// Even nonce previously generated by TPM to cover inputs
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle

	do {
		// Allocate memory for temporary variables

		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;
		if (bNegativeTest)
			memset(psAuthLastNonceEven, 0, sizeof(TPM_NONCE));

		// Perform TPM_OwnerClear
		dwRCVal = TPM_OwnerClear(dwAuthHandle,
					 psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tClear operation under Owner authentication failed !!!\n");

	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);
	SAFE_FREE(psAuthLastNonceEven);

	return dwRCVal;
}

/*++
SetCapability

Description:
This command sets values in the TPM.

Arguments:
[in]	BOOL	bWithAuth	Specify whether command is with authentication or physical presence

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 SetCapability(BOOL bWithAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value

	TPM_CAPABILITY_AREA dwCapArea = 0;
	UINT32 dwSubCapSize = 0;
	BYTE *abSubCap = NULL;
	UINT32 dwSetValueSize = 0;
	BYTE *abSetValue = NULL;
	TPM_AUTHHANDLE dwAuthHandle = 0;	// Authorization session handle
	TPM_NONCE *psAuthLastNonceEven = NULL;
	BYTE bContinueAuthSession = FALSE;
	TPM_AUTHDATA *psOwnerAuth = NULL;

	do {
		// Allocate memory for temporary variables

		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);
		SAFE_CALLOC(abSubCap, sizeof(UINT32), &dwRCVal);
		SAFE_CALLOC(abSetValue, sizeof(BYTE), &dwRCVal);
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psOwnerAuth, sizeof(TPM_AUTHDATA), &dwRCVal);

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		if (!bWithAuth)
			dwAuthHandle = 0;
		else {
			// Get Authorization Session handle and even nonce
			dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
			if (dwRCVal != RC_SUCCESS)
				break;
		}
		if (bNegativeTest)
			dwCapArea = 0;
		else
			dwCapArea = TPM_PF_DISABLE;
		dwSubCapSize = 4;

		abSubCap[0] = (BYTE) (TPM_PF_DISABLE >> 24);
		abSubCap[1] = (BYTE) (TPM_PF_DISABLE >> 16);
		abSubCap[2] = (BYTE) (TPM_PF_DISABLE >> 8);
		abSubCap[3] = (BYTE) (TPM_PF_DISABLE);

		dwSetValueSize = 1;
		abSetValue[0] = TRUE;

		// Perform TPM_SetCapability
		dwRCVal = TPM_SetCapability(dwCapArea,
					    dwSubCapSize,
					    abSubCap,
					    dwSetValueSize,
					    abSetValue,
					    dwAuthHandle,
					    psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash);
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM set capability failed !!!\n");

	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);
	SAFE_FREE(abSubCap);
	SAFE_FREE(abSetValue);
	SAFE_FREE(psAuthLastNonceEven);
	SAFE_FREE(psOwnerAuth);

	return dwRCVal;
}

/*++
Seal

Description:
The SEAL operation allows software to explicitly state the future trusted configuration
that the platform must be in for the secret to be revealed.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/10
--*/

UINT32 Seal(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the OSAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	TPM_ENTITY_TYPE wEntityType = TPM_ET_KEYHANDLE;
	UINT32 dwEntityValue = TPM_KH_SRK;
	TPM_NONCE *psNonceOddOSAP = NULL;
	TPM_NONCE *psNonceEven = NULL;
	TPM_NONCE *psNonceEvenOSAP = NULL;
	TPM_AUTHDATA sSRKAuth= SRK_HASH;

	TPM_KEY_HANDLE dwKeyHandle = TPM_KH_SRK;
	TPM_ENCAUTH *psEncAuth = NULL;
	UINT32 dwPcrInfoSize = 0;
	TPM_PCR_INFO *psPcrInfo = NULL;
	UINT32 dwInDataSize = dwSealInputDataSize;
	BYTE *pbInData = NULL;
	TPM_AUTHHANDLE dwAuthHandle = 0;	// OSAP Authorization session handle
	BYTE bContinueAuthSession = FALSE;
	TPM_AUTHDATA *psSharedSecret = NULL;

	do {
		// Initialize temporary data buffers for HMAC calculation according to the OIAP
		wInParamDigestSize = 2 * HASH_LEN;
		wHmacInputSize = 2 * sizeof(TPM_NONCE);

		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Allocate memory for temporary variables
		SAFE_CALLOC(psNonceOddOSAP, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEvenOSAP, sizeof(TPM_NONCE), &dwRCVal);

		SAFE_CALLOC(psEncAuth, sizeof(TPM_ENCAUTH), &dwRCVal);
		SAFE_CALLOC(psPcrInfo, sizeof(TPM_PCR_INFO), &dwRCVal);
		SAFE_CALLOC(psSharedSecret, sizeof(TPM_AUTHDATA), &dwRCVal);

		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psNonceOddOSAP->nonce[i] = (BYTE) i;

		dwRCVal = TPM_OSAP(wEntityType, dwEntityValue, psNonceOddOSAP, &dwAuthHandle, psNonceEven, psNonceEvenOSAP);
		if (dwRCVal != RC_SUCCESS)
			break;

		i = 0;
		memcpy(&(pbHmacInput[i]), psNonceEvenOSAP, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), psNonceOddOSAP, sizeof(TPM_NONCE));
		//i += sizeof(TPM_NONCE);//Dead increment

		// Create HMAC for authenticated TPM command according to OSAP
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) & sSRKAuth, (BYTE *) psSharedSecret);
		if (dwRCVal != RC_SUCCESS)
			break;

		memcpy(pbInParamDigest, psSharedSecret, HASH_LEN);
		memcpy(&(pbInParamDigest[HASH_LEN]), psNonceEven, HASH_LEN);
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, (BYTE *) psEncAuth);
		if (dwRCVal != RC_SUCCESS)
			break;

		memset(psPcrInfo, 0, sizeof(TPM_PCR_INFO));

		pbInData = abSealInputData;

		if (bNegativeTest)
			// set to a small size for error return
			dwSealedDataSize = 20;
		else
			dwSealedDataSize = DEFAULT_BUFFERSIZE;

		// Perform TPM_Seal
		dwRCVal = TPM_Seal(dwKeyHandle,
				   psEncAuth,
				   dwPcrInfoSize,
				   psPcrInfo,
				   dwInDataSize,
				   pbInData,
				   dwAuthHandle,
				   psNonceEven,
				   bContinueAuthSession,
				   (TPM_AUTHDATA *) psSharedSecret, &dwSealedDataSize, (TPM_STORED_DATA *) abSealedData);
		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, abSealedData, dwSealedDataSize);

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM seal failed !!!\n");

	SAFE_FREE(pbInParamDigest);
	SAFE_FREE(pbHmacInput);

	SAFE_FREE(psNonceOddOSAP);
	SAFE_FREE(psNonceEven);
	SAFE_FREE(psNonceEvenOSAP);

	SAFE_FREE(psEncAuth);
	SAFE_FREE(psPcrInfo);
	SAFE_FREE(psSharedSecret);

	return dwRCVal;
}

/*++
Unseal

Description:
The TPM_Unseal operation will reveal TPM_Seal'ed data only if it was encrypted on this
platform and the current configuration (as defined by the named PCR contents) is the one
named as qualified to decrypt it.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/04/23
--*/

UINT32 Unseal(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_KEY_HANDLE dwParentHandle = TPM_KH_SRK;
	//UINT32                  dwInDataSize;
	//TPM_STORED_DATA         *psInData;
	TPM_AUTHHANDLE dwAuthHandle = 0;
	TPM_NONCE *psAuthLastNonceEven = NULL;
	BYTE bContinueAuthSession = FALSE;
	TPM_AUTHDATA *psParentAuth = NULL;
	TPM_AUTHHANDLE dwDataAuthHandle = 0;
	TPM_NONCE *psDataLastNonceEven = NULL;
	BYTE bContinueDataSession = FALSE;
	TPM_AUTHDATA *psDataAuth = NULL;

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psParentAuth, sizeof(TPM_AUTHDATA), &dwRCVal);
		SAFE_CALLOC(psDataLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psDataAuth, sizeof(TPM_AUTHDATA), &dwRCVal);

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;

		memset(psParentAuth, 0, sizeof(TPM_AUTHDATA));

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwDataAuthHandle, psDataLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;
		if (bNegativeTest)
			memset(psDataLastNonceEven, 0, sizeof(TPM_NONCE));

		memset(psDataAuth, 0, sizeof(TPM_AUTHDATA));

		// Perform TPM_Unseal
		dwRCVal = TPM_Unseal(dwParentHandle,
				     dwSealedDataSize,
				     (TPM_STORED_DATA *) abSealedData,
				     dwAuthHandle,
				     psAuthLastNonceEven,
				     bContinueAuthSession,
				     psParentAuth,
				     dwDataAuthHandle,
				     psDataLastNonceEven, bContinueDataSession, psDataAuth, &dwSealedDataSize, abSealedData);

		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, abSealedData, dwSealedDataSize);
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM unseal failed !!!\n");

	SAFE_FREE(psAuthLastNonceEven);
	SAFE_FREE(psParentAuth);
	SAFE_FREE(psDataLastNonceEven);
	SAFE_FREE(psDataAuth);

	return dwRCVal;
}

/*++
CreateWrapKey

Description:
The TPM_CreateWrapKey command both generates and creates a secure storage bundle for
asymmetric keys.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/04/23
--*/
UINT32 CreateWrapKey(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wOffset = 0;
	char *pbRqu = NULL;

	// Temporary data buffers for HMAC calculation according to the authorization
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	TPM_ENTITY_TYPE wEntityType = TPM_ET_KEYHANDLE;
	UINT32 dwEntityValue = TPM_KH_SRK;
	TPM_NONCE *psNonceOddOSAP = NULL;
	TPM_NONCE *psNonceEven = NULL;
	TPM_NONCE *psNonceEvenOSAP = NULL;
	TPM_AUTHDATA sSRKAuth = SRK_HASH;

	TPM_KEY_HANDLE dwParentHandle = TPM_KH_SRK;
	TPM_ENCAUTH *psDataUsageAuth = NULL;
	TPM_ENCAUTH *psDataMigrationAuth = NULL;
	UINT32 dwKeyInfoSize = KEY_LEN;
	TPM_KEY12 *psKeyInfo = NULL;
	TPM_AUTHHANDLE dwAuthHandle = 0;	// Authorization session handle
	// TPM_NONCE                            *psAuthLastNonceEven;   // nonce to be generated by TPM prior TPM_TakeOwnership
	// BYTE                                 bContinueAuthSession;   // Ignored
	// TPM_AUTHDATA            *psPubAuth;
	TPM_AUTHDATA *psSharedSecret = NULL;

	do {
		// Initialize temporary data buffers for HMAC calculation according to the authorization
		wInParamDigestSize = 2 * HASH_LEN;
		wHmacInputSize = 2 * sizeof(TPM_NONCE);

		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Allocate memory for temporary variables
		SAFE_CALLOC(psNonceOddOSAP, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEvenOSAP, sizeof(TPM_NONCE), &dwRCVal);

		SAFE_CALLOC(psDataUsageAuth, sizeof(TPM_ENCAUTH), &dwRCVal);
		SAFE_CALLOC(psDataMigrationAuth, sizeof(TPM_ENCAUTH), &dwRCVal);
		SAFE_CALLOC(psKeyInfo, dwKeyInfoSize, &dwRCVal);
		SAFE_CALLOC(psSharedSecret, sizeof(TPM_AUTHDATA), &dwRCVal);

		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psNonceOddOSAP->nonce[i] = (BYTE) i;

		dwRCVal = TPM_OSAP(wEntityType, dwEntityValue, psNonceOddOSAP, &dwAuthHandle, psNonceEven, psNonceEvenOSAP);
		if (dwRCVal != RC_SUCCESS)
			break;

		i = 0;
		memcpy(&(pbHmacInput[i]), psNonceEvenOSAP, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), psNonceOddOSAP, sizeof(TPM_NONCE));
		//i += sizeof(TPM_NONCE);//Dead increment

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) & sSRKAuth, (BYTE *) psSharedSecret);
		if (dwRCVal != RC_SUCCESS)
			break;

		memcpy(pbInParamDigest, psSharedSecret, HASH_LEN);
		memcpy(&(pbInParamDigest[HASH_LEN]), psNonceEven, HASH_LEN);
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, (BYTE *) psDataUsageAuth);
		if (dwRCVal != RC_SUCCESS)
			break;
		for (i = 0; i < sizeof(HASH_LEN); i++)
			psDataUsageAuth->authdata[i] = psDataUsageAuth->authdata[i] ^ sSRKAuth.authdata[i];

		memset(psDataMigrationAuth, 0, sizeof(TPM_ENCAUTH));

		// fill TPM_KEY12
		pbRqu = (char *)psKeyInfo;
		wOffset = 0;
		// This field is a byte array (TPM_KEY) or a 2 word field (TPM_KEY12)
		pbRqu[wOffset++] = (BYTE) (TPM_TAG_KEY12);	// TPM_TAG_KEY12
		pbRqu[wOffset++] = (BYTE) (TPM_TAG_KEY12 >> 8);
		pbRqu[wOffset++] = 0;	// fill
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = (BYTE) (TPM_KEY_SIGNING);	// keyUsage 0x0015
		pbRqu[wOffset++] = (BYTE) (TPM_KEY_SIGNING >> 8);
		pbRqu[wOffset++] = (BYTE) (0x0000000C);	// TPM_KEY_FLAGS.isVolatile keyFlags 0x04
		pbRqu[wOffset++] = (BYTE) (0x0000000C >> 8);
		pbRqu[wOffset++] = (BYTE) (0x0000000C >> 16);
		pbRqu[wOffset++] = (BYTE) (0x0000000C >> 24);
		pbRqu[wOffset++] = TPM_AUTH_NEVER;	// authDataUsage 0x00
		pbRqu[wOffset++] = (BYTE) (TPM_ALG_RSA);	// algorithmParms.algorithmID 0x00000001
		pbRqu[wOffset++] = (BYTE) (TPM_ALG_RSA >> 8);
		pbRqu[wOffset++] = (BYTE) (TPM_ALG_RSA >> 16);
		pbRqu[wOffset++] = (BYTE) (TPM_ALG_RSA >> 24);
		pbRqu[wOffset++] = (BYTE) (TPM_ES_NONE);	// algorithmParms.encScheme 0x0001
		pbRqu[wOffset++] = (BYTE) (TPM_ES_NONE >> 8);
		pbRqu[wOffset++] = (BYTE) (TPM_SS_RSASSAPKCS1v15_SHA1);	// algorithmParms.sigScheme 0x0002
		pbRqu[wOffset++] = (BYTE) (TPM_SS_RSASSAPKCS1v15_SHA1 >> 8);
		pbRqu[wOffset++] = (BYTE) (0x0000000C);	// algorithmParms.parmSize
		pbRqu[wOffset++] = (BYTE) (0x0000000C >> 8);
		pbRqu[wOffset++] = (BYTE) (0x0000000C >> 16);
		pbRqu[wOffset++] = (BYTE) (0x0000000C >> 24);
DISABLE_WARNING(4310)
		pbRqu[wOffset++] = (BYTE) (0x00000800);	// algorithmParms.parms.keyLength
RESTORE_WARNING(4310)
		pbRqu[wOffset++] = (BYTE) (0x00000800 >> 8);
		pbRqu[wOffset++] = (BYTE) (0x00000800 >> 16);
		pbRqu[wOffset++] = (BYTE) (0x00000800 >> 24);
		pbRqu[wOffset++] = (BYTE) (0x00000002);	// algorithmParms.parms.numPrimes
		pbRqu[wOffset++] = (BYTE) (0x00000002 >> 8);
		pbRqu[wOffset++] = (BYTE) (0x00000002 >> 16);
		pbRqu[wOffset++] = (BYTE) (0x00000002 >> 24);
		pbRqu[wOffset++] = 0;	// algorithmParms.parms.exponentSize
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;	// PCRInfoSize
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		// PCRInfo;                             // actually: BYTE* PCRInfo;
		pbRqu[wOffset++] = 0;	// pubkey.keyLength;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;	// encDataSize;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		pbRqu[wOffset++] = 0;
		// encData[1];                  // size_is(encDataSize)

		if (bNegativeTest)
			// Set to a value which is too small for key
			dwCreateWrapKeySize = 200;
		else
			dwCreateWrapKeySize = DEFAULT_BUFFERSIZE;

		// Perform TPM_CreateWrapKey
		dwRCVal = TPM_CreateWrapKey(dwParentHandle, psDataUsageAuth, psDataMigrationAuth, wOffset,	// dwKeyInfoSize,
					    (TPM_KEY *) psKeyInfo, dwAuthHandle, psNonceEven, (TPM_AUTHDATA *) psSharedSecret,	// psPubAuth
					    &dwCreateWrapKeySize, (TPM_KEY *) abCreateWrapKey);
		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, (BYTE *) abCreateWrapKey, dwCreateWrapKeySize);

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM create wrap key failed !!!\n");

	SAFE_FREE(pbInParamDigest);
	SAFE_FREE(pbHmacInput);

	SAFE_FREE(psNonceOddOSAP);
	SAFE_FREE(psNonceEven);
	SAFE_FREE(psNonceEvenOSAP);

	SAFE_FREE(psDataUsageAuth);
	SAFE_FREE(psDataMigrationAuth);
	SAFE_FREE(psKeyInfo);
	SAFE_FREE(psSharedSecret);

	return dwRCVal;
}

/*++
LoadKey2

Description:
The TPM_LoadKey2 function loads the
key into the TPM for further use.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/10
--*/

UINT32 LoadKey2(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_KEY_HANDLE dwParentHandle = TPM_KH_SRK;
	// UINT32                  dwInKeySize;
	// TPM_KEY                 *psInKey;
	TPM_AUTHHANDLE dwAuthHandle = 0;	// Authorization session handle
	TPM_NONCE *psAuthLastNonceEven = NULL;
	BYTE bContinueAuthSession = FALSE;
	// TPM_AUTHDATA            *psParentAuth;
	BYTE abSRKHash[HASH_LEN] = SRK_HASH;
	// TPM_KEY_HANDLE          dwInKeyHandle;

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;
		if (bNegativeTest)
			dwParentHandle = 0;

		// Perform TPM_LoadKey2
		dwRCVal = TPM_LoadKey2(dwParentHandle, dwCreateWrapKeySize,	// dwInKeySize
				       (TPM_KEY *) abCreateWrapKey,	// psInKey
				       dwAuthHandle, psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) abSRKHash,	// psKeyUsageAuth
				       &dwLoadKey2Handle);	// dwInKeyHandle
		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, (BYTE *) & dwLoadKey2Handle, sizeof(TPM_KEY_HANDLE));

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM load key 2 failed !!!\n");

	SAFE_FREE(psAuthLastNonceEven);

	return dwRCVal;
}

/*++
GetPubKey

Description:
The owner of a key may wish to obtain the public key value from a loaded key.

Arguments:
[in]	BOOL	bWithAuth	Specify whether command is with authentication or physical presence

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/04/23
--*/

UINT32 GetPubKey(BOOL bWithAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	// TPM_KEY_HANDLE          dwKeyHandle;
	TPM_AUTHHANDLE dwAuthHandle = 0;	// Authorization session handle
	TPM_NONCE *psAuthLastNonceEven = NULL;
	BYTE bContinueAuthSession = FALSE;
	//TPM_AUTHDATA            *psKeyAuth;
	BYTE abSRKHash[HASH_LEN] = SRK_HASH;
	UINT32 dwPubKeySize = DEFAULT_BUFFERSIZE;
	TPM_PUBKEY *psPubKey = NULL;

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psPubKey, dwPubKeySize, &dwRCVal);

		if (!bWithAuth)
			dwAuthHandle = 0;
		else {
			// Get Authorization Session handle and even nonce
			dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
			if (dwRCVal != RC_SUCCESS)
				break;
		}
		if (bNegativeTest)
			// set to a buffer size which is too small
			dwPubKeySize = 100;

		// Perform TPM_GetPubKey
		dwRCVal = TPM_GetPubKey(dwLoadKey2Handle,	// dwKeyHandle,
					dwAuthHandle, psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) abSRKHash,	// psKeyAuth,
					&dwPubKeySize, psPubKey);
		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, (BYTE *) psPubKey, dwPubKeySize);

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM get public key failed !!!\n");

	SAFE_FREE(psAuthLastNonceEven);
	SAFE_FREE(psPubKey);

	return dwRCVal;
}

/*++
Extend

Description:
This adds a new measurement to a PCR

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 Extend(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i;

	TPM_PCRINDEX dwPcrNum = 0;	// The PCR to be updated.
	TPM_DIGEST *psInDigest = NULL;	// The 160 bit value representing the event to be recorded.
	TPM_PCRVALUE *psOutDigest = NULL;	// Outgoing Operands and Sizes

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psInDigest, sizeof(TPM_DIGEST), &dwRCVal);
		SAFE_CALLOC(psOutDigest, sizeof(TPM_PCRVALUE), &dwRCVal);

		dwRCVal = PromptForNumber("Enter dwPcrNum:\n", &dwPcrNum);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		for (i = 0; i < sizeof(TPM_DIGEST); i++)
			psInDigest->digest[i] = (BYTE) i;

		dwRCVal = TPM_Extend(dwPcrNum, psInDigest, psOutDigest);
		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, (BYTE *) psOutDigest, sizeof(TPM_PCRVALUE));
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM extend failed !!!\n");

	SAFE_FREE(psInDigest);
	SAFE_FREE(psOutDigest);

	return dwRCVal;
}

/*++
PCRRead

Description:
This adds a new measurement to a PCR

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 PCRRead(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_PCRINDEX dwPcrIndex = 0;	// The PCR to be updated.
	TPM_PCRVALUE *psOutDigest = NULL;	// Outgoing Operands and Sizes

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psOutDigest, sizeof(TPM_PCRVALUE), &dwRCVal);

		dwRCVal = PromptForNumber("Enter dwPcrIndex:\n", &dwPcrIndex);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = TPM_PCRRead(dwPcrIndex, psOutDigest);

		if (dwRCVal != RC_SUCCESS)
			break;

		Dump(TG_BOTH, MD_HEX, (BYTE *) psOutDigest, sizeof(TPM_PCRVALUE));

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM PCR read failed !!!\n");

	SAFE_FREE(psOutDigest);

	return dwRCVal;
}

/*++
PCR_Reset

Description:
For PCR with the pcrReset attribute set to TRUE, this command resets the PCR back to the
default value, this mimics the actions of TPM_Init.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/03
--*/
UINT32 PCR_Reset(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT32 bitmap = 0;

	UINT32 dwPCRSelectionSize = 0;
	TPM_PCR_SELECTION12 sPcrSelection;	// The PCR to be updated.
	UINT32 number = 0;

	do {
		dwRCVal = PromptForNumber("Enter the PCR number to reset (0..23):\n", &number);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		sPcrSelection.sizeOfSelect = 3;
		if (number > 23) {
			Log("PCR number is not a valid value\n");
			break;
		} else {
			bitmap = 1 << number;
			printf("bitmap %x\n", bitmap);
			sPcrSelection.pcrSelect[2] = (BYTE) (bitmap >> 16);
			sPcrSelection.pcrSelect[1] = (BYTE) (bitmap >> 8);
			sPcrSelection.pcrSelect[0] = (BYTE) (bitmap);
			dwPCRSelectionSize = sizeof(sPcrSelection);

			dwRCVal = TPM_PCR_Reset(dwPCRSelectionSize, &sPcrSelection);
		}

		if (dwRCVal != RC_SUCCESS)
			break;
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM PCR reset failed !!!\n");

	return dwRCVal;
}

/*++
OSAP

Description:
The TPM_OSAP command creates the authorization session handle, the shared secret and
generates nonceEven and nonceEvenOSAP.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/10
--*/
UINT32 OSAP(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	TPM_ENTITY_TYPE wEntityType = 0;	// The type of entity in use
	UINT32 dwEntityValue = 0;	// The selection value based on entityType, e.g. a keyHandle #
	TPM_NONCE *psNonceOddOSAP = NULL;	// The nonce generated by the caller associated with the shared secret.

	TPM_AUTHHANDLE dwAuthHandle = 0;	// Handle that TPM creates that points to the authorization state.
	TPM_NONCE *psNonceEven = NULL;	// Nonce generated by TPM and associated with session.
	TPM_NONCE *psNonceEvenOSAP = NULL;	// Nonce generated by TPM and associated with shared secret.

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psNonceOddOSAP, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEvenOSAP, sizeof(TPM_NONCE), &dwRCVal);

		if (bNegativeTest)
			wEntityType = 0;
		else
			wEntityType = TPM_ET_SRK;
		dwEntityValue = TPM_KH_SRK;

		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psNonceOddOSAP->nonce[i] = (BYTE) i;

		// Perform TPM_OSAP
		dwRCVal = TPM_OSAP(wEntityType, dwEntityValue, psNonceOddOSAP, &dwAuthHandle, psNonceEven, psNonceEvenOSAP);
		if (dwRCVal != RC_SUCCESS)
			break;

		Log("Auth handle:\n");
		Dump(TG_BOTH, MD_HEX, (BYTE *) & dwAuthHandle, sizeof(TPM_AUTHHANDLE));
		Log("Nonce even:\n");
		Dump(TG_BOTH, MD_HEX, (BYTE *) psNonceEven, sizeof(TPM_NONCE));
		Log("Nonce even OSAP:\n");
		Dump(TG_BOTH, MD_HEX, (BYTE *) psNonceEvenOSAP, sizeof(TPM_NONCE));

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tOSAP failed !!!\n");

	SAFE_FREE(psNonceOddOSAP);
	SAFE_FREE(psNonceEven);
	SAFE_FREE(psNonceEvenOSAP);

	return dwRCVal;
}

/*++
NV_DefineSpace

Description:
This establishes the space necessary for the indicated index.

Arguments:
[in]	BOOL	bWithAuth	Specify whether command is with authentication or physical presence

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/10
--*/
UINT32 NV_DefineSpace(BOOL bWithAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value

	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	TPM_ENTITY_TYPE wEntityType = TPM_ET_OWNER;
	UINT32 dwEntityValue = 0;
	TPM_NONCE *psNonceOddOSAP = NULL;
	TPM_NONCE *psNonceEven = NULL;
	TPM_NONCE *psNonceEvenOSAP = NULL;

	UINT32 dwPubInfoSize = 0;
	TPM_NV_DATA_PUBLIC *psPubInfo = NULL;	// The public parameters of the NV area
	TPM_ENCAUTH *psEncAuth = NULL;	// The encrypted AuthData, only valid if the attributes require subsequent authorization
	TPM_AUTHHANDLE dwAuthHandle = 0;	// The authorization session handle used for ownerAuth
	TPM_NONCE *psAuthLastNonceEven = NULL;	// Even nonce newly generated by TPM to cover outputs
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle
	TPM_AUTHDATA *psSharedSecret = NULL;

	do {
		// Initialize temporary data buffers for HMAC calculation according to the OSAP
		wHmacInputSize = 2 * sizeof(TPM_NONCE);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Allocate memory for temporary variables
		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);

		SAFE_CALLOC(psNonceOddOSAP, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psNonceEvenOSAP, sizeof(TPM_NONCE), &dwRCVal);

		SAFE_CALLOC(psPubInfo, sizeof(TPM_NV_DATA_PUBLIC), &dwRCVal);
		SAFE_CALLOC(psEncAuth, sizeof(TPM_ENCAUTH), &dwRCVal);
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);
		SAFE_CALLOC(psSharedSecret, sizeof(TPM_AUTHDATA), &dwRCVal);

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwPubInfoSize = sizeof(TPM_NV_DATA_PUBLIC);

		psPubInfo->tag = TPM_TAG_NV_DATA_PUBLIC;
		psPubInfo->nvIndex = USER_DEF_INDEX;

		memset(&psPubInfo->pcrInfoRead, 0, sizeof(TPM_PCR_INFO_SHORT));
		psPubInfo->pcrInfoRead.pcrSelection.sizeOfSelect = 3;
		psPubInfo->pcrInfoRead.localityAtRelease = 0x1F;	// Locality 0-4

		memset(&psPubInfo->pcrInfoWrite, 0, sizeof(TPM_PCR_INFO_SHORT));
		psPubInfo->pcrInfoWrite.pcrSelection.sizeOfSelect = 3;
		psPubInfo->pcrInfoWrite.localityAtRelease = 0x1F;	// Locality 0-4

		psPubInfo->permission.tag = TPM_TAG_NV_ATTRIBUTES;
		psPubInfo->permission.attributes = TPM_NV_PER_PPWRITE | TPM_NV_PER_OWNERWRITE | TPM_NV_PER_OWNERREAD;

		psPubInfo->bReadSTClear = FALSE;
		psPubInfo->bWriteSTClear = FALSE;
		psPubInfo->bWriteDefine = FALSE;
		psPubInfo->dataSize = 16;

		memset(psEncAuth, 0, sizeof(TPM_ENCAUTH));

		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psNonceOddOSAP->nonce[i] = (BYTE) i;

		if (!bWithAuth)
			dwAuthHandle = 0;
		else {
			dwRCVal = TPM_OSAP(wEntityType,
					   dwEntityValue, psNonceOddOSAP, &dwAuthHandle, psNonceEven, psNonceEvenOSAP);
			if (dwRCVal != RC_SUCCESS)
				break;
			if (bNegativeTest)
				memset(psNonceEvenOSAP, 0, sizeof(TPM_NONCE));
		}

		i = 0;
		memcpy(&(pbHmacInput[i]), psNonceEvenOSAP, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), psNonceOddOSAP, sizeof(TPM_NONCE));
		//i += sizeof(TPM_NONCE);//Dead assignment

		// Create HMAC for authenticated TPM command according to OSAP
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) pbOwnerPWHash, (BYTE *) psSharedSecret);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Perform TPM_NV_DefineSpace
		dwRCVal = TPM_NV_DefineSpace(dwPubInfoSize, psPubInfo, psEncAuth, dwAuthHandle, psNonceEven,	// psAuthLastNonceEven,
					     bContinueAuthSession, (TPM_AUTHDATA *) psSharedSecret);	// pbOwnerPWHash
		if (dwRCVal != RC_SUCCESS)
			break;

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM define space failed !!!\n");

	SAFE_FREE(pbHmacInput);
	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);

	SAFE_FREE(psNonceOddOSAP);
	SAFE_FREE(psNonceEven);
	SAFE_FREE(psNonceEvenOSAP);

	SAFE_FREE(psPubInfo);
	SAFE_FREE(psEncAuth);
	SAFE_FREE(psAuthLastNonceEven);
	SAFE_FREE(psSharedSecret);

	return dwRCVal;
}

/*++
NV_WriteValue

Description:
This command writes the value to a defined area.

Arguments:
[in]	BOOL	bWithAuth	Specify whether command is with authentication or physical presence

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/04/04
--*/
UINT32 NV_WriteValue(BOOL bWithAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value

	TPM_NV_INDEX dwNvIndex = 0;	// The index of the area to set
	UINT32 dwOffset = 0;	// The offset into the NV Area
	UINT32 dwDataSize = 0;	// The size of the data parameter
	BYTE *abData = NULL;	// The data to set the area to
	TPM_AUTHHANDLE dwAuthHandle = 0;	// The authorization session handle used for TPM Owner
	TPM_NONCE *psAuthLastNonceEven = NULL;	// Even nonce newly generated by TPM to cover outputs
	//TPM_NONCE               *psAuthNonceOdd;    // Nonce generated by caller
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle

	do {

		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		if (bNegativeTest)
			// 0 is global lock, so take an invalid index
			dwNvIndex = 55;
		else
			dwNvIndex = USER_DEF_INDEX;
		dwOffset = 0;
		dwDataSize = 16;

		// Allocate memory for temporary variables
		SAFE_CALLOC(abData, dwDataSize, &dwRCVal);

		for (i = 0; i < 16; i++)
			abData[i] = (BYTE) i;

		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		if (!bWithAuth)
			dwAuthHandle = 0;
		else {
			// Get Authorization Session handle and even nonce
			dwRCVal = TPM_OIAP(&dwAuthHandle, psAuthLastNonceEven);
			if (dwRCVal != RC_SUCCESS)
				break;
		}

		// Perform TPM_NV_DefineSpace
		dwRCVal = TPM_NV_WriteValue(dwNvIndex,
					    dwOffset,
					    dwDataSize,
					    abData,
					    dwAuthHandle,
					    psAuthLastNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM NV write value failed !!!\n");

	SAFE_FREE(psAuthLastNonceEven);
	SAFE_FREE(abData);
	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);

	return dwRCVal;
}

/*++
NV_ReadValue

Description:
Read a value from the NV store. This command uses owner authentication.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/04/04
--*/
UINT32 NV_ReadValue(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	BYTE *pbOwnerPW = NULL;	// Owner password
	UINT32 dwOwnerPWSize = 0;	// Owner password size
	BYTE *pbOwnerPWHash = NULL;	// Owner password hash value = owner authentication value

	TPM_NV_INDEX dwNvIndex = 0;	// The index of the area to set
	UINT32 dwOffset = 0;	// The offset into the NV Area
	UINT32 dwDataSize = 0;	// The size of the data parameter
	BYTE *abData = NULL;	// The data to set the area to
	TPM_AUTHHANDLE dwAuthHandle = 0;	// The authorization session handle used for TPM Owner
	TPM_NONCE *psNonceEven = NULL;	// Even nonce newly generated by TPM to cover outputs
	//TPM_NONCE               *psAuthNonceOdd;    // Nonce generated by caller
	BYTE bContinueAuthSession = FALSE;	// The continue use flag for the authorization session handle

	do {

		SAFE_CALLOC(pbOwnerPW, MAX_VAL_LEN, &dwRCVal);
		SAFE_CALLOC(pbOwnerPWHash, HASH_LEN, &dwRCVal);

		// Get owner password, hash it and encrypt the result
		dwRCVal = GetCfgString(CFG_FILE_NAME, "[OWNER_PASSWORD]", "PASSWORD", &dwOwnerPWSize, pbOwnerPW);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = SHA1_Func(pbOwnerPW, (UINT16) dwOwnerPWSize, pbOwnerPWHash);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwNvIndex = USER_DEF_INDEX;
		dwOffset = 0;
		dwDataSize = 16;

		// Allocate memory for temporary variables
		SAFE_CALLOC(abData, dwDataSize, &dwRCVal);

		for (i = 0; i < dwDataSize; i++)
			abData[i] = (BYTE) i;

		SAFE_CALLOC(psNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwAuthHandle, psNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;

		if (bNegativeTest)
			memset(psNonceEven, 0, sizeof(TPM_NONCE));

		// Perform TPM_NV_DefineSpace
		dwRCVal = TPM_NV_ReadValue(dwNvIndex,
					   dwOffset,
					   &dwDataSize,
					   dwAuthHandle,
					   psNonceEven, bContinueAuthSession, (TPM_AUTHDATA *) pbOwnerPWHash, abData);
		if (dwRCVal != RC_SUCCESS)
			break;

	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM NV read value failed !!!\n");

	SAFE_FREE(psNonceEven);
	SAFE_FREE(abData);
	SAFE_FREE(pbOwnerPW);
	SAFE_FREE(pbOwnerPWHash);

	return dwRCVal;
}

/*++
FlushSpecific

Description:
TPM_FlushSpecific flushes from the TPM a specific handle.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/10
--*/
UINT32 FlushSpecific(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TPM_HANDLE dwHandle = 0;	// The handle of the item to flush
	TPM_NONCE *psAuthLastNonceEven = NULL;	// dummy for TPM_OIAP
	TPM_RESOURCE_TYPE dwResourceType = 0;	// The type of resource that is being flushed

	do {
		SAFE_CALLOC(psAuthLastNonceEven, sizeof(TPM_NONCE), &dwRCVal);

		// Get Authorization Session handle and even nonce
		dwRCVal = TPM_OIAP(&dwHandle, psAuthLastNonceEven);
		if (dwRCVal != RC_SUCCESS)
			break;

		if (bNegativeTest)
			dwResourceType = 0;	// invalid resource type
		else
			dwResourceType = TPM_RT_AUTH;

		dwRCVal = TPM_FlushSpecific(dwHandle, dwResourceType);

		if (dwRCVal != RC_SUCCESS)
			break;
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM flush specific failed !!!\n");

	SAFE_FREE(psAuthLastNonceEven);

	return dwRCVal;
}

/*++
GetTicks

Description:
This command returns the current tick count of the TPM.

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		H. Obermeier     2008/03/10
--*/
UINT32 GetTicks(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwCurrentTicksSize = sizeof(TPM_CURRENT_TICKS);
	TPM_CURRENT_TICKS *psCurrentTime = NULL;
	BYTE *pbHelp;
	BYTE bCount;

	do {
		// Allocate memory for temporary variables
		SAFE_CALLOC(psCurrentTime, sizeof(TPM_CURRENT_TICKS), &dwRCVal);

		if (bNegativeTest)
			dwCurrentTicksSize = 0;

		dwRCVal = TPM_GetTicks(&dwCurrentTicksSize, psCurrentTime);
		if (dwRCVal != RC_SUCCESS)
			break;

		// dump TPM_CURRENT_TICKS fields
		// tag
		Log("\ntag:\t\t %.4X\n", psCurrentTime->tag);
		// currentTicks
		Log("\ncurrentTicks:\t");
		pbHelp = (BYTE *) & (psCurrentTime->currentTicks.bUINT64[7]);
		for (bCount = 0; bCount < sizeof(TPM_UINT64); bCount++, pbHelp--)
			Log(" %.2X", *pbHelp);
		Log("\n");
		// tickRate
		Log("\ntickRate:\t %.4X\n", psCurrentTime->tickRate);
		// tickNonce
		Log("\ntickNonce:\t");
		pbHelp = (BYTE *) & (psCurrentTime->tickNonce);
		for (bCount = 0; bCount < sizeof(TPM_NONCE); bCount++, pbHelp++)
			Log(" %.2X", *pbHelp);
		Log("\n");
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
		Log("\n\tTPM get ticks failed !!!\n");

	SAFE_FREE(psCurrentTime);

	return dwRCVal;
}

/*++
IsTPMOwned
   
Description:
Gets if the TPM owner is set
   
Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	TRUE			The TPM owner is set
	FALSE			The TPM owner is not set

Author:  Georg Rankl (ran) 30.01.2004
   
--*/
BOOL IsTPMOwned(void)
{
	BOOL bState = TRUE;
	UINT32 dwSize;
	UINT32 dwSubCap;

	dwSize = sizeof(bState);
	dwSubCap = dwSwitchEndian32(TPM_CAP_PROP_OWNER);
	TPM_GetCapability(TPM_CAP_PROPERTY, sizeof(UINT32), (BYTE *) & dwSubCap, &dwSize, (BYTE *) & bState);

	return bState;
}

/*++
IsTPMEnabled
   
Description:
Gets if the TPM is enabled
   
Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	TRUE			The TPM owner is enabled
	FALSE			The TPM owner is disabled

Author:  Georg Rankl (ran) 30.01.2004
   
--*/
BOOL IsTPMEnabled(void)
{
	UINT32 dwRCVal;
	BOOL bState = FALSE;
	UINT32 dwSize;
	UINT32 dwSubCap;
	TPM_PERMANENT_FLAGS_12_103 tdPermanentFlags;
	TPM_STCLEAR_FLAGS tdVolatileFlags;

	dwSize = sizeof(tdPermanentFlags);
	dwSubCap = dwSwitchEndian32(TPM_CAP_FLAG_PERMANENT);
	dwRCVal = TPM_GetCapability(TPM_CAP_FLAG, sizeof(UINT32), (BYTE *) & dwSubCap, &dwSize, (BYTE *) & tdPermanentFlags);
	if (dwRCVal == RC_SUCCESS) {
		// Persistent disable || deactivated
		if ((tdPermanentFlags.disable == TRUE) || (tdPermanentFlags.deactivated == TRUE))
			bState = FALSE;
		else
			bState = TRUE;
	}
	if (bState == TRUE) {
		dwSize = sizeof(tdVolatileFlags);
		dwSubCap = dwSwitchEndian32(TPM_CAP_FLAG_VOLATILE);
		dwRCVal = TPM_GetCapability(TPM_CAP_FLAG,
					    sizeof(UINT32), (BYTE *) & dwSubCap, &dwSize, (BYTE *) & tdVolatileFlags);
		if (dwRCVal == RC_SUCCESS) {
			// Volatile deactivated
			if (tdVolatileFlags.deactivated == TRUE)
				bState = FALSE;
		} else
			bState = FALSE;
	}
	return bState;
}
