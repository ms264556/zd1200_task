/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Sealtest.c

Description:	Implementation of the TPM test functions using TPM_Seal
				and TPM_Unseal

Author:			Georg Rankl	2009/03/16

Environment:	16-Bit/DOS, 32-Bit/Windows, 32-Bit/Linux

Revision History:

Notes:

--*/

#include "FileIO.h"
#include "ProgFunc.h"
#include "TPM_Cmds.h"
#include "TPM_Func.h"
#include "TPM_Stru.h"

// external global buffers for Seal input and output
extern UINT32 dwSealInputDataSize;
extern BYTE abSealInputData[];
extern UINT32 dwSealedDataSize;
extern BYTE abSealedData[];

/*++
TPMSealTest

Description:
Perform a test for the TPM to verify the ability to seal and unseal data
with a comparison of the data whether the process was ok

Arguments:
none

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	operation failed
	UINT32			error return code

Author:		Georg Rankl	2009/03/16
--*/
UINT32 TPMSealTest()
{
	UINT32 dwRCVal = 0;
	BOOL bState;
	int bResult;
	BOOL bOwnerSet = FALSE;

	do {
		Log("\n\tStarting the TPM SealTest\n");

		// Call ContinueSelftest to avoid errors due to Selftest Needed
		dwRCVal = TPM_SimpleCommand(TPM_ORD_ContinueSelfTest);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Check if TPM is enabled
		bState = IsTPMEnabled();
		if (bState == FALSE) {
			dwRCVal = RC_E_DISABLED;
			break;
		}
		// Check if the TPM has already an Owner
		bState = IsTPMOwned();
		if (bState == TRUE) {
			dwRCVal = RC_E_HASOWNER;
			break;
		}

		Log("\n\tPerforming a TPM_TakeOwnership\n");
		dwRCVal = TakeOwnership();
		if (dwRCVal != RC_SUCCESS)
			break;

		// Flag that an owner has been successfully set
		bOwnerSet = TRUE;

		Log("\n\tSealing a constant data string to the platform\n");
		dwRCVal = Seal();
		if (dwRCVal != RC_SUCCESS)
			break;

		Log("\n\tUnsealing the previously sealed data string\n");
		dwRCVal = Unseal();
		if (dwRCVal != RC_SUCCESS)
			break;

		// Compare the input with the result
		bResult = memcmp(abSealInputData, abSealedData, dwSealInputDataSize);
		if (bResult != 0) {
			dwRCVal = RC_E_SEALTESTERROR;
			break;
		}

	} while (FALSE);

	if (bOwnerSet == TRUE)
		dwRCVal = OwnerClear();

	if (dwRCVal == RC_SUCCESS)
		// Sealtest was successful
		Log("\n\tPassed: The Sealtest was executed successfully\n");
	else
		// Sealtest failed
		Log("\n\tFailed: The Sealtest was not successful\n");

	return (dwRCVal);

}
