/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	RSA_Arit.c

Description:	Long integer arithmetics

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "RSA.h"
DISABLE_WARNING(4706)

// Internal arithmetics function prototypes -----------------------------------------------------
static int lb(const AA_LONG * const number);

static char modeq(AA_LONG * number, const AA_LONG * const module);

static char mult(const AA_LONG * number1, const AA_LONG * number2, AA_LONG * result);

static char shift(const AA_LONG * const num, signed char nbit, AA_LONG * res);

static char square(const AA_LONG * number, AA_LONG * result);

//-----------------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------------
/*++
mexp

Description:
Computes "(number1 ** EXPONENT) % modul" and stores the "result".
*modul must be smaller than (AA_LENGTH-1)/2.

Return value:
	0 if successful
	-1 in case of an error
Error conditions:
	Overflow error possible when shifting number
	Zero module, if modul == 0
--*/
DISABLE_OPTIMIZATION	// because of memcpy optimization of loops 
char UNOPTIMIZED mexp			/* r = (n1 ** EXPONENT) % m */
 (const AA_LONG * const number, AA_LONG * result, const AA_LONG * const modul) {
	const UINT32 exponent[2] = { 1L, EXPONENT };
	signed char k = 0;
	/* w gives the size of the "bit window sliding over the exponent" */
	BYTE expnbits, modnbits, n_bits, n, w, getbits = 1;
	AA_LONG *res = NULL;	/* shifted result */
	AA_LONG *smodul = NULL;	/* shifted module */
	AA_LONG(*power)[63][AA_LENGTH] = NULL;
	AA_LONG *h = NULL;
	AA_LONG *a, *aa;	/* create temporary pointer to res to enable pointer arithmetics */
	UINT32 l, i, mask[3] = { 15, 31, 63 };

	if (AA_EQUAL0(modul))	/* modul == 0 */
		return (-1);	/* zero module */

	if (*modul <= 16)
		w = 4;
	else if (*modul <= 24)
		w = 5;
	else
		w = 6;

	/* power[0] = number mod modul */

	if ((power = malloc((63 * AA_LENGTH + 64) * sizeof(AA_LONG))) == NULL)
		return (-1);

	for (i = 0; i < (63 * AA_LENGTH + 64); i++)
		*(power[0][0] + i) = 0;

	AA_TRANS(number, (*power)[0])
	    if (modeq((*power)[0], modul)) {
		SAFE_FREE(power);
		return (-1);
	}

	if (AA_EQUAL0((*power)[0])) {	/* number == 0 mod module */
		SAFE_FREE(power);
		*result = 0L;
		return (0);
	}

	/* modul is shifted to the left, until the most significant bit
	 * of the most significant word is 1. First we calculate the
	 * shifting factor k */

	i = *(modul + (int)(*modul));

	if ((smodul = malloc(AA_LENGTH * sizeof(AA_LONG))) == NULL) {
		SAFE_FREE(power);
		return (-1);
	}

	if (i & 0x80000000) {
		AA_TRANS(modul, smodul)
	} else {
		k = 32;
		do {
			k--;
			i >>= 1;
		}
		while (i);

		shift(modul, k, smodul);
	}
#ifdef UEFI_X64
	modnbits = (BYTE)lb((AA_LONG*)exponent) + 1;
#else
	modnbits = (BYTE)lb(exponent) + 1;
#endif
	n = w - 1;

	if (!(expnbits = modnbits % w))
		expnbits = w;

	/* Initialisation of power[i]:
	 * power[i-1] = number^i mod modul. */

	for (i = 2; i <= mask[n - 3]; i++) {
		if (i & 1) {
			mult((*power)[0], (*power)[i - 2], (*power)[i - 1]);
			modeq((*power)[i - 1], smodul);
		} else {
			square((*power)[(i >> 1) - 1], (*power)[i - 1]);
			modeq((*power)[i - 1], smodul);
		}
	}

	GETNBITS(expnbits);

	if ((res = malloc((AA_LENGTH + 64) * sizeof(AA_LONG))) == NULL) {
		SAFE_FREE(power);
		SAFE_FREE(smodul);
		return (-1);
	}

	AA_TRANS((*power)[n_bits - 1], res)

	    if ((h = malloc(AA_LENGTH * sizeof(AA_LONG))) == NULL) {
		SAFE_FREE(power);
		SAFE_FREE(res);
		SAFE_FREE(smodul);
		return (-1);
	}

	while (getbits) {
		/* res = (res^(2^n)) % smodul: */

		for (i = w; i; i--) {
			AA_TRANS(res, h)
			    square(h, res);

			modeq(res, smodul);
		}

		GETNBITS(w);

		if (n_bits != 0) {
			a = res;	// create temporary pointer to res to enable pointer arithmetics
			l = *a;
			a += l;
			aa = a + *((*power)[n_bits - 1]);	/* copy a to aa = a + *((*power)[n_bits-1]) */

			*aa = *a;	/* don't use AA_TRANS for copying! (case *((*power)[n_bits-1]) <= *a) */
			while (l--)
				*--aa = *--a;

			mult(aa, ((*power)[n_bits - 1]), a);

			modeq(res, smodul);
		}
	}

	SAFE_FREE(power);

	if (k) {
		shift(res, k, res);
		modeq(res, smodul);
		shift(res, (signed char)(-k), result);
	} else
		AA_TRANS(res, result)

		    SAFE_FREE(smodul);
	SAFE_FREE(res);
	SAFE_FREE(h);
	return (0);
}				/* mexpn() */
ENABLE_OPTIMIZATION

//-----------------------------------------------------------------------------------------------
/*++
comp

Description:
Compares two AA_LONGs "number1" and "number2".

Return value:
	-1	if number2 < number1 OR if an error occurred
	0	if number2 == number1
	+1	if number2 > number1
--*/
char comp(const AA_LONG * number1, const AA_LONG * number2)
{
	BYTE digits;

	if (*number1 == *number2) {
		digits = (BYTE) * number1;
		number1 += digits;	/* most significant digits */
		number2 += digits;

		while (--digits > 0 && *number1 == *number2) {
			number1--;
			number2--;
		}
	}

	if (*number1 < *number2)
		return (1);	/* number1 < number2 */

	if (*number1 > *number2)
		return (-1);	/* number1 > number2 */

	return (0);		/* number1 == number2 */
}				/* comp() */

//-----------------------------------------------------------------------------------------------
// Converts a BYTE array to an AA_LONG number
char auint82long(const BYTE * ap_auint8, UINT16 a_len, AA_LONG ap_long[AA_LENGTH]
    )
{
	AA_LONG *p_tmp;
	UINT32 v_i;

	/* an empty octet string is interpreted as 0 */
	if (!a_len) {
		ap_long[0] = 0;
		return (0);
	}

	/* skip leading zeroes */
	for (; *ap_auint8 == 0; ap_auint8++)
		if (!(--a_len)) {
			ap_long[0] = 0;
			return (0);
		}

	/* we have at most (AA_LENGTH-1)*sizeof(AA_LONG) available Bytes */
	if (a_len > (AA_LENGTH - 1) * sizeof(AA_LONG))
		return (-1);

	/* how many complete AA_LONGs do we need? */
	ap_long[0] = v_i = (UINT32) (a_len / 4);
	p_tmp = ap_long + v_i;

	/* do we need an additional AA_LONG? */
	if ((a_len %= 4) != 0) {
		/* we do! */
		ap_long[0]++;
		v_i++;
		p_tmp++;

		/* convert a_len leading Bytes to most significant AA_LONG */
		*p_tmp = (AA_LONG) (*ap_auint8++);
		while (--a_len > 0)
			*p_tmp = (*p_tmp << 8) | (AA_LONG) (*ap_auint8++);

		/* first AA_LONG has been processed */
		v_i--;
		p_tmp--;
	}

	/* convert rest of octet string */
	for (; v_i > 0; v_i--, p_tmp--) {
		*p_tmp = (AA_LONG) (*ap_auint8++);
		for (a_len = 3; a_len > 0; a_len--)
			*p_tmp = (*p_tmp << 8) | (AA_LONG) (*ap_auint8++);
	}

	return (0);
}				/* auint82long() */

//-----------------------------------------------------------------------------------------------
// Converts an AA_LONG number to a BYTE array
char long2auint8(const AA_LONG ap_long[AA_LENGTH], BYTE * ap_auint8, UINT16 * const ap_len)
{
	UINT16 v_i, v_len;

	if (AA_EQUAL0(ap_long))
		v_len = 0;
	else
		v_len = (UINT16)lb(ap_long) / 8 + 1;

	/* does caller only ask for needed space? */
	if (!ap_auint8) {
		*ap_len = v_len;
		return (0);
	}

	/* does ap_long fit into *ap_len Bytes? */
	if (v_len > *ap_len) {
		*ap_len = v_len;
		return (-1);
	}

	/* produce leading zeroes */
	memset(ap_auint8, 0, *ap_len - v_len);

	/* ap_long == 0 => we are ready */
	if (!v_len)
		return (0);

	/* fill ap_auint8 from the least significant byte to the most
	 * significant Byte */
	ap_auint8 += *ap_len - 1;
	ap_long++;

	/* process complete AA_LONGs */
	for (; v_len > 4; v_len -= 4) {
		for (v_i = 0; v_i < 4; v_i++)
			*ap_auint8-- = (BYTE) (*ap_long >> (8 * v_i));
		ap_long++;
	}

	/* process most significant AA_LONG */
	for (v_i = 0; v_i < v_len; v_i++)
		*ap_auint8-- = (BYTE) (*ap_long >> (8 * v_i));

	return (0);
}				/* long2auint8() */

//-----------------------------------------------------------------------------------------------
/*++
lb

Description:
Computes the base 2 logarithm of "number". More precisely:
lb(number) == (number of bits of number) - 1.

Return value:
	Base 2 logarithm of "number" if successful
	-1 in case of an error
Error conditions:
	Singularity, if number == 0
--*/
static int lb(const AA_LONG * const number)
{
	UINT32 msd;		/* most significant digit */
	int nbits;

	/* N.B.:
	 *      lb(number1) + lb(number2) + 1
	 *                      >= lb(number1 * number2)
	 *                      >= lb(number1) + lb(number2). */

	if (!(*number))
		return (-1);	/* singularity */

	nbits = (int)((*number - 1L) * 32);

	msd = *(number + *number);
	if (msd & 0xffff0000L)
		nbits += 16, msd >>= 16;
	if (msd & 0x0000ff00L)
		nbits += 8, msd >>= 8;
	if (msd & 0x000000f0L)
		nbits += 4, msd >>= 4;
	if (msd & 0x0000000cL)
		nbits += 2, msd >>= 2;
	if (msd & 0x00000002L)
		nbits += 1;

	return (nbits);
}				/* lb() */

//-----------------------------------------------------------------------------------------------
/*++
modeq

Description:
computes a = a % m.
Parameter errors are NOT checked!
a and m MAY point to the same memory area!

Return value:
	0 if successful
	-1 in case of an error
Error conditions:
	Overflow error possible when shifting a
	Zero module if m == 0
--*/
static char modeq		/* a = a % m */
 (AA_LONG * a, const AA_LONG * const modul) {
	UINT32 lm, qd, N0, N1, E0, E1, R1, Z0, Z1, E0a, E1a, E0b, E1b, E_DIF, tmplm, c2, j;
	AA_LONG *pa, *paa, *pm, *atmp, *btmp, *m = NULL;
	signed char s, k;

	if ((m = malloc(63 * AA_LENGTH * sizeof(AA_LONG))) == NULL)
		return (-1);

	AA_TRANS(modul, m)

	if (!(lm = *m)){
		SAFE_FREE(m);
		return (-1);	/* zero module */
	}

	if (comp(a, m) == 1) {	/* a < m */
		SAFE_FREE(m);
		return (0);
	}

	if (lm == 1)
		s = 0;
	else
		s = 1;

	N0 = *(m + (int)lm);

	if (N0 & 0x80000000)
		k = 0;
	else {
		k = 32;

		do {
			k--;
			N0 >>= 1;
		}
		while (N0);

		if (shift(a, k, a) < 0 || shift(m, k, m) < 0) {
			SAFE_FREE(m);
			return (-1);
		}

		N0 = *(m + (int)lm);
	}

	if (s)
		N1 = *(m + (int)(lm - 1));
	else
		N1 = 0L;

	pa = a + (int)(*a);

	/* If the first lm digits of a are greater or equal to m,
	 * they are subtracted first */

	atmp = pa;
	btmp = (m + (int)lm);
	tmplm = lm;

	while (tmplm--) {
		if (*atmp < *btmp) {
			tmplm = 1;
			break;
		} else if (*atmp > *btmp) {
			tmplm = 0;
			break;
		}
		atmp--;
		btmp--;
	}

	if (!tmplm) {
		paa = pa - ((int)lm - 1);
		pm = m + 1;
		qd = 0L;
		for (Z1 = lm; Z1; Z1--) {
			E0 = *pm++ + qd;
			qd = ((E0 > *paa || (!E0 && qd)) ? 1L : 0L);
			*paa++ -= E0;
		}
	}

	{
		UINT32 a, h, k;

		k = 0x80000000;
		a = 0L - (N0 << 1);
		c2 = 0L;
		h = 0;

		while (k) {
			if (h || a > N0) {
				c2 |= k;
				a -= N0;
			}

			h = a & 0x80000000;
			k >>= 1;
			a <<= 1;
		}

		if (!c2)
			c2 = (UINT32) (-1);
	}

	for (j = *a - lm; j; j--) {
		Z1 = *pa;
		Z0 = *(pa - 1);
		if (Z1 == N0) {
			E1a = N0 - 1;
			E0a = 0L - N0;
			qd = (UINT32) (-1);
		} else {
			/* Division simulated by multiplication with c2. */
			LMULT(Z1, c2, E1, E0);
			qd = Z1 + E1;
			if (qd < Z1) {
				E1a = N0 - 1;
				E0a = 0L - N0;
				qd = (UINT32) (-1);
			} else {
				LMULT(N0, qd, E1a, E0a);
				R1 = Z1 - E1a;
				if (E0a > Z0)
					R1--;
				E_DIF = Z0 - E0a;
				while (R1) {
					qd++;
					if (E_DIF < N0)
						R1--;
					E0a += N0;
					if (E0a < N0)
						E1a++;
					E_DIF = E_DIF - N0;
				}
				if (E_DIF >= N0) {
					E0a += N0;
					if (E0a < N0)
						E1a++;
					qd++;
				}
			}
		}
		/* Now there is an approximation of qd and
		 * E1a * BASIS + E0a == qd * N0 */
		R1 = Z0 - E0a;
		if (s) {
			LMULT(N1, qd, E1b, E0b);
			/* Now E1b * BASIS + E0a == qd * N1. If qd is too great,
			 * this is corrected now */
			if ((Z0 >= E0a && Z1 == E1a) || (Z0 < E0a && Z1 == E1a + 1L)) {
				while ((E1b > R1) || ((E1b == R1) && (E0b > *(pa - 2)))) {
					--qd;
					if (E0a < N0)
						E1a--;
					E0a -= N0;
					if (E0b < N1)
						E1b--;
					E0b -= N1;
					R1 += N0;
					if (R1 < N0)
						break;
				}
			}
		} else {
			E0b = 0L;
			E1b = 0L;
		}
		/* Now qd is correct (but see below). We subtract qd * m from
		 * the first lm digits of a */
		if (qd) {
			paa = pa - (int)lm;
			pm = m + 1;
			R1 = 0L;
			Z0 = 0L;	/* now Z0 is the carry, Z1 index */
			if (s) {
				{
					UINT16 A00, A01;

					A00 = (UINT16) qd;
					A01 = (UINT16) (qd >> 16);

					for (Z1 = lm - 2; Z1; Z1--) {
						LMULT1(*pm, E1, E0);
						pm++;
						if ((E0 += R1) < R1)
							E1++;
						E0 += Z0;
						if ((!E0) && Z0)
							paa++;
						else {
							Z0 = (*paa < E0);
							*paa++ -= E0;
						}
						R1 = E1;
					}
				}
				if ((E0b += R1) < R1)
					E1b++;
				E0b += Z0;
				if ((!E0b) && Z0)
					paa++;
				else {
					Z0 = (*paa < E0b);
					*paa++ -= E0b;
				}
				R1 = E1b;
			}
			if ((E0a += R1) < R1)
				E1a++;
			E0a += Z0;
			if ((!E0a) && Z0)
				paa++;
			else {
				Z0 = (*paa < E0a);
				*paa++ -= E0a;
			}
			R1 = E1a;
			E0 = R1 + Z0;
			if ((!E0) && Z0)
				paa++;
			else {
				Z0 = (*paa < E0);
				*paa++ -= E0;
			}
			/* If there is still a carry (Z0), we subtracted
			 * too much and qd was too great. */
			if (Z0) {
				Z0 = 0L;
				pm = m + 1;
				paa = pa - (int)lm;
				for (Z1 = lm; Z1; Z1--) {
					E0 = *pm++ + Z0;
					if ((!E0) && Z0)
						paa++;
					else {
						Z0 = ((*paa + E0) < E0);
						*paa++ += E0;
					}
				}
			}
			*paa += Z0;
		}
		--pa;
	}

	pa = a + (int)lm;
	while (!(*pa--))
		--lm;
	*a = lm;

	if (k)
		if (shift(a, (signed char)(-k), a) < 0 || shift(m, (signed char)(-k), m) < 0) {
			SAFE_FREE(m);
			return (-1);
		}

	SAFE_FREE(m);
	return (0);
}				/* modeq() */

//-----------------------------------------------------------------------------------------------
/*++
mult

Description:
computes r = a * b.
a and r and b and r must point to different memory areas.

Return value:
	always 0
--*/
static char mult		/* r = a * b */
 (const AA_LONG * a, const AA_LONG * b, AA_LONG * r) {
	const AA_LONG *pb;
	AA_LONG *prr, *pr;
	UINT32 A, h0, h1, h, lb, lbb, la;

	if (!(lb = lbb = *b++)) {
		*r = 0;
		return (0);
	}
	if (!(la = *a)) {
		*r = 0;
		return (0);
	}

	pr = prr = r + 1;
	A = *++a;
	pb = b;
	{
		UINT16 A00, A01;

		A00 = (UINT16) A;
		A01 = (UINT16) (A >> 16);
		LMULT1(*pb, h, *pr);
		while (--lb) {
			++pb;
			++pr;
			LMULT1(*pb, h1, *pr);
			if ((*pr += h) < h)
				h1++;
			h = h1;
		}		/* while loop */
	}
	while (--la) {
		*++pr = h;
		pr = ++prr;
		A = *++a;
		pb = b;
		{
			UINT16 A00, A01;

			A00 = (UINT16) A;
			A01 = (UINT16) (A >> 16);
			LMULT1(*pb, h, h0);
			if ((*pr += h0) < h0)
				h++;
			lb = lbb;
			while (--lb) {
				++pb;
				LMULT1(*pb, h1, h0);
				if ((h0 += h) < h)
					h1++;
				if ((*++pr += h0) < h0)
					h1++;
				h = h1;
			}	/* while loop */
		}
	}			/* while loop */

	if (h)
		*++pr = h;

DISABLE_WARNING(4244)
	*r = pr - r;
RESTORE_WARNING(4244)

	return (0);
}				/* mult() */

//-----------------------------------------------------------------------------------------------
/*++
shift

Description:
Shifts "number" by "shifts" bits.
"shifts" may be positive (left shift) or negative (right shift).
The result is stored in "result".

Return value:
	0 if successful
	-1 in case of an error
--*/
static char shift(const AA_LONG * const number, signed char shifts, AA_LONG * result)
{
	UINT16 rest, longbitsminusrest;
	const AA_LONG *p_number, *n1;
	AA_LONG *p_result, *e_result, *r1;
	UINT32 digits, help;
	BYTE nwords;

	if (AA_EQUAL0(number)) {
		/* number == 0 */
		*result = 0L;
		return (0);
	}

	/* number != 0 */
	if (shifts < 0) {
		/* shifting to the right */
		shifts = -shifts;
		if (shifts >= 32) {
			nwords = shifts / 32;
			rest = (UINT16) (shifts % 32);
		} else {
			rest = (UINT16) shifts;
			nwords = 0;
		}
		if (*number <= nwords) {
			/* result == 0 */
			*result = 0L;
			return (0);
		}

		digits = *number - nwords;

		p_number = number + nwords + 1;
		p_result = result + 1;
		e_result = result + digits;
		if (!rest) {
			/* shifting complete AA_LONGs */
			do {
				*p_result = *p_number++;
			} while (p_result++ <= e_result);
			*result = digits;
			return (0);
		}

		/* rest != 0 */
		longbitsminusrest = (UINT16) (32 - rest);
		if (digits > 1L) {
			do {
				RSHIFT(*p_number++, help, rest);
				LSHIFT(*p_number, *p_result, longbitsminusrest);
				*p_result |= help;
			} while (++p_result < e_result);
		}

		RSHIFT(*p_number, *e_result, rest);
		if (!(*e_result))
			--digits;
		*result = digits;
	} else {
		/* shifting to the left, but shifts may be 0 */
		if (shifts >= 32) {
			nwords = shifts / 32;
			rest = (UINT16) (shifts % 32);
		} else {
			rest = (UINT16) shifts;
			nwords = 0;
		}

		if ((digits = nwords + *number + 1L) >= AA_LENGTH)
			return (-1);	/* overflow */

		p_number = number + *number;
		p_result = result + digits;
		if (!rest) {
			/* shifting complete AA_LONGs, but shifts may be 0 */
			*result = digits - 1L;
			do {
				*--p_result = *p_number;
			} while (--p_number > number);
			/* set skipped words to 0 */
			if (--p_result > result) {
				/* if shifts == 0, this is not executed */
				do {
					*p_result = 0L;
				} while (--p_result > result);
			}
			return (0);
		}

		/* rest != 0 */
		longbitsminusrest = (UINT16) (32 - rest);
		RSHIFT(*p_number, *p_result, longbitsminusrest);
		if (*p_result != 0)
			*result = digits;
		else
			*result = digits - 1L;
		if (p_number > (n1 = number + 1)) {
			do {
				LSHIFT(*p_number, help, rest);
				RSHIFT(*--p_number, *--p_result, longbitsminusrest);
				*p_result |= help;
			} while (p_number > n1);
		}
		LSHIFT(*p_number, *--p_result, rest);
		if (p_result > (r1 = result + 1)) {
			do {
				*--p_result = 0L;
			} while (p_result > r1);
		}
	}

	return (0);
}				/* shift() */

//-----------------------------------------------------------------------------------------------
/*++
square

Description:
computes r = a * a.
Error conditions are NOT checked!
a and r must point to different memory areas.

Return value:
	always 0
Algorithm:
	First all multiplications with different digits, then a shift to the left
	(multiplication by 2), then the squares of the digits are added.
--*/
static char square		/* r = a * a */
 (const AA_LONG * a, AA_LONG * r) {
	const AA_LONG *pb, *aa;
	AA_LONG *prr, *pr;
	UINT32 A, B, h, h0, h1, lb, lbb, la;

	la = *a++;
	/* simple cases, a == 0 or a one digit */
	if (!la--) {
		*r = 0L;
		return (0);
	}
	if (!(lbb = la--)) {
		A = *a;
		pr = r + 1;
		LSQUARE(A, h, h0);
		*pr++ = h0;
		if (h != 0) {
			*pr = h;
			*r = 2L;
		} else
			*r = 1L;
		return (0);
	}

	/* Multiplication of different digits */
	aa = a;
	A = *a++;
	pr = r + 2;
	{
		UINT16 A00, A01;

		A00 = (UINT16) A;
		A01 = (UINT16) (A >> 16);
		B = *a;
		LMULT1(B, h, *pr);
		if ((lb = la) != 0) {
			pb = a + 1;
			LMULT1(*pb, h1, h0);
			if ((h += h0) < h0)
				h1++;
			*++pr = h;
			h = h1;
			while (--lb) {
				++pb;
				LMULT1(*pb, h1, h0);
				if ((h += h0) < h0)
					h1++;
				*++pr = h;
				h = h1;
			}	/* while loop */
		}
	}
	prr = r + 4;
	while (la--) {
		*++pr = h;
		A = B;
		pr = prr;
		B = *(pb = ++a);
		LMULT(A, B, h1, h0);
		if ((*pr += h0) < h0)
			h1++;
		prr += 2;
		h = h1;
		if ((lb = la) != 0) {
			{
				UINT16 A00, A01;

				A00 = (UINT16) A;
				A01 = (UINT16) (A >> 16);
				++pb;
				LMULT1(*pb, h1, h0);
				if ((h0 += h) < h)
					h1++;
				if ((*++pr += h0) < h0)
					h1++;
				h = h1;
				while (--lb) {
					++pb;
					LMULT1(*pb, h1, h0);
					if ((h0 += h) < h)
						h1++;
					if ((*++pr += h0) < h0)
						h1++;
					h = h1;
				}	/* while loop */
			}
		}
	}			/* while loop */
	if (h)
		*++pr = h;

	/* begin of left shift */
	prr = r + 2;
	la = (((*prr) & 0x80000000) != 0L);
	*prr <<= 1;
	while (prr != pr) {
		lb = ((B = *++prr) & 0x80000000);
		*prr = ((B << 1) | la);
		la = (lb != 0L);
	}
	if (la)
		*++prr = 1L;
	/* end of left shift */

	/* calculating and adding the squares */
	A = *aa;
	pr = r + 1;
	LSQUARE(A, h, h0);
	*pr++ = h0;
	if ((*pr += h) < h)
		h = 1;
	else
		h = 0;
	if (lbb--) {
		while (lbb--) {
			A = *++aa;
			LSQUARE(A, h1, h0);
			if ((h0 += h) < h)
				h1++;
			if ((*++pr += h0) < h0)
				h0 = h1 + 1;
			else
				h0 = h1;
			if ((*++pr += h0) < h0)
				h = 1;
			else
				h = 0;
		}
		A = *++aa;
		LSQUARE(A, h1, h0);
		if ((h0 += h) < h)
			h1++;
		if (prr != pr) {
			if ((*++pr += h0) < h0)
				h1++;
		} else {
			*++pr = h0;
			++prr;
		}
		h = h1;

		if (prr != pr)
			*++pr += h;
		else if (h)
			*++pr = h;
	}
DISABLE_WARNING(4244)
	*r = pr - r;
RESTORE_WARNING(4244)

	return (0);
}				/* square() */

RESTORE_WARNING(4706)