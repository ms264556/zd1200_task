/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	LPC_Comm.c

Description:	Implementation of the TPM communication protocol for LPC I/O access

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef UEFI_X64
#include <time.h>
#endif //--------!UEFI_X64---------
#include "ProgFunc.h"
#include "LowLevIO.h"
#include "LPC_Comm.h"

#ifndef TVICDRV		//  I/O Access Functions no longer supported since TVic-driver
/*++
TPM_CheckDefaultConfig

Description:
Check the default configuration of the TPM

Arguments:
[in]	UINT16	wTPMIndexReg	TPM Configuration Base Address

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_CheckDefaultConfig(UINT16 wTPMIndexReg)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bTemp;
	UINT16 wTPMDataReg = wTPMIndexReg + 1;

	DebugToFile("\n-> TPM_CheckDefaultConfig\n");

	do {
		TPM_ON_OFF_Data(wTPMIndexReg, ON);

		DebugToFile("TPM ID:\n");
		OutByte(wTPMIndexReg, TPM_ID1);
		bChipDetected = InpByte(wTPMDataReg);
		if (bChipDetected != TPM_ID1_INFO && bChipDetected != TPM12_ID1_INFO)
			break;

		OutByte(wTPMIndexReg, TPM_ID2);
		bTemp = InpByte(wTPMDataReg);
		if (bTemp != TPM_ID2_INFO && bTemp != TPM12_ID2_INFO)
			break;

		DebugToFile("Vendor Info:\n");
		OutByte(wTPMIndexReg, TPM_IDVENL);
		if (InpByte(wTPMDataReg) != TPM_VENDOR_INFO_L)
			break;

		OutByte(wTPMIndexReg, TPM_IDVENH);
		if (InpByte(wTPMDataReg) != TPM_VENDOR_INFO_H)
			break;

		DebugToFile("Device Info:\n");
		OutByte(wTPMIndexReg, TPM_IDPDL);
		bChipDetected = InpByte(wTPMDataReg);
		if (bChipDetected != TPM_DEVICE_INFO_L && bChipDetected != TPM12_DEVICE_INFO_L)
			break;

		OutByte(wTPMIndexReg, TPM_IDPDH);
		bTemp = InpByte(wTPMDataReg);
		if (bTemp != TPM_DEVICE_INFO_H && bTemp != TPM12_DEVICE_INFO_H)
			break;

		dwRCVal = RC_SUCCESS;
	} while (FALSE);

	TPM_ON_OFF_Data(wTPMIndexReg, OFF);

	DebugToFile("<- TPM_CheckDefaultConfig\n\n");

	return dwRCVal;
}

/*++
TPM_ON_OFF_Data

Description:
Enable/diable the index/data registers in TPM

Arguments:
[in]	UINT16	wTPMIndexReg	Base address of the config space
[in]	BYTE	bTPMAction		On or off

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void TPM_ON_OFF_Data(UINT16 wTPMIndexReg, BYTE bTPMAction)
{
	DebugToFile("\n-> TPM_ON_OFF_Data: %s\n", bTPMAction ? "ON" : "OFF");

	if (bTPMAction)
		OutByte(wTPMIndexReg, TPM_ENABLE_CONFIG);
	else
		OutByte(wTPMIndexReg, TPM_DISABLE_CONFIG);

	DebugToFile("<- TPM_ON_OFF_Data\n\n");
}

/*++
TPM_Set_IO_BaseAdr

Description:
Set the I/O Base Address for TPM access

Arguments:
[in]	UINT16	wTPMIndexReg	Base address of the config space
[in]	UINT16	wTmpIOBase		Base address of the TPM IO space

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void TPM_Set_IO_BaseAdr(UINT16 wTPMIndexReg, UINT16 wTmpIOBase)
{
	UINT16 wTPMDataReg = wTPMIndexReg + 1;

	DebugToFile("\n-> TPM_Set_IO_BaseAdr: 0x%.4X\n", wTPMIndexReg);

	// Set the high part for the IO Register
	OutByte(wTPMIndexReg, TPM_IOLIMH);
	OutByte(wTPMDataReg, (BYTE) ((wTmpIOBase & 0xFF00) >> 0x08));

	// Set the low part for the IO Register
	OutByte(wTPMIndexReg, TPM_IOLIML);
	OutByte(wTPMDataReg, (BYTE) (wTmpIOBase & 0x00FF));

	DebugToFile("<- TPM_Set_IO_BaseAdr\n\n");
}

/*++
TPM_SetIRQ

Description:
Set the IRQ number for the TPM

Arguments:
[in]	UINT16	wTPMIndexReg	Base address of the config space
[in]	UINT16	wIrqNr			TPM IRQ selection
[in]	UINT16	wIrqCtrl		TPM IRQ control

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void TPM_SetIRQ(UINT16 wTPMIndexReg, BYTE bIrqNr, BYTE bIrqCtrl)
{
	UINT16 wTPMDataReg = wTPMIndexReg + 1;

	DebugToFile("\n-> TPM_SetIRQ: %d (Type: %d)\n", bIrqNr, bIrqCtrl);

	OutByte(wTPMIndexReg, TPM_IRQSEL);
	OutByte(wTPMDataReg, (BYTE) (bIrqNr & TPM_IRQ_MASK));

	OutByte(wTPMIndexReg, TPM_IRTYPE);
	OutByte(wTPMDataReg, bIrqCtrl);

	DebugToFile("<- TPM_SetIRQ\n\n");
}

/*++
TPM_SetDAR

Description:
Activate or deactivate the TPM

Arguments:
[in]	UINT16	wTPMIndexReg	Base address of the config space
[in]	BYTE	bTPMAction		On or off

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void TPM_SetDAR(UINT16 wTPMIndexReg, BYTE bTPMAction)
{
	BYTE bTmp = 0;
	UINT16 wTPMDataReg = wTPMIndexReg + 1;

	DebugToFile("\n-> TPM_SetDAR: %s\n", bTPMAction ? "ON" : "OFF");

	OutByte(wTPMIndexReg, TPM_DAR);
	bTmp = InpByte(wTPMDataReg);
	if (bTPMAction)
		bTmp |= TPM_DAR_ACT;
	else
		bTmp &= ~TPM_DAR_ACT;

	OutByte(wTPMDataReg, bTmp);

	DebugToFile("<- TPM_SetDAR\n\n");
}

/*++
TPM_CMD_RegAccess

Description:
Write the flags into the TPM Command Register

Arguments:
[in]	UINT16	wTPMIndexReg	I/O Base Address of the TPM
[in]	BYTE	bCmdFlags		Flags to be written
[in]	BYTE	bCMDAction		Flag on or off

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE	verification failed

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_CMD_RegAccess(UINT16 wTPMIndexReg, BYTE bCmdFlags, BYTE bCMDAction)
{
	UINT32 dwRCVal = RC_SUCCESS;
	BYTE bTmpCmd1 = 0;
	BYTE bTmpCmd2 = 0;

	DebugToFile("\n-> TPM_CMD_RegAccess: %s CMD flag 0x%.2X\n", bCMDAction ? "Set" : "Clear", bCmdFlags);

	bTmpCmd1 = InpByte((UINT16) (wTPMIndexReg + TPM_CMD));

	if (bCMDAction)
		bTmpCmd1 |= bCmdFlags;
	else
		bTmpCmd1 &= ~bCmdFlags;

	OutByte((UINT16) (wTPMIndexReg + TPM_CMD), bTmpCmd1);

	bTmpCmd2 = InpByte((UINT16) (wTPMIndexReg + TPM_CMD));
	if (bTmpCmd2 != bTmpCmd1)
		dwRCVal = RC_E_FAILURE;

	DebugToFile("<- TPM_CMD_RegAccess\n\n");

	return dwRCVal;
}

/*++
TPM_ReadByteFromFIFO

Description:
Read one Byte from the TPM FIFO

Arguments:
[in]	UINT16	wTPMIndexReg	I/O Base Address of the TPM
[in]	BYTE	*pbByteToRead	Byte to read
[in]	BYTE	wTimeOut		Timeout limit in ms

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_TIMEOUT	timeout

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 TPM_ReadByteFromFIFO(UINT16 wTPMIndexReg, BYTE * pbByteToRead, BYTE bTimeOut)
{
	UINT32 dwRCVal = RC_E_TIMEOUT;

	BYTE i, bTmpDebug = bDebug, bDone = FALSE, bReg, bFirstTime = TRUE;
	clock_t wTimeOut = bTimeOut * 100;

#ifdef linux
	time_t start, current;
#else
	clock_t start, current;
#endif

	DebugToFile("\n-> TPM_ReadByteFromFIFO\n");

	// wTime Correction for bTimeOut == 0
	if (wTimeOut == 0)
		wTimeOut = 1;

#ifdef linux
	start = time(NULL);
#else
	start = clock();
#endif

	do {
		for (i = 0; i < 3; i++) {
			if ((bReg = TPM_ReadStatusReg(wTPMIndexReg)) & TPM_STAT_RDA) {
				if (!bFirstTime) {
					bDebug = bTmpDebug;	// Restore original mode
					DebugToFile("InpByte:  Address: %.4X :    %.2X\n",	// Print last output of
						    (wTPMIndexReg + TPM_STAT), bReg);	// TPM_ReadStatusReg
				}

				*pbByteToRead = InpByte((UINT16) (wTPMIndexReg + TPM_RDFIFO));
				dwRCVal = RC_SUCCESS;
				bDone = TRUE;
				break;
			}
		}
		if (dwRCVal != RC_SUCCESS) {
#ifdef linux
			current = time(NULL);
#else
			current = clock();
#endif
			if ((current - start) > wTimeOut) {
				bDebug = bTmpDebug;	// Restore original mode
				bDone = TRUE;
			} else if (bFirstTime) {
				// Do not show obsolete data bytes when waiting for the TPM
				DebugToFile("...polling until TPM is ready...\n");
				bDebug = 0;	// Disable debug mode
				bFirstTime = FALSE;
			}
		}
	} while (!bDone);

	DebugToFile("<- TPM_ReadByteFromFIFO: 0x%.2X\n\n", *pbByteToRead);

	return dwRCVal;
}

/*++
TPM_WriteByteToFIFO

Description:
Send one Byte to the TPM FIFO

Arguments:
[in]	UINT16	wTPMIndexReg	I/O Base Address of the TPM
[in]	BYTE	bByteToWrite	Byte to send
[in]	BYTE	wTimeOut		Timeout limit in ms

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_TIMEOUT	timeout

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 TPM_WriteByteToFIFO(UINT16 wTPMIndexReg, BYTE bByteToWrite, BYTE bTimeOut)
{
	UINT32 dwRCVal = RC_E_TIMEOUT;

	BYTE i, bDone = FALSE;
	clock_t wTimeOut = bTimeOut * 100;
#ifdef linux
	time_t start, current;
#else
	clock_t start, current;
#endif

	DebugToFile("\n-> TPM_WriteByteToFIFO: 0x%.2X\n", bByteToWrite);

#ifdef linux
	start = time(NULL);
#else
	start = clock();
#endif

	do {
		for (i = 0; i < 3; i++) {
			if (TPM_ReadStatusReg(wTPMIndexReg) & TPM_STAT_XFE) {
				OutByte((UINT16) (wTPMIndexReg + TPM_WRFIFO), bByteToWrite);
				dwRCVal = RC_SUCCESS;
				bDone = TRUE;
				break;
			}
		}
		if (dwRCVal != RC_SUCCESS) {
#ifdef linux
			current = time(NULL);
#else
			current = clock();
#endif
			if ((current - start) > wTimeOut)
				bDone = TRUE;
		}
	} while (!bDone);

	DebugToFile("<- TPM_WriteByteToFIFO\n\n");

	return dwRCVal;
}

/*++
TPM_ReadBuffer

Description:
Read a data block from the TPM

Arguments:
[in]		TPM_INFO_STRUCTURE	*psTPMInfo	Pointer to TPM info structure
[out]		BYTE				*pbByteBuf	Buffer to receive
[in/out]	UINT16				wLen		Max size of receive buffer / actual size received

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_BUFFER2SMALL	buffer size insufficient
	RC_E_INVALID_DATA	TPM sent corrupted data
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_NAKRECEIVED	TPM received corrupted data
	RC_E_TIMEOUT		timeout
	RC_E_WTXRECEIVED	TPM received WTX request

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 TPM_ReadBuffer(TPM_INFO_STRUCTURE * psTPMInfo, BYTE * pbByteBuf, UINT16 * wLen)
{
	UINT32 dwRCVal = RC_SUCCESS;

	BYTE bTmpReadByte = 0, bVersionInfo = 0, bCtrlByte = 0;
	UINT16 wLenCount = 0;

	DebugToFile("\n-> TPM_ReadBuffer\n");

	do {
		if ((pbByteBuf == NULL) || (wLen == NULL)) {
			dwRCVal = RC_E_INVALID_PARAM;
			break;
		}
		// Read the version info
		if ((dwRCVal =
		     TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bVersionInfo,
					  psTPMInfo->bTPMBwtTimeOut)) != RC_SUCCESS)
			break;

		// Read the control info byte
		if ((dwRCVal =
		     TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bCtrlByte, psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		// Read high byte for length info
		if ((dwRCVal =
		     TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bTmpReadByte,
					  psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;
		wLenCount = bTmpReadByte;
		wLenCount = ((wLenCount & 0x00FF) << 8);

		// Read low byte for length info
		if ((dwRCVal =
		     TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bTmpReadByte,
					  psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;
		wLenCount |= bTmpReadByte;

		if (bCtrlByte & TPM_CTRL_DATA) {
			if (wLenCount <= *wLen) {
				*wLen = wLenCount;
				wLenCount = 0;
				do {
					if ((dwRCVal =
					     TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, (pbByteBuf + wLenCount),
								  psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
						break;
				} while (++wLenCount < *wLen);
			} else
				dwRCVal = RC_E_BUFFER2SMALL;
		} else if (bCtrlByte & TPM_CTRL_ERROR) {
			// Read error specifier (NAK)
			if ((dwRCVal =
			     TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bTmpReadByte,
						  psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
				break;
			dwRCVal = RC_E_NAKRECEIVED;
		} else if (bCtrlByte & TPM_CTRL_WTX)
			dwRCVal = RC_E_WTXRECEIVED;
		else
			dwRCVal = RC_E_INVALID_DATA;
	} while (FALSE);

	TPM_ClearFIFO(psTPMInfo);

	DebugToFile("<- TPM_ReadBuffer\n\n");

	return dwRCVal;
}

/*++
TPM_SendBuffer

Description:
Send a data block to the TPM

Arguments:
[in]	TPM_INFO_STRUCTURE	*psTPMInfo	Pointer to TPM info structure
[in]	BYTE				*pbByteBuf	Buffer to send
[in]	UINT16				wLen		Size of send buffer

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_TIMEOUT		timeout

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 TPM_SendBuffer(TPM_INFO_STRUCTURE * psTPMInfo, BYTE * pbByteBuf, UINT16 wLen)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT16 wStatusReg = 0, wLenCount = 0;

	DebugToFile("\n-> TPM_SendBuffer\n");

	do {
		if ((pbByteBuf == NULL) || (wLen == 0)) {
			dwRCVal = RC_E_INVALID_PARAM;
			break;
		}
		// Write the LPC protocol version info
		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, TPM_DEFAULT_LPCVER,
					 psTPMInfo->bTPMBwtTimeOut)) != RC_SUCCESS)
			break;

		// Write the control byte info
		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, TPM_CTRL_DATA,
					 psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, (BYTE) ((wLen & 0xFF00) >> 8),
					 psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, (BYTE) (wLen & 0x00FF),
					 psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		do {
			if ((dwRCVal =
			     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, (BYTE) (*(pbByteBuf + wLenCount)),
						 psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
				break;
		} while (++wLenCount < wLen);
	} while (FALSE);

	DebugToFile("<- TPM_SendBuffer\n\n");

	return dwRCVal;
}

/*++
TPM_SendCtrl

Description:
Send a control sequence to the TPM

Arguments:
[in]	TPM_INFO_STRUCTURE	*psTPMInfo	Pointer to TPM info structure
[in]	BYTE				bTPMCtrl	Type of control

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_TIMEOUT		timeout

Author:		Markus Schmoelzer	2007/02/23
--*/
static UINT32 TPM_SendCtrl(TPM_INFO_STRUCTURE * psTPMInfo, BYTE bTPMCtrl)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bLenLow;

	DebugToFile("\n-> TPM_SendCtrl\n");

	do {
		if ((bTPMCtrl != TPM_CTRL_WTX) && (bTPMCtrl != TPM_CTRL_ERROR)) {
			dwRCVal = RC_E_INVALID_PARAM;
			break;
		}
		// Write the version info
		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, TPM_DEFAULT_LPCVER,
					 psTPMInfo->bTPMBwtTimeOut)) != RC_SUCCESS)
			break;

		// Write the control byte info
		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, bTPMCtrl, psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		// Write the length info high byte always 0
		if ((dwRCVal = TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, 0, psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		// Write the length info low byte 0 for WTX or 1 for NAK
		if (bTPMCtrl == TPM_CTRL_WTX)
			bLenLow = 0;
		else
			bLenLow = 1;

		if ((dwRCVal =
		     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, bLenLow, psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
			break;

		if (bTPMCtrl == TPM_CTRL_ERROR)
			if ((dwRCVal =
			     TPM_WriteByteToFIFO(psTPMInfo->wTPM_IO_BaseAdr, TPM_NAK,
						 psTPMInfo->bTPMCwtTimeOut)) != RC_SUCCESS)
				break;
	} while (FALSE);

	DebugToFile("<- TPM_SendCtrl\n\n");

	return (dwRCVal);
}

/*++
TPM_ClearFIFO

Description:
Clear all remaining data of the TPMs FIFO

Arguments:
[in]	TPM_INFO_STRUCTURE	*psTPMInfo	Pointer to TPM info structure

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INVALID_DATA	invalid data in FIFO
	RC_E_TIMEOUT		timeout

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_ClearFIFO(TPM_INFO_STRUCTURE * psTPMInfo)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bTmpReadByte = 0;
	BYTE bTmpDebug = bDebug;

	DebugToFile("\n-> TPM_ClearFIFO\n");

	// Do not show obsolete data bytes transferred from the TPM in debug mode
	// (a dump of the transferred communication data will be displayed instead)
	DebugToFile("InpByte:  Address: %.4X :    01\n", psTPMInfo->wTPM_IO_BaseAdr + TPM_STAT);
	DebugToFile("...polling until FIFO buffer is empty...\n");
	DebugToFile("InpByte:  Address: %.4X :    01\n", psTPMInfo->wTPM_IO_BaseAdr + TPM_STAT);
	bDebug = 0;		// Disable debug mode

	// Read Fifo
	dwRCVal = TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bTmpReadByte, 0);
	if (dwRCVal == RC_SUCCESS) {
		do {
			dwRCVal = TPM_ReadByteFromFIFO(psTPMInfo->wTPM_IO_BaseAdr, &bTmpReadByte, psTPMInfo->bTPMCwtTimeOut);
		} while (dwRCVal == RC_SUCCESS);
		dwRCVal = RC_E_INVALID_DATA;
	} else
		dwRCVal = RC_SUCCESS;

	bDebug = bTmpDebug;	// Restore original mode

	DebugToFile("<- TPM_ClearFIFO\n\n");

	return dwRCVal;
}

/*++
TPM_ReadStatusReg

Description:
Read the Status Register of the TPM

Arguments:
[in]	UINT16	wTPMIndexReg	I/O Base Address of the TPM

Return Value:
	Return			Meaning
	======			=======
	BYTE			TPM status

Author:		Markus Schmoelzer	2007/02/23
--*/
BYTE TPM_ReadStatusReg(UINT16 wTPMIndexReg)
{
	return InpByte((UINT16) (wTPMIndexReg + TPM_STAT));
}

/*++
TPM_Transceive

Description:
Send the Tx Buffer to the TPM and return the response

Arguments:
[in]	BYTE	*pbTxBuffer		Pointer to transmit buffer
[in]	UINT16	wTxLen			Output data length
[out]	BYTE	*pbRxBuffer		Pointer to receive buffer
[in]	UINT16	*pwRxLen		Input data length

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_BUFFER2SMALL	buffer size insufficient
	RC_E_INVALID_DATA	TPM sent corrupted data
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_NAKRECEIVED	TPM received corrupted data
	RC_E_TIMEOUT		timeout
	RC_E_WTXABORT		command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED	TPM received WTX request

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_Transceive(TPM_INFO_STRUCTURE * psTPMInfo, BYTE * pbTxBuffer, UINT16 wTxLen, BYTE * pbRxBuffer, UINT16 * pwRxLen)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bTrscvState = TRSCV_TX_DATA, bErrCnt = 0;
	UINT16 wTmpRxLen = 0;

	DebugToFile("\n-> TPM_Transceive\n");

	do {
		switch (bTrscvState) {
		case TRSCV_TX_DATA:
			dwRCVal = TPM_SendBuffer(psTPMInfo, pbTxBuffer, wTxLen);
			if (dwRCVal == RC_E_TIMEOUT)
				bTrscvState = TRSCV_TIMEOUT;
			else
				bTrscvState = TRSCV_RX_DATA;
			break;

		case TRSCV_RX_DATA:
			wTmpRxLen = *pwRxLen;
			dwRCVal = TPM_ReadBuffer(psTPMInfo, pbRxBuffer, &wTmpRxLen);
			if (dwRCVal == RC_E_TIMEOUT)
				bTrscvState = TRSCV_TIMEOUT;
			else if (dwRCVal == RC_E_NAKRECEIVED) {
				bErrCnt++;
				if (bErrCnt >= MAX_ERRORS)
					bTrscvState = TRSCV_ERROR;
				else
					bTrscvState = TRSCV_TX_DATA;
			} else if (dwRCVal == RC_E_WTXRECEIVED) {
				bTrscvState = TRSCV_TX_WTX;
			} else if (dwRCVal == RC_E_INVALID_DATA) {
				bErrCnt++;
				if (bErrCnt >= MAX_ERRORS)
					bTrscvState = TRSCV_ERROR;
				else
					bTrscvState = TRSCV_TX_NAK;
			} else
				bTrscvState = TRSCV_COMPLETE;
			break;

		case TRSCV_TX_WTX:
			dwRCVal = TPM_SendCtrl(psTPMInfo, TPM_CTRL_WTX);
			if (dwRCVal == RC_E_TIMEOUT)
				bTrscvState = TRSCV_TIMEOUT;
			else
				bTrscvState = TRSCV_RX_DATA;
			break;

		case TRSCV_TX_ABORT:
			dwRCVal = TPM_SendCtrl(psTPMInfo, (TPM_CTRL_WTX | TPM_CTRL_ABORT));
			if (dwRCVal == RC_E_TIMEOUT)
				bTrscvState = TRSCV_TIMEOUT;
			else {
				*pwRxLen = 0;
				dwRCVal = RC_E_WTXABORT;
				bTrscvState = TRSCV_RETURN;
			}
			break;

		case TRSCV_TX_NAK:
			dwRCVal = TPM_SendCtrl(psTPMInfo, TPM_CTRL_ERROR);
			if (dwRCVal == RC_E_TIMEOUT)
				bTrscvState = TRSCV_TIMEOUT;
			else
				bTrscvState = TRSCV_RX_DATA;
			break;

		case TRSCV_TIMEOUT:
			*pwRxLen = 0;
			dwRCVal = RC_E_TIMEOUT;
			bTrscvState = TRSCV_RETURN;
			break;

		case TRSCV_ERROR:
			*pwRxLen = 0;
			dwRCVal = RC_E_FAILURE;
			bTrscvState = TRSCV_RETURN;
			break;

		case TRSCV_COMPLETE:
			*pwRxLen = wTmpRxLen;
			dwRCVal = RC_SUCCESS;
			bTrscvState = TRSCV_RETURN;
		}
	} while (bTrscvState != TRSCV_RETURN);

	DebugToFile("<- TPM_Transceive\n\n");

	return dwRCVal;
}
#endif
