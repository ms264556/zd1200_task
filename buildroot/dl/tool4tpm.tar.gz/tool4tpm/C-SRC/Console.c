/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Console.c

Description:	Implementation of the screen control routines

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/
#ifdef UEFI_X64
#else
#ifdef linux			// Porting Applications to Linux, Portable conditional compilation

#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>

#else
#ifndef WIN32			//--------DOS-------------
#include <dos.h>
#ifdef DJGPP
#include <pc.h>
#endif // DJGPP
#endif //-------DOS/WIN----------
#endif // linux
#endif //-------UEFI_X64----------
#include "Console.h"
#include "ProgFunc.h"

#ifdef UEFI_X64
int kbhit()
{
	gBS->WaitForEvent(1, &gST->ConIn->WaitForKey, NULL);
	return 1;
}

char getch()
{
	EFI_INPUT_KEY Key;
	char bKey = EOF;

	if (gST->ConIn->ReadKeyStroke(gST->ConIn, &Key) == EFI_SUCCESS) {
		bKey = getCharForUEFIKey(Key);
	}

	return bKey;
}
char getCharForUEFIKey(EFI_INPUT_KEY Key) {
	char cKey = 0;

	// UEFI uses 23 as Scancode for ESC and returns 0 as UnicodeChar
	// So we map the UEFI ESC Scancode to the Char for ESC
	if (Key.UnicodeChar == 0 && Key.ScanCode == SCAN_ESC) {
		cKey = CHAR_ESC;
	}
	else {
		cKey = (char) (*(&Key.UnicodeChar) & 0xFF);
	}

	return cKey;
}
#else
#ifdef linux
#if TTY_ACCESS == 0
static struct termios initial_settings, new_settings;
static UINT32 dwInitKeyboardCnt = 0;

void init_keyboard()
{
	if (dwInitKeyboardCnt == 0) {
		tcgetattr(STDIN_FILENO, &initial_settings);
		new_settings = initial_settings;
		new_settings.c_lflag &= ~ICANON;
		new_settings.c_lflag &= ~ECHO;
		new_settings.c_lflag &= ~ISIG;
		new_settings.c_cc[VMIN] = 1;
		new_settings.c_cc[VTIME] = 0;
		tcsetattr(STDIN_FILENO, TCSANOW, &new_settings);
	}
	dwInitKeyboardCnt++;
}

void close_keyboard()
{
	dwInitKeyboardCnt--;
	
	if (dwInitKeyboardCnt == 0) {
		tcsetattr(STDIN_FILENO, TCSANOW, &initial_settings);
	}
}

int kbhit()
{
	struct timeval tv;
	fd_set fds;
	// timeout 0 means return immediately
	tv.tv_sec = 0;
	tv.tv_usec = 500;
	FD_ZERO(&fds);
	FD_SET(STDIN_FILENO, &fds);
	select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv);
	//FD_ISSET returns whether the stream in param 1 has data available
	return FD_ISSET(STDIN_FILENO, &fds);
}
#endif // TTY_ACCESS
#endif //   --------linux--------
#endif //-------UEFI_X64----------

/*++
  InitConsole

Description:
Initialize console

Arguments:
[in]	BYTE	b80x50mode		80x50 DOS screen mode indicator

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void InitConsole(BYTE b80x50mode)
{
#ifdef UEFI_X64
	INT32 Index;
	UINTN ColCnt, RowCnt;
	EFI_STATUS Status;
	
	InitialScreenMode = gST->ConOut->Mode->Mode;
	if (b80x50mode) {			// set default mode					
		for (Index = 0; Index < gST->ConOut->Mode->MaxMode; Index++) {
			gST->ConOut->QueryMode(gST->ConOut, (UINTN)Index, &ColCnt, &RowCnt);
			if (ColCnt == 80) {
				if (InitialScreenMode == Index)
					break;
				if ((Index+1) < gST->ConOut->Mode->MaxMode)
					Status = gST->ConOut->SetMode(gST->ConOut, (UINTN)Index+1);
			}
		}
	} else {						// set highest possible mode
		for (Index = gST->ConOut->Mode->MaxMode-1; Index >=0; Index--) {
			Status = gST->ConOut->QueryMode(gST->ConOut, (UINTN)Index, &ColCnt, &RowCnt);
			if (EFI_ERROR (Status))
				continue;
			Status = gST->ConOut->SetMode(gST->ConOut, (UINTN)Index);
			if (!EFI_ERROR (Status))
				break;
		}
	}
#else
#ifdef linux
#else
#ifdef WIN32			//--------WIN32-----------

	BOOL fSuccess;
	COORD coord;

	// Get a handle to the STDOUT screen buffer
	HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	coord.X = SCREEN_BUFFER_SIZE_X;
	coord.Y = SCREEN_BUFFER_SIZE_Y;

	fSuccess = SetConsoleScreenBufferSize(hStdout, coord);
	if (!fSuccess) {
		Log("\nConsole: SetConsoleScreenBufferSize error !!!\n");
		exit(1);
	}
#else //--------DOS-------------

	if (b80x50mode)		// Set 80x50 mode
	{
		union REGS regs;

		regs.x.ax = 0x1202;	// Select 400 scan line mode
		regs.h.bl = 0x30;
		int86(0x10, &regs, &regs);

		regs.x.ax = 3;	// Select 80 x 25 16 color mode
		int86(0x10, &regs, &regs);

		regs.x.ax = 0x1112;	// Load 8x8 character set into RAM
		regs.h.bl = 0;
		int86(0x10, &regs, &regs);
	}
#endif //-------DOS/WIN----------
#endif //--------linux--------
#endif //-------UEFI_X64----------
}

/*++
  ClrScr

Description:
Clear console screen using the specified color attribute CLRSCR_ATTRIB

Arguments:
none

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void ClrScr(void)
{
#ifdef UEFI_X64
	EFI_STATUS Status;
	
  Status = gST->ConOut->ClearScreen(gST->ConOut);
  if (EFI_ERROR(Status)) {
		Log("\nConsole: ClearScreen error !!!\n");
		Exit(EFI_SUCCESS);
  }
#else
#ifdef linux
#if TTY_ACCESS != 1
	printf("\033c");	// The Linux keyboard and console HOWTO
#endif
#else
#ifdef WIN32			//--------WIN32-----------

	BOOL fSuccess;
	CONSOLE_SCREEN_BUFFER_INFO csbInfo;
	DWORD cWritten;
	DWORD num;

	// Get a handle to the STDOUT screen buffer
	HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	// Go to upper left of screen ---------------------------------------------------
	if (!GetConsoleScreenBufferInfo(hStdout, &csbInfo)) {
		Log("\nConsole: GetConsoleScreenBufferInfo error !!!\n");
		exit(1);
	}

	csbInfo.dwCursorPosition.X = 0;
	csbInfo.dwCursorPosition.Y = 0;

	if (!SetConsoleCursorPosition(hStdout, csbInfo.dwCursorPosition)) {
		Log("\nConsole: SetConsoleCursorPosition error !!!\n");
		exit(1);
	}
	// Clear EOS --------------------------------------------------------------------

	num = SCREEN_BUFFER_SIZE_Y * SCREEN_BUFFER_SIZE_X;

	fSuccess = FillConsoleOutputCharacter(hStdout,	// Screen buffer handle
					      ' ',	// Fill with spaces
					      num,	// Number of cells to fill
					      csbInfo.dwCursorPosition,	// First cell to write to
					      &cWritten);	// Actual number written

	if (!fSuccess) {
		Log("\nConsole: FillConsoleOutputCharacter error !!!\n");
		exit(1);
	}
#else //--------DOS-------------

#ifdef DJGPP
	ScreenSetCursor(0, 0);
	ScreenClear();
#else // DJGPP
	// Go to upper left of screen ---------------------------------------------------
	UINT16 _far *screen = (UINT16 _far *) SCRBUFF;
	short row, col;
	union REGS regs;

	regs.h.ah = 2;
	regs.h.bh = VIDEOPAGE;
	regs.x.dx = 0;
	int86(0x10, &regs, &regs);

	// Clear EOS --------------------------------------------------------------------
	regs.h.ah = 3;
	regs.h.bh = VIDEOPAGE;
	int86(0x10, &regs, &regs);

	for (row = 0; row < SCREENROWS; ++row)
		for (col = 0; col < 80; ++col, ++screen)
			*screen = 0x700;
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux-----------
#endif //-------UEFI_X64----------
}

/*++
  ConsoleWritef

Description:
Writes a formatted string to the console

Arguments:
[in]	char	*pcFormat		String format
[in]	...					optional arguments

Return Value:
none

Author:		Viktor Wallner	2013/02/21
--*/
void ConsoleWritef(char *pcFormat, ...) {
	va_list pcArguments;
	char* pcBuffer;
	UINT32 dwBufferSize;

	va_start(pcArguments, pcFormat);
	dwBufferSize = GetFormattedBufferSizev(pcFormat, pcArguments);
	va_end(pcArguments);
	va_start(pcArguments, pcFormat);
	if (CALLOC(pcBuffer, dwBufferSize)) {
		FormatStringv(pcBuffer, dwBufferSize, pcFormat, pcArguments);
		ConsoleWrite(pcBuffer);
	}
	va_end(pcArguments);
	SAFE_FREE(pcBuffer);
}

/*++
  ConsoleWrite

Description:
Writes a string to the console

Arguments:
[in]	char	*pcString		The string to write to the console 

Return Value:
none

Author:		Viktor Wallner	2013/02/21
--*/
void ConsoleWrite(char *pcString)
{
	#ifdef UEFI_X64
	// UEFI doesn't understand tab chars, so we have to handle them ourself
	char *cBuffer, *pcCurr, *pcNext, *pcNextTab, *pcNextBreak;
	UINT32 dwLength, i, k;
	UINTN dwCharsPrinted = 0;

	dwLength = (UINT32)strlen(pcString);
	if (CALLOC(cBuffer, dwLength + 1)) {
		pcCurr = pcString;	

		while(pcCurr < pcString + dwLength) {
			// search the next tab char
			pcNextTab = strchr(pcCurr, '\t');
			pcNextBreak = strchr(pcCurr, '\n');
			if (pcNextTab != 0 && pcNextBreak != 0) {
				pcNext = min(pcNextTab, pcNextBreak);
			}
			else if (pcNextTab != 0) {
				pcNext = pcNextTab;
			}
			else if (pcNextBreak != 0) {
				pcNext = pcNextBreak;
			}
			else {
				// there's no tab or break char, so we take the rest of the string
				pcNext = pcString + dwLength;
			}

			memcpy(cBuffer, pcCurr, pcNext - pcCurr);
			cBuffer[pcNext - pcCurr] = '\0';
			dwCharsPrinted = AsciiPrint("%a", cBuffer);

			if (dwCharsPrinted < (UINTN)(pcNext - pcCurr)) {				
				// UEFI wasn't able to print the complete string at once
				// so we move our cursor and start over
				pcCurr += dwCharsPrinted;
				continue;
			}

			if(*pcNext =='\t') {
				// if we're not at the ende of the string
				if (pcNext < pcString + dwLength) {
					// insert the correct number of spaces
					k = TAB_WIDTH - (gST->ConOut->Mode->CursorColumn % TAB_WIDTH);			
					for (i = 0; i < k; i++)	AsciiPrint(" ");
				}
			} else if (*pcNext =='\n') {
				if (*pcCurr != '\r') {
					AsciiPrint("\r\n");
				}
				else {
					AsciiPrint("\n");
				}
			}
			pcCurr = pcNext + 1;
		}
	}
	SAFE_FREE(cBuffer);
	#else	
	printf("%s", pcString);
	fflush(stdout);
	#endif
}

/*++
  PrintErrorMessage

Description:
Print the error message based on the error code

Arguments:
[in]	UINT32	dwErrorCode		Error code

Return Value:
none

Author:		Viktor	Wallner	2013/02/20
--*/
void PrintErrorMessage(UINT32 dwErrorCode)
{
	char cFormattedErrorMessage[512];
	GetFormattedErrorMessage(dwErrorCode, cFormattedErrorMessage, 512, 1, 80, TRUE);
	Log("%s\n", cFormattedErrorMessage);
}

/*++
  ErrorCodeToMessage

Description:
Returns a string message for a given error code

Arguments:
[in]	UINT32	dwErrorCode		Error code
[out]	char	*pcErrorMessage	Pointer to the error message
[in]	UINT32	dwMaxLength		Size of the buffer for the error message

Return Value:
none

Author:		Viktor	Wallner	2013/02/20
--*/
void ErrorCodeToMessage(UINT32 dwErrorCode, char *pcErrorMessage, UINT32 dwMaxLength)
{
	char *pcMessage = NULL;
	char *pcFormat = NULL;
	UINT32 dwBufferSize = 0;

	// If there's a function to extend ErrorCodeToMessage, call it first, so it's possible to overwrite
	// error messages
	if (ErrorCodeToMessageEx != NULL && ErrorCodeToMessageEx(dwErrorCode, pcErrorMessage, dwMaxLength)) {
		return;
	}

	switch (dwErrorCode) {
		// TPM fatal error codes
		case TPM_E_IFX_AUTHFAIL:			pcMessage = "Authentication failed"; break;
		case TPM_E_IFX_BADINDEX:			pcMessage = "The index to a PCR, DIR or other register is incorrect"; break;
		case TPM_E_IFX_BAD_PARAMETER:		pcMessage = "One or more parameters are bad"; break;
		case TPM_E_IFX_AUDITFAILURE:		pcMessage = "An operation completed successfully but the auditing of that operation failed"; break;
		case TPM_E_IFX_CLEAR_DISABLED:		pcMessage = "The clear disable flag is set and all clear operations now require physical access"; break;
		case TPM_E_IFX_DEACTIVATED:			pcMessage = "The TPM is deactivated"; break;
		case TPM_E_IFX_DISABLED:			pcMessage = "The TPM is disabled"; break;
		case TPM_E_IFX_DISABLED_CMD:		pcMessage = "The target command has been disabled";	break;
		case TPM_E_IFX_FAIL:				pcMessage = "The operation has failed";	break;
		case TPM_E_IFX_BAD_ORDINAL:			pcMessage = "The ordinal is unknown or inconsistent"; break;
		case TPM_E_IFX_INSTALL_DISABLED:	pcMessage = "The ability to install an owner is disabled"; break;
		case TPM_E_IFX_INVALID_KEYHANDLE:	pcMessage = "The key handle presented was invalid";	break;
		case TPM_E_IFX_KEYNOTFOUND:			pcMessage = "The target key was not found";	break;
		case TPM_E_IFX_INAPPROPRIATE_ENC:	pcMessage = "Unacceptable encryption scheme"; break;
		case TPM_E_IFX_MIGRATEFAIL:			pcMessage = "Migration authorization failed"; break;
		case TPM_E_IFX_INVALID_PCR_INFO:	pcMessage = "PCR information could not be interpreted";	break;
		case TPM_E_IFX_NOSPACE:				pcMessage = "No room to load key"; break;
		case TPM_E_IFX_NOSRK:				pcMessage = "There is no SRK set"; break;
		case TPM_E_IFX_NOTSEALED_BLOB:		pcMessage = "An encrypted blob is invalid or was not created by this TPM"; break;
		case TPM_E_IFX_OWNER_SET:			pcMessage = "There is already an Owner"; break;
		case TPM_E_IFX_RESOURCES:			pcMessage = "The TPM has insufficient internal resources to perform the requested action"; break;
		case TPM_E_IFX_SHORTRANDOM:			pcMessage = "A random string was too short"; break;
		case TPM_E_IFX_SIZE:				pcMessage = "The TPM does not have the space to perform the operation";	break;
		case TPM_E_IFX_WRONGPCRVAL:			pcMessage = "The named PCR value does not match the current PCR value";	break;
		case TPM_E_IFX_BAD_PARAM_SIZE:		pcMessage = "The ParamSize argument to the command contains an incorrect value"; break;
		case TPM_E_IFX_SHA_THREAD:			pcMessage = "There is no existing SHA-1 thread"; break;
		case TPM_E_IFX_SHA_ERROR:			pcMessage = "The calculation is unable to proceed because the existing SHA-1 thread has already encountered an error"; break;
		case TPM_E_IFX_FAILEDSELFTEST:		pcMessage = "Self-test has failed and the TPM has shutdown"; break;
		case TPM_E_IFX_AUTH2FAIL:			pcMessage = "The authorization for the second key in a 2 key function has failed"; break;
		case TPM_E_IFX_BADTAG:				pcMessage = "The sent tag value for a command is invalid"; break;
		case TPM_E_IFX_IOERROR:				pcMessage = "An IO error occurred transmitting information to the TPM";	break;
		case TPM_E_IFX_ENCRYPT_ERROR:		pcMessage = "The encryption process had a problem";	break;
		case TPM_E_IFX_DECRYPT_ERROR:		pcMessage = "The decryption process did not complete"; break;
		case TPM_E_IFX_INVALID_AUTHHANDLE:	pcMessage = "An invalid handle was used"; break;
		case TPM_E_IFX_NO_ENDORSEMENT:		pcMessage = "The TPM does not a EK installed"; break;
		case TPM_E_IFX_INVALID_KEYUSAGE:	pcMessage = "The usage of a key is not allowed"; break;
		case TPM_E_IFX_WRONG_ENTITYTYPE:	pcMessage = "The submitted entity type is not allowed";	break;
		case TPM_E_IFX_INVALID_POSTINIT:	pcMessage = "The command was received in the wrong sequence relative to TPM_Init and a subsequent TPM_Startup";	break;
		case TPM_E_IFX_INAPPROPRIATE_SIG:	pcMessage = "Signed data cannot include additional DER information"; break;
		case TPM_E_IFX_BAD_KEY_PROPERTY:	pcMessage = "The key properties in TPM_KEY_PARMs are not supported by this TPM"; break;
		case TPM_E_IFX_BAD_MIGRATION:		pcMessage = "The migration properties of this key are incorrect"; break;
		case TPM_E_IFX_BAD_SCHEME:			pcMessage = "The signature or encryption scheme for this key is incorrect or not permitted in this situation"; break;
		case TPM_E_IFX_BAD_DATASIZE:		pcMessage = "The size of the data (or blob) parameter is bad or inconsistent with the referenced key"; break;
		case TPM_E_IFX_BAD_MODE:			pcMessage = "A mode parameter is bad, such as capArea or subCapArea for TPM_GetCapability, physicalPresence parameter for TPM_PhysicalPresence, or migrationType for TPM_CreateMigrationBlob"; break;
		case TPM_E_IFX_BAD_PRESENCE:		pcMessage = "Either the bits for the PhysicalPresence or the PhysicalPresenceLock are containing a wrong value"; break;
		case TPM_E_IFX_BAD_VERSION:			pcMessage = "The TPM cannot perform this version of the capability"; break;
		case TPM_E_IFX_NO_WRAP_TRANSPORT:	pcMessage = "The TPM does not allow for wrapped transport sessions"; break;
		case TPM_E_IFX_AUDITFAIL_UNSUCCESSFUL:	pcMessage = "TPM audit construction failed and the underlying command was returning a failure code also"; break;
		case TPM_E_IFX_AUDITFAIL_SUCCESSFUL:	pcMessage = "TPM audit construction failed and the underlying command was returning success"; break;
		case TPM_E_IFX_NOTRESETABLE:		pcMessage = "Attempt to reset a PCR register that does not have the resettable attribute"; break;
		case TPM_E_IFX_NOTLOCAL:			pcMessage = "Attempt to reset a PCR register that requires Locality and Locality modifier not part of command transport"; break;
		case TPM_E_IFX_BAD_TYPE:			pcMessage = "Make identity blob not properly typed"; break;
		case TPM_E_IFX_INVALID_RESOURCE:	pcMessage = "When saving context identified resource type does not match actual resource"; break;
		case TPM_E_IFX_NOTFIPS:				pcMessage = "The TPM is attempting to execute a command only available when in FIPS mode"; break;
		case TPM_E_IFX_INVALID_FAMILY:		pcMessage = "The command is attempting to use an invalid family ID"; break;
		case TPM_E_IFX_NO_NV_PERMISSION:	pcMessage = "The permission to manipulate the NV storage is not available"; break;
		case TPM_E_IFX_REQUIRES_SIGN:		pcMessage = "The operation requires a signed command"; break;
		case TPM_E_IFX_KEY_NOTSUPPORTED:	pcMessage = "Wrong operation to load an NV key"; break;
		case TPM_E_IFX_AUTH_CONFLICT:		pcMessage = "NV_LoadKey blob requires both owner and blob authorization"; break;
		case TPM_E_IFX_AREA_LOCKED:			pcMessage = "The NV area is locked and not writable"; break;
		case TPM_E_IFX_BAD_LOCALITY:		pcMessage = "The Locality is incorrect for the attempted operation"; break;
		case TPM_E_IFX_READ_ONLY:			pcMessage = "The NV area is read only and can't be written to";	break;
		case TPM_E_IFX_PER_NOWRITE:			pcMessage = "There is no protection on the write to the NV area"; break;
		case TPM_E_IFX_FAMILYCOUNT:			pcMessage = "The family count value does not match"; break;
		case TPM_E_IFX_WRITE_LOCKED:		pcMessage = "The NV area has already been written to"; break;
		case TPM_E_IFX_BAD_ATTRIBUTES:		pcMessage = "The NV area attributes conflict"; break;
		case TPM_E_IFX_INVALID_STRUCTURE:	pcMessage = "The structure tag and version are invalid or inconsistent"; break;
		case TPM_E_IFX_KEY_OWNER_CONTROL:	pcMessage = "The key is under control of the TPM Owner and can only be evicted by the TPM Owner"; break;
		case TPM_E_IFX_BAD_COUNTER:			pcMessage = "The counter handle is incorrect"; break;
		case TPM_E_IFX_NOT_FULLWRITE:		pcMessage = "The write is not a complete write of the area"; break;
		case TPM_E_IFX_CONTEXT_GAP:			pcMessage = "The gap between saved context counts is too large"; break;
		case TPM_E_IFX_MAXNVWRITES:			pcMessage = "The maximum number of NV writes without an owner has been exceeded"; break;
		case TPM_E_IFX_NOOPERATOR:			pcMessage = "No operator authorization value is set"; break;
		case TPM_E_IFX_RESOURCEMISSING:		pcMessage = "The resource pointed to by context is not loaded";	break;
		case TPM_E_IFX_DELEGATE_LOCK:		pcMessage = "The delegation administration is locked"; break;
		case TPM_E_IFX_DELEGATE_FAMILY:		pcMessage = "Attempt to manage a family other then the delegated family"; break;
		case TPM_E_IFX_DELEGATE_ADMIN:		pcMessage = "Delegation Management not enabled"; break;
		case TPM_E_IFX_TRANSPORT_NOTEXCLUSIVE: pcMessage = "There was a command executed outside of an exclusive transport session"; break;
		case TPM_E_IFX_OWNER_CONTROL:		pcMessage = "Attempt to context save a owner evict controlled key"; break;
		case TPM_E_IFX_DAA_RESOURCES:		pcMessage = "The DAA command has no resource available to execute the command"; break;
		case TPM_E_IFX_DAA_INPUT_DATA0:		pcMessage = "The consistency check on DAA parameter inputData0 has failed";	break;
		case TPM_E_IFX_DAA_INPUT_DATA1:		pcMessage = "The consistency check on DAA parameter inputData1 has failed";	break;
		case TPM_E_IFX_DAA_ISSUER_SETTINGS:	pcMessage = "The consistency check on DAA_issuerSettings has failed"; break;
		case TPM_E_IFX_DAA_TPM_SETTINGS:	pcMessage = "The consistency check on DAA_tpmSpecific has failed"; break;
		case TPM_E_IFX_DAA_STAGE:			pcMessage = "The atomic process indicated by the submitted DAA command is not the expected process"; break;
		case TPM_E_IFX_DAA_ISSUER_VALIDITY:	pcMessage = "The issuer's validity check has detected an inconsistency"; break;
		case TPM_E_IFX_DAA_WRONG_W:			pcMessage = "The consistency check on w has failed"; break;
		case TPM_E_IFX_BAD_HANDLE:			pcMessage = "The handle is incorrect"; break;
		case TPM_E_IFX_NOCONTEXTSPACE:		pcMessage = "There is no room in the context list for additional contexts"; break;
		case TPM_E_IFX_BADCONTEXT:			pcMessage = "The context blob is invalid";	break;
		case TPM_E_IFX_TOOMANYCONTEXTS:		pcMessage = "There are too many contexts made for this owner"; break;
		case TPM_E_IFX_MA_TICKET_SIGNATURE:	pcMessage = "Migration authority signature validation failure"; break;
		case TPM_E_IFX_MA_DESTINATION:		pcMessage = "Migration destination not authenticated"; break;
		case TPM_E_IFX_MA_SOURCE:			pcMessage = "Migration source incorrect"; break;
		case TPM_E_IFX_MA_AUTHORITY:		pcMessage = "Incorrect migration authority"; break;

		// TPM additional error codes
		case TPM_E_IFX_COMM_DATA_LOST:		pcMessage = "A communications error with the TPM has been detected"; break;
		case TPM_E_IFX_UNSUPPORTED_FEATURE:	pcMessage = "The TPM does not support the requested feature"; break;
		case TPM_E_IFX_PENDING:				pcMessage = "The operation that was requested is pending completion"; break;
		case TPM_E_IFX_TIMEOUT:				pcMessage = "The operation has timed out"; break;
		case TPM_E_IFX_ALREADY_OPENED:		pcMessage = "The connection was already established"; break;
		case TPM_E_IFX_INSUFFICIENT_BUFFER:	pcMessage = "Buffer was to small"; break;

		case TPM_E_IFX_NOT_READY:			pcMessage = "The TPM is not ready to accept commands"; break;
		case TPM_E_IFX_CANCELLED:			pcMessage = "The action was cancelled by request"; break;
		case TPM_E_IFX_UNKNOWN_TPM:			pcMessage = "The specified TPM is not recognized"; break;
		case TPM_E_IFX_NO_SERVICE:			pcMessage = "The TPS is not running"; break;
		case TPM_E_IFX_SERVICE_STOPPED:		pcMessage = "The TPS has shut down"; break;
		case TPM_E_IFX_UNEXPECTED:			pcMessage = "An unexpected TPM error has occurred";	break;
		case TPM_E_IFX_UNKNOWN_ERROR:		pcMessage = "An internal error has been detected, but the source is unknown"; break;
		case TPM_E_IFX_INTERNAL_ERROR:		pcMessage = "An internal SW error has been detected"; break;
		case TPM_E_IFX_OUTOFMEMORY:			pcMessage = "Ran out of memory"; break;

		// TPM non-fatal error codes
		case TPM_E_IFX_RETRY:				pcMessage = "The TPM is too busy to respond to the command immediately, but the command could be resubmitted at a later time"; break;
		case TPM_E_IFX_NEEDS_SELFTEST:		pcMessage = "SelfTestFull has not been run"; break;
		case TPM_E_IFX_DOING_SELFTEST:		pcMessage = "The TPM is currently executing a full selftest"; break;
		case TPM_E_IFX_DEFEND_LOCK_RUNNING:	pcMessage = "The TPM is defending against dictionary attacks and is in some time-out period"; break;

		// General error return codes
		case RC_E_FAILURE:					pcMessage = "Unspecified error"; break;
		case RC_E_INVALID_PARAM:			pcMessage = "Invalid parameter specified"; break;
		case RC_E_TIMEOUT:					pcMessage = "Maximum waiting time ran down"; break;
		case RC_E_BUFFER2SMALL:				pcMessage = "Buffer size insufficient"; break;
		case RC_E_NAKRECEIVED:				pcMessage = "TPM received corrupted data"; break;
		case RC_E_WTXRECEIVED:				pcMessage = "TPM received WTX request"; break;
		case RC_E_INVALID_DATA:				pcMessage = "TPM sent corrupted data"; break;
		case RC_E_NOT_READY:				pcMessage = "Device is not ready"; break;
		case RC_E_FILE_EMPTY:				pcMessage = "No data in file"; break;
		case RC_E_NO_MEMORY:				pcMessage = "No more memory available"; break;
		case RC_E_NODISKSPC:				pcMessage = "No space on disk left"; break;
		case RC_E_INV_FILE_SPEC:			pcMessage = "File or path not found"; break;
		case RC_E_FILE2LARGE:				pcMessage = "File is too big to complete operation"; break;
		case RC_E_WTXABORT:					pcMessage = "Command not sent because maximum number of waiting cycles is exceeded"; break;
		case RC_E_HASOWNER:					pcMessage = "TPM has an Owner"; break;
		case RC_E_DISABLED:					pcMessage = "TPM is disabled"; break;
		case RC_E_LOCALITY_NOT_ACTIVE:		pcMessage = "The requested Locality is not active";	break;
		case RC_E_TPM_TRANSMIT_DATA:		pcMessage = "The TPM indicates an error during transmission of the data"; break;
		case RC_E_TPM_RECEIVE_DATA:			pcMessage = "The TPM indicates an error during reception of the data"; break;
		case RC_E_TPM_NO_DATA_AVAILABLE:	pcMessage = "The TPM has no response available yet"; break;
		case RC_E_LOCALITY_NOT_SUPPORTED:	pcMessage = "The requested Locality isn't supported."; break;
		case RC_E_BAD_PARAMETER:			pcMessage = "One or more parameters are invalid"; break;
		case RC_E_COMPONENT_NOT_FOUND:		pcMessage = "The requested TPM component was not found"; break;
		case RC_E_INSUFFICIENT_BUFFER:		pcMessage = "The receive buffer is too small."; break;
		case RC_E_SYNTAXERROR:				pcMessage = "Invalid syntax of the input file";	break;

		// General warning return codes
		case RC_W_TPM_CFG:					pcMessage = "TPM is not configured to 4E!"; break;
		case RC_W_TPM_INACTIVE:				pcMessage = "TPM is not activated"; break;
		case RC_W_CNF_IN_USE:				pcMessage = "Config space already occupied"; break;
		case RC_W_GEN_IN_USE:				pcMessage = "Decoder range already occupied"; break;

		case RC_SUCCESS:					pcMessage = "Success"; break;

		default:
			if (dwErrorCode > RC_W_BASE) {
				pcFormat = "Unknown error code: %d";
			}
			else if (dwErrorCode > RC_E_BASE) {
				pcFormat = "Unknown warning code: %d";
			}
			else {
				pcFormat = "Unknown message code: %d";
			}
			dwBufferSize = GetFormattedBufferSize(pcFormat, dwErrorCode);
			if (CALLOC(pcMessage, dwBufferSize)) {
				FormatString(pcMessage, dwBufferSize, pcFormat, dwErrorCode);
			}
			break;
	}

	memcpy(pcErrorMessage, pcMessage, min(dwMaxLength - 1, (UINT32)strlen(pcMessage) + 1));
	pcErrorMessage[dwMaxLength - 1] = '\0';
	
	if (dwBufferSize > 0) {
		SAFE_FREE(pcMessage);
	}
}

/*++
  GetFormattedErrorMessage

Description:
Returns a formatted error message for a given error code

Arguments:
[in]	UINT32	dwErrorCode			Error code
[out]	char	*pcFormattedMessage	Pointer to the formatted error message
[in]	UINT32	dwMaxLength			Size of the buffer for the error message
[in]	UINT32	dwIndent			The number of tabs to insert at the start of each line
[in]	UINT32	dwMaxCharsPerLine	The maximum number of chars in a line
[in]	BOOL	bAddErrorCode		Determines if the error code is included in the error message

Return Value:
none

Author:		Viktor	Wallner	2013/02/20
--*/
void GetFormattedErrorMessage(UINT32 dwErrorCode, char *pcFormattedMessage, UINT32 dwMaxLength, UINT32 dwIndent, UINT32 dwMaxCharsPerLine, BOOL bAddErrorCode) {
	char cErrorMessage[512], cIndent[128];
	char *pcNextWhitespace = NULL;
	UINT32 dwMessageLen = 0;
	UINT32 i = 0;
	UINT32 dwDefaultLineLength = 0, dwLineLength = 0;
	UINT32 dwWordLen = 0, dwPos = 0;

	do {
		memset(pcFormattedMessage, 0, dwMaxLength);
		memset(cIndent, 0, 128);

		ErrorCodeToMessage(dwErrorCode, cErrorMessage, 512);
		dwMessageLen = (UINT32)strlen(cErrorMessage);

		// initialize the indent string
		for (i = 0; i < dwIndent; i++) {
			strcat(cIndent, "\t");
		}
		dwDefaultLineLength = dwIndent * TAB_WIDTH;

		if (bAddErrorCode) {
			strcat(cIndent, "         "); // 9 whitespaces (length of E[XXXXX] plus 1 whitespace);
			dwDefaultLineLength += 9;
		}

		// check if the string is getting too long
		if (dwDefaultLineLength + 1 > dwMaxLength - 1)
			break;
		// indent the first line
		strcat(pcFormattedMessage, cIndent);	

		if (bAddErrorCode) {
			// write the warning or error code
			sprintf(pcFormattedMessage + dwIndent, ((dwErrorCode > RC_W_BASE) ? "W[%.5d] " : "E[%.5d] "), dwErrorCode);	
		}

		dwLineLength = dwDefaultLineLength;
		while (dwPos < dwMessageLen) {
			// skip whitespaces
			while (cErrorMessage[dwPos] == ' ') dwPos++;
			// get the length of the next word
			pcNextWhitespace = strchr(cErrorMessage + dwPos, ' ');
			dwWordLen = (UINT32)((pcNextWhitespace > 0) ? (pcNextWhitespace - cErrorMessage - dwPos) : (dwMessageLen - dwPos));

			if (dwLineLength + dwWordLen + 1 > dwMaxLength - 1) {
				dwWordLen = dwMaxLength - dwLineLength - 2;
			}

			if (dwMaxCharsPerLine > 0) {
				// break words that are too long
				if (dwWordLen > dwMaxCharsPerLine - TAB_WIDTH * dwIndent - 1) {
					dwWordLen = dwMaxCharsPerLine - TAB_WIDTH * dwIndent - 1;
				}
				// break line if it would be too long
				if (dwMaxCharsPerLine > 0 && dwLineLength + dwWordLen >= dwMaxCharsPerLine) {
					// check if the string is getting too long
					if (strlen(pcFormattedMessage) + dwDefaultLineLength + 1 > dwMaxLength - 1)
						break;
					// new line
					strcat(pcFormattedMessage, "\n");
					//indent the line
					strcat(pcFormattedMessage, cIndent);
					dwLineLength = dwDefaultLineLength;
				}
			}

			// check if the string is getting too long
			if (strlen(pcFormattedMessage) + dwWordLen + 1 > dwMaxLength - 1)
				break;

			// concat the word			
			strncat(pcFormattedMessage, cErrorMessage + dwPos, dwWordLen);
			strcat(pcFormattedMessage, " ");
			dwLineLength += dwWordLen + 1;

			dwPos += dwWordLen;
		}
	} while( FALSE ) ;
}

/*++
  FlushInputBuffer

Description:
Flushes the input buffer.

Arguments:
none

Return Value:
none

Author:		Viktor Wallner	2013/02/19
--*/
void FlushInputBuffer(void) {
	#ifdef UEFI_X64
	EFI_INPUT_KEY Key;
	while(gST->ConIn->ReadKeyStroke(gST->ConIn, &Key) == EFI_SUCCESS);
	#else
	// don't use fflush to flush stdin as its behavior is (at least on linux platforms) undefined
	while(kbhit()) {
		getch();
	}
	#endif
}

/*++
  WaitForKey

Description:
Waits for the user to press a key and returns the pressed key.
The input buffer is flushed before the program waits for the key press.

Arguments:
none

Return Value:
	The char representing the key the user pressed.	

Author:		Viktor Wallner	2013/02/19
--*/
char WaitForKey(void)
{
	if (WaitForKeyHook != NULL) {
		return WaitForKeyHook();
	} else {
		FlushInputBuffer();
		while(!kbhit());
		return getch();
	}
}

/*++
  IsKeyPressed

Description:
Checks if the given key is pressed.
The input buffer is flushed after the check, so it's always empty after the
execution of this function.

Arguments:
[in]	char	cKey		The char representing the key to check

Return Value:
	TRUE if cKey is pressed, FALSE otherwise

Author:		Viktor Wallner	2013/02/19
--*/
BOOL IsKeyPressed(char cKey) {
	BOOL bKeyPressed = FALSE;

	if (IsKeyPressedHook != NULL) {
		bKeyPressed = IsKeyPressedHook(cKey);
	} else {
		#ifdef UEFI_X64
		EFI_INPUT_KEY Key;
		while(gST->ConIn->ReadKeyStroke(gST->ConIn, &Key) == EFI_SUCCESS) {
			if (getCharForUEFIKey(Key) == cKey) {
				bKeyPressed = TRUE;
				break;
			}
		}
		#else
		while(kbhit()) {
			if (getch() == cKey) {
				bKeyPressed = TRUE;
				break;
			}
		}
		#endif
		FlushInputBuffer();
	}

	return bKeyPressed;
}

/*++
  PromptForNumber

Description:
Prompts the user to enter a number

Arguments:
[in]	char	*pcPrompt		The text to display
[out]	UINT32	*pdwNumber		The number the user entered

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_INVALID_PARAM	the user did not enter a number
	UINT32			error return code

Author:		Viktor Wallner	2013/02/19
--*/
UINT32 PromptForNumber(char *pcPrompt, UINT32 *pdwNumber) {
	UINT32 dwRCVal = RC_E_INVALID_PARAM;
	char cChar = 0;
	UINT16 wCnt = 0;
	UINT16 wBase = 10;

	Log(pcPrompt);

	if (PromptForNumberHook != NULL) {
		dwRCVal = PromptForNumberHook(pcPrompt, pdwNumber);
		if (dwRCVal == RC_SUCCESS) {
			ConsoleWritef("%d", *pdwNumber);
		}
	} else {
		*pdwNumber = 0;
		init_keyboard();
		while(cChar != '\r' && cChar != '\n') {
			cChar = WaitForKey();
		
			if (cChar >= '0' && cChar <= '9') {
				dwRCVal = RC_SUCCESS;

				*pdwNumber = (*pdwNumber)*wBase + cChar - '0';
				ConsoleWritef("%c", cChar);
				wCnt++;
			}

			// Handle backspace (Win, Dos, UEFI = \b, Linux = 0x7F)
			if ((cChar == '\b' || cChar == 0x7F) && wCnt > 0) {
				ConsoleWrite("\b \b");
				*pdwNumber = (*pdwNumber)/wBase;
				wCnt--;
				if (wCnt == 0) {
					dwRCVal = RC_E_INVALID_PARAM;
				}
			}
		}
		close_keyboard();
	}
	if (dwRCVal == RC_SUCCESS) {
		LogToFile("%d", *pdwNumber);
	}
	Log("\n");
	return dwRCVal;
}