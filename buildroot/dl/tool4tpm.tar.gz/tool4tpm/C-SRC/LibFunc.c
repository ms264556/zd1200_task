/*++

Copyright (c) 2012	Infineon Technologies AG

Module Name:	LibFunc.c

Description:	Implementation of the file I\O help routines

Author:		Peter Huewe 2012/07/26

Environment:	Linux

Revision History:

Notes:

--*/
#include "Globals.h"
#include <sys/types.h>
#include <sys/stat.h>
int is_dir (char* pbFileName) {
	struct stat stats;
	//check if directory
	if (stat(pbFileName, &stats) != 0) {
		return RC_E_INV_FILE_SPEC;
	}
	return S_ISDIR(stats.st_mode);
}

int is_regfile (char* pbFileName) {
	struct stat stats;
	//check if regular file
	if (stat(pbFileName, &stats) != 0) {
		return RC_E_INV_FILE_SPEC;
	}
	return S_ISREG(stats.st_mode);
}
