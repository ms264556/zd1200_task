/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	RSA.c

Description:	Source code file for the RSA public key encryption
				according to PKCS #1 v2.1 (RSAES EME-OAEP)

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "Hash.h"
#include "RSA.h"

// Internal RSA function prototypes -------------------------------------------------------------
// OAE padding for encoded message according to PKCS #1 v2.1
static char iPad(const BYTE * const pbM, const UINT16 wInpLen, BYTE * const pbEM, BYTE * pbSeed);

// Mask Generation Function "MGF1" according to PKCS #1 v2.1
static char MGF(const BYTE * const pbSeedInp, const BYTE bSeedLen, const BYTE bMaskLen, BYTE * const pbMask);

//-----------------------------------------------------------------------------------------------

/*++
RSA_Encrypt

Description:
Encrypts a message with a public key of a given modulus and a fixed exponent

Arguments:
[in]		BYTE	*pbInput			Input message
[in]		BYTE	wInpLen				Input message size in Bytes
[out]		BYTE	*pbOutput			Encoded output message
[in/out]	UINT32	*pwOutpLen			Output message size in Bytes
[in]		BYTE	bPublicKey[KEY_LEN]	Modulus of the public key
[in]		BYTE	bSeed[HASH_LEN]		Masking seed input

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			Operation successfully completed
	RC_E_FAILURE		RSA computation was not successful
	RC_E_INVALID_PARAM	Invalid parameter

Author:		Markus Schmoelzer	2007/02/23
--*/
DISABLE_OPTIMIZATION	// because of memcpy optimization of loops 
UINT32 UNOPTIMIZED RSA_Encrypt(const BYTE * const pbInput,
		   const UINT16 wInpLen,
		   BYTE * const pbOutput, UINT16 * const pwOutpLen, const BYTE bPublicKey[KEY_LEN], BYTE bSeed[HASH_LEN])
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bEncMsg[KEY_LEN];
	AA_LONG aaBase[AA_LENGTH], aaResult[AA_LENGTH] = { 0 }, aaModulus[AA_LENGTH];

	// Check memory available at pbOutput
	if (*pwOutpLen < KEY_LEN) {
		dwRCVal = RC_E_INVALID_PARAM;	// Return code if output length is too small
		*pwOutpLen = KEY_LEN;	// Adjust pwOutpLen to the minimum length needed
	}
	// Perform OAE padding and check it for errors
	else if (iPad(pbInput, wInpLen, bEncMsg, bSeed) == 0) {
		*pwOutpLen = KEY_LEN;	// Adjust output length to the actually needed value

		// Perform base conversion to AA_LONG and check it for errors
		if (auint82long(bEncMsg, KEY_LEN, aaBase) == 0)
			// Perform key conversion to AA_LONG and check it for errors
			if (auint82long(bPublicKey, KEY_LEN, aaModulus) == 0)
				// Check base size relative to the modulus size (base < modulus?)
				if (comp(aaBase, aaModulus) == 1)
					// Perform RSA Exponentiation and check it for errors
					if (mexp(aaBase, aaResult, aaModulus) == 0)
						// Perform result conversion to BYTE array and check it for errors
						if (long2auint8(aaResult, pbOutput, pwOutpLen) == 0)
							dwRCVal = RC_SUCCESS;	// Return code if everything was successful
	}

	return (dwRCVal);
}				/* RSA_Encrypt() */
ENABLE_OPTIMIZATION

DISABLE_OPTIMIZATION	// because of memcpy optimization of loops 
// OAE padding for encoded message according to PKCS #1 v2.1 ------------------------------------
static char UNOPTIMIZED iPad(const BYTE * const pbM, const UINT16 wInpLen, BYTE * const pbEM, BYTE * pbSeed)
{
	// SHA-1 hash value of the string "TCPA"
	const BYTE bTcpaHash[] = { 0xf7, 0x7d, 0x67, 0xa7, 0xb7, 0xcb, 0xdf, 0xd8, 0x09, 0x33,
		0x49, 0x80, 0xaf, 0xe6, 0xb9, 0x4d, 0x83, 0xa8, 0x0b, 0x51
	};

	BYTE bDB[KEY_LEN - HASH_LEN - 1], bDB_Mask[KEY_LEN - HASH_LEN - 1], bSeedMask[HASH_LEN], bTempSeed[HASH_LEN];
	BYTE i;

	// Is the message too long?
	if (wInpLen > KEY_LEN - 2 * HASH_LEN - 2)
		return (-1);

	// DB concatenation
	for (i = 0; i < HASH_LEN; i++)	// Concatenate empty string hash value
		bDB[i] = bTcpaHash[i];

	// Concatenate KEY_LEN-wInpLen-2*HASH_LEN-2 Zero-Bytes
	while (i < KEY_LEN - (BYTE) (wInpLen) - HASH_LEN - 2) {
		bDB[i] = 0x00;
		i++;
	}
	bDB[i] = 0x01;		// Concatenate 0x01
	i++;
	while (i < KEY_LEN - HASH_LEN - 1)	// Concatenate input message
	{
		bDB[i] = *(pbM + (i - (KEY_LEN - (BYTE) (wInpLen) - HASH_LEN - 1)));
		i++;
	}
	//memcpy(&bDB[i], (pbM + (i - (KEY_LEN - (BYTE) (wInpLen) - HASH_LEN - 1))), (KEY_LEN - HASH_LEN - 1));

	// Get pseudo random Byte string seed, if predefined pbSeed == NULL
	if (pbSeed == NULL) {
		pbSeed = bTempSeed;
		for (i = 0; i < HASH_LEN; i++)
			pbSeed[i] = i;
	}
	// Mask DB and seed
	if (MGF(pbSeed, HASH_LEN, KEY_LEN - HASH_LEN - 1, bDB_Mask) != 0)
		return (-1);
	for (i = 0; i < KEY_LEN - HASH_LEN - 1; i++)
		bDB[i] = bDB[i] ^ bDB_Mask[i];
	if (MGF(bDB, KEY_LEN - HASH_LEN - 1, HASH_LEN, bSeedMask) != 0)
		return (-1);
	for (i = 0; i < HASH_LEN; i++)
		pbSeed[i] = pbSeed[i] ^ bSeedMask[i];

	// Concatenate masked seed and data block to encoded message
	pbEM[0] = 0;
	for (i = 0; i < HASH_LEN; i++) {
		pbEM[i + 1] = pbSeed[i];
	}
	for (i = 0; i < KEY_LEN - HASH_LEN - 1; i++)
		pbEM[i + 1 + HASH_LEN] = bDB[i];
	//memcpy(&pbEM[1 + HASH_LEN], bDB, (KEY_LEN - HASH_LEN - 1));

	return (0);
}				/* iPad() */
ENABLE_OPTIMIZATION

// Mask Generation Function "MGF1" according to PKCS #1 v2.1 ------------------------------------
/* ATTENTION!
 *	Compared to the PKCS, there are stricter length limitations:
 *	bMaskLen and bSeedLen must not be greater than 255!
 */
DISABLE_OPTIMIZATION	// because of memcpy optimization of loops 
static char UNOPTIMIZED MGF(const BYTE * const pbSeedInp, const BYTE bSeedLen, const BYTE bMaskLen, BYTE * const pbMask)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	BYTE bCount;
	BYTE bHashOutp[HASH_LEN];
	BYTE *pbHashInp = NULL;
	BYTE *T = NULL;
	BYTE i;

	do {
		// Memory allocation for the hash input and the temporary working value 'T'
		SAFE_CALLOC(pbHashInp, bSeedLen + 4, &dwRCVal);
		SAFE_CALLOC(T, (bMaskLen / HASH_LEN + 1) * HASH_LEN, &dwRCVal);

		// General hash input preparation
		for (i = 0; i < bSeedLen; i++)
			pbHashInp[i] = *(pbSeedInp + i);
		pbHashInp[i++] = 0;
		pbHashInp[i++] = 0;
		pbHashInp[i] = 0;

		// Concatenate hash values to T
		for (bCount = 0; bCount <= bMaskLen / HASH_LEN; bCount++) {
			pbHashInp[bSeedLen + 3] = bCount;	// Loop run specific hash input preparation
			dwRCVal = SHA1_Func(pbHashInp, (UINT16) (bSeedLen + 4), bHashOutp);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			for (i = 0; i < HASH_LEN; i++)
				T[bCount * HASH_LEN + i] = bHashOutp[i];	// Concatenation
		}

		// Output of the first <bMaskLen> Bytes of T
		for (i = 0; i < bMaskLen; i++)
			*(pbMask + i) = T[i];

		dwRCVal = RC_SUCCESS;
	} while (FALSE);

	// Deallocate memory
	SAFE_FREE(pbHashInp);
	SAFE_FREE(T);

	return (dwRCVal == RC_SUCCESS ? 0 : -1);
}				/* MGF() */
ENABLE_OPTIMIZATION