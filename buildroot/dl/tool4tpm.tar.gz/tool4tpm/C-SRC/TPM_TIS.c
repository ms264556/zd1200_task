/*++

Copyright (c) 2013  Infineon Technologies A.G.

Module Name:

	TPM_TIS.c

Abstract:
	Implementation of the TIS related Functions

Author:

	Georg Rankl

Environment:

	Win32/Win64

Revision History:
	01		First revision

Notes:

--*/
#ifdef UEFI_X64
#include <Library/UefiLib.h>	// because of Print
#else
#ifdef WIN32
#include <windows.h>
#endif //-------WIN32----------
#include <stdio.h>
#endif //-------UEFI_X64----------
#include "Globals.h"
#include "TPM_TIS.h"
#include "LowLevIO.h"
#include "ProgFunc.h"

/*++
TIS_ReadRegister

Description:

Read the value of a TIS register

Arguments:
bLocality
wRegOffset
bRegSize
pdwValue

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ReadRegister(BYTE bLocality, UINT16 wRegOffset, BYTE bRegSize, void *pValue)
{
	UINT32 dwReturnCode = RC_SUCCESS;

#if defined(UEFI_X64) && !defined(UEFI_I2C)
	UINT16 dwTemp;
#endif

#ifdef UEFI_I2C
	UINT8 i = 0;
	BYTE bTmpSfrAdr;
#else
	UINT32 dwAddress = 0;
#endif

	do {

#ifdef UEFI_I2C
		bTmpSfrAdr = (bLocality << IFX_LOCALITY_SHIFT) | (UINT8) wRegOffset;

		for (i = 0; i < LATE_ACK_RETRY; i++) {
			dwReturnCode = HPP_ReadData(bTmpSfrAdr, (UINT16)bRegSize, (BYTE*)pValue);
			if ( (wRegOffset == TIS_TPM_ACCESS && (*(BYTE*)pValue & 0x40) == 0x40) || 
					 (wRegOffset == TIS_TPM_STS && (*(BYTE*)pValue & 0x04) == 0x04) ||
					 (wRegOffset == TIS_TPM_STS && (*(BYTE*)pValue & 0x01) == 0x01) ) {
				Log("  TIS_ReadRegister: %0.2X-SFR shows invalid %0.2X data. Redoing access\n", bTmpSfrAdr, *(BYTE*)pValue);
				Sleep_us(LATE_ACK_TIME);
				continue;
			}
			break;
		}
#else
		switch (bLocality) {
		case TIS_LOCALITY_0:
			dwAddress = TIS_LOCALITY0OFFSET;
			break;

		case TIS_LOCALITY_1:
			dwAddress = TIS_LOCALITY1OFFSET;
			break;

		case TIS_LOCALITY_2:
			dwAddress = TIS_LOCALITY2OFFSET;
			break;

		case TIS_LOCALITY_3:
			dwAddress = TIS_LOCALITY3OFFSET;
			break;

		case TIS_LOCALITY_4:
			dwAddress = TIS_LOCALITY4OFFSET;
			break;

		default:
			dwReturnCode = RC_E_LOCALITY_NOT_SUPPORTED;
		}

		if (dwReturnCode != RC_SUCCESS)
			break;

		// Calculate effective Address
		dwAddress = dwAddress | wRegOffset;

		switch (bRegSize) {
		case sizeof(BYTE):
			*(BYTE *) pValue = MemAccessReadByte(dwAddress);
			break;

		case sizeof(UINT16):
#ifdef UEFI_X64
			// 16 bit read access must be aligned on a 16-bit boundary
			// because of that the access is split up into two 8 bit read's if necessary
			// This restriction is also true for a 16 bit write, and a 32 bit read/write access,
			// (32-bit aligned) but for the LPC-TPM there is so far no use case for this access 
			if ((dwAddress & 1) == 1) {
				*(UINT16 *) pValue = MemAccessReadByte(dwAddress);
				dwTemp = MemAccessReadByte(dwAddress+1);
				*(UINT16 *) pValue |= (dwTemp << 8);
				break;
			}
#endif
			*(UINT16 *) pValue = MemAccessReadWord(dwAddress);
			break;

		case sizeof(UINT32):
			*(UINT32 *) pValue = MemAccessReadDWord(dwAddress);
			break;

		default:
			// Invalid Register Size requested
			dwReturnCode = RC_E_BAD_PARAMETER;
		}
#endif

	} while (FALSE);

	return dwReturnCode;

}

/*++
TIS_WriteRegister

Description:

Write the value into a TIS register

Arguments:
bLocality
wRegOffset
bRegSize
dwValue

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_WriteRegister(BYTE bLocality, UINT16 wRegOffset, BYTE bRegSize, UINT32 dwValue)
{
	UINT32 dwReturnCode = RC_SUCCESS;
#ifdef UEFI_I2C
	BYTE bSfrAddr;
#else
	UINT32 dwAddress = 0;
#endif

	do {
#ifdef UEFI_I2C
		bSfrAddr = (bLocality << IFX_LOCALITY_SHIFT) | (BYTE) wRegOffset;
		dwReturnCode = HPP_WriteData(bSfrAddr, bRegSize, (BYTE *) & dwValue);
#else
		switch (bLocality) {
			case TIS_LOCALITY_0:
				dwAddress = TIS_LOCALITY0OFFSET;
				break;

			case TIS_LOCALITY_1:
				dwAddress = TIS_LOCALITY1OFFSET;
				break;

			case TIS_LOCALITY_2:
				dwAddress = TIS_LOCALITY2OFFSET;
				break;

			case TIS_LOCALITY_3:
				dwAddress = TIS_LOCALITY3OFFSET;
				break;

			case TIS_LOCALITY_4:
				dwAddress = TIS_LOCALITY4OFFSET;
				break;

			default:
				dwReturnCode = RC_E_LOCALITY_NOT_SUPPORTED;
			}

			if (dwReturnCode != RC_SUCCESS)
				break;

			// Calculate effective Address
			dwAddress = dwAddress | wRegOffset;

			switch (bRegSize) {
			case sizeof(BYTE):
				MemAccessWriteByte(dwAddress, (BYTE) dwValue);
				break;

			case sizeof(UINT16):
				MemAccessWriteWord(dwAddress, (UINT16) dwValue);
				break;

			case sizeof(UINT32):
				MemAccessWriteDWord(dwAddress, (UINT32) dwValue);
				break;

			default:
				// Invalid Register Size requested
				dwReturnCode = RC_E_BAD_PARAMETER;
		}
#endif

	} while (FALSE);

	return dwReturnCode;

}

/*++
TIS_ReadAccessRegister

Description:

Read the value from the Access register

Arguments:
bLocality
pbValue

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ReadAccessRegister(BYTE bLocality, BYTE * pbValue)
{
	UINT32 dwReturnCode = RC_SUCCESS;

	dwReturnCode = TIS_ReadRegister(bLocality, TIS_TPM_ACCESS, sizeof(BYTE), pbValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (*pbValue == 0xFF)
			// Access register may never be 0xFF if TPM is working
			dwReturnCode = RC_E_COMPONENT_NOT_FOUND;

	}

	return dwReturnCode;
}

/*++
TIS_ReadStsRegister

Description:

Read the value from the Status register

Arguments:
bLocality
pbValue

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ReadStsRegister(BYTE bLocality, BYTE * pbValue)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	BOOL bFlag;

	do {
		// Check whether requested Locality is active
		dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if (!bFlag) {
			dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			break;
		}

		dwReturnCode = TIS_ReadRegister(bLocality, TIS_TPM_STS, sizeof(BYTE), pbValue);

	} while (FALSE);

	return dwReturnCode;
}

/*++
TIS_WriteStsRegister

Description:

Writes the value into the Status register

Arguments:
bLocality
bValue

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_WriteStsRegister(BYTE bLocality, BYTE bValue)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	BOOL bFlag;

	do {
		// Check whether requested Locality is active
		dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if (!bFlag) {
			dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			break;
		}

		dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_STS, sizeof(BYTE), (UINT32) bValue);

	} while (FALSE);

	return dwReturnCode;
}

/*++
TIS_IsAccessValid

Description:

Returns the value of TPM.ACCESS.VALID

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsAccessValid(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadAccessRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_ACCESS_VALID)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_IsActiveLocality

Description:

Returns the value of TPM.ACCESS.ACTIVE.LOCALITY

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsActiveLocality(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadAccessRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_ACCESS_ACTIVELOCALITY)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_ReleaseActiveLocality

Description:

Release the currently active locality

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ReleaseActiveLocality(BYTE bLocality)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	// To clear the active Locality a 1 must be written to ACCESS.activeLocality
	bValue = TIS_TPM_ACCESS_ACTIVELOCALITY;
	dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_ACCESS, sizeof(BYTE), (UINT32) bValue);

	return dwReturnCode;
}

/*++
TIS_IsSeized

Description:

Returns the value of TPM.ACCESS.BEEN.SEIZED

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsSeized(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadAccessRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_ACCESS_BEENSEIZED)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_ClearBeenSeized

Description:

Clears TPM.ACCESS.BEEN.SEIZED

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ClearBeenSeized(BYTE bLocality)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	// To clear the beenSeized Bit a 1 must be written to ACCESS.beenSeized
	bValue = TIS_TPM_ACCESS_BEENSEIZED;
	dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_ACCESS, sizeof(BYTE), (UINT32) bValue);

	return dwReturnCode;
}

/*++
TIS_Seize

Description:

Seize the TPM from a lower locality

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_Seize(BYTE bLocality)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	// To seize the TPM from a lower Locality a 1 must be written to ACCESS.Seize
	bValue = TIS_TPM_ACCESS_SEIZE;
	dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_ACCESS, sizeof(BYTE), (UINT32) bValue);

	return dwReturnCode;
}

/*++
TIS_IsPendingRequest

Description:

Returns the value of TPM.ACCESS.PENDING.REQUEST

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsPendingRequest(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadAccessRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_ACCESS_PENDINGREQUEST)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_RequestUse

Description:

Requests ownership of the TPM

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_RequestUse(BYTE bLocality)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	// To request the TPM for a given Locality a 1 must be written to ACCESS.requestUse
	bValue = TIS_TPM_ACCESS_REQUESTUSE;
	dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_ACCESS, sizeof(BYTE), (UINT32) bValue);

	return dwReturnCode;
}

/*++
TIS_IsRequestUse

Description:

Returns the value of TPM.ACCESS.REQUEST.USE

Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsRequestUse(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadAccessRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_ACCESS_REQUESTUSE)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_IsEstablishement

Description:

Returns the value of TPM.ACCESS.TPM.ESTABLISHEMENT

Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsEstablishement(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadAccessRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_ACCESS_ESTABLISHEMENT)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_GetBurstCount

Description:

Returns the value of TPM.STS.BURSTCOUNT

Arguments:
bLocality
*pwBurstCount

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_GetBurstCount(BYTE bLocality, UINT16 * pwBurstCount)
{
	UINT32 dwReturnCode;
	BOOL bFlag;
#ifdef UEFI_I2C
	BYTE bRxData[3];
#endif

	do {
		// Check whether requested Locality is active
		dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if (!bFlag) {
			dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			break;
		}
#ifdef UEFI_I2C
		dwReturnCode = TIS_ReadRegister(bLocality, TIS_TPM_STS, 3, bRxData);
		*pwBurstCount = ((UINT16) bRxData[2] << 8) | ((UINT16) bRxData[1]);
#else
		dwReturnCode = TIS_ReadRegister(bLocality, TIS_TPM_BURSTCOUNT, sizeof(UINT16), pwBurstCount);
#endif
		if (dwReturnCode != RC_SUCCESS)
			*pwBurstCount = 0;

	} while (FALSE);

	return dwReturnCode;
}

/*++
TIS_IsStsValid

Description:

Returns the value of TPM.STS.VALID

Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsStsValid(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_STS_VALID)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_IsCommandReady

Description:

Returns the value of TPM.STS.COMMAND.READY

Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsCommandReady(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if (bValue & TIS_TPM_STS_CMDRDY)
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_Abort

Description:

Aborts the currently running action by writing 1 to Command Ready

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_Abort(BYTE bLocality)
{
	UINT32 dwReturnCode;

	dwReturnCode = TIS_WriteStsRegister(bLocality, TIS_TPM_STS_CMDRDY);

	return dwReturnCode;
}

/*++
TIS_Go

Description:

Lets the TPM execute a command

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_Go(BYTE bLocality)
{
	UINT32 dwReturnCode;

	dwReturnCode = TIS_WriteStsRegister(bLocality, TIS_TPM_STS_GO);

	return dwReturnCode;
}

/*++
TIS_IsDataAvailable

Description:

Returns the value of TPM.STS.DATA.AVAIL

Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsDataAvailable(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if ((bValue & TIS_TPM_STS_VALID) && (bValue & TIS_TPM_STS_AVAIL))
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_IsExpect

Description:

Returns the value of TPM.STS.EXPECT

Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_IsExpect(BYTE bLocality, BOOL * pbFlag)
{
	UINT32 dwReturnCode;
	BYTE bValue;

	dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);

	if (dwReturnCode == RC_SUCCESS) {
		if ((bValue & TIS_TPM_STS_VALID) && (bValue & TIS_TPM_STS_EXPECT))
			*pbFlag = TRUE;
		else
			*pbFlag = FALSE;
	}

	return dwReturnCode;
}

/*++
TIS_Retry

Description:

Lets the TPM repeat the last response

Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_Retry(BYTE bLocality)
{
	UINT32 dwReturnCode;

	dwReturnCode = TIS_WriteStsRegister(bLocality, TIS_TPM_STS_RETRY);

	return dwReturnCode;
}

/*++
TIS_GetVendorID

Description:

Reads the Vendor ID from the TPM

Arguments:
*pwVendorID

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_GetVendorID(UINT16 * pwVendorID)
{
	UINT32 dwReturnCode;

	dwReturnCode = TIS_ReadRegister(TIS_LOCALITY_0, TIS_TPM_VID, sizeof(UINT16), pwVendorID);

	if (dwReturnCode != RC_SUCCESS)
		*pwVendorID = 0;
	else if (*pwVendorID == 0xFFFF)
		// ID register may never be 0xFFFF if TPM is working
		dwReturnCode = RC_E_COMPONENT_NOT_FOUND;

	return dwReturnCode;
}

/*++
TIS_GetDeviceID

Description:

Reads the Device ID from the TPM

Arguments:
*pwDeviceID

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_GetDeviceID(UINT16 * pwDeviceID)
{
	UINT32 dwReturnCode;

	dwReturnCode = TIS_ReadRegister(TIS_LOCALITY_0, TIS_TPM_DID, sizeof(UINT16), pwDeviceID);

	if (dwReturnCode != RC_SUCCESS)
		*pwDeviceID = 0;
	else if (*pwDeviceID == 0xFFFF)
		// ID register may never be 0xFFFF if TPM is working
		dwReturnCode = RC_E_COMPONENT_NOT_FOUND;

	return dwReturnCode;
}

/*++
TIS_GetRevisionID

Description:

Reads the Revision ID from the TPM

Arguments:
*pbRevisionID

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_GetRevisionID(BYTE * pbRevisionID)
{
	UINT32 dwReturnCode;

	dwReturnCode = TIS_ReadRegister(TIS_LOCALITY_0, TIS_TPM_RID, sizeof(BYTE), pbRevisionID);

	if (dwReturnCode != RC_SUCCESS)
		*pbRevisionID = 0;
	else if (*pbRevisionID == 0xFF)
		// ID register may never be 0xFF if TPM is working
		dwReturnCode = RC_E_COMPONENT_NOT_FOUND;

	return dwReturnCode;
}

/*++
TIS_WriteByteLPC

Description:

Send one Byte to the TPM TIS data FIFO

Arguments:
bLocality
bByteToWrite	Byte to send

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS	operation completed successfully.
	RC_E_FAILURE	Byte could not be written

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_WriteByteLPC(BYTE bLocality, BYTE bByteToWrite)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	BYTE bValue;
	BOOL bFlag;
	UINT16 wBurstCount = 0;

	do {
		// Check whether requested Locality is active
		dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if (!bFlag) {
			dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			break;
		}
		// Now check whether a Byte can be placed in the TPM FIFO
		dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if (((bValue & TIS_TPM_STS_CMDRDY) || (bValue & (TIS_TPM_STS_VALID | TIS_TPM_STS_EXPECT))) == FALSE) {
			dwReturnCode = RC_E_NOT_READY;
			break;
		}

		dwReturnCode = TIS_GetBurstCount(bLocality, &wBurstCount);
		if (wBurstCount == 0) {
			dwReturnCode = RC_E_NOT_READY;
			break;
		}
		// All ok, now write Byte to the TPM FIFO
		dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_DATA_FIFO, sizeof(BYTE), (UINT32) bByteToWrite);

	} while (FALSE);

	return dwReturnCode;
}

/*++
TIS_ReadByteLPC

Description:

Read one Byte from the TPM TIS data FIFO

Arguments:
bLocality
pbByteToRead	Byte to read

Return Value:
	Return			Meaning
	======			=======
	SUCCESS			operation completed successfully.
	RC_E_FAILURE	Byte could not be written

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ReadByteLPC(BYTE bLocality, BYTE * pbByteToRead)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	BYTE bValue;
	BOOL bFlag;
	UINT16 wBurstCount = 0;

	do {
		// Check whether requested Locality is active
		dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if (!bFlag) {
			dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			break;
		}
		// Now check whether a Byte can be read from the TPM FIFO
		dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);
		if (dwReturnCode != RC_SUCCESS)
			break;

		if ((bValue & (TIS_TPM_STS_VALID | TIS_TPM_STS_AVAIL)) == FALSE) {
			dwReturnCode = RC_E_TPM_NO_DATA_AVAILABLE;
			break;
		}

		dwReturnCode = TIS_GetBurstCount(bLocality, &wBurstCount);
		if (wBurstCount == 0) {
			dwReturnCode = RC_E_NOT_READY;
			break;
		}
		// All ok, now write Byte to the TPM FIFO
		dwReturnCode = TIS_ReadRegister(bLocality, TIS_TPM_DATA_FIFO, sizeof(BYTE), pbByteToRead);

	} while (FALSE);

	return dwReturnCode;
}

/*++
TIS_SendLPC

Description:

Send a data block to the TPM TIS data FIFO under consideration of the
TIS communication protocol

Arguments:
bLocality
pbByteBuf		Buffer to send
wLen			Size of send buffer

Return Value:
	Return				Meaning
	======				=======
	SUCCESS				operation completed successfully.
	RC_E_TIMEOUT		Timeout
	RC_E_INVALID_PARAM	Wrong parameters

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_SendLPC(BYTE bLocality, BYTE * pbByteBuf, UINT16 wLen)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	BYTE bValue, i;
	BOOL bFlag;
	UINT16 wBurstCount, wTxSize;
	UINT32 dwTimeOut;
	BYTE *pbTxData;

	wTxSize = wLen;
	pbTxData = pbByteBuf;

	do {
		// Request the locality
		dwReturnCode = TIS_RequestUse(bLocality);
		if (dwReturnCode != RC_SUCCESS)
			break;

		// Check whether requested Locality is active, timeout after TIMEOUT_A
		dwTimeOut = (TIMEOUT_A * 1000) / SLEEP_TIME_US_CR;
		do {
			dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
			if (dwReturnCode != RC_SUCCESS)
				dwTimeOut = 0;	// Stop immediately on Error
			else if (bFlag)
				dwTimeOut = 0;	// Stop immediately if Flag is set
			else {
				Sleep_us(SLEEP_TIME_US_CR);
				dwTimeOut = dwTimeOut - 1;
				if (dwTimeOut == 0)
					dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			}

		} while (dwTimeOut > 0);
		if (dwReturnCode != RC_SUCCESS)
			break;

		// Check the commandReady flag first
		dwReturnCode = TIS_IsCommandReady(bLocality, &bFlag);
		if (bFlag == FALSE) {
			dwReturnCode = TIS_Abort(bLocality);
			if (dwReturnCode != RC_SUCCESS)
				break;

			// Check whether the TPM can receive a command, timeout after TIMEOUT_B
			dwTimeOut = (TIMEOUT_B * 1000) / SLEEP_TIME_US;
			do {
				dwReturnCode = TIS_IsCommandReady(bLocality, &bFlag);
				if (dwReturnCode != RC_SUCCESS)
					dwTimeOut = 0;	// Stop immediately on Error
				else if (bFlag)
					dwTimeOut = 0;	// Stop immediately if Flag is set
				else {
					Sleep_us(SLEEP_TIME_US);
					dwTimeOut = dwTimeOut - 1;
					if (dwTimeOut == 0)
						dwReturnCode = RC_E_NOT_READY;
				}

			} while (dwTimeOut > 0);
		}
		if (dwReturnCode != RC_SUCCESS)
			break;

#ifdef UEFI_I2C
		if (wLen >= 0) {		//always use this branch
#else
		if (wLen > 9) {			//10 bytes should always be writeable
#endif
			do {
				// Read the BurstCount register, timeout after TIMEOUT_C if it remains 0
				dwTimeOut = (TIMEOUT_C * 1000) / SLEEP_TIME_US_BURSTCOUNT;
				do {
					dwReturnCode = TIS_GetBurstCount(bLocality, &wBurstCount);
					if (dwReturnCode != RC_SUCCESS)
						dwTimeOut = 0;	// Stop immediately on Error
					else if (wBurstCount > 0)
						dwTimeOut = 0;
					else {
						Sleep_us(SLEEP_TIME_US_BURSTCOUNT);
						dwTimeOut = dwTimeOut - 1;
						if (dwTimeOut == 0)
							dwReturnCode = RC_E_NOT_READY;
					}

				} while (dwTimeOut > 0);
				if (dwReturnCode != RC_SUCCESS)
					break;
#ifdef UEFI_I2C
				if (wBurstCount >= wTxSize) {
					wBurstCount = wTxSize - 1;
				}

				dwReturnCode = HPP_WriteData((bLocality << IFX_LOCALITY_SHIFT)|TIS_TPM_DATA_FIFO, wBurstCount, pbTxData);
				pbTxData += wBurstCount;
				wTxSize -= wBurstCount;
#else
				if (wTxSize > wBurstCount) {
					for (i = 0; i < wBurstCount; i++) {
						// All ok, now write Byte to the TPM FIFO
						dwReturnCode = TIS_WriteRegister(bLocality,
								TIS_TPM_DATA_FIFO,
								sizeof(BYTE), (UINT32) * pbTxData);

						if (dwReturnCode != RC_SUCCESS)
							break;
						pbTxData++;

					}
					wTxSize -= wBurstCount;

				} else {
					for (i = 0; i < (wTxSize - 1); i++) {
						// All ok, now write Byte(s) to the TPM FIFO
						dwReturnCode = TIS_WriteRegister(bLocality,
								TIS_TPM_DATA_FIFO,
								sizeof(BYTE), (UINT32) * pbTxData);

						if (dwReturnCode != RC_SUCCESS)
							break;
						pbTxData++;

					}
					wTxSize = 1;

				}
#endif
				if (dwReturnCode != RC_SUCCESS)
					break;

			} while (wTxSize > 1);
			//// Request the locality
			//dwReturnCode = TIS_RequestUse(bLocality);
			//if (dwReturnCode != RC_SUCCESS)
			//	break;

			//// Check whether requested Locality is active, timeout after TIMEOUT_A
			//dwTimeOut = (TIMEOUT_A * 1000) / SLEEP_TIME_US;
			//do {
			//	dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
			//	if (dwReturnCode != RC_SUCCESS)
			//		dwTimeOut = 0;	// Stop immediately on Error
			//	else if (bFlag)
			//		dwTimeOut = 0;	// Stop immediately if Flag is set
			//	else {
			//		Sleep_us(SLEEP_TIME_US);
			//		dwTimeOut = dwTimeOut - 1;
			//		if (dwTimeOut == 0)
			//			dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
			//	}

			//} while (dwTimeOut > 0);

			//if (dwReturnCode != RC_SUCCESS)
			//	break; 

			//Last Byte, check stsValid & stsExpect, timeout after TIMEOUT_C
			dwTimeOut = (TIMEOUT_C * 1000) / SLEEP_TIME_US;
			do {
				dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);
				if (dwReturnCode != RC_SUCCESS)
					dwTimeOut = 0;	// Stop immediately on Error
				else if ((bValue & TIS_TPM_STS_VALID) && (bValue & TIS_TPM_STS_EXPECT))
					dwTimeOut = 0;	// Stop immediately if Flag is set
				else {
					Sleep_us(SLEEP_TIME_US);
					dwTimeOut = dwTimeOut - 1;
					if (dwTimeOut == 0)
						dwReturnCode = RC_E_TPM_TRANSMIT_DATA;
				}

			} while (dwTimeOut > 0);
			if (dwReturnCode != RC_SUCCESS) {
				TIS_Abort(bLocality);	// Abort TPM in case of an Error
				break;
			}
			// Transmit the last Byte now
			dwReturnCode = TIS_WriteRegister(bLocality, TIS_TPM_DATA_FIFO, sizeof(BYTE), (UINT32) * pbTxData);
		} else { //10 bytes should always be writeable, for HPP_I2C this code is never executed
			for (i = 0; i < wLen; i++) {
				// All ok, now write Byte to the TPM FIFO
				dwReturnCode = TIS_WriteRegister(bLocality,
						TIS_TPM_DATA_FIFO,
						sizeof(BYTE), (UINT32) * pbTxData);

				if (dwReturnCode != RC_SUCCESS)
					break;
				pbTxData++;

			}
		}

		//After the last Byte, check stsValid=TRUE & stsExpect=FALSE, timeout after TIMEOUT_C
		dwTimeOut = (TIMEOUT_C * 1000) / SLEEP_TIME_US;
		do {
			dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);
			if (dwReturnCode != RC_SUCCESS)
				dwTimeOut = 0;	// Stop immediately on Error
			else if ((bValue & TIS_TPM_STS_VALID) && (!(bValue & TIS_TPM_STS_EXPECT)))
				dwTimeOut = 0;	// Stop immediately if condition is met
			else {
				Sleep_us(SLEEP_TIME_US);
				dwTimeOut = dwTimeOut - 1;
				if (dwTimeOut == 0)
					dwReturnCode = RC_E_TPM_TRANSMIT_DATA;
			}

		} while (dwTimeOut > 0);
		if (dwReturnCode != RC_SUCCESS) {
			TIS_Abort(bLocality);	// Abort TPM in case of an Error
			break;
		}
		// Successful Transmission, now the command can be executed
		dwReturnCode = TIS_Go(bLocality);

	} while (FALSE);

	return dwReturnCode;
}

/*++
TIS_ReadLPC

Description:

Read a data block from the TPM TIS port

Arguments:
bLocality
pbByteBuf		Buffer to receive
pwLen			Max Size of receive buffer/Actual size received

Return Value:
	Return				Meaning
	======				=======
	SUCCESS				operation completed successfully.
	RC_E_TIMEOUT		Timeout
	RC_E_INVALID_PARAM	Wrong parameters

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_ReadLPC(BYTE bLocality, BYTE * pbByteBuf, UINT16 * pwLen)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	BYTE bValue, bRetryCount;
	BOOL bFlag, bUpdateBytes2Read, bRxDone;
	UINT16 wBurstCount, wRxSize, wBytes2Read;
	UINT32 dwTimeOut;
	BYTE *pbRxData;

	#ifndef UEFI_I2C
	BYTE i;
	#endif

	bRxDone = FALSE;
	bRetryCount = 0;

	do {
		do {
			pbRxData = pbByteBuf;
			bUpdateBytes2Read = TRUE;
			// Basic Buffersize check, must be at least 10 Bytes (TAG, Size, Ordinal)
			if (*pwLen < 10) {
				dwReturnCode = RC_E_INSUFFICIENT_BUFFER;
				bRxDone = TRUE;	// It makes no sense to retry if the buffer is too small
				break;
			}
			// Check whether requested Locality is active
			dwReturnCode = TIS_IsActiveLocality(bLocality, &bFlag);
			if (dwReturnCode != RC_SUCCESS) {
				bRxDone = TRUE;	// Retry not reasonable if ACCESS can't be read
				break;	// Stop immediately on Error
			}

			if (!bFlag) {
				dwReturnCode = RC_E_LOCALITY_NOT_ACTIVE;
				bRxDone = TRUE;	// Retry not reasonable if the Locality ia not available
				break;
			}
			// Check whether there are already data available
			dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);
			if (dwReturnCode != RC_SUCCESS) {
				bRxDone = TRUE;	// Retry not reasonable if the STS register can't be read
				break;	// Stop immediately on Error
			}

			if ((!(bValue & TIS_TPM_STS_VALID)) || (!(bValue & TIS_TPM_STS_AVAIL))) {
				dwReturnCode = RC_E_TPM_NO_DATA_AVAILABLE;
				bRxDone = TRUE;	// Retry not reasonable when data are not available
				break;
			}
			// Set initial sizes
			wRxSize = 0;
			wBytes2Read = 10;

			while ((wBytes2Read - wRxSize) > 0) {
				// Read the BurstCounter whether there are Bytes in the data FIFO
				dwTimeOut = (TIMEOUT_D * 1000) / SLEEP_TIME_US_BURSTCOUNT;
				do {
					dwReturnCode = TIS_GetBurstCount(bLocality, &wBurstCount);
					if (dwReturnCode != RC_SUCCESS)
						dwTimeOut = 0;	// Stop immediately on Error
					else if (wBurstCount > 0)
						dwTimeOut = 0;
					else {
						Sleep_us(SLEEP_TIME_US_BURSTCOUNT);
						dwTimeOut = dwTimeOut - 1;
						if (dwTimeOut == 0)
							dwReturnCode = RC_E_NOT_READY;
					}

				} while (dwTimeOut > 0);
				if (dwReturnCode != RC_SUCCESS) {
					bRxDone = FALSE;	// It could make sense to retry
					break;
				}
				// Set BurstCount to the actual number of Bytes to be read
				if (wBurstCount > (wBytes2Read - wRxSize))
					wBurstCount = wBytes2Read - wRxSize;
#ifdef UEFI_I2C
				dwReturnCode = HPP_ReadData((bLocality << IFX_LOCALITY_SHIFT)|TIS_TPM_DATA_FIFO, wBurstCount, pbRxData);
				pbRxData += wBurstCount;
#else
				for (i = 0; i < wBurstCount; i++) {
					dwReturnCode = TIS_ReadRegister(bLocality,
							TIS_TPM_DATA_FIFO, sizeof(BYTE), pbRxData);

					if (dwReturnCode != RC_SUCCESS)
						break;

					pbRxData++;

				}
#endif
				if (dwReturnCode != RC_SUCCESS) {
					bRxDone = FALSE;	// It could make sense to retry
					break;
				}

				wRxSize += wBurstCount;

				// Correct the number of Bytes to be read according to the real param size if available
				if ((wRxSize > 5) && (bUpdateBytes2Read == TRUE)) {
					wBytes2Read = (pbByteBuf[4] << 8) + pbByteBuf[5];
					bUpdateBytes2Read = FALSE;
					// Check for sufficient space in the Buffer now
					if (*pwLen < wBytes2Read) {
						dwReturnCode = RC_E_INSUFFICIENT_BUFFER;
						bRxDone = TRUE;	// It makes no sense to retry if the buffer is too small
						break;
					}
				}

			};

			if (dwReturnCode != RC_SUCCESS)
				break;

			// All Bytes received, check whether this is indicated by the TPM
			dwTimeOut = (TIMEOUT_C * 1000) / SLEEP_TIME_US;
			do {
				dwReturnCode = TIS_ReadStsRegister(bLocality, &bValue);
				if (dwReturnCode != RC_SUCCESS)
					dwTimeOut = 0;	// Stop immediately on Error
				else if ((bValue & TIS_TPM_STS_VALID) && (!(bValue & TIS_TPM_STS_AVAIL)))
					dwTimeOut = 0;	// Stop immediately if condition is met
				else {
					Sleep_us(SLEEP_TIME_US);
					dwTimeOut = dwTimeOut - 1;
					if (dwTimeOut == 0)
						dwReturnCode = RC_E_TPM_RECEIVE_DATA;
				}

			} while (dwTimeOut > 0);
			if (dwReturnCode != RC_SUCCESS) {
				bRxDone = FALSE;
				break;
			}
			// Finally check the correct data size of the received data
			if (wRxSize != wBytes2Read) {
				dwReturnCode = RC_E_TPM_RECEIVE_DATA;
				bRxDone = FALSE;
				break;
			}
			// All ok, write CmdRdy to prepare the TPM for the next command and to release the retry buffer
			dwReturnCode = TIS_Abort(bLocality);
			if (dwReturnCode != RC_SUCCESS) {
				bRxDone = FALSE;
				break;
			}

			*pwLen = wRxSize;

			bRxDone = TRUE;	// Reception really successfully done

		} while (FALSE);

		if ((dwReturnCode != RC_SUCCESS) && (bRxDone == FALSE) && (bRetryCount < MAX_ERRORS)) {
			dwReturnCode = TIS_Retry(bLocality);
			if (dwReturnCode != RC_SUCCESS)
				bRxDone = TRUE;	// It makes no sense to retry if we have an error here

			bRetryCount++;
		} else if ((dwReturnCode != RC_SUCCESS) && (bRetryCount >= MAX_ERRORS)) {
			TIS_Abort(bLocality);
			bRxDone = TRUE;	// Max number of errors, abort reception
		}

	} while (!bRxDone);

	// Set received size to 0 in case of an error
	if (dwReturnCode != RC_SUCCESS)
		*pwLen = 0;

	return dwReturnCode;
}

/*++
TIS_TransceiveLPC

Description:

Sends the Tx Buffer to the TPM and returns the response

Arguments:
bLocality
pbTxBuffer		Buffer to send
wTxLen			Size of send buffer
pbRxBuffer		Buffer to receive
pwRxLen			Max Size of receive buffer/Actual size received

Return Value:
	Return				Meaning
	======				=======
	SUCCESS				operation completed successfully.
	RC_E_TIMEOUT		Timeout
	RC_E_INVALID_PARAM	Wrong parameters

Author:
	Georg Rankl (ran) 11.01.2007

--*/
UINT32 TIS_TransceiveLPC(BYTE bLocality, BYTE * pbTxBuffer, UINT16 wTxLen, BYTE * pbRxBuffer, UINT16 * pwRxLen)
{
	UINT32 dwReturnCode = RC_SUCCESS;
	UINT16 wRxSize;
	UINT32 dwTimeOut;
	BOOL bFlag;

	do {
		dwReturnCode = TIS_SendLPC(bLocality, pbTxBuffer, wTxLen);
		if (dwReturnCode != RC_SUCCESS)
			break;

		// Run reception until it is successful or has a fatal error
		dwTimeOut = (CMD_DURATION * 1000) / SLEEP_TIME_US;
		do {
			dwReturnCode = TIS_IsDataAvailable(bLocality, &bFlag);
			if (dwReturnCode != RC_SUCCESS)
				dwTimeOut = 0;	// Stop immediately on Error
			else if (bFlag)
				dwTimeOut = 0;	// Stop immediately if Flag is set
			else {
				Sleep_us(SLEEP_TIME_US);
				dwTimeOut = dwTimeOut - 1;
				if (dwTimeOut == 0)
					dwReturnCode = RC_E_TPM_NO_DATA_AVAILABLE;
			}

		} while (dwTimeOut > 0);
		if (dwReturnCode != RC_SUCCESS)
			break;

		wRxSize = *pwRxLen;
		dwReturnCode = TIS_ReadLPC(bLocality, pbRxBuffer, &wRxSize);

		*pwRxLen = wRxSize;
		if (dwReturnCode != RC_SUCCESS)
			break;

		// Release current Locality
		dwReturnCode = TIS_ReleaseActiveLocality(bLocality);

	} while (FALSE);

	return dwReturnCode;

}
