/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	LowLevIO.c

Description:	Implementation of the low level TPM communication

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/
#include "ProgFunc.h"
#include "LowLevIO.h"

#ifdef UEFI_X64
#include <Library/UefiApplicationEntryPoint.h>	// because of Exit
#include <Library/IoLib.h>											// because of TPM-LPC
#include <Library/UefiLib.h>										// because of Print
#else
#ifdef linux			//--------linux--------

#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>

static UINT32 dwFileHandle = 0;
static BYTE *bMemPtr = NULL;

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
#include "TVicPort.h"

static ULONG memPtr = 0L;

#else
#include "NT_Port.h"		// NTPort Library header
#include "MemAcc.h"		// MemAccess Library header
#include "Reg.h"		// Header file with MemAccess and NTPort registration information
#endif

#else //--------DOS-------------

#ifdef DJGPP
#include <dpmi.h>
static BYTE *pbMapMemoryAreaBase;	// Pointer to mapped memory area
static BYTE *pbMallocPt;	// Pointer to allocated memory (only needed for deallocation)
#else // DJGPP
// Use only when compiled for DOS environment without DJGPP
// If so, you also have to add "PortC.obj" to the project prior to compilation
extern UINT32 InPort32(UINT16 wportAdr);
extern UINT32 OutPort32(UINT16 wportAdr, UINT32 dwOutValue);
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux---------
#endif //--------UEFI_X64--------- 
// ==============================================================================================
// Init Functions
// ==============================================================================================

/*++
LowLevelInit

Description:
Initialize the appropriate low level driver

Arguments:
[in]	BYTE	bLocality		Used Locality

Return value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
#ifdef linux
#if USE_DRIVER == 0		// using native Linux interfaces
#undef DEV_TPM_MEM
#undef DEV_TPM_IO
#define DEV_TPM_MEM "/dev/mem"
#define DEV_TPM_IO "/dev/port"
#endif
#if USE_DRIVER == 2		// using TPM Driver interfaces
#undef DEV_TPM_MEM
#undef DEV_TPM_IO
#define DEV_TPM_MEM DEV_TPM_TPM
#define DEV_TPM_IO DEV_TPM_TPM
#endif
#endif

void LowLevelInit(BYTE bLocality)
{
#ifdef UEFI_X64
#ifdef UEFI_I2C
	InitializeI2c_Ex();
#else
	if (bLocality == LOCALITY_LEGACY) {
		Log("\n\tError: Legacy access is not supported with the UEFI version\n");
		Exit(RC_E_FAILURE);
	}
#endif
#else
#ifdef linux
	int rc = 0;
#if USE_DRIVER == 1
	Log("\n\t Using Kernel-Driver!\n");
#endif
	if (bLocality != LOCALITY_LEGACY) {
		dwFileHandle = open(DEV_TPM_MEM, O_RDWR);
		if (dwFileHandle == -1) {
			Log("\n\tError: open device pseudo file " DEV_TPM_MEM " failed !!! errno %d\n", errno);
			exit(EXIT_FAILURE);
		}
#if USE_DRIVER == 0
		bMemPtr =
		    (BYTE *) mmap(0, TPM_DEFAULT_MEM_SIZE, PROT_READ | PROT_WRITE, MAP_FILE | MAP_SHARED, dwFileHandle,
				  TPM_DEFAULT_MEM_BASE);
		if (bMemPtr == MAP_FAILED) {
			Log("\n\tError: Memory mapping failed !!! errno %d\n", errno);
			exit(EXIT_FAILURE);
		}
#endif
	} else {
		dwFileHandle = open(DEV_TPM_IO, O_RDWR);
		if (dwFileHandle == -1) {
			Log("\n\tError: open device pseudo file " DEV_TPM_IO " failed !!! errno %d\n", errno);
			exit(EXIT_FAILURE);
		}

	}
	//Drop Root-Privileges
	rc = seteuid(getuid());
	if(rc) {
		perror("Seteuid failed:");
		exit(errno);
	}
	rc = setegid(getgid());
	if(rc) {
		perror("Setegid failed:");
		exit(errno);
	}
#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV

	OpenTVicPort();

	if( IsDriverOpened() == FALSE )
	{
		Log("\n\tError: open \"TVicPort\"-Driver failed !!!\n");
		exit(EXIT_FAILURE);
	}

	memPtr = MapPhysToLinear( (ULONG) TPM_DEFAULT_MEM_BASE, (ULONG) TPM_DEFAULT_MEM_SIZE);

#else
	if (bLocality != LOCALITY_LEGACY) {

#ifdef MEMACC_REGISTERED
		maLicenseInfo(MEMACC_USER_NAME, MEMACC_KEY);
#endif // MEMACC_REGISTERED

		maOpenLibrary();
	}
#ifdef NT_PORT_REGISTERED
	else
		LicenseInfo(NT_PORT_USER_NAME, NT_PORT_KEY);
#endif // NT_PORT_REGISTERED

#endif
#else //--------DOS-------------

	if (bLocality != LOCALITY_LEGACY) {
#ifdef DJGPP
		// Get area for mapping high addresses
		pbMallocPt = malloc(0x6000);
		pbMapMemoryAreaBase = (char *)(((long)pbMallocPt + 0xfff) & 0xfffff000);
		if (__djgpp_map_physical_memory(pbMapMemoryAreaBase, 0x5000, TPM_DEFAULT_MEM_BASE) == -1) {
			SAFE_FREE(pbMallocPt);
			pbMallocPt = NULL;
			pbMapMemoryAreaBase = NULL;
			Log("\n\tError: DOS memory mapping failed !!!\n");
		}
#else // DJGPP
		Log("Memory access under DOS not available, if not compiled with DJGPP!\n");
		Log("Set 'USE_LEGACY' in the config file to '1' to use I/O access.\n");
		exit(1);
#endif // DJGPP
	}
#endif //-------DOS/WIN----------
#endif //--------linux--------
#endif //--------UEFI_X64--------
}

/*++
LowLevelUninit

Description:
Initialize the appropriate low level driver

Arguments:
[in]	BYTE	bLocality		Used Locality

Return value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void LowLevelUninit(BYTE bLocality)
{
#ifdef UEFI_X64

#else
#ifdef linux
	UINT32 dwRCVal = 0;
#if USE_DRIVER == 0
	if (bLocality != LOCALITY_LEGACY) {
		munmap(bMemPtr, TPM_DEFAULT_MEM_SIZE);
	}
#endif
	dwRCVal = close(dwFileHandle);
	if (dwRCVal == -1) {
		if (bLocality != LOCALITY_LEGACY) {
			Log("\n\tError: close device pseudo file " DEV_TPM_MEM " failed !!!\n");
		} else {
			Log("\n\tError: close device pseudo file " DEV_TPM_IO " failed !!!\n");
		}
		exit(EXIT_FAILURE);
	}
#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV

	UnmapMemory( (ULONG) TPM_DEFAULT_MEM_BASE, (ULONG) TPM_DEFAULT_MEM_SIZE);
	CloseTVicPort();

#else
	if (bLocality != LOCALITY_LEGACY)
		maCloseLibrary();
#endif
#else //--------DOS-------------

#ifdef DJGPP
	if (bLocality != LOCALITY_LEGACY)
		// Free mapping area
		SAFE_FREE(pbMallocPt);
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux--------
#endif //--------UEFI_X64--------
}

// ==============================================================================================
// I/O Access Functions
// ==============================================================================================
#ifndef TVICDRV		//  I/O Access Functions no longer supported since TVic-driver

/*++
InpByte

Description:
Read a Byte from the specified port address

Arguments:
[in]	UINT16	wPortAdr	Port address from which should be read

Return value:
Data value read from specified port

Author:		Markus Schmoelzer	2007/02/23
--*/
BYTE InpByte(UINT16 wPortAdr)
{
	BYTE bPortValue;

#ifdef linux
	UINT32 dwRC = 0;

	bPortValue = 0;
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETPORTADDR, &wPortAdr);
#else
	lseek(dwFileHandle, wPortAdr, SEEK_SET);
#endif
	if (dwRC != -1) {
		dwRC = read(dwFileHandle, &bPortValue, sizeof(bPortValue));
		if (dwRC == -1)
			Log("\n\tError: InpByte: read device pseudo file " DEV_TPM_IO " failed !!!\n");
	} else
		Log("\n\tError: InpByte: ioctl device pseudo file " DEV_TPM_IO " failed !!!\n");

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	bPortValue = ReadPort ((USHORT) wPortAdr);
#else
	// Use NTPort Library
	bPortValue = (BYTE) (Inp(wPortAdr));
#endif
#else //--------DOS-------------

#ifdef DJGPP
	// Use DJGPP functions
	bPortValue = (BYTE) (inp(wPortAdr));
#else // DJGPP
	// Use C Runtime Lib
	bPortValue = (BYTE) (_inp(wPortAdr));
#endif // DJGPP
#endif //-------DOS/WIN----------
#endif // linux
	DebugToFile("InpByte: Address: %0.4X: %0.2X\n", wPortAdr, bPortValue);
	return bPortValue;
}

/*++
OutByte

Description:
Write a Byte to the specified port address

Arguments:
[in]	UINT16	wPortAdr	Port address to which should be written
[in]	BYTE	bPortValue	Data to be written

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void OutByte(UINT16 wPortAdr, BYTE bPortValue)
{
	DebugToFile("OutByte: Address: %0.4X = %0.2X\n", wPortAdr, bPortValue);

#ifdef linux
	UINT32 dwRC = 0;

#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETPORTADDR, &wPortAdr);
#else
	lseek(dwFileHandle, wPortAdr, SEEK_SET);
#endif
	if (dwRC != -1) {
		dwRC = write(dwFileHandle, &bPortValue, sizeof(bPortValue));
		if (dwRC == -1)
			Log("\n\tError: OutByte: write device pseudo file " DEV_TPM_IO " failed !!!\n");
	} else
		Log("\n\tError: OutByte: ioctl device pseudo file " DEV_TPM_IO " failed !!!\n");

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	WritePort ((USHORT) wPortAdr, bPortValue);
#else
	// Use NTPort Library
	Outp(wPortAdr, bPortValue);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	// Use DJGPP functions
	outp(wPortAdr, bPortValue);
#else // DJGPP
	// Use C Runtime Lib
	_outp(wPortAdr, bPortValue);
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux---------
}

/*++
InpWord

Description:
Read a Word from the specified port address

Arguments:
[in]	UINT16	wPortAdr	Port address from which should be read

Return Value:
Data value read from specified port

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT16 InpWord(UINT16 wPortAdr)
{
	UINT16 wPortValue;

#ifdef linux
	UINT32 dwRC = 0;

	wPortValue = 0;
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETPORTADDR, &wPortAdr);
#else
	lseek(dwFileHandle, wPortAdr, SEEK_SET);
#endif
	if (dwRC != -1) {
		dwRC = read(dwFileHandle, &wPortValue, sizeof(wPortValue));
		if (dwRC == -1)
			Log("\n\tError: InpWord: read device pseudo file " DEV_TPM_IO " failed !!!\n");
	} else
		Log("\n\tError: InpWord: ioctl device pseudo file " DEV_TPM_IO " failed !!!\n");

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	wPortValue = ReadPortW ((USHORT) wPortAdr);
#else
	// Use NTPort Library
	wPortValue = Inpw(wPortAdr);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	// Use DJGPP functions
	wPortValue = (UINT16) (inpw(wPortAdr));
#else // DJGPP
	// Use C Runtime Lib
	wPortValue = (UINT16) (_inpw(wPortAdr));
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif // --------linux--------
	DebugToFile("InpWord: Address: %0.4X: %0.4X\n", wPortAdr, wPortValue);
	return wPortValue;
}

/*++
OutWord

Description:
Write a Word to the specified port address

Arguments:
[in]	UINT16	wPortAdr	Port address to which should be written
[in]	BYTE	wPortValue	Data to be written

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void OutWord(UINT16 wPortAdr, UINT16 wPortValue)
{
	DebugToFile("OutWord:  Address: %0.4X = %0.4X\n", wPortAdr, wPortValue);

#ifdef linux
	UINT32 dwRC = 0;

#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETPORTADDR, &wPortAdr);
#else
	lseek(dwFileHandle, wPortAdr, SEEK_SET);
#endif
	if (dwRC != -1) {
		dwRC = write(dwFileHandle, &wPortValue, sizeof(wPortValue));
		if (dwRC == -1)
			Log("\n\tError: OutWord: write device pseudo file " DEV_TPM_IO " failed !!!\n");
	} else
		Log("\n\tError: OutWord: ioctl device pseudo file " DEV_TPM_IO " failed !!!\n");

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	WritePortW((USHORT) wPortAdr, wPortValue); // write one word
#else
	// Use NTPort Library
	Outpw(wPortAdr, wPortValue);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	// Use DJGPP functions
	outpw(wPortAdr, wPortValue);
#else // DJGPP
	// Use C Runtime Lib
	_outpw(wPortAdr, wPortValue);
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux--------
}

/*++
InpDWord

Description:
Read a DoubleWord from the specified port address

Arguments:
[in]	UINT16	wPortAdr	Port address from which should be read

Return Value:
Data value read from specified port

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 InpDWord(UINT16 wPortAdr)
{
	UINT32 dwPortValue;

#ifdef linux
	UINT32 dwRC = 0;

	dwPortValue = 0;
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETPORTADDR, &wPortAdr);
#else
	lseek(dwFileHandle, wPortAdr, SEEK_SET);
#endif
	if (dwRC != -1) {
		dwRC = read(dwFileHandle, &dwPortValue, sizeof(dwPortValue));
		if (dwRC == -1)
			Log("\n\tError: InpDWord: read device pseudo file " DEV_TPM_IO " failed !!!\n");
	} else
		Log("\n\tError: InpDWord: ioctl device pseudo file " DEV_TPM_IO " failed !!!\n");

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	dwPortValue = ReadPortL ((USHORT) wPortAdr);
#else
	// Use NTPort Library
	dwPortValue = Inpd(wPortAdr);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	// Use DJGPP functions
	dwPortValue = (UINT32) (inportl(wPortAdr));
#else // DJGPP
	// Use PortC.obj
	dwPortValue = (UINT32) (InPort32(wPortAdr));
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux--------
	DebugToFile("InpDWord: Address: %0.4X: %0.8X\n", wPortAdr, dwPortValue);

	return dwPortValue;
}

/*++
OutDWord

Description:
Write a DoubleWord to the specified port address

Arguments:
[in]	UINT16	wPortAdr	Port address to which should be written
[in]	BYTE	dwPortValue	Data to be written

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void OutDWord(UINT16 wPortAdr, UINT32 dwPortValue)
{
#ifdef linux
	UINT32 dwRC = 0;

#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETPORTADDR, &wPortAdr);
#else
	lseek(dwFileHandle, wPortAdr, SEEK_SET);
#endif
	if (dwRC != -1) {
		dwRC = write(dwFileHandle, &dwPortValue, sizeof(dwPortValue));
		if (dwRC == -1)
			Log("\n\tError: OutDWord: write device pseudo file " DEV_TPM_IO " failed !!!\n");
	} else
		Log("\n\tError: OutDword: ioctl device pseudo file " DEV_TPM_IO " failed !!!\n");

	DebugToFile("OutDWord: Address: %0.4X = %0.8X\n", wPortAdr, dwPortValue);
#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	WritePortL((USHORT) wPortAdr, dwPortValue);
#else
	// Use NTPort Library
	DebugToFile("OutDWord: Address: %0.4X = %0.8X\n", wPortAdr, dwPortValue);
	Outpd(wPortAdr, dwPortValue);
#endif
#else //--------DOS-------------

	// Use C Runtime Lib
	DebugToFile("OutDWord: Address: %0.4X = %0.4X%0.4X\n", wPortAdr, (UINT16) (dwPortValue >> 16), (UINT16) dwPortValue);
#ifdef DJGPP
	// Use DJGPP functions
	outportl(wPortAdr, dwPortValue);
#else // DJGPP
	// Use PortC.obj
	OutPort32(wPortAdr, dwPortValue);
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux--------
}
#endif

// ==============================================================================================
// Memory Access Functions
// ==============================================================================================

/*++
MemAccessReadByte

Description:
Read a Byte from the specified memory address

Arguments:
[in]	UINT32	dwMemAddr	Memory address from which should be read

Return Value:
Data value read from specified memory

Author:		Markus Schmoelzer	2007/02/23
--*/
BYTE MemAccessReadByte(UINT32 dwMemAddr)
{
	BYTE bData;

#ifdef UEFI_X64
	bData = (UINT8)MmioRead8((UINTN)dwMemAddr);
	DebugToFile("MemAccessReadByte:   Address: %0.8X :         %0.2X\n", dwMemAddr, bData);
#else
#ifdef linux			//----------linux----------
	UINT32 dwRC = 0;

	bData = 0;
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETMEMADDR, &dwMemAddr);
	if (dwRC != -1) {
		dwRC = read(dwFileHandle, &bData, sizeof(bData));
		if (dwRC == -1)
			Log("\n\tError: MemAccessReadByte: read device pseudo file " DEV_TPM_MEM " failed !!!\n");
	} else
		Log("\n\tError: MemAccessReadByte: ioctl device pseudo file " DEV_TPM_MEM " failed !!!\n");
#else
	if (dwMemAddr < TPM_DEFAULT_MEM_BASE || dwMemAddr >= (TPM_DEFAULT_MEM_BASE + TPM_DEFAULT_MEM_SIZE))
		Log("\n\tError: MemAccessReadByte: MemAddress %x is invalid !!!\n", dwMemAddr);
	else
		bData = bMemPtr[dwMemAddr - TPM_DEFAULT_MEM_BASE];
#endif
	DebugToFile("MemAccessReadByte:   Address: %0.8X :         %0.2X\n", dwMemAddr, bData);
#else
#ifdef WIN32			//--------WIN32-----------
 #ifdef TVICDRV
	bData = GetMem( memPtr, dwMemAddr - TPM_DEFAULT_MEM_BASE );
 #else
	bData = maPeekB(dwMemAddr);
 #endif
	DebugToFile("MemAccessReadByte:   Address: %0.8X :         %0.2X\n", dwMemAddr, bData);
#else //--------DOS-------------

#ifdef DJGPP
	if (pbMapMemoryAreaBase != NULL) {
		UINT32 dwOffset = (UINT32) dwMemAddr - TPM_DEFAULT_MEM_BASE;
		BYTE *pData = (BYTE *) & pbMapMemoryAreaBase[dwOffset];
		bData = *pData;
		DebugToFile("MemAccessReadByte:   Address: %0.4X%0.4X :         %0.2X\n",
			    (UINT16) (dwMemAddr >> 16), (UINT16) dwMemAddr, bData);
	}
#else // DJGPP
	bData = 0xFF;
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //----------linux----------
#endif //----------UEFI_X64----------
	return bData;
}

/*++
MemAccessWriteByte

Description:
Write a Byte to the specified memory address

Arguments:
[in]	UINT32	dwMemAddr	Memory address to which should be written
[in]	BYTE	bData		Data to be written

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void MemAccessWriteByte(UINT32 dwMemAddr, BYTE bData)
{

#ifdef UEFI_X64
	UINT8 bRC = 0;
	DebugToFile("MemAccessWriteByte:  Address: %0.8X = %0.2X\n", dwMemAddr, bData);
	bRC = MmioWrite8(dwMemAddr, bData);
	
	if (bRC != bData) {
		//Log("\n\tError: MemAccessWriteByte: MemAddress %x is invalid !!!\n", dwMemAddr);
	}
	
#else
#ifdef linux			//----------linux----------
	UINT32 dwRC = 0;
	DebugToFile("MemAccessWriteByte:  Address: %0.8X = %0.2X\n", dwMemAddr, bData);
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETMEMADDR, &dwMemAddr);
	if (dwRC != -1) {
		dwRC = write(dwFileHandle, &bData, sizeof(bData));
		if (dwRC == -1)
			Log("\n\tError: MemAccessWriteByte: write device pseudo file " DEV_TPM_MEM " failed !!!\n");
	} else
		Log("\n\tError: MemAccessWriteByte: ioctl device pseudo file " DEV_TPM_MEM " failed !!!\n");
#else
	if (dwMemAddr < TPM_DEFAULT_MEM_BASE || dwMemAddr >= (TPM_DEFAULT_MEM_BASE + TPM_DEFAULT_MEM_SIZE))
		Log("\n\tError: MemAccessWriteByte: MemAddress %x is invalid !!!\n", dwMemAddr);
	else
		bMemPtr[dwMemAddr - TPM_DEFAULT_MEM_BASE] = bData;
#endif
#else
#ifdef WIN32			//--------WIN32-----------
	DebugToFile("MemAccessWriteByte:  Address: %0.8X = %0.2X\n", dwMemAddr, bData);
#ifdef TVICDRV
	SetMem( memPtr, dwMemAddr - TPM_DEFAULT_MEM_BASE, bData );
#else
	maPokeB(dwMemAddr, bData);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	if (pbMapMemoryAreaBase != NULL) {
		DebugToFile("MemAccessWriteBytX:  Address: %0.4X%0.4X = %0.2X\n",
			    (UINT16) (dwMemAddr >> 16), (UINT16) dwMemAddr, bData);

		UINT32 dwOffset = (UINT32) dwMemAddr - TPM_DEFAULT_MEM_BASE;
		BYTE *pData = (BYTE *) & pbMapMemoryAreaBase[dwOffset];
		*pData = bData;
	}
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //--------linux--------
#endif //----------UEFI_X64----------
}

/*++
MemAccessReadWord

Description:
Read a Word from the specified memory address

Arguments:
[in]	UINT32	dwMemAddr	Memory address from which should be read

Return Value:
Data value read from specified memory

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT16 MemAccessReadWord(UINT32 dwMemAddr)
{
	UINT16 wData = 0;

#ifdef UEFI_X64
	wData = MmioRead16((UINTN)dwMemAddr);
	DebugToFile("MemAccessReadWord:   Address: %0.8X :         %0.4X\n", dwMemAddr, wData);
#else
#ifdef linux			//----------linux----------
	UINT32 dwRC = 0;
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETMEMADDR, &dwMemAddr);
	if (dwRC != -1) {
		dwRC = read(dwFileHandle, &wData, sizeof(wData));
		if (dwRC == -1)
			Log("\n\tError: MemAccessReadWord: read device pseudo file " DEV_TPM_MEM " failed !!!\n");
	} else
		Log("\n\tError: MemAccessReadWord: ioctl device pseudo file " DEV_TPM_MEM " failed !!!\n");
#else
	if (dwMemAddr < TPM_DEFAULT_MEM_BASE || dwMemAddr >= (TPM_DEFAULT_MEM_BASE + TPM_DEFAULT_MEM_SIZE))
		Log("\n\tError: MemAccessReadWord: MemAddress %x is invalid !!!\n", dwMemAddr);
	else
		wData = *(UINT16 *) & bMemPtr[dwMemAddr - TPM_DEFAULT_MEM_BASE];
#endif
	DebugToFile("MemAccessReadWord:   Address: %0.8X :         %0.4X\n", dwMemAddr, wData);
#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	wData = GetMemW( memPtr, dwMemAddr - TPM_DEFAULT_MEM_BASE );
#else
	wData = maPeekW(dwMemAddr);
#endif
	DebugToFile("MemAccessReadWord:   Address: %0.8X :         %0.4X\n", dwMemAddr, wData);
#else //--------DOS-------------

#ifdef DJGPP
	if (pbMapMemoryAreaBase != NULL) {
		UINT32 dwOffset = (UINT32) dwMemAddr - TPM_DEFAULT_MEM_BASE;
		UINT16 *pwData = (UINT16 *) & pbMapMemoryAreaBase[dwOffset];
		wData = *pwData;
		DebugToFile("MemAccessReadWord:   Address: %0.4X%0.4X :         %0.4X\n",
			    (UINT16) (dwMemAddr >> 16), (UINT16) dwMemAddr, wData);
	}
#else // DJGPP
	wData = 0xFFFF;
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //----------linux----------
#endif //----------UEFI_X64----------
	return wData;
}

/*++
MemAccessWriteWord

Description:
Write a Word to the specified memory address

Arguments:
[in]	UINT32	dwMemAddr	Memory address to which should be written
[in]	UINT16	wData		Data to be written

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void MemAccessWriteWord(UINT32 dwMemAddr, UINT16 wData)
{
#ifdef UEFI_X64
	UINT16 wRC = 0;
	DebugToFile("MemAccessWriteWord:  Address: %0.8X = %0.4X\n", dwMemAddr, wData);
	wRC = MmioWrite16(dwMemAddr, wData);
	
	if (wRC != wData) {
		//Log("\n\tError: MemAccessWriteWord: MemAddress %x is invalid !!!\n", dwMemAddr);
	}
#else
#ifdef linux			//----------linux----------
	UINT32 dwRC = 0;
	DebugToFile("MemAccessWriteWord:  Address: %0.8X = %0.4X\n", dwMemAddr, wData);
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETMEMADDR, &dwMemAddr);
	if (dwRC != -1) {
		dwRC = write(dwFileHandle, &wData, sizeof(wData));
		if (dwRC == -1)
			Log("\n\tError: MemAccessWriteWord: write device pseudo file " DEV_TPM_MEM " failed !!!\n");
	} else
		Log("\n\tError: MemAccessWriteWord: ioctl device pseudo file " DEV_TPM_MEM " failed !!!\n");
#else
	if (dwMemAddr < TPM_DEFAULT_MEM_BASE || dwMemAddr >= (TPM_DEFAULT_MEM_BASE + TPM_DEFAULT_MEM_SIZE))
		Log("\n\tError: MemAccessWriteWord: MemAddress %x is invalid !!!\n", dwMemAddr);
	else
		*(UINT16 *) & bMemPtr[dwMemAddr - TPM_DEFAULT_MEM_BASE] = wData;
#endif
#else
#ifdef WIN32			//--------WIN32-----------
	DebugToFile("MemAccessWriteWord:  Address: %0.8X = %0.4X\n", dwMemAddr, wData);
#ifdef TVICDRV
	SetMemW( memPtr, dwMemAddr - TPM_DEFAULT_MEM_BASE, wData );
#else
	maPokeW(dwMemAddr, wData);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	if (pbMapMemoryAreaBase != NULL) {
		DebugToFile("MemAccessWriteWord:  Address: %0.4X%0.4X = %0.4X\n",
			    (UINT16) (dwMemAddr >> 16), (UINT16) dwMemAddr, wData);

		UINT32 dwOffset = (UINT32) dwMemAddr - TPM_DEFAULT_MEM_BASE;
		UINT16 *pwData = (UINT16 *) & pbMapMemoryAreaBase[dwOffset];
		*pwData = wData;
	}
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //----------linux----------
#endif //----------UEFI_X64----------
}

/*++
MemAccessReadDWord

Description:
Read a DoubleWord from the specified memory address

Arguments:
[in]	UINT32	dwMemAddr	Memory address from which should be read

Return Value:
Data value read from specified memory

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 MemAccessReadDWord(UINT32 dwMemAddr)
{
	UINT32 dwData = 0;

#ifdef UEFI_X64
	dwData = MmioRead32((UINTN)dwMemAddr);
	DebugToFile("MemAccessReadDWord:  Address: %0.8X :         %0.8X\n", dwMemAddr, dwData);
#else
#ifdef linux			//----------linux----------
	UINT32 dwRC = 0;
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETMEMADDR, &dwMemAddr);
	if (dwRC != -1) {
		dwRC = read(dwFileHandle, &dwData, sizeof(dwData));
		if (dwRC == -1)
			Log("\n\tError: MemAccessReadDWord: read device pseudo file " DEV_TPM_MEM " failed !!!\n");
	} else
		Log("\n\tError: MemAccessReadDWord: ioctl device pseudo file " DEV_TPM_MEM " failed !!!\n");
#else
	if (dwMemAddr < TPM_DEFAULT_MEM_BASE || dwMemAddr >= (TPM_DEFAULT_MEM_BASE + TPM_DEFAULT_MEM_SIZE))
		Log("\n\tError: MemAccessReadDWord: MemAddress %x is invalid !!!\n", dwMemAddr);
	else
		dwData = *(UINT32 *) & bMemPtr[dwMemAddr - TPM_DEFAULT_MEM_BASE];
#endif

	DebugToFile("MemAccessReadDWord:  Address: %0.8X :         %0.8X\n", dwMemAddr, dwData);

#else
#ifdef WIN32			//--------WIN32-----------
#ifdef TVICDRV
	dwData = GetMemL( memPtr, dwMemAddr - TPM_DEFAULT_MEM_BASE );
#else
	dwData = maPeekD(dwMemAddr);
#endif
	DebugToFile("MemAccessReadDWord:  Address: %0.8X :         %0.8X\n", dwMemAddr, dwData);
#else //--------DOS-------------

#ifdef DJGPP
	if (pbMapMemoryAreaBase != NULL) {
		UINT32 dwOffset = (UINT32) dwMemAddr - TPM_DEFAULT_MEM_BASE;
		UINT32 *pdwData = (UINT32 *) & pbMapMemoryAreaBase[dwOffset];
		dwData = *pdwData;
		DebugToFile("MemAccessReadDWord:  Address: %0.4X%0.4X :         %0.4X%0.4X\n",
			    (UINT16) (dwMemAddr >> 16), (UINT16) dwMemAddr, (UINT16) (dwData >> 16), (UINT16) dwData);
	}
#else // DJGPP
	dwData = 0xFFFFFFFF;
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //----------linux----------
#endif //----------UEFI_X64----------
	return dwData;
}

/*++
MemAccessWriteDWord

Description:
Write a DoubleWord to the specified memory address

Arguments:
[in]	UINT32	dwMemAddr	Memory address to which should be written
[in]	UINT32	dwData		Data to be written

Return Value:
none

Author:		Markus Schmoelzer	2007/02/23
--*/
void MemAccessWriteDWord(UINT32 dwMemAddr, UINT32 dwData)
{
#ifdef UEFI_X64
	UINT32 dwRC = 0;
	DebugToFile("MemAccessWriteDWord:  Address: %0.8X = %0.8X\n", dwMemAddr, dwData);
	dwRC = MmioWrite32((UINTN)dwMemAddr, dwData);
	
	if (dwRC != dwData) {
		//Log("\n\tError: MemAccessWriteDWord: MemAddress %x is invalid !!!\n", dwMemAddr);
	}
#else
#ifdef linux			//----------linux----------
	UINT32 dwRC = 0;
	DebugToFile("MemAccessWriteDWord: Address: %0.8X = %0.8X\n", dwMemAddr, dwData);
#if USE_DRIVER == 1
	dwRC = ioctl(dwFileHandle, IOCTL_SETMEMADDR, &dwMemAddr);
	if (dwRC != -1) {
		dwRC = write(dwFileHandle, &dwData, sizeof(dwData));
		if (dwRC == -1)
			Log("\n\tError: MemAccessWriteDWord: write device pseudo file " DEV_TPM_MEM " failed !!!\n");
	} else
		Log("\n\tError: MemAccessWriteDWord: ioctl device pseudo file " DEV_TPM_MEM " failed !!!\n");
#else
	if (dwMemAddr < TPM_DEFAULT_MEM_BASE || dwMemAddr >= (TPM_DEFAULT_MEM_BASE + TPM_DEFAULT_MEM_SIZE))
		Log("\n\tError: MemAccessWriteDWord: MemAddress %x is invalid !!!\n", dwMemAddr);
	else
		*(UINT32 *) & bMemPtr[dwMemAddr - TPM_DEFAULT_MEM_BASE] = dwData;
#endif
#else
#ifdef WIN32			//--------WIN32-----------
	DebugToFile("MemAccessWriteDWord: Address: %0.8X = %0.8X\n", dwMemAddr, dwData);
#ifdef TVICDRV
	SetMemL( memPtr, dwMemAddr - TPM_DEFAULT_MEM_BASE, dwData );
#else
	maPokeD(dwMemAddr, dwData);
#endif
#else //--------DOS-------------

#ifdef DJGPP
	if (pbMapMemoryAreaBase != NULL) {
		DebugToFile("MemAccessWriteDWord: Address: %0.4X%0.4X = %0.4X%0.4X\n",
			    (UINT16) (dwMemAddr >> 16), (UINT16) dwMemAddr, (UINT16) (dwData >> 16), (UINT16) dwData);

		UINT32 dwOffset = (UINT32) dwMemAddr - TPM_DEFAULT_MEM_BASE;
		UINT32 *pdwData = (UINT32 *) & pbMapMemoryAreaBase[dwOffset];
		*pdwData = dwData;
	}
#endif // DJGPP

#endif //-------DOS/WIN----------
#endif //----------linux----------
#endif //----------UEFI_X64----------
}
#if USE_DRIVER == 2
/*++
TpmTransmit

Description:
Send the TPM Application Protocol Data Unit (APDU) to the TPM and return the response APDU

Arguments:
[in]		BYTE	*pbTransmitBuf		Transmit data buffer
[in]		UINT32	dwTransmitBufLen	Transmit data buffer size
[out]		BYTE	*pbReceiveBuf		Receive data buffer
[in/out]	UINT32	*pdwReceiveBufLen	Receive data buffer size

Return Value:
	Return			Meaning
	======			=======
	RC_SUCCESS		operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_BUFFER2SMALL	buffer size insufficient
	RC_E_INVALID_DATA	TPM sent corrupted data
	RC_E_INVALID_PARAM	wrong parameters
	RC_E_NAKRECEIVED	TPM received corrupted data
	RC_E_NO_MEMORY		not enough memory in Heap available
	RC_E_TIMEOUT		timeout
	RC_E_WTXABORT		command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED	TPM received WTX request

--*/
#define TPM_BUF_SIZE 4096
UINT32 TpmTransmit(BYTE * pbTransmitBuf,
                   UINT32 dwTransmitBufLen,
                   BYTE * pbReceiveBuf,
                   UINT32 * pdwReceiveBufLen)
{
	static BYTE buf[TPM_BUF_SIZE];
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT32 tx_ret;
	ssize_t rx_ret;					// HF: 'read' has _signed_ return, not unsigned, important for < 0 compare
	UINT32 ReceiveBufLen = *pdwReceiveBufLen;
	*pdwReceiveBufLen = 0;
	//check pointers
	if (!pbTransmitBuf || !pbReceiveBuf || !dwTransmitBufLen || !pdwReceiveBufLen)
		return RC_E_INVALID_PARAM;

	//check buffer size
	if (dwTransmitBufLen > TPM_BUF_SIZE)
		return RC_E_BUFFER2SMALL;

	memcpy(buf, pbTransmitBuf, dwTransmitBufLen);
	tx_ret = write(dwFileHandle, buf, dwTransmitBufLen);
	if (tx_ret != dwTransmitBufLen) {
		DebugToFile("TpmTransmit: Error on write %d\n", tx_ret);
		dwRCVal = RC_E_TPM_TRANSMIT_DATA;				// VW: new, so it behaves identical to the other access modes
		return dwRCVal;
	}

	//write successful
	rx_ret = read(dwFileHandle, buf, TPM_BUF_SIZE);
	if (rx_ret < 0) {
		DebugToFile("TpmTransmit: Error on read: %d\n", rx_ret);
		dwRCVal = RC_E_TPM_TRANSMIT_DATA;				// HF: new, than identical to memaccess-behaviour
	} else if (rx_ret == 0) {
		DebugToFile("TpmTransmit: read 0 bytes\n");
	} else if (rx_ret > ReceiveBufLen) {
		DebugToFile("TpmTransmit: received more bytes than requested: %d\n", rx_ret);
		dwRCVal = RC_E_INSUFFICIENT_BUFFER;		// right error for _receive_ buffer too small / instead of RC_E_BUFFER2SMALL
	} else {
		memcpy(pbReceiveBuf, buf, rx_ret);
		*pdwReceiveBufLen = rx_ret;
		dwRCVal = RC_SUCCESS;
	}

	return dwRCVal;
}
#endif //-------USE_DRIVER--------
//vim: syntax=c.ifdef

// ==============================================================================================
// HPP I2C Access Functions
// ==============================================================================================

#ifdef UEFI_I2C

/*++
InitializeI2c_Ex

Description:
Enable communication with HPP I2C master

Arguments:
none

Return Value:
UEFI status

Author:	HPP
--*/
EFI_STATUS InitializeI2c_Ex(void) {
  EFI_STATUS Status = EFI_SUCCESS;

	Status = gBS->LocateProtocol(&gI2CBusIoExProtocolGuid,NULL, (VOID **)&I2CBusIoEx);
  if(EFI_ERROR(Status)) {
		Print(L"ERROR: Cannot find I2C Ex protocol: %r (0x%x)\n",Status, Status);
    return Status;
  }

	return Status;
}

/*++
SetI2cFrequency

Description:
Set I2C frequency.

Arguments:
[in]	dwValue	Frequency[Hz]

Return Value:
none

Author:		Christopher Unterweger	2012/12/17
--*/
void SetI2cFrequency(UINT32 dwValue)
{
	I2cSpeed = dwValue;
}

/*++
HPP_WriteData

Description:
Write multible I2C bytes within a single frame. HPP I2C master supports a maximum
payload of 6 bytes (1 adr byte + 5 user data bytes).

Arguments:
[in]	BYTE 	bLocality
[in]	BYTE 	bSfrAddr
[in]	UINT8	bTxDataCount
[in]	BYTE 	pbRxData

Return Value:
UEFI Status

Author:		Christopher Unterweger	2012/12/17
--*/
UINT32 HPP_WriteData(BYTE bSfrAddr, UINT16 wTxDataCount, BYTE *pbTxData)
{
	UINT16 wTxCount, wTmpDataCount, i, j;
	BYTE bTmpData[6];
	EFI_STATUS Status;
	
	if (wTxDataCount == 0)
		return EFI_INVALID_PARAMETER;
	
	// max 6 byte payload (1 byte for register address, 5 byte for user data)
	wTmpDataCount = wTxDataCount + wTxDataCount/5;
	if (wTxDataCount%5)
		wTmpDataCount++;
	j = 0;
	bTmpData[0] = bSfrAddr;
	while (wTmpDataCount > 0) {
		if (wTmpDataCount/6 > 0)
			wTxCount = 5;
		else
			wTxCount = wTmpDataCount%6 - 1;
		wTmpDataCount = wTmpDataCount - wTxCount -1;
		CopyMem(&bTmpData[1], &pbTxData[j], wTxCount);
		for (i = 0; i < LATE_ACK_RETRY; i++) {
			Status = I2CBusIoEx->WriteAtSpeed(I2CBusIoEx, I2cSpeed, (UINT8)I2C_TPM_ADR, wTxCount+1, &bTmpData);
			if( Status != EFI_SUCCESS) {
				DetLogToFile("HPP_WriteData: Late Acknowledge hits. Redoing access %d\n", wTmpDataCount);
				Sleep_us(LATE_ACK_TIME);
				continue;
			}
			j += wTxCount;
			break;
		}
		if( Status != EFI_SUCCESS)
			break;
	}
	
	return Status;
}

/*++
HPP_ReadData

Description:
Read multible I2C bytes within a single frame. HPP I2C master supports a maximum
payload (user data) of 4 bytes.

Arguments:
[in]	BYTE 	bLocality
[in]	BYTE 	bSfrAddr
[in]	UINT8	bRxDataCount
[in]	BYTE 	pbRxData

Return Value:
UEFI Status

Author:		Christopher Unterweger	2012/12/17
--*/
UINT32 HPP_ReadData(BYTE bSfrAddr, UINT16 wRxDataCount, BYTE *pbRxData)
{
	UINT16 i, j;
	UINT16 wRxCount, WrData;
	EFI_STATUS Status;

	WrData = (bSfrAddr << 8)|(IFX_TPM_I2C_READ_FROM);
	if (wRxDataCount == 0)
		return EFI_INVALID_PARAMETER;

	for (i = 0; i < LATE_ACK_RETRY; i++) {	
		Status = I2CBusIoEx->WriteAtSpeed(I2CBusIoEx, I2cSpeed, (UINT8) I2C_TPM_ADR, 2, &WrData);
		if( Status != EFI_SUCCESS) {
			DetLogToFile("\n\tError: HPP_ReadData: writing of address %0.2X failed. Redoing access\n", (UINT8)bSfrAddr);
			Sleep_us(LATE_ACK_TIME);
			continue;
		}
		break;
	}
	Sleep_us(I2C_GUARD_TIME);
	if( Status != EFI_SUCCESS) {
		DetLogToFile("\n\tError: HPP_ReadData: writing of address %0.2X failed.\n", (UINT8)bSfrAddr);
		return Status;
	}
	
	j = 0;
	while (wRxDataCount > 0) {
		// max 4 byte payload (user data)
		if (wRxDataCount/4 > 0)
			wRxCount = 4;
		else
			wRxCount = wRxDataCount%4;
		wRxDataCount -= wRxCount;
		for (i = 0; i < LATE_ACK_RETRY; i++) {
			Status = I2CBusIoEx->ReadAtSpeed(I2CBusIoEx, I2cSpeed, (UINT8) I2C_TPM_ADR, 1, &bSfrAddr, wRxCount, &pbRxData[j]);
			if( Status != EFI_SUCCESS) {
				DetLogToFile("  HPP_ReadData: Late Acknowledge hits. Redoing access\n");
				Sleep_us(LATE_ACK_TIME);
				continue;
			}
			j += wRxCount;
			break;
		}
		if( Status != EFI_SUCCESS)
			break;
	}
	Sleep_us(I2C_GUARD_TIME);
	if(Status != EFI_SUCCESS)
		DetLogToFile("\n\tError: HPP_ReadData: read from address %0.2X failed !!!\n", (UINT8)bSfrAddr);

	return Status;
}

#endif