/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Tool4TPM.c

Description:	Tool4TPM main program

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows, UEFI

Revision History:
				16th March 2009 RAN enhanced for HP special version
				included Sealtest

Notes:

--*/

// HII Database is not implemented on all systems or in the correct version (old systems).
// This causes the UefiHiiServices constructor to ASSERT
// inside MdeModulePkg\Library\UefiHiiServicesLib\UefiHiiServicesLib.c comment line 100 (ASSERT_EFI_ERROR (Status);)

#ifdef UEFI_X64
#include <Uefi.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiLib.h>
#include <Library/UefiBootServicesTableLib.h>		// because of gST, gBS
#include <Library/UefiRuntimeServicesTableLib.h>	// because of Time
#include <Library/PcdLib.h>
#include <Library/IoLib.h>											// because of TPM-LPC
#include <Library/ShellLib.h>										// because file access
#include <Library/MemoryAllocationLib.h>				// because of FreePool
#else
#include <time.h>
#endif
#include "Console.h"
#include "FileIO.h"
#include "ProgFunc.h"
#include "TDDL.h"
#include "TPM_Func.h"
#include "Sealtest.h"
#include "LowLevIO.h"
#include "Autotest.h"
#include "T4T_Func.h"

#ifdef UEFI_X64
INTN
EFIAPI
ShellAppMain (
  IN UINTN Argc,
  IN CHAR16 **Argv
  )
#else
int main(int argc, char *argv[])
#endif
{
	UINT32 dwRCVal;		// Error return code variable

	BYTE bCycle = FALSE;	// Do not cycle entered menu commands by default	
	UINT32 dwProdCycle = 0;	// Number of test runs in production test mode
	T4T_MODE eMode = MODE_MENU;	// Start Tool4TPM with console menu by default
	BYTE *pcAutoMenuSelect = NULL;	// Automenu selections
	BYTE *pcCmdFileName = NULL;	// Command input file
	BYTE *pcRspFileName = RSP_FILE_NAME;	// Response file name
	BYTE *pcFlagCheckFileName = NULL;	// Flag check option input file
#ifdef TOOL4TPM_TEST 	
	char *pcStartTestID = NULL;	// Name of the Testcase ID to start from at autotest
#endif
	UINT16 argcnt;		// Argument index for command line parameters
	UINT16 icount;		// Selection index in automenu mode
	UINT16 istrLength;	// Number of selections in auto menumode
	UINT32 dwRegister = 0;	// Looptest register address
	BYTE bData = 0;		// Looptest data to write
	UINT16 wNumber = 0;	// Looptest number of cycles
	BYTE bEvalResponse = TRUE;	// Looptest evaluation mode
	UINT32 dwCounter=0;

#ifdef UEFI_X64
	UINTN argc;
	CHAR8 **argv;
	EFI_TIME Time;
	
	InitialScreenMode = -1;
#else
	time_t tTime;		// Long integer time value
	struct tm *sTime;	// Local time structure
#endif

	ErrorCodeToMessageEx = T4T_ErrorCodeToMessage;

	pvLogFileHandle = NULL;		// Global log file I/O handle

	bChipDetected = 0;	// Global TPM detection variable
	
	SetLoggingLevel();

#ifdef UEFI_I2C
	GetI2cSpeed();
#endif

	//---------------------------------------------------------------------------
	// Process command line parameters

#ifdef UEFI_X64
	argc = Argc;
	argv = (CHAR8**)AllocateZeroPool(Argc*sizeof(CHAR8*));
  for (argcnt = 0; argcnt < Argc; argcnt++) {
		argv[argcnt] = (CHAR8*)AllocateZeroPool(StrLen(Argv[argcnt])*sizeof(CHAR8)+1);
		UnicodeStrToAsciiStr(Argv[argcnt],argv[argcnt]);
  }	
#endif

	for (argcnt = 1; argcnt < argc; argcnt++) {
		if (!strcasecmp(argv[argcnt], "-integrationtest"))
			eMode = MODE_INTEGRATION;
		else if (!strcasecmp(argv[argcnt], "-productiontest"))
			eMode = MODE_PRODUCTION;
		else if (!strcasecmp(argv[argcnt], "-sealtest"))
			eMode = MODE_SEALTEST;
#ifdef TOOL4TPM_TEST
		else if (!strcasecmp(argv[argcnt], "-autotest"))
		{
			if ((argc - argcnt) == 2)
				pcStartTestID = argv[++argcnt];
			eMode = MODE_AUTOTEST;
		}
#endif
		else if (!strcasecmp(argv[argcnt], "-cycle"))
			bCycle = TRUE;
		else if (!strcasecmp(argv[argcnt], "-automenu")) {
			if ((argc - argcnt) < 2)
				ShowHelp();
			else {
				pcAutoMenuSelect = argv[++argcnt];
				eMode = MODE_AUTOMENU;
			}
		} else if (!strcasecmp(argv[argcnt], "-commandfile")) {
			if ((argc - argcnt) < 3)
				ShowHelp();
			else {
				pcCmdFileName = argv[argcnt + 1];
				if (strcasecmp(argv[argcnt + 2], ".."))
					pcRspFileName = argv[argcnt + 2];
				eMode = MODE_COMMANDFILE;
				argcnt += 2;
			}
		} else if (!strcasecmp(argv[argcnt], "-looptest")) {
			if ((argc - argcnt) < 4)
				ShowHelp();
			else {
#ifdef UEFI_X64
				dwRegister = (UINT32)AsciiStrHexToUint64 (argv[argcnt + 1]);
				bData = (BYTE)AsciiStrHexToUint64 (argv[argcnt + 2]);
				wNumber = (UINT16)AsciiStrDecimalToUint64 (argv[argcnt + 3]);
#else
				dwRegister = strtoul(argv[argcnt + 1], NULL, 16);
				bData = (BYTE) strtoul(argv[argcnt + 2], NULL, 16);
				wNumber = (UINT16) strtoul(argv[argcnt + 3], NULL, 10);
#endif
				if ((argc - argcnt) > 4) {
					// Is this not the next command line switch?
					if (argv[argcnt + 4][0] != '-') {
						bEvalResponse = argv[argcnt + 4][0] == '1' ? TRUE : FALSE;
						argcnt++;
					}
				}
				eMode = MODE_LOOPTEST;
				argcnt += 3;
			}
		} else if (!strcasecmp(argv[argcnt], "-flagcheck")) {
			if ((argc - argcnt) < 2)
				ShowHelp();
			else {
				pcFlagCheckFileName = argv[argcnt + 1];
				eMode = MODE_FLAGCHECK;
				argcnt++;
			}
		} else
			ShowHelp();
	}

	//---------------------------------------------------------------------------
	// Initialize Tool4TPM

	InitConsole(GetScreenMode());	// Initialize console user interface

	if (bDebug) {
		OpenLogFile(LOG_FILE_NAME);
		Log("Infineon Technologies   " PROGNAME " " PLATFORM "   Ver " VERSION "\n");
#ifdef UEFI_X64
		gRT->GetTime(&Time, NULL);
		Log("%d %d %d %d:%d:%d", Time.Day, Time.Month, Time.Year, Time.Hour, Time.Minute, Time.Second);
#else
		time(&tTime);	// Get time as long integer
		sTime = localtime(&tTime);	// Convert to local time
		Log("%s", asctime(sTime));	// Convert time structure to string and display it
#endif
		Sleep_ms(100);
		Log("\nStarting tests of the TPM hardware...\n\n");
		Sleep_ms(100);

	}

	dwRCVal = TDDL_Open();	// Connect to the TPM
	if (dwRCVal != RC_SUCCESS) {
		Log("\tConnection to TPM failed !!!\n");
		PrintErrorMessage(dwRCVal);
	} else {

		

		//---------------------------------------------------------------------------
		// Switch to chosen program mode

		switch (eMode) {
		case MODE_MENU:
			dwRCVal = PollMenu(bCycle);
			break;

		case MODE_AUTOMENU:
			init_keyboard();
			if (bDebug)
				CloseLogFile(LOG_FILE_NAME);
			do {
				if (bDebug) {
					switch (dwCounter % 5) {
						case 0: OpenLogFile(LOG_FILE_NAME0); break;
						case 1: OpenLogFile(LOG_FILE_NAME1); break;
						case 2: OpenLogFile(LOG_FILE_NAME2); break;
						case 3: OpenLogFile(LOG_FILE_NAME3); break;
						case 4: OpenLogFile(LOG_FILE_NAME4); break;
					}
				}
				Log("Iteration: %d\n", dwCounter);
				
				istrLength = (UINT16) strlen(pcAutoMenuSelect);
				Log("\n\nProcessing %d menu items: %s \n", istrLength, pcAutoMenuSelect);
				for (icount = 0; icount < istrLength; icount++) {
					dwRCVal = MenuSelect((char)(pcAutoMenuSelect[icount]), bCycle);
					if (dwRCVal != RC_SUCCESS) {
						PrintErrorMessage(dwRCVal);
						break;
					}
					//Sleep_ms(500);
				}
				Log("\n\n");
				if (bDebug) {
					switch (dwCounter % 5) {
						case 0: CloseLogFile(LOG_FILE_NAME0); break;
						case 1: CloseLogFile(LOG_FILE_NAME1); break;
						case 2: CloseLogFile(LOG_FILE_NAME2); break;
						case 3: CloseLogFile(LOG_FILE_NAME3); break;
						case 4: CloseLogFile(LOG_FILE_NAME4); break;
					}
				}
				dwCounter++;
			} while (bCycle && dwRCVal == RC_SUCCESS && !ESC_IS_PRESSED);
			close_keyboard();
			break;

		case MODE_COMMANDFILE:
			init_keyboard();
			do {
				Log("Transmit TPM Command from \"%s\"\n", pcCmdFileName);
				dwRCVal = GetTPMCmdFromFile(pcCmdFileName, pcRspFileName);
				if (dwRCVal != RC_SUCCESS)
					PrintErrorMessage(dwRCVal);
				else
					Log("\n\tTPM Response received and saved to \"%s\"\n\n", pcRspFileName);
				//argcnt += 2;
			} while (bCycle && dwRCVal == RC_SUCCESS && !ESC_IS_PRESSED);
			close_keyboard();
			break;

		case MODE_INTEGRATION:
			dwRCVal = TestTPM(ATTENDED);
			if (dwRCVal != RC_SUCCESS)
				PrintErrorMessage(dwRCVal);
			break;

		case MODE_PRODUCTION:
			init_keyboard();
			do {
				ClrScr();
				Log("\n=================================   Test %3d   =================================\n",
				    ++dwProdCycle);
				dwRCVal = TestTPM(UNATTENDED);
				if (dwRCVal != RC_SUCCESS)
					PrintErrorMessage(dwRCVal);
			} while (bCycle && dwRCVal == RC_SUCCESS && !ESC_IS_PRESSED);
			close_keyboard();
			break;

		case MODE_SEALTEST:
			ClrScr();
			Log("\n=================================   SealTest   =================================\n");
			dwRCVal = TPMSealTest();
			if (dwRCVal != RC_SUCCESS)
				PrintErrorMessage(dwRCVal);
			break;

		case MODE_LOOPTEST:
			LoopTest(dwRegister, bData, wNumber, bEvalResponse);
			break;

		case MODE_FLAGCHECK:
			dwRCVal = FlagCheck(pcFlagCheckFileName);
			if (dwRCVal != RC_SUCCESS) {
				PrintErrorMessage(dwRCVal);
			}
			else
				Log("\tFlag check completed successfully\n\n");
			break;
#ifdef TOOL4TPM_TEST
		case MODE_AUTOTEST:
			TestRunnerInit( pcStartTestID );
			AutoTest( 0 );
			TestRunnerExit();
			break;
#endif
		default:
			Log("Invalid mode! \n");
			break;
		}

		//---------------------------------------------------------------------------
		// Shut down Tool4TPM
	}
#ifdef UEFI_X64
	for (argcnt = 0; argcnt < Argc; argcnt++) {
		FreePool(argv[argcnt]);
	}
	FreePool(argv);
#endif
	Tool4TPMexit();

	return dwRCVal;
}

void Tool4TPMexit(void)
{
	Log("Exiting Tool4TPM...\n");
	TDDL_Close();		// Disconnect from the TPM

	if (bDebug)
		CloseLogFile(LOG_FILE_NAME);

#ifdef UEFI_X64		
	if (InitialScreenMode > -1 )
		gST->ConOut->SetMode(gST->ConOut, (UINTN)InitialScreenMode);
	ClrScr();
#endif
}