/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Cmds.c

Description:	Implementation of the TPM commands

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "Hash.h"
#include "ProgFunc.h"
#include "RSA.h"
#include "TDDL.h"
#include "TPM_Cmds.h"

/*++
TPM_11_ReadEKCert

Description:
TPM 1.1 command for reading the Endorsement Key Certificate

Arguments:
[in]		BYTE	bIndex			Index number
[out]		BYTE	*pbCertPortion	Pointer to EK Certificate portion
[in/out]	UINT32	*pdwPortionLen	Pointer to EK Certificate portion size

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_11_ReadEKCert(BYTE bIndex, BYTE * pbMaxIndex, BYTE * pbCertPortion, UINT32 * pdwPortionLen)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE i;
	UINT32 dwRdEkCertRspSize;
	TPM_11_READ_EKCERT_RQU *psRdEkCertRqu = NULL;
	TPM_11_READ_EKCERT_RSP *psRdEkCertRsp = NULL;

	DetLogToFile("\n-> TPM_11_ReadEKCert\n");

	do {
		// Initialize the command structures
		dwRdEkCertRspSize = sizeof(TPM_11_READ_EKCERT_RSP);
		SAFE_CALLOC(psRdEkCertRqu, sizeof(TPM_11_READ_EKCERT_RQU), &dwRCVal);
		SAFE_CALLOC(psRdEkCertRsp, sizeof(TPM_11_READ_EKCERT_RSP), &dwRCVal);

		psRdEkCertRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psRdEkCertRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_11_READ_EKCERT_RQU));
		psRdEkCertRqu->dwOrdinal = 0x02000020;
		psRdEkCertRqu->bIndex = bIndex;
		for (i = 0; i < 20; i++)
			psRdEkCertRqu->sNonce.nonce[i] = i;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psRdEkCertRqu,
					    sizeof(TPM_11_READ_EKCERT_RQU), (BYTE *) psRdEkCertRsp, &dwRdEkCertRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psRdEkCertRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

		// Copy result length to the output argument
		if (*pdwPortionLen < dwSwitchEndian32(psRdEkCertRsp->dwCertSize)) {
			dwRCVal = RC_E_BUFFER2SMALL;
			*pdwPortionLen = 0;	// No data if return buffer is too small
			break;
		}
		*pdwPortionLen = dwSwitchEndian32(psRdEkCertRsp->dwCertSize);

		// Copy results from the command response structure to the output argument
		memcpy(pbCertPortion, &(psRdEkCertRsp->abCert), (size_t) (*pdwPortionLen));
		*pbMaxIndex = psRdEkCertRsp->bMaxIndex;
	} while (FALSE);

	SAFE_FREE(psRdEkCertRqu);	// Free command request structure
	SAFE_FREE(psRdEkCertRsp);	// Free command response structure

	DetLogToFile("<- TPM_11_ReadEKCert\n\n");

	return dwRCVal;
}

/*++
TPM_FieldUpgradeInfoRequest

Description:
Transmits the TPM command TPM_FieldUpgradeInfoRequest

Arguments:
[out]	IFX_FIELDUPGRADEINFO	*psFUInfo		Pointer to FieldUpgrade info structure

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_FieldUpgradeInfoRequest(IFX_FIELDUPGRADEINFO * psFUInfo)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwFUInfoRspSize;
	TPM_FU_INFO_REQ_RQU *psFUInfoRqu = NULL;
	TPM_FU_INFO_REQ_RSP *psFUInfoRsp = NULL;

	DetLogToFile("\n-> TPM_FieldUpgradeInfoRequest\n");

	do {
		// Initialize the command structures
		dwFUInfoRspSize = sizeof(TPM_FU_INFO_REQ_RSP);
		SAFE_CALLOC(psFUInfoRqu, sizeof(TPM_FU_INFO_REQ_RQU), &dwRCVal);
		SAFE_CALLOC(psFUInfoRsp, sizeof(TPM_FU_INFO_REQ_RSP), &dwRCVal);

		psFUInfoRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psFUInfoRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_FU_INFO_REQ_RQU));
		psFUInfoRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_FieldUpgrade);
		psFUInfoRqu->bSubCommand = TPM_FIELD_UPGRADE_INFO_REQUEST;
		psFUInfoRqu->wInInfoRequestSize = 0;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psFUInfoRqu,
					    sizeof(TPM_FU_INFO_REQ_RQU), (BYTE *) psFUInfoRsp, &dwFUInfoRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psFUInfoRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

		// Copy results from the command response structure to the output argument
		memcpy(psFUInfo, &(psFUInfoRsp->sOutInfoRequestData), sizeof(IFX_FIELDUPGRADEINFO));
		psFUInfo->maxDataSize = wSwitchEndian16(psFUInfo->maxDataSize);
		psFUInfo->romCRC = wSwitchEndian16(psFUInfo->romCRC);
		psFUInfo->flagsFieldUpgrade = wSwitchEndian16(psFUInfo->flagsFieldUpgrade);
	} while (FALSE);

	SAFE_FREE(psFUInfoRqu);	// Free command request structure
	SAFE_FREE(psFUInfoRsp);	// Free command response structure

	DetLogToFile("<- TPM_FieldUpgradeInfoRequest\n\n");

	return dwRCVal;
}

/*++
TPM_FieldUpgradeInfoRequest2

Description:
Transmits the TPM command TPM_FieldUpgradeInfoRequest2

Arguments:
[out]	IFX_FIELDUPGRADEINFO2	*psFUInfo2		Pointer to FieldUpgrade info structure

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Christoph Zausner	2011/08/03
--*/
UINT32 TPM_FieldUpgradeInfoRequest2 (IFX_FIELDUPGRADEINFO2 * psFUInfo2)
{
  UINT32 dwRCVal = RC_E_FAILURE;

  TPM_FU_INFO_REQ_RQU *psFUInfoRqu;
  UINT32 respSize = 256;
  BYTE respData[256];

  DetLogToFile ("\n-> TPM_FieldUpgradeInfoRequest2\n");

  do
    {
      // Initialize the command structures
	  SAFE_CALLOC(psFUInfoRqu, sizeof(TPM_FU_INFO_REQ_RQU), &dwRCVal);      

      psFUInfoRqu->wTag = wSwitchEndian16 (TPM_TAG_RQU_COMMAND);
      psFUInfoRqu->dwParamSize = dwSwitchEndian32 (sizeof (TPM_FU_INFO_REQ_RQU));
      psFUInfoRqu->dwOrdinal = dwSwitchEndian32 (TPM_ORD_FieldUpgrade);
      psFUInfoRqu->bSubCommand = TPM_FIELD_UPGRADE_INFO_REQUEST_2;
      psFUInfoRqu->wInInfoRequestSize = 0;

      // Send command request and receive command response
      dwRCVal = TDDL_TransmitData ((BYTE *) psFUInfoRqu,
				   sizeof (TPM_FU_INFO_REQ_RQU),
				   respData, &respSize);
      if (dwRCVal != RC_SUCCESS)
		break;

      psFUInfo2->firmwareVersion = 0;
      psFUInfo2->bootloaderstatus = (respData[94] << 8 | respData[95]);
      psFUInfo2->firmwareVersion =
			(respData[74] << 24) | (respData[75] << 16) | (respData[76] << 8) |
			(respData[77]);
      memcpy (psFUInfo2->bootloaderVersion, &respData[56], 12);
      memcpy (psFUInfo2->firmwarepackage, &respData[97], 12);

    }
  while (FALSE);

  SAFE_FREE (psFUInfoRqu);	// Free command request structure

  DetLogToFile ("<- TPM_FieldUpgradeInfoRequest2\n\n");

  return dwRCVal;
}

/*++
TPM_GetCapability

Description:
Transmits the TPM command TPM_GetCapability

Arguments:
[in]		TPM_CAPABILITY_AREA	wCapArea		Partition of capabilities to be interrogated
[in]		UINT32				dwSubCapSize	Size of dwSubCap parameter
[in]		BYTE				*pbSubCap		Further definition of information
[out]		UINT32				*pdwRespSize	The length of the returned capability response
[out]		BYTE				*pbResp			The capability response

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_GetCapability(TPM_CAPABILITY_AREA wCapArea,
			 UINT32 dwSubCapSize, BYTE * pbSubCap, UINT32 * pdwRespSize, BYTE * pbResp)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwGetCapRquSize;
	UINT32 dwGetCapRspSize;
	TPM_GET_CAPABILITY_RQU *psGetCapRqu = NULL;
	TPM_GET_CAPABILITY_RSP *psGetCapRsp = NULL;

	DetLogToFile("\n-> TPM_GetCapability: Area: %.8X\n", wCapArea);

	do {
		// Initialize the command structures
		// Size of the request structure is dwSubCapSize + size of the structure header (-1)
		dwGetCapRquSize = dwSubCapSize + sizeof(TPM_GET_CAPABILITY_RQU) - sizeof(BYTE);
		// Size of the response structure is *pdwResultLen + size of the structure header (-1)
		dwGetCapRspSize = *pdwRespSize + sizeof(TPM_GET_CAPABILITY_RSP) - sizeof(BYTE);
		SAFE_CALLOC(psGetCapRqu, (size_t) dwGetCapRquSize, &dwRCVal);
		SAFE_CALLOC(psGetCapRsp, (size_t) dwGetCapRspSize, &dwRCVal);

		psGetCapRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psGetCapRqu->dwParamSize = dwSwitchEndian32(dwGetCapRquSize);
		psGetCapRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_GetCapability);
		psGetCapRqu->dwCapArea = dwSwitchEndian32(wCapArea);
		psGetCapRqu->dwSubCapSize = dwSwitchEndian32(dwSubCapSize);
		if (dwSubCapSize != 0) {
			memcpy(psGetCapRqu->abSubCap, pbSubCap, dwSubCapSize);
		}
		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psGetCapRqu, dwGetCapRquSize, (BYTE *) psGetCapRsp, &dwGetCapRspSize);
		if (dwRCVal != RC_SUCCESS) {
			*pdwRespSize = 0;	// No data if error occurred
			break;
		}

		dwRCVal = dwSwitchEndian32(psGetCapRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwRespSize = 0;	// No data if error occurred
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result length to the output argument
		if (*pdwRespSize < dwSwitchEndian32(psGetCapRsp->dwRespSize)) {
			dwRCVal = RC_E_BUFFER2SMALL;
			*pdwRespSize = 0;	// No data if return buffer is too small
			break;
		}
		*pdwRespSize = dwSwitchEndian32(psGetCapRsp->dwRespSize);

		// Copy result from the command response structure to the output argument
		memcpy(pbResp, psGetCapRsp->abResp, (size_t) (*pdwRespSize));
	} while (FALSE);

	SAFE_FREE(psGetCapRqu);	// Free command request structure
	SAFE_FREE(psGetCapRsp);	// Free command response structure

	DetLogToFile("<- TPM_GetCapability\n\n");

	return dwRCVal;
}

/*++
TPM_GetTestResult

Description:
Transmits the TPM command TPM_GetTestResult

Arguments:
[i/o]	UINT32	*pdwSize	i: Max size for *pbResult, o: Returned size for *pbResult
[out]	BYTE	*pbResult	Pointer to test result

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_GetTestResult(UINT32 * pdwOutDataSize, BYTE * pbOutData)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwGetTRRspSize = 0;
	TPM_SIMPLE_CMD_RQU *psGetTRRqu = NULL;
	TPM_GET_TEST_RESULT_RSP *psGetTRRsp = NULL;

	DetLogToFile("\n-> TPM_GetTestResult\n");

	do {
		// Initialize the command structures
		dwGetTRRspSize = sizeof(TPM_GET_TEST_RESULT_RSP) + *pdwOutDataSize;
		SAFE_CALLOC(psGetTRRqu, sizeof(TPM_SIMPLE_CMD_RQU), &dwRCVal);
		// Allocate memory for expected response plus max buffer size given from caller
		SAFE_CALLOC(psGetTRRsp, dwGetTRRspSize, &dwRCVal);

		psGetTRRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psGetTRRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SIMPLE_CMD_RQU));
		psGetTRRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_GetTestResult);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psGetTRRqu,
					    sizeof(TPM_SIMPLE_CMD_RQU), (BYTE *) psGetTRRsp, &dwGetTRRspSize);
		if (dwRCVal != RC_SUCCESS) {
			*pdwOutDataSize = 0;
			break;
		}

		dwRCVal = dwSwitchEndian32(psGetTRRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwOutDataSize = 0;
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		*pdwOutDataSize = dwSwitchEndian32(psGetTRRsp->dwOutDataSize);
		memcpy(pbOutData, psGetTRRsp->abOutData, *pdwOutDataSize);
	} while (FALSE);

	SAFE_FREE(psGetTRRqu);	// Free command request structure
	SAFE_FREE(psGetTRRsp);	// Free command response structure

	DetLogToFile("<- TPM_GetTestResult\n\n");

	return dwRCVal;
}

/*++
TPM_NV_DefineSpace

Description:
Transmits the TPM command TPM_NV_DefineSpace

Arguments:
[in]		UINT32              *dwPubInfoSize  The size of the public parameters of the NV area
[in]		TPM_NV_DATA_PUBLIC	*pspubInfo      The public parameters of the NV area
[in]		TPM_ENCAUTH         *psEncAuth		The encrypted AuthData, only valid if the attributes require subsequent
                                                authorization
[in]        TPM_AUTHHANDLE		dwAuthHandle    The authorization session handle used for ownerAuth
[in/out]    TPM_NONCE			*psAuthNonceEven    Even nonce previously generated by TPM to cover inputs
[in]        BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]        TPM_AUTHDATA        *psOwnerAuth    The authorization session digest HMAC key: ownerAuth

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier    2008/03/10
--*/
UINT32 TPM_NV_DefineSpace(UINT32 dwPubInfoSize, TPM_NV_DATA_PUBLIC * psPubInfo, TPM_ENCAUTH * psEncAuth, TPM_AUTHHANDLE dwAuthHandle,	// If NULL command executes un-authorized
			  TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			  BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wOffset = 0;
	UINT16 wNonceOdd = 0;

	// Temporary data buffers for HMAC calculation according to the OSAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwNvDefineSpaceRquSize = 0;
	UINT32 dwNvDefineSpaceRspSize = 0;
	TPM_NV_DEFINE_SPACE_RQU *psNvDefineSpaceRqu = NULL;
	BYTE *pbRqu = NULL;
	UINT32 dwTPMNVDataPublicHelp = 0;
	BYTE *pbTPMNVDataPublic = NULL;
	TPM_NV_DEFINE_SPACE_RSP *psNvDefineSpaceRsp = NULL;

	BYTE bHMACResult[20];
	BYTE NonceOdd[20];

	DetLogToFile("\n-> TPM_NV_DefineSpace\n");

	do {
		// with authorization
		if (dwAuthHandle) {
			// Initialize temporary data buffers for HMAC calculation according to the OSAP
			wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) + dwPubInfoSize + sizeof(TPM_ENCAUTH));
			// The HMAC input uses (HASH_LEN + 2*sizeof(TPM_NONCE) + 1) Bytes
			wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
			SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
			SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);
			// Initialize the command structures
			dwNvDefineSpaceRquSize =
			    sizeof(TPM_NV_DEFINE_SPACE_RQU) - sizeof(TPM_NV_DATA_PUBLIC) + dwPubInfoSize;
			dwNvDefineSpaceRspSize = sizeof(TPM_NV_DEFINE_SPACE_RSP);
			SAFE_CALLOC(psNvDefineSpaceRqu, dwNvDefineSpaceRquSize, &dwRCVal);
			SAFE_CALLOC(psNvDefineSpaceRsp, dwNvDefineSpaceRspSize, &dwRCVal);
			// Fill byte stream
			psNvDefineSpaceRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
			psNvDefineSpaceRqu->dwParamSize = dwSwitchEndian32(dwNvDefineSpaceRquSize);
			psNvDefineSpaceRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_NV_DefineSpace);

			// TPM_NV_DATA_PUBLIC
			memcpy(&(psNvDefineSpaceRqu->sPubInfo), psPubInfo, dwPubInfoSize);
			psNvDefineSpaceRqu->sPubInfo.tag = wSwitchEndian16(psNvDefineSpaceRqu->sPubInfo.tag);
			psNvDefineSpaceRqu->sPubInfo.nvIndex = dwSwitchEndian32(psNvDefineSpaceRqu->sPubInfo.nvIndex);
			// pcrInfoRead.pcrSelection.sizeOfSelect
			// help variable for endian switch
			dwTPMNVDataPublicHelp = psNvDefineSpaceRqu->sPubInfo.pcrInfoRead.pcrSelection.sizeOfSelect;
			psNvDefineSpaceRqu->sPubInfo.pcrInfoRead.pcrSelection.sizeOfSelect =
			    wSwitchEndian16((UINT16) dwTPMNVDataPublicHelp);
			pbTPMNVDataPublic = (BYTE *) & (psNvDefineSpaceRqu->sPubInfo.pcrInfoRead.pcrSelection.pcrSelect);
			// Step over pcrInfoRead.pcrSelection.pcrSelect
			i = (UINT16)dwTPMNVDataPublicHelp;
			// Step over fields
			i += sizeof(TPM_LOCALITY_SELECTION);
			i += sizeof(TPM_COMPOSITE_HASH);
			// pcrInfoWrite.pcrSelection.sizeOfSelect
			SwitchEndian16ByteArray(&pbTPMNVDataPublic[i]);
			// Now big endian
			dwTPMNVDataPublicHelp = (pbTPMNVDataPublic[i] << 8) | (pbTPMNVDataPublic[i + 1]);
			i += sizeof(UINT16);
			// Step over pcrInfoWrite.pcrSelection.pcrSelect
			i += (UINT16)dwTPMNVDataPublicHelp;
			// Step over fields
			i += sizeof(TPM_LOCALITY_SELECTION);
			i += sizeof(TPM_COMPOSITE_HASH);
			// permission.tag
			SwitchEndian16ByteArray(&pbTPMNVDataPublic[i]);
			i += sizeof(UINT16);
			// permission.attributes
			SwitchEndian32ByteArray(&pbTPMNVDataPublic[i]);
			i += sizeof(UINT32);
			i += 3;	// Step over bReadSTClear; bWriteSTClear; bWriteDefine;
			// dataSize
			SwitchEndian32ByteArray(&pbTPMNVDataPublic[i]);
			//i += sizeof(UINT32); //Dead assignment

			for (i = 0; i < sizeof(TPM_NONCE); i++)
				NonceOdd[i] = (unsigned char)i;

			// TPM_ENCAUTH
			pbRqu = (BYTE *) & (psNvDefineSpaceRqu->sPubInfo);
			wOffset = (UINT16)dwPubInfoSize;
			memcpy(&(pbRqu[wOffset]), psEncAuth, sizeof(TPM_ENCAUTH));
			wOffset += sizeof(TPM_ENCAUTH);
			pbRqu[wOffset++] = (BYTE)(dwAuthHandle >> 24);
			pbRqu[wOffset++] = (BYTE)(dwAuthHandle >> 16);
			pbRqu[wOffset++] = (BYTE)(dwAuthHandle >> 8);
			pbRqu[wOffset++] = (BYTE)(dwAuthHandle);
			wNonceOdd = wOffset;
			for (i = 0; i < sizeof(TPM_NONCE); i++)
				pbRqu[wNonceOdd + i] = NonceOdd[i];
			wOffset += sizeof(TPM_NONCE);
			pbRqu[wOffset++] = bContinueAuthSession;
			// TPM_AUTHDATA below

			// Fill SHA-1 input parameters
			i = 0;
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_DefineSpace >> 24);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_DefineSpace >> 16);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_DefineSpace >> 8);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_DefineSpace);
			memcpy(&(pbInParamDigest[i]), &(psNvDefineSpaceRqu->sPubInfo), dwPubInfoSize);
			i += (UINT16)dwPubInfoSize;
			memcpy(&(pbInParamDigest[i]), psEncAuth, sizeof(TPM_ENCAUTH));

			// Create SHA-1 hash from the input parameters and initialise the HMAC input (first 20 bytes) with the result
			dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
			if (dwRCVal != RC_SUCCESS)
				break;

			// Fill HMAC input buffer according to authorization
			i = HASH_LEN;
			memcpy(pbHmacInput + i, psNonceEven, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			memcpy(pbHmacInput + i, NonceOdd, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			*(pbHmacInput + i) = bContinueAuthSession;

			// Create HMAC for authenticated TPM command according to authorization
			dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psOwnerAuth, bHMACResult);
			if (dwRCVal != RC_SUCCESS)
				break;

			// TPM_AUTHDATA
			memcpy(&(pbRqu[wOffset]), bHMACResult, sizeof(TPM_NONCE));

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psNvDefineSpaceRqu,
						    dwNvDefineSpaceRquSize,
						    (BYTE *) psNvDefineSpaceRsp, &dwNvDefineSpaceRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psNvDefineSpaceRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;

			dwRCVal = RC_SUCCESS;
			memcpy(psNonceEven, &(psNvDefineSpaceRsp->sNonceEven), sizeof(TPM_NONCE));
		} else		// !dwAuthHandle: without authorization
		{
			// Initialize the command structures
			dwNvDefineSpaceRquSize = sizeof(TPM_TAG) +
			    sizeof(UINT32) + sizeof(TPM_COMMAND_CODE) + dwPubInfoSize + sizeof(TPM_ENCAUTH);
			dwNvDefineSpaceRspSize = sizeof(TPM_NV_DEFINE_SPACE_RSP);
			SAFE_CALLOC(psNvDefineSpaceRqu, dwNvDefineSpaceRquSize, &dwRCVal);
			SAFE_CALLOC(psNvDefineSpaceRsp, dwNvDefineSpaceRspSize, &dwRCVal);
			// Fill byte stream
			psNvDefineSpaceRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
			psNvDefineSpaceRqu->dwParamSize = dwSwitchEndian32(dwNvDefineSpaceRquSize);
			psNvDefineSpaceRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_NV_DefineSpace);

			// TPM_NV_DATA_PUBLIC
			memcpy(&(psNvDefineSpaceRqu->sPubInfo), psPubInfo, dwPubInfoSize);
			psNvDefineSpaceRqu->sPubInfo.tag = wSwitchEndian16(psNvDefineSpaceRqu->sPubInfo.tag);
			psNvDefineSpaceRqu->sPubInfo.nvIndex = dwSwitchEndian32(psNvDefineSpaceRqu->sPubInfo.nvIndex);
			// pcrInfoRead.pcrSelection.sizeOfSelect
			// help variable for endian switch
			dwTPMNVDataPublicHelp = psNvDefineSpaceRqu->sPubInfo.pcrInfoRead.pcrSelection.sizeOfSelect;
			psNvDefineSpaceRqu->sPubInfo.pcrInfoRead.pcrSelection.sizeOfSelect =
			    wSwitchEndian16((UINT16) dwTPMNVDataPublicHelp);
			pbTPMNVDataPublic = (BYTE *) & (psNvDefineSpaceRqu->sPubInfo.pcrInfoRead.pcrSelection.pcrSelect);
			// Step over pcrInfoRead.pcrSelection.pcrSelect
			i = (UINT16)dwTPMNVDataPublicHelp;
			// Step over fields
			i += sizeof(TPM_LOCALITY_SELECTION);
			i += sizeof(TPM_COMPOSITE_HASH);
			// pcrInfoWrite.pcrSelection.sizeOfSelect
			SwitchEndian16ByteArray(&pbTPMNVDataPublic[i]);
			// Now big endian
			dwTPMNVDataPublicHelp = (pbTPMNVDataPublic[i] << 8) | (pbTPMNVDataPublic[i + 1]);
			i += sizeof(UINT16);
			// Step over pcrInfoWrite.pcrSelection.pcrSelect
			i += (UINT16)dwTPMNVDataPublicHelp;
			// Step over fields
			i += sizeof(TPM_LOCALITY_SELECTION);
			i += sizeof(TPM_COMPOSITE_HASH);
			// permission.tag
			SwitchEndian16ByteArray(&pbTPMNVDataPublic[i]);
			i += sizeof(UINT16);
			// permission.attributes
			SwitchEndian32ByteArray(&pbTPMNVDataPublic[i]);
			i += sizeof(UINT32);
			i += 3;	// Step over bReadSTClear; bWriteSTClear; bWriteDefine;
			// dataSize
			SwitchEndian32ByteArray(&pbTPMNVDataPublic[i]);
			i += sizeof(UINT32);

			// TPM_ENCAUTH
			memcpy(&pbTPMNVDataPublic[i], psEncAuth, sizeof(TPM_ENCAUTH));

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psNvDefineSpaceRqu,
						    dwNvDefineSpaceRquSize,
						    (BYTE *) psNvDefineSpaceRsp, &dwNvDefineSpaceRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psNvDefineSpaceRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;

			dwRCVal = RC_SUCCESS;
			psNonceEven = NULL;
		}
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);
	SAFE_FREE(pbHmacInput);

	SAFE_FREE(psNvDefineSpaceRqu);	// Free command request structure
	SAFE_FREE(psNvDefineSpaceRsp);	// Free command response structure

	DetLogToFile("<- TPM_NV_DefineSpace\n\n");

	return dwRCVal;
}

/*++
TPM_NV_WriteValue

Description:
Transmits the TPM command TPM_NV_WriteValue

Arguments:
[in]        TPM_NV_INDEX        dwNvIndex           The index of the area to set
[in]        UINT32              dwOffset            The offset into the NV Area
[in]        UINT32              dwDataSize          The size of the data parameter
[in]        BYTE                *abData             The data to set the area to
[in]        TPM_AUTHHANDLE      dwAuthHandle        The authorization session handle used for TPM Owner
[in/out]    TPM_NONCE           *psNonceEven        Even nonce previously generated by TPM to cover inputs
[in]        BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]        TPM_AUTHDATA        *psOwnerAuth        The authorization session digest HMAC key: ownerAuth

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier    2008/03/10
--*/
UINT32 TPM_NV_WriteValue(TPM_NV_INDEX dwNvIndex, UINT32 dwOffset, UINT32 dwDataSize, BYTE * pbData, TPM_AUTHHANDLE dwAuthHandle,	// If NULL command executes un-authorized
			 TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wNonceOdd = 0;
	UINT16 wOwnerAuth = 0;

	// Temporary data buffers for HMAC calculation according to the OIAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwNvWriteValueRquSize = 0;
	UINT32 dwNvWriteValueRspSize = 0;
	TPM_NV_WRITE_VALUE_RQU *psNvWriteValueRqu = NULL;
	TPM_NV_WRITE_VALUE_RSP *psNvWriteValueRsp = NULL;

	DetLogToFile("\n-> TPM_NV_WriteValue\n");

	do {
		// with authorization
		if (dwAuthHandle) {
			// Initialize temporary data buffers for HMAC calculation according to the auth session
			wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) +
						       sizeof(TPM_NV_INDEX) + sizeof(UINT32) + sizeof(UINT32) + dwDataSize);

			// The HMAC input uses (HASH_LEN + 2*sizeof(TPM_NONCE) + 1) Bytes
			wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
			SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
			SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);
			// Initialize the command structures
			dwNvWriteValueRquSize = sizeof(TPM_NV_WRITE_VALUE_RQU) + dwDataSize - sizeof(BYTE);
			dwNvWriteValueRspSize = sizeof(TPM_NV_WRITE_VALUE_RSP);
			SAFE_CALLOC(psNvWriteValueRqu, dwNvWriteValueRquSize, &dwRCVal);
			SAFE_CALLOC(psNvWriteValueRsp, dwNvWriteValueRspSize, &dwRCVal);

			psNvWriteValueRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
			psNvWriteValueRqu->dwParamSize = dwSwitchEndian32(dwNvWriteValueRquSize);
			psNvWriteValueRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_NV_WriteValue);
			psNvWriteValueRqu->dwNvIndex = dwSwitchEndian32(dwNvIndex);
			psNvWriteValueRqu->dwOffset = dwSwitchEndian32(dwOffset);
			psNvWriteValueRqu->dwDataSize = dwSwitchEndian32(dwDataSize);
			memcpy(&(psNvWriteValueRqu->abData), pbData, dwDataSize);
			i = (UINT16)dwDataSize;
			psNvWriteValueRqu->abData[i++] = (BYTE)(dwAuthHandle >> 24);
			psNvWriteValueRqu->abData[i++] = (BYTE)(dwAuthHandle >> 16);
			psNvWriteValueRqu->abData[i++] = (BYTE)(dwAuthHandle >> 8);
			psNvWriteValueRqu->abData[i++] = (BYTE)dwAuthHandle;
			wNonceOdd = i;
			for (i = 0; i < sizeof(TPM_NONCE); i++)
				psNvWriteValueRqu->abData[wNonceOdd + i] = (BYTE) i;
			i = wNonceOdd + sizeof(TPM_NONCE);
			psNvWriteValueRqu->abData[i++] = bContinueAuthSession;
			wOwnerAuth = i;

			// Fill pbInParamDigest buffer according to authorization
			i = 0;
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_WriteValue >> 24);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_WriteValue >> 16);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_WriteValue >> 8);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_WriteValue);
			pbInParamDigest[i++] = (BYTE) (dwNvIndex >> 24);
			pbInParamDigest[i++] = (BYTE) (dwNvIndex >> 16);
			pbInParamDigest[i++] = (BYTE) (dwNvIndex >> 8);
			pbInParamDigest[i++] = (BYTE) (dwNvIndex);
			pbInParamDigest[i++] = (BYTE) (dwOffset >> 24);
			pbInParamDigest[i++] = (BYTE) (dwOffset >> 16);
			pbInParamDigest[i++] = (BYTE) (dwOffset >> 8);
			pbInParamDigest[i++] = (BYTE) (dwOffset);
			pbInParamDigest[i++] = (BYTE) (dwDataSize >> 24);
			pbInParamDigest[i++] = (BYTE) (dwDataSize >> 16);
			pbInParamDigest[i++] = (BYTE) (dwDataSize >> 8);
			pbInParamDigest[i++] = (BYTE) (dwDataSize);
			memcpy(&(pbInParamDigest[i]), pbData, dwDataSize);
			//i += dwDataSize; //dead assignment

			// Create SHA-1 hash from the input parameters according to authorization
			dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
			if (dwRCVal != RC_SUCCESS)
				break;

			// Fill HMAC input buffer according to authorization
			i = HASH_LEN;
			memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			memcpy(&(pbHmacInput[i]), &(psNvWriteValueRqu->abData[wNonceOdd]), sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			pbHmacInput[i] = bContinueAuthSession;

			// Create HMAC for authenticated TPM command according to authorization
			dwRCVal = HMAC_Func(pbHmacInput,
					    wHmacInputSize, (BYTE *) psOwnerAuth, &psNvWriteValueRqu->abData[wOwnerAuth]);
			if (dwRCVal != RC_SUCCESS)
				break;

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psNvWriteValueRqu,
						    dwNvWriteValueRquSize,
						    (BYTE *) psNvWriteValueRsp, &dwNvWriteValueRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psNvWriteValueRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;

			dwRCVal = RC_SUCCESS;
			memcpy(psNonceEven, &(psNvWriteValueRsp->sNonceEven), sizeof(TPM_NONCE));
		} else		// !dwAuthHandle: without authorization
		{
			// Initialize the command structures
			dwNvWriteValueRquSize = sizeof(TPM_TAG) +
			    sizeof(UINT32) +
			    sizeof(TPM_COMMAND_CODE) + sizeof(TPM_NV_INDEX) + sizeof(UINT32) + sizeof(UINT32) + dwDataSize;
			dwNvWriteValueRspSize = sizeof(TPM_NV_WRITE_VALUE_RSP);
			SAFE_CALLOC(psNvWriteValueRqu, dwNvWriteValueRquSize, &dwRCVal);
			SAFE_CALLOC(psNvWriteValueRsp, dwNvWriteValueRspSize, &dwRCVal);

			psNvWriteValueRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
			psNvWriteValueRqu->dwParamSize = dwSwitchEndian32(dwNvWriteValueRquSize);
			psNvWriteValueRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_NV_WriteValue);
			psNvWriteValueRqu->dwNvIndex = dwSwitchEndian32(dwNvIndex);
			psNvWriteValueRqu->dwOffset = dwSwitchEndian32(dwOffset);
			psNvWriteValueRqu->dwDataSize = dwSwitchEndian32(dwDataSize);
			memcpy(&(psNvWriteValueRqu->abData), pbData, dwDataSize);
			// i = dwDataSize; // Dead increment

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psNvWriteValueRqu,
						    dwNvWriteValueRquSize,
						    (BYTE *) psNvWriteValueRsp, &dwNvWriteValueRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psNvWriteValueRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;

			dwRCVal = RC_SUCCESS;
		}
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);
	SAFE_FREE(pbHmacInput);
	SAFE_FREE(psNvWriteValueRqu);	// Free command request structure
	SAFE_FREE(psNvWriteValueRsp);	// Free command response structure

	DetLogToFile("<- TPM_NV_WriteValue\n\n");

	return dwRCVal;
}

/*++
TPM_NV_ReadValue

Description:
Transmits the TPM command TPM_NV_ReadValue

Arguments:
[in]		TPM_NV_INDEX	dwIndex			The index of the area to set
[in]		UINT32			dwOffset		The offset into the area
[in]		UINT32			*pdwDataSize    The size of the data area
[in]        TPM_AUTHHANDLE	dwAuthHandle    The authorization session handle used for TPM Owner authorization
[in/out]	TPM_NONCE		*psNonceEven    Even nonce previously generated by TPM to cover inputs
[in]        BOOL            bContinueAuthSession    The continue use flag for the authorization session handle
[in]        TPM_AUTHDATA	*psOwnerAuth    HMAC key: ownerAuth
[in]		BYTE			*pbData         The data to set the area to

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_NV_ReadValue(TPM_NV_INDEX dwIndex, UINT32 dwOffset, UINT32 * pdwDataSize, TPM_AUTHHANDLE dwAuthHandle,	// If NULL command executes un-authorized
			TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			BOOL bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth, BYTE * pbData)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the authSession
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwNvReadValRquSize = 0;
	UINT32 dwNvReadValRspSize = 0;
	TPM_NV_READ_VALUE_RQU *psNvReadValRqu = NULL;
	TPM_NV_READ_VALUE_RSP *psNvReadValRsp = NULL;
	BYTE *pbNonce;

	DetLogToFile("\n-> TPM_NV_ReadValue\n");

	do {
		// with authorization
		if (dwAuthHandle) {
			// Initialize temporary data buffers for HMAC calculation according to the authSession
			wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) +
						       sizeof(TPM_NV_INDEX) + sizeof(UINT32) + sizeof(UINT32));
			// The HMAC input uses (HASH_LEN + 2*sizeof(TPM_NONCE) + 1) Bytes
			wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
			SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
			SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);
			// Initialize the command structures
			// Size of the response structure is pdwDataSize + size of the structure header (-1)
			dwNvReadValRspSize = sizeof(TPM_NV_READ_VALUE_RSP) + *pdwDataSize - sizeof(BYTE);
			SAFE_CALLOC(psNvReadValRqu, sizeof(TPM_NV_READ_VALUE_RQU), &dwRCVal);
			SAFE_CALLOC(psNvReadValRsp, (size_t) dwNvReadValRspSize, &dwRCVal);

			psNvReadValRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
			psNvReadValRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_NV_READ_VALUE_RQU));
			psNvReadValRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_NV_ReadValue);
			psNvReadValRqu->dwNvIndex = dwSwitchEndian32(dwIndex);
			psNvReadValRqu->dwOffset = dwSwitchEndian32(dwOffset);
			psNvReadValRqu->dwDataSize = dwSwitchEndian32(*pdwDataSize);
			// authorization
			psNvReadValRqu->dwAuthHandle = dwSwitchEndian32(dwAuthHandle);
			for (i = 0; i < sizeof(TPM_NONCE); i++)
				psNvReadValRqu->sAuthNonceOdd.nonce[i] = (BYTE) i;
			psNvReadValRqu->bContinueAuthSession = bContinueAuthSession;
			memcpy(&(psNvReadValRqu->sOwnerAuth), psOwnerAuth, sizeof(TPM_AUTHDATA));

			// Fill pbInParamDigest buffer according to OIAP
			i = 0;
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_ReadValue >> 24);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_ReadValue >> 16);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_ReadValue >> 8);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_NV_ReadValue);
			pbInParamDigest[i++] = (BYTE) (dwIndex >> 24);
			pbInParamDigest[i++] = (BYTE) (dwIndex >> 16);
			pbInParamDigest[i++] = (BYTE) (dwIndex >> 8);
			pbInParamDigest[i++] = (BYTE) (dwIndex);
			pbInParamDigest[i++] = (BYTE) (dwOffset >> 24);
			pbInParamDigest[i++] = (BYTE) (dwOffset >> 16);
			pbInParamDigest[i++] = (BYTE) (dwOffset >> 8);
			pbInParamDigest[i++] = (BYTE) (dwOffset);
			pbInParamDigest[i++] = (BYTE) (*pdwDataSize >> 24);
			pbInParamDigest[i++] = (BYTE) (*pdwDataSize >> 16);
			pbInParamDigest[i++] = (BYTE) (*pdwDataSize >> 8);
			pbInParamDigest[i++] = (BYTE) (*pdwDataSize);

			// Create SHA-1 hash from the input parameters according to OIAP
			dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}
			// Fill HMAC input buffer according to OIAP
			i = HASH_LEN;
			memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			memcpy(&(pbHmacInput[i]), &(psNvReadValRqu->sAuthNonceOdd), sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			pbHmacInput[i] = bContinueAuthSession;

			// Create HMAC for authenticated TPM command according to OIAP
			dwRCVal = HMAC_Func(pbHmacInput,
					    wHmacInputSize, (BYTE *) psOwnerAuth, (BYTE *) & psNvReadValRqu->sOwnerAuth);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}
			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psNvReadValRqu,
						    sizeof(TPM_NV_READ_VALUE_RQU),
						    (BYTE *) psNvReadValRsp, &dwNvReadValRspSize);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwRCVal = dwSwitchEndian32(psNvReadValRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS) {
				*pdwDataSize = 0;
				break;
			}

			dwRCVal = RC_SUCCESS;

			// Copy result length to the output argument
			if (*pdwDataSize < dwSwitchEndian32(psNvReadValRsp->dwDataSize)) {
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			}
			*pdwDataSize = dwSwitchEndian32(psNvReadValRsp->dwDataSize);

			// Copy result from the command response structure to the output argument
			memcpy(pbData, psNvReadValRsp->abData, (size_t) (*pdwDataSize));
			// Do not write the following two lines in one or you'll get an pointer arithmetic error
			pbNonce = (BYTE *) & (psNvReadValRsp->abData);
			pbNonce += *pdwDataSize;
			memcpy(psNonceEven, pbNonce, sizeof(TPM_NONCE));
		} else		// !dwAuthHandle: without authorization
		{
			// Initialize the command structures
			dwNvReadValRquSize = sizeof(TPM_TAG) +
			    sizeof(UINT32) +
			    sizeof(TPM_COMMAND_CODE) + sizeof(TPM_NV_INDEX) + sizeof(UINT32) + sizeof(UINT32);
			dwNvReadValRspSize = sizeof(TPM_NV_READ_VALUE_RSP) - sizeof(BYTE) + *pdwDataSize;
			SAFE_CALLOC(psNvReadValRqu, dwNvReadValRquSize, &dwRCVal);
			SAFE_CALLOC(psNvReadValRsp, dwNvReadValRspSize, &dwRCVal);

			psNvReadValRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
			psNvReadValRqu->dwParamSize = dwSwitchEndian32(dwNvReadValRquSize);
			psNvReadValRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_NV_ReadValue);
			psNvReadValRqu->dwNvIndex = dwSwitchEndian32(dwIndex);
			psNvReadValRqu->dwOffset = dwSwitchEndian32(dwOffset);
			psNvReadValRqu->dwDataSize = dwSwitchEndian32(*pdwDataSize);

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psNvReadValRqu,
						    dwNvReadValRquSize, (BYTE *) psNvReadValRsp, &dwNvReadValRspSize);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwRCVal = dwSwitchEndian32(psNvReadValRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS) {
				*pdwDataSize = 0;
				break;
			}

			dwRCVal = RC_SUCCESS;

			// Copy result length to the output argument
			if (*pdwDataSize < dwSwitchEndian32(psNvReadValRsp->dwDataSize)) {
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			}
			*pdwDataSize = dwSwitchEndian32(psNvReadValRsp->dwDataSize);

			// Copy result from the command response structure to the output argument
			memcpy(pbData, psNvReadValRsp->abData, *pdwDataSize);
		}
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwDataSize = 0;
	}

	SAFE_FREE(pbInParamDigest);
	SAFE_FREE(pbHmacInput);
	SAFE_FREE(psNvReadValRqu);	// Free command request structure
	SAFE_FREE(psNvReadValRsp);	// Free command response structure

	DetLogToFile("<- TPM_NV_ReadValue\n\n");

	return dwRCVal;
}

/*++
TPM_OIAP

Description:
Transmits the TPM command TPM_OIAP

Arguments:
[out]	TPM_AUTHHANDLE	*pdwAHandle		Handle that points to the authorization state
[out]	TPM_NONCE		*psNonceEven	Nonce generated by TPM and associated with session

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_OIAP(TPM_AUTHHANDLE * pdwAuthHandle, TPM_NONCE * psNonceEven)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwOiapRspSize;
	TPM_SIMPLE_CMD_RQU *psOiapRqu = NULL;
	TPM_OIAP_RSP *psOiapRsp = NULL;

	DetLogToFile("\n-> TPM_OIAP\n");

	do {
		// Initialize the command structures
		dwOiapRspSize = sizeof(TPM_OIAP_RSP);
		SAFE_CALLOC(psOiapRqu, sizeof(TPM_SIMPLE_CMD_RQU), &dwRCVal);
		SAFE_CALLOC(psOiapRsp, sizeof(TPM_OIAP_RSP), &dwRCVal);

		psOiapRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psOiapRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SIMPLE_CMD_RQU));
		psOiapRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_OIAP);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psOiapRqu,
					    sizeof(TPM_SIMPLE_CMD_RQU), (BYTE *) psOiapRsp, &dwOiapRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psOiapRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		else
			dwRCVal = RC_SUCCESS;

		// Copy results from the command response structure to the output arguments
		*pdwAuthHandle = dwSwitchEndian32(psOiapRsp->dwAuthHandle);
		memcpy(psNonceEven, &(psOiapRsp->sNonceEven), sizeof(TPM_NONCE));
	} while (FALSE);

	SAFE_FREE(psOiapRqu);	// Free command request structure
	SAFE_FREE(psOiapRsp);	// Free command response structure

	DetLogToFile("<- TPM_OIAP\n\n");

	return dwRCVal;
}

/*++
TPM_OSAP

Description:
Transmits the TPM command TPM_OSAP

Arguments:
[in]    TPM_ENTITY_TYPE wEntityType     The type of entity in use
[in]    UINT32          dwEntityValue   The selection value based on entityType, e.g. a keyHandle #
[in]    TPM_NONCE       *psNonceOddOSAP The nonce generated by the caller associated with the shared secret.
[out]	TPM_AUTHHANDLE	*pdwAuthHandle	Handle that TPM creates that points to the authorization state.
[out]	TPM_NONCE		*psNonceEven	Nonce generated by TPM and associated with session.
[out]	TPM_NONCE		*psNonceEvenOSAP	Nonce generated by TPM and associated with shared secret.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_OSAP(TPM_ENTITY_TYPE wEntityType,
		UINT32 dwEntityValue,
		TPM_NONCE * psNonceOddOSAP,
		TPM_AUTHHANDLE * pdwAuthHandle, TPM_NONCE * psNonceEven, TPM_NONCE * psNonceEvenOSAP)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	UINT32 dwOSAPRquSize = 0;
	UINT32 dwOSAPRspSize = 0;
	TPM_OSAP_RQU *psOSAPRqu = NULL;
	TPM_OSAP_RSP *psOSAPRsp = NULL;

	DetLogToFile("\n-> TPM_OSAP\n");

	do {
		// Initialize the command structures
		dwOSAPRquSize = sizeof(TPM_OSAP_RQU);
		dwOSAPRspSize = sizeof(TPM_OSAP_RSP);
		SAFE_CALLOC(psOSAPRqu, dwOSAPRquSize, &dwRCVal);
		SAFE_CALLOC(psOSAPRsp, dwOSAPRspSize, &dwRCVal);

		psOSAPRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psOSAPRqu->dwParamSize = dwSwitchEndian32(dwOSAPRquSize);
		psOSAPRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_OSAP);
		psOSAPRqu->wEntityType = wSwitchEndian16(wEntityType);
		psOSAPRqu->dwEntityValue = dwSwitchEndian32(dwEntityValue);
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psOSAPRqu->sNonceOddOSAP.nonce[i] = (BYTE) i;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psOSAPRqu, dwOSAPRquSize, (BYTE *) psOSAPRsp, &dwOSAPRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psOSAPRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;

		// Copy results from the command response structure to the output arguments
		*pdwAuthHandle = dwSwitchEndian32(psOSAPRsp->dwAuthHandle);
		memcpy(psNonceEven, &(psOSAPRsp->sNonceEven), sizeof(TPM_NONCE));
		memcpy(psNonceEvenOSAP, &(psOSAPRsp->sNonceEvenOSAP), sizeof(TPM_NONCE));
	} while (FALSE);

	SAFE_FREE(psOSAPRqu);	// Free command request structure
	SAFE_FREE(psOSAPRsp);	// Free command response structure

	DetLogToFile("<- TPM_OSAP\n\n");

	return dwRCVal;
}

/*++
TPM_SetOwnerInstall

Description:
Transmits the TPM command TPM_SetOwnerInstall

Arguments:
[in]	BYTE	bState		ON or OFF (allows or disallows the ability to insert an owner)

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/
UINT32 TPM_SetOwnerInstall(BYTE bState)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bLocalState = 0;
	UINT32 dwSetOwnInsRspSize = 0;
	TPM_SET_OWNER_INSTALL_RQU *psSetOwnInsRqu = NULL;
	TPM_SIMPLE_CMD_RSP *psSetOwnInsRsp = NULL;

	DetLogToFile("\n-> TPM_SetOwnerInstall\n");

	switch (bState) {
	case ON:
		bLocalState = 0x01;
		break;
	case OFF:
		bLocalState = 0x00;
		break;
	default:
		bLocalState = 0x00;
	}

	do {
		// Initialize the command structures
		dwSetOwnInsRspSize = sizeof(TPM_SIMPLE_CMD_RSP);
		SAFE_CALLOC(psSetOwnInsRqu, sizeof(TPM_SET_OWNER_INSTALL_RQU), &dwRCVal);
		SAFE_CALLOC(psSetOwnInsRsp, sizeof(TPM_SIMPLE_CMD_RSP), &dwRCVal);

		psSetOwnInsRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSetOwnInsRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SET_OWNER_INSTALL_RQU));
		psSetOwnInsRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SetOwnerInstall);
		psSetOwnInsRqu->bState = bLocalState;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSetOwnInsRqu,
					    sizeof(TPM_SET_OWNER_INSTALL_RQU), (BYTE *) psSetOwnInsRsp, &dwSetOwnInsRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSetOwnInsRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psSetOwnInsRqu);	// Free command request structure
	SAFE_FREE(psSetOwnInsRsp);	// Free command response structure

	DetLogToFile("<- TPM_SetOwnerInstall\n\n");

	return dwRCVal;
}

/*++
TPM_PhysicalSetDeactivated

Description:
Transmits the TPM command TPM_PhysicalSetDeactivated

Arguments:
[in]	BYTE	bState		ON or OFF (deactivate or activate TPM)

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_PhysicalSetDeactivated(BYTE bState)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE bLocalState = 0;
	UINT32 dwSetDeacRspSize = 0;
	TPM_PHYS_SET_DEAC_RQU *psSetDeacRqu = NULL;
	TPM_PHYS_SET_DEAC_RSP *psSetDeacRsp = NULL;

	DetLogToFile("\n-> TPM_PhysicalSetDeactivated\n");

	switch (bState) {
	case ON:
		bLocalState = 0x01;
		break;
	case OFF:
		bLocalState = 0x00;
		break;
	default:
		bLocalState = 0x00;
	}

	do {
		// Initialize the command structures
		dwSetDeacRspSize = sizeof(TPM_PHYS_SET_DEAC_RSP);
		SAFE_CALLOC(psSetDeacRqu, sizeof(TPM_PHYS_SET_DEAC_RQU), &dwRCVal);
		SAFE_CALLOC(psSetDeacRsp, sizeof(TPM_PHYS_SET_DEAC_RSP), &dwRCVal);

		psSetDeacRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSetDeacRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_PHYS_SET_DEAC_RQU));
		psSetDeacRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_PhysicalSetDeactivated);
		psSetDeacRqu->bState = bLocalState;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSetDeacRqu,
					    sizeof(TPM_PHYS_SET_DEAC_RQU), (BYTE *) psSetDeacRsp, &dwSetDeacRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSetDeacRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psSetDeacRqu);	// Free command request structure
	SAFE_FREE(psSetDeacRsp);	// Free command response structure

	DetLogToFile("<- TPM_PhysicalSetDeactivated\n\n");

	return dwRCVal;
}

/*++
TPM_CreateEndorsementKeyPair

Description:
Transmits the TPM command TPM_CreateEndorsementKeyPair

Arguments:
[in]        UINT32			dwKeyInfoSize   The size of the key info parameters
[in			TPM_KEY_PARMS	*psKeyInfo      Information about key to be created, this includes all algorithm parameters
[in/out]    UINT32          *pdwKeySize     The size of the public endorsement key
[out]		TPM_PUBKEY		*pubEndorsementKey  The public endorsement key

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_CreateEndorsementKeyPair(UINT32 dwKeyInfoSize,
				    TPM_KEY_PARMS * psKeyInfo, UINT32 * pdwKeySize, TPM_PUBKEY * pPubEndorsementKey)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	BYTE i = 0;
	BYTE *pbHelp = NULL;
	UINT32 dwHelp = 0;
	UINT32 dwRspSize = 0;

	UINT32 dwCreateEndorsementKeyPairRquSize = 0;
	UINT32 dwCreateEndorsementKeyPairRspSize = 0;
	TPM_CREATE_ENDORSEMENT_KEY_PAIR_RQU *psCreateEndorsementKeyPairRqu = NULL;
	TPM_CREATE_ENDORSEMENT_KEY_PAIR_RSP *psCreateEndorsementKeyPairRsp = NULL;

	DetLogToFile("\n-> TPM_CreateEndorsementKeyPair\n");

	do {
		// Initialize the command structures
		dwCreateEndorsementKeyPairRquSize =
		    sizeof(TPM_CREATE_ENDORSEMENT_KEY_PAIR_RQU) - sizeof(TPM_KEY_PARMS) + dwKeyInfoSize;
		// memory allocation for key pair response (default size)
		dwCreateEndorsementKeyPairRspSize =
		    sizeof(TPM_CREATE_ENDORSEMENT_KEY_PAIR_RSP) - sizeof(TPM_PUBKEY) + DEFAULT_BUFFERSIZE;
		SAFE_CALLOC(psCreateEndorsementKeyPairRqu, dwCreateEndorsementKeyPairRquSize, &dwRCVal);
		SAFE_CALLOC(psCreateEndorsementKeyPairRsp, dwCreateEndorsementKeyPairRspSize, &dwRCVal);

		psCreateEndorsementKeyPairRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psCreateEndorsementKeyPairRqu->dwParamSize = dwSwitchEndian32(dwCreateEndorsementKeyPairRquSize);
		psCreateEndorsementKeyPairRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_CreateEndorsementKeyPair);
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psCreateEndorsementKeyPairRqu->sAntiReplay.nonce[i] = (i + 1) % 10;
		memcpy(&(psCreateEndorsementKeyPairRqu->sKeyInfo), psKeyInfo, dwKeyInfoSize);
		// Switch TPM_KEY_PARMS
		pbHelp = (BYTE *) & (psCreateEndorsementKeyPairRqu->sKeyInfo);
		i = 0;
		// algorithmParms.algorithmID
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(TPM_ALGORITHM_ID);
		// algorithmParms.encScheme
		SwitchEndian16ByteArray(&pbHelp[i]);
		i += sizeof(TPM_ENC_SCHEME);
		// algorithmParms.sigScheme
		SwitchEndian16ByteArray(&pbHelp[i]);
		i += sizeof(TPM_SIG_SCHEME);
		// algorithmParms.parmSize
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(UINT32);
		// parms.keyLength
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(UINT32);
		// parms.numPrimes
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(UINT32);
		// parms.exponentSize
		SwitchEndian32ByteArray(&pbHelp[i]);
		//i += sizeof(UINT32); //Dead assignment

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psCreateEndorsementKeyPairRqu,
					    dwCreateEndorsementKeyPairRquSize,
					    (BYTE *) psCreateEndorsementKeyPairRsp, &dwCreateEndorsementKeyPairRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psCreateEndorsementKeyPairRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwKeySize = 0;	// No data if error occurred
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result length to the output argument
		// sizeof(TPM_PUBKEY) = sizeof(whole telegram) - sizeof(fixed size of fields of telegram)
		dwRspSize = dwSwitchEndian32(psCreateEndorsementKeyPairRsp->dwParamSize) -
		    sizeof(TPM_TAG) - sizeof(UINT32) - sizeof(TPM_RESULT) - sizeof(TPM_DIGEST);

		// is the returned size of the TPM_PUBKEY structure bigger than the user provided?
		if (dwRspSize > *pdwKeySize) {
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		} else
			*pdwKeySize = dwRspSize;

		// Switch TPM_PUBKEY
		pbHelp = (BYTE *) & (psCreateEndorsementKeyPairRsp->sPubEndorsementKey);
		i = 0;
		// algorithmParms.algorithmID
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(TPM_ALGORITHM_ID);
		// algorithmParms.encScheme
		SwitchEndian16ByteArray(&pbHelp[i]);
		i += sizeof(TPM_ENC_SCHEME);
		// algorithmParms.sigScheme
		SwitchEndian16ByteArray(&pbHelp[i]);
		i += sizeof(TPM_SIG_SCHEME);
		// algorithmParms.parmSize
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(UINT32);
		// parms.keyLength
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(UINT32);
		// parms.numPrimes
		SwitchEndian32ByteArray(&pbHelp[i]);
		i += sizeof(UINT32);
		// parms.exponentSize
		SwitchEndian32ByteArray(&pbHelp[i]);
		// step over exponent
		// Now little endian
		dwHelp = (pbHelp[i]) | (pbHelp[i + 1] << 8) | (pbHelp[i + 2] << 16) | (pbHelp[i + 3] << 24);
		i += sizeof(UINT32);
		i += (BYTE)dwHelp;
		// pubKey.keyLength
		SwitchEndian32ByteArray(&pbHelp[i]);

		// Copy result from the command response structure to the output argument
		memcpy(pPubEndorsementKey, &(psCreateEndorsementKeyPairRsp->sPubEndorsementKey), *pdwKeySize);
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwKeySize = 0;
	}

	SAFE_FREE(psCreateEndorsementKeyPairRqu);	// Free command request structure
	SAFE_FREE(psCreateEndorsementKeyPairRsp);	// Free command response structure

	DetLogToFile("<- TPM_CreateEndorsementKeyPair\n\n");

	return dwRCVal;
}

/*++
TPM_ReadPubek

Description:
Transmits the TPM command TPM_ReadPubek

Arguments:
[in]		BYTE	*pKey		Pointer to PUBEK
[in/out]	UINT32	*pdwKeyLen	PUBEK length in Bytes (usually 256)

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_ReadPubek(UINT32 * pdwKeyLen, BYTE * pKey)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE i = 0;
	UINT32 dwReadPubekRspSize = 0;
	TPM_READ_PUBEK_RQU *psReadPubekRqu = NULL;
	TPM_READ_PUBEK_RSP *psReadPubekRsp = NULL;

	//BYTE *pbHelp = NULL;
	//UINT32 dwHelp = 0;
	//UINT32 dwRspSize = 0;

	DetLogToFile("\n-> TPM_ReadPubek\n");

	do {
		// Initialize the command structures
		dwReadPubekRspSize = sizeof(TPM_READ_PUBEK_RSP);
		SAFE_CALLOC(psReadPubekRqu, sizeof(TPM_READ_PUBEK_RQU), &dwRCVal);
		SAFE_CALLOC(psReadPubekRsp, sizeof(TPM_READ_PUBEK_RSP), &dwRCVal);

		psReadPubekRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psReadPubekRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_READ_PUBEK_RQU));
		psReadPubekRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_ReadPubek);
		for (i = 0; i < 20; i++)
			psReadPubekRqu->sAntiReplay.nonce[i] = (i + 1) % 10;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psReadPubekRqu,
					    sizeof(TPM_READ_PUBEK_RQU), (BYTE *) psReadPubekRsp, &dwReadPubekRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psReadPubekRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwKeyLen = 0;	// No data if error occurred
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result length to the output argument
		if (*pdwKeyLen < dwSwitchEndian32(psReadPubekRsp->sPubEndorsementKey.pubKey.keyLength)) {
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		}
		*pdwKeyLen = dwSwitchEndian32(psReadPubekRsp->sPubEndorsementKey.pubKey.keyLength);
/*
        // sizeof(TPM_PUBKEY) = sizeof(whole telegram) - sizeof(fixed size of fields of telegram)
        dwRspSize = dwSwitchEndian32(psReadPubekRsp->dwParamSize) -
            sizeof(TPM_TAG) -
            sizeof(UINT32) -
            sizeof(TPM_RESULT) -
            sizeof(TPM_DIGEST);

        // is the returned size of the TPM_PUBKEY structure bigger than the user provided?
		if (dwRspSize > *pdwKeyLen)
		{
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		}
		else
		    *pdwKeyLen = dwRspSize;

        // Switch TPM_PUBKEY
        pbHelp = (BYTE *)&(psReadPubekRsp->sPubEndorsementKey);
        i = 0;
        // algorithmParms.algorithmID
        SwitchEndian32ByteArray(&pbHelp[i]);
        i += sizeof(TPM_ALGORITHM_ID);
        // algorithmParms.encScheme
        SwitchEndian16ByteArray(&pbHelp[i]);
        i += sizeof(TPM_ENC_SCHEME);
        // algorithmParms.sigScheme
        SwitchEndian16ByteArray(&pbHelp[i]);
        i += sizeof(TPM_SIG_SCHEME);
        // algorithmParms.parmSize
        SwitchEndian32ByteArray(&pbHelp[i]);
        i += sizeof(UINT32);
        // parms.keyLength
        SwitchEndian32ByteArray(&pbHelp[i]);
        i += sizeof(UINT32);
        // parms.numPrimes
        SwitchEndian32ByteArray(&pbHelp[i]);
        i += sizeof(UINT32);
        // parms.exponentSize
        SwitchEndian32ByteArray(&pbHelp[i]);
        // step over exponent
        // Now little endian
        dwHelp = (pbHelp[i]) |
                (pbHelp[i + 1] << 8) |
                (pbHelp[i + 2] << 16) |
                (pbHelp[i + 3] << 24);
        i += sizeof(UINT32);
        i += dwHelp;
        // pubKey.keyLength
        SwitchEndian32ByteArray(&pbHelp[i]);

		// Copy result from the command response structure to the output argument
		memcpy(pKey, &(psReadPubekRsp->sPubEndorsementKey), (size_t)(*pdwKeyLen));
*/
		memcpy(pKey, &(psReadPubekRsp->sPubEndorsementKey.pubKey.key), (size_t) (*pdwKeyLen));
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwKeyLen = 0;
	}

	SAFE_FREE(psReadPubekRqu);	// Free command request structure
	SAFE_FREE(psReadPubekRsp);	// Free command response structure

	DetLogToFile("<- TPM_ReadPubek\n\n");

	return dwRCVal;
}

/*++
TPM_Extend

Description:
Transmits the TPM command TPM_Extend

Arguments:
[in]	TPM_PCRINDEX	dwPcrNum        The PCR to be updated.
[in]	TPM_DIGEST  	*psInDigest     The 160 bit value representing the event to be recorded.
[out]	TPM_PCRVALUE	*psOutDigest    Outgoing Operands and Sizes

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_Extend(TPM_PCRINDEX dwPcrNum, TPM_DIGEST * psInDigest, TPM_PCRVALUE * psOutDigest)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwExtendRquSize = 0;
	UINT32 dwExtendRspSize = 0;
	TPM_EXTEND_RQU *psExtendRqu = NULL;
	TPM_EXTEND_RSP *psExtendRsp = NULL;

	DetLogToFile("\n-> TPM_Extend\n");

	do {
		// Initialize the command structures
		dwExtendRquSize = sizeof(TPM_EXTEND_RQU);
		dwExtendRspSize = sizeof(TPM_EXTEND_RSP);
		SAFE_CALLOC(psExtendRqu, (size_t) dwExtendRquSize, &dwRCVal);
		SAFE_CALLOC(psExtendRsp, sizeof(TPM_EXTEND_RSP), &dwRCVal);

		psExtendRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psExtendRqu->dwParamSize = dwSwitchEndian32(dwExtendRquSize);
		psExtendRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_Extend);
		psExtendRqu->dwPcrNum = dwSwitchEndian32(dwPcrNum);
		memcpy(&(psExtendRqu->sInDigest), psInDigest, sizeof(TPM_DIGEST));

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psExtendRqu, dwExtendRquSize, (BYTE *) psExtendRsp, &dwExtendRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psExtendRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		memcpy(psOutDigest, &(psExtendRsp->sOutDigest), sizeof(TPM_PCRVALUE));
	} while (FALSE);

	SAFE_FREE(psExtendRqu);	// Free command request structure
	SAFE_FREE(psExtendRsp);	// Free command response structure

	DetLogToFile("<- TPM_Extend\n\n");

	return dwRCVal;
}

/*++
TPM_PCRRead

Description:
Transmits the TPM command TPM_PCRRead

Arguments:
[in]	TPM_PCRINDEX	dwPcrNum        The PCR to be updated.
[out]	TPM_PCRVALUE	*psOutDigest    Outgoing Operands and Sizes

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_PCRRead(TPM_PCRINDEX dwPcrIndex, TPM_PCRVALUE * psOutDigest)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwPCRReadRquSize = 0;
	UINT32 dwPCRReadRspSize = 0;
	TPM_PCR_READ_RQU *psPCRReadRqu = NULL;
	TPM_PCR_READ_RSP *psPCRReadRsp = NULL;

	DetLogToFile("\n-> TPM_PCRRead\n");

	do {
		// Initialize the command structures
		dwPCRReadRquSize = sizeof(TPM_PCR_READ_RQU);
		dwPCRReadRspSize = sizeof(TPM_PCR_READ_RSP);
		SAFE_CALLOC(psPCRReadRqu, (size_t) dwPCRReadRquSize, &dwRCVal);
		SAFE_CALLOC(psPCRReadRsp, sizeof(TPM_PCR_READ_RSP), &dwRCVal);

		psPCRReadRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psPCRReadRqu->dwParamSize = dwSwitchEndian32(dwPCRReadRquSize);
		psPCRReadRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_PcrRead);
		psPCRReadRqu->pcrIndex = dwSwitchEndian32(dwPcrIndex);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psPCRReadRqu,
					    dwPCRReadRquSize, (BYTE *) psPCRReadRsp, &dwPCRReadRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psPCRReadRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		memcpy(psOutDigest, &(psPCRReadRsp->sOutDigest), sizeof(TPM_PCRVALUE));
	} while (FALSE);

	SAFE_FREE(psPCRReadRqu);	// Free command request structure
	SAFE_FREE(psPCRReadRsp);	// Free command response structure

	DetLogToFile("<- TPM_PCRRead\n\n");

	return dwRCVal;
}

/*++
TPM_PCR_Reset

Description:
Transmits the TPM command TPM_PCR_Reset

Arguments:
[in]    UINT32                  dwPCRSelectionSize  The Size of the PCR to be updated.
[in]	TPM_PCR_SELECTION12     sPcrSelection   The PCR to be updated.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_PCR_Reset(UINT32 dwPCRSelectionSize, TPM_PCR_SELECTION12 * psPcrSelection)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwPCR_ResetRquSize = 0;
	UINT32 dwPCR_ResetRspSize = 0;
	TPM_PCR_RESET_RQU *psPCR_ResetRqu = NULL;
	TPM_SIMPLE_CMD_RSP *psPCR_ResetRsp = NULL;

	DetLogToFile("\n-> TPM_PCR_Reset\n");

	do {
		// Initialize the command structures
		dwPCR_ResetRquSize = sizeof(TPM_PCR_RESET_RQU) - sizeof(TPM_PCR_SELECTION12) + dwPCRSelectionSize;
		dwPCR_ResetRspSize = sizeof(TPM_SIMPLE_CMD_RSP);
		SAFE_CALLOC(psPCR_ResetRqu, dwPCR_ResetRquSize, &dwRCVal);
		SAFE_CALLOC(psPCR_ResetRsp, dwPCR_ResetRspSize, &dwRCVal);

		psPCR_ResetRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psPCR_ResetRqu->dwParamSize = dwSwitchEndian32(dwPCR_ResetRquSize);
		psPCR_ResetRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_PCR_Reset);
		memcpy(&(psPCR_ResetRqu->sPcrSelection), psPcrSelection, dwPCRSelectionSize);
		SwitchEndian16ByteArray((BYTE *) & (psPCR_ResetRqu->sPcrSelection.sizeOfSelect));

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psPCR_ResetRqu,
					    dwPCR_ResetRquSize, (BYTE *) psPCR_ResetRsp, &dwPCR_ResetRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psPCR_ResetRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

	} while (FALSE);

	SAFE_FREE(psPCR_ResetRqu);	// Free command request structure
	SAFE_FREE(psPCR_ResetRsp);	// Free command response structure

	DetLogToFile("<- TPM_PCR_Reset\n\n");

	return dwRCVal;
}

/*++
TPM_SHA1Complete

Description:
Transmits the TPM command TPM_SHA1Complete

Arguments:
[in]	UINT32	dwHashDataSize	Number of Bytes in pbHashData
[in]	BYTE	*pbHashData		Bytes to be hashed
[out]	BYTE	*pbHashValue	Resulting digest of the SHA-1 process

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_SHA1Complete(UINT32 dwHashDataSize, BYTE * pbHashData, BYTE * pbHashValue)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwSha1CompleteRquSize = 0;
	UINT32 dwSha1CompleteRspSize = 0;
	TPM_SHA1_CM_RQU *psSha1CompleteRqu = NULL;
	TPM_SHA1_CM_RSP *psSha1CompleteRsp = NULL;

	DetLogToFile("\n-> TPM_SHA1Complete\n");

	do {
		// Initialize the command structures
		// Size of the request structure is dwHashDataSize + size of the structure header (-1)
		dwSha1CompleteRquSize = dwHashDataSize + sizeof(TPM_SHA1_CM_RQU) - sizeof(BYTE);
		dwSha1CompleteRspSize = sizeof(TPM_SHA1_CM_RSP);
		SAFE_CALLOC(psSha1CompleteRqu, (size_t) dwSha1CompleteRquSize, &dwRCVal);
		SAFE_CALLOC(psSha1CompleteRsp, sizeof(TPM_SHA1_CM_RSP), &dwRCVal);

		psSha1CompleteRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSha1CompleteRqu->dwParamSize = dwSwitchEndian32(dwSha1CompleteRquSize);
		psSha1CompleteRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SHA1Complete);
		psSha1CompleteRqu->dwHashDataSize = dwSwitchEndian32(dwHashDataSize);
		if (dwHashDataSize != 0 && pbHashData != NULL)
			memcpy(psSha1CompleteRqu->abHashData, pbHashData, (size_t) dwHashDataSize);
		else if (pbHashData == NULL) {
			dwRCVal = RC_E_INVALID_PARAM;
			break;
		}
		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSha1CompleteRqu,
					    dwSha1CompleteRquSize, (BYTE *) psSha1CompleteRsp, &dwSha1CompleteRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSha1CompleteRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		memcpy(pbHashValue, &(psSha1CompleteRsp->sHashValue), HASH_LEN);
	} while (FALSE);

	SAFE_FREE(psSha1CompleteRqu);	// Free command request structure
	SAFE_FREE(psSha1CompleteRsp);	// Free command response structure

	DetLogToFile("<- TPM_SHA1Complete\n\n");

	return dwRCVal;
}

/*++
TPM_SHA1Start

Description:
Transmits the TPM command TPM_SHA1Start

Arguments:
[out]	UINT32		*pdwMaxBlockSize		Maximum number of Bytes for TPM_SHA1Update

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_SHA1Start(UINT32 * pdwMaxBlockSize)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwSha1StartRspSize = 0;
	TPM_SIMPLE_CMD_RQU *psSha1StartRqu = NULL;
	TPM_SHA1_ST_RSP *psSha1StartRsp = NULL;

	DetLogToFile("\n-> TPM_SHA1Start\n");

	do {
		// Initialize the command structures
		dwSha1StartRspSize = sizeof(TPM_SHA1_ST_RSP);
		SAFE_CALLOC(psSha1StartRqu, sizeof(TPM_SIMPLE_CMD_RQU), &dwRCVal);
		SAFE_CALLOC(psSha1StartRsp, sizeof(TPM_SHA1_ST_RSP), &dwRCVal);

		psSha1StartRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSha1StartRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SIMPLE_CMD_RQU));
		psSha1StartRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SHA1Start);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSha1StartRqu,
					    sizeof(TPM_SIMPLE_CMD_RQU), (BYTE *) psSha1StartRsp, &dwSha1StartRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psSha1StartRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwMaxBlockSize = 0;	// Zero value if error occurred
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		*pdwMaxBlockSize = dwSwitchEndian32(psSha1StartRsp->dwMaxNumBytes);
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwMaxBlockSize = 0;	// Zero value if error occurred
	}

	SAFE_FREE(psSha1StartRqu);	// Free command request structure
	SAFE_FREE(psSha1StartRsp);	// Free command response structure

	DetLogToFile("<- TPM_SHA1Start\n\n");

	return dwRCVal;
}

/*++
TPM_SHA1Update

Description:
Transmits the TPM command TPM_SHA1Update

Arguments:
[in]	UINT32	dwHashDataSize	Number of Bytes in pbHashData
[in]	BYTE	*pbHashData		Bytes to be hashed

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_SHA1Update(UINT32 dwHashDataSize, BYTE * pbHashData)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwSha1UpdateRquSize = 0;
	UINT32 dwSha1UpdateRspSize = 0;
	TPM_SHA1_UP_RQU *psSha1UpdateRqu = NULL;
	TPM_SIMPLE_CMD_RSP *psSha1UpdateRsp = NULL;

	DetLogToFile("\n-> TPM_SHA1Update\n");

	do {
		// Initialize the command structures
		// Size of the request structure is dwHashDataSize + size of the structure header (-1)
		dwSha1UpdateRquSize = dwHashDataSize + sizeof(TPM_SHA1_UP_RQU) - sizeof(BYTE);
		dwSha1UpdateRspSize = sizeof(TPM_SIMPLE_CMD_RSP);
		SAFE_CALLOC(psSha1UpdateRqu, (size_t) dwSha1UpdateRquSize, &dwRCVal);
		SAFE_CALLOC(psSha1UpdateRsp, sizeof(TPM_SIMPLE_CMD_RSP), &dwRCVal);

		psSha1UpdateRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSha1UpdateRqu->dwParamSize = dwSwitchEndian32(dwSha1UpdateRquSize);
		psSha1UpdateRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SHA1Update);
		psSha1UpdateRqu->dwNumBytes = dwSwitchEndian32(dwHashDataSize);
		if (dwHashDataSize)
			memcpy(psSha1UpdateRqu->abHashData, pbHashData, (size_t) dwHashDataSize);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSha1UpdateRqu,
					    dwSha1UpdateRquSize, (BYTE *) psSha1UpdateRsp, &dwSha1UpdateRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSha1UpdateRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psSha1UpdateRqu);	// Free command request structure
	SAFE_FREE(psSha1UpdateRsp);	// Free command response structure

	DetLogToFile("<- TPM_SHA1Update\n\n");

	return dwRCVal;
}

/*++
TPM_SHA1CompleteExtend

Description:
Transmits the TPM command TPM_SHA1CompleteExtend

Arguments:
[in]    TPM_PCRINDEX    dwPcrNum    Index of the PCR to be modified
[in]	UINT32	    dwHashDataSize	Number of Bytes in pbHashData
[in]	BYTE	    *pbHashData		Bytes to be hashed
[out]   TPM_DIGEST  *psHashValue    The output of the SHA-1 hash.
[out]   TPM_PCRVALUE    *psOutDigest    The PCR value after execution of the command.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_SHA1CompleteExtend(TPM_PCRINDEX dwPcrNum,
			      UINT32 dwHashDataSize, BYTE * pbHashData, TPM_DIGEST * psHashValue, TPM_PCRVALUE * psOutDigest)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwSha1CompleteExtendRquSize = 0;
	UINT32 dwSha1CompleteExtendRspSize = 0;
	TPM_SHA1_COMPLETE_EXTEND_RQU *psSha1CompleteExtendRqu = NULL;
	TPM_SHA1_COMPLETE_EXTEND_RSP *psSha1CompleteExtendRsp = NULL;

	DetLogToFile("\n-> TPM_SHA1CompleteExtend\n");

	do {
		// Initialize the command structures
		// Size of the request structure is dwHashDataSize + size of the structure header (-1)
		dwSha1CompleteExtendRquSize = sizeof(TPM_SHA1_COMPLETE_EXTEND_RQU) + dwHashDataSize - sizeof(BYTE);
		dwSha1CompleteExtendRspSize = sizeof(TPM_SHA1_COMPLETE_EXTEND_RSP);
		SAFE_CALLOC(psSha1CompleteExtendRqu, dwSha1CompleteExtendRquSize, &dwRCVal);
		SAFE_CALLOC(psSha1CompleteExtendRsp, dwSha1CompleteExtendRspSize, &dwRCVal);

		psSha1CompleteExtendRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSha1CompleteExtendRqu->dwParamSize = dwSwitchEndian32(dwSha1CompleteExtendRquSize);
		psSha1CompleteExtendRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SHA1CompleteExtend);
		psSha1CompleteExtendRqu->dwPcrNum = dwSwitchEndian32(dwPcrNum);
		psSha1CompleteExtendRqu->dwHashDataSize = dwSwitchEndian32(dwHashDataSize);
		if (dwHashDataSize)
			memcpy(psSha1CompleteExtendRqu->abHashData, pbHashData, (size_t) dwHashDataSize);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSha1CompleteExtendRqu,
					    dwSha1CompleteExtendRquSize,
					    (BYTE *) psSha1CompleteExtendRsp, &dwSha1CompleteExtendRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSha1CompleteExtendRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;

		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		memcpy(psHashValue, &(psSha1CompleteExtendRsp->sHashValue), sizeof(TPM_DIGEST));
		memcpy(psOutDigest, &(psSha1CompleteExtendRsp->sOutDigest), sizeof(TPM_PCRVALUE));
	} while (FALSE);

	SAFE_FREE(psSha1CompleteExtendRqu);	// Free command request structure
	SAFE_FREE(psSha1CompleteExtendRsp);	// Free command response structure

	DetLogToFile("<- TPM_SHA1CompleteExtend\n\n");

	return dwRCVal;
}

/*++
TPM_GetRandom

Description:
Transmits the TPM command TPM_GetRandom

Arguments:
[in]	UINT32	*pdwBytesRequested      Number of bytes to return
[out]   BYTE    *pbRandomBytes          The returned bytes

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/10
--*/
UINT32 TPM_GetRandom(UINT32 * pdwBytesRequested, BYTE * pbRandomBytes)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwGetRandomRspSize = 0;
	TPM_GET_RANDOM_RQU *psGetRandomRqu = NULL;
	TPM_GET_RANDOM_RSP *psGetRandomRsp = NULL;

	DetLogToFile("\n-> TPM_GetRandom\n");

	do {
		// Initialize the command structures
		// Exclude fixed size abRandomBytes from telegram. Use variable size pdwBytesRequested instead.
		dwGetRandomRspSize = sizeof(TPM_GET_RANDOM_RSP) + *pdwBytesRequested - sizeof(BYTE);
		SAFE_CALLOC(psGetRandomRqu, sizeof(TPM_GET_RANDOM_RQU), &dwRCVal);
		SAFE_CALLOC(psGetRandomRsp, dwGetRandomRspSize, &dwRCVal);

		psGetRandomRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psGetRandomRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_GET_RANDOM_RQU));
		psGetRandomRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_GetRandom);
		psGetRandomRqu->dwBytesRequested = dwSwitchEndian32(*pdwBytesRequested);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psGetRandomRqu,
					    sizeof(TPM_GET_RANDOM_RQU), (BYTE *) psGetRandomRsp, &dwGetRandomRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psGetRandomRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS) {
			UINT32 size = dwSwitchEndian32(psGetRandomRsp->dwRandomBytesSize);
			if (size > *pdwBytesRequested) {
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			}
			dwRCVal = RC_SUCCESS;
			*pdwBytesRequested = size;
			memcpy(pbRandomBytes, psGetRandomRsp->abRandomBytes, size);
		}
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS)
	{
		*pdwBytesRequested = 0;
	}

	SAFE_FREE(psGetRandomRqu);	// Free command request structure
	SAFE_FREE(psGetRandomRsp);	// Free command response structure

	DetLogToFile("<- TPM_GetRandom\n\n");

	return dwRCVal;
}

/*++
TPM_SimpleCommand

Description:
Transmits simple TPM commands (TPM_PhysicalEnable, TPM_PhysicalDisable, TPM_ForceClear,... )

Arguments:
[in]	UINT32	dwOrdinal	Command ordinal

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
            H. Obermeier        2008/03/03
--*/
UINT32 TPM_SimpleCommand(UINT32 dwOrdinal)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwSimpleCmdRspSize = 0;
	TPM_SIMPLE_CMD_RQU *psSimpleCmdRqu = NULL;
	TPM_SIMPLE_CMD_RSP *psSimpleCmdRsp = NULL;

	switch (dwOrdinal) {
	case TPM_ORD_PhysicalEnable:
		DetLogToFile("\n-> TPM_Enable\n");
		break;
	case TPM_ORD_PhysicalDisable:
		DetLogToFile("\n-> TPM_Disable\n");
		break;
	case TPM_ORD_ForceClear:
		DetLogToFile("\n-> TPM_ForceClear\n");
		break;
	case TPM_ORD_SelfTestFull:
		DetLogToFile("\n-> TPM_SelfTestFull\n");
		break;
	case TPM_ORD_SaveState:
		DetLogToFile("\n-> TPM_SaveState\n");
		break;
	case TPM_ORD_ContinueSelfTest:
		DetLogToFile("\n-> TPM_ContinueSelfTest\n");
		break;
	case TSC_ORD_ResetEstablishmentBit:
		DetLogToFile("\n-> TSC_ResetEstablishmentBit\n");
		break;
	default:
		return dwRCVal;
	}

	do {
		// Initialize the command structures
		dwSimpleCmdRspSize = sizeof(TPM_SIMPLE_CMD_RSP);
		SAFE_CALLOC(psSimpleCmdRqu, sizeof(TPM_SIMPLE_CMD_RQU), &dwRCVal);
		SAFE_CALLOC(psSimpleCmdRsp, sizeof(TPM_SIMPLE_CMD_RSP), &dwRCVal);

		psSimpleCmdRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSimpleCmdRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SIMPLE_CMD_RQU));
		psSimpleCmdRqu->dwOrdinal = dwSwitchEndian32(dwOrdinal);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSimpleCmdRqu,
					    sizeof(TPM_SIMPLE_CMD_RQU), (BYTE *) psSimpleCmdRsp, &dwSimpleCmdRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSimpleCmdRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psSimpleCmdRqu);	// Free command request structure
	SAFE_FREE(psSimpleCmdRsp);	// Free command response structure

	switch (dwOrdinal) {
	case TPM_ORD_PhysicalEnable:
		DetLogToFile("<- TPM_Enable\n\n");
		break;
	case TPM_ORD_PhysicalDisable:
		DetLogToFile("<- TPM_Disable\n\n");
		break;
	case TPM_ORD_ForceClear:
		DetLogToFile("<- TPM_ForceClear\n\n");
		break;
	case TPM_ORD_SelfTestFull:
		DetLogToFile("<- TPM_SelfTestFull\n\n");
		break;
	case TPM_ORD_SaveState:
		DetLogToFile("<- TPM_SaveState\n\n");
		break;
	case TPM_ORD_ContinueSelfTest:
		DetLogToFile("<- TPM_ContinueSelfTest\n\n");
		break;
	case TSC_ORD_ResetEstablishmentBit:
		DetLogToFile("<- TSC_ResetEstablishmentBit\n\n");
	}

	return dwRCVal;
}

/*++
TPM_Startup

Description:
Transmits the TPM command TPM_Startup

Arguments:
[in]	UINT16	wStartupType	Startup type

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_Startup(UINT16 wStartupType)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwStartRspSize = 0;
	TPM_STARTUP_RQU *psStartRqu = NULL;
	TPM_STARTUP_RSP *psStartRsp = NULL;

	DetLogToFile("\n-> TPM_Startup: ");
	switch (wStartupType) {
	case TPM_ST_DEACTIVATED:
		DetLogToFile("\"Deactivated\"\n");
		break;
	case TPM_ST_STATE:
		DetLogToFile("\"Save\"\n");
		break;
	case TPM_ST_CLEAR:
		DetLogToFile("\"Clear\"\n");
		break;
	default:
		return dwRCVal;
	}

	do {
		// Initialize the command structures
		dwStartRspSize = sizeof(TPM_STARTUP_RSP);
		SAFE_CALLOC(psStartRqu, sizeof(TPM_STARTUP_RQU), &dwRCVal);
		SAFE_CALLOC(psStartRsp, sizeof(TPM_STARTUP_RSP), &dwRCVal);

		psStartRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psStartRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_STARTUP_RQU));
		psStartRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_Startup);
		psStartRqu->wStartupType = wSwitchEndian16(wStartupType);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psStartRqu,
					    sizeof(TPM_STARTUP_RQU), (BYTE *) psStartRsp, &dwStartRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psStartRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS || dwRCVal == TPM_E_IFX_INVALID_POSTINIT)	// Ignore Invalid Postinit Error
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psStartRqu);	// Free command request structure
	SAFE_FREE(psStartRsp);	// Free command response structure

	DetLogToFile("<- TPM_Startup: ");
	switch (wStartupType) {
	case TPM_ST_DEACTIVATED:
		DetLogToFile("\"Deactivated\"\n\n");
		break;
	case TPM_ST_STATE:
		DetLogToFile("\"Save\"\n\n");
		break;
	case TPM_ST_CLEAR:
		DetLogToFile("\"Clear\"\n\n");
	}

	return dwRCVal;
}

/*++
TPM_SaveState

Description:
Transmits the TPM command TPM_SaveState

Arguments:
none

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Georg Rankl		2008/07/22
--*/
UINT32 TPM_SaveState(void)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwSaveStateRspSize = 0;
	TPM_SAVESTATE_RQU *psSaveStateRqu = NULL;
	TPM_SAVESTATE_RSP *psSaveStateRsp = NULL;

	DetLogToFile("\n-> TPM_SaveState\n");

	do {
		// Initialize the command structures
		dwSaveStateRspSize = sizeof(TPM_SAVESTATE_RSP);
		SAFE_CALLOC(psSaveStateRqu, sizeof(TPM_SAVESTATE_RQU), &dwRCVal);
		SAFE_CALLOC(psSaveStateRsp, sizeof(TPM_SAVESTATE_RSP), &dwRCVal);

		psSaveStateRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSaveStateRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SAVESTATE_RQU));
		psSaveStateRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SaveState);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSaveStateRqu,
					    sizeof(TPM_SAVESTATE_RQU), (BYTE *) psSaveStateRsp, &dwSaveStateRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSaveStateRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psSaveStateRqu);	// Free command request structure
	SAFE_FREE(psSaveStateRsp);	// Free command response structure

	DetLogToFile("<- TPM_SaveState\n");

	return dwRCVal;
}

/*++
TPM_OwnerSetDisable

Description:
Transmits the TPM command TPM_OwnerSetDisable

Arguments:
[in]		BYTE				bDisableState		Value for disable state - enable if TRUE
[in]		TPM_AUTHHANDLE      dwAuthHandle		The authorization session handle used for owner authentication.
[in/out]	TPM_NONCE           psNonceOdd          Nonce generated by system associated with authHandle
[in]		BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]		TPM_AUTHDATA		psOwnerAuth         The authorization session digest for inputs and owner authentication.
                                                    HMAC key: ownerAuth.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/
UINT32 TPM_OwnerSetDisable(BYTE bDisableState, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			   BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the OIAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwOwnerSetDisableRquSize = 0;
	UINT32 dwOwnerSetDisableRspSize = 0;
	TPM_OWNER_SET_DISABLE_RQU *psOwnerSetDisableRqu = NULL;
	TPM_OWNER_SET_DISABLE_RSP *psOwnerSetDisableRsp = NULL;

	DetLogToFile("\n-> TPM_OwnerSetDisable\n");

	do {
		// Initialize temporary data buffers for HMAC calculation according to the OIAP
		wInParamDigestSize = sizeof(TPM_COMMAND_CODE) + sizeof(BYTE);
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Initialize the command structures
		dwOwnerSetDisableRquSize = sizeof(TPM_OWNER_SET_DISABLE_RQU);
		dwOwnerSetDisableRspSize = sizeof(TPM_OWNER_SET_DISABLE_RSP);
		SAFE_CALLOC(psOwnerSetDisableRqu, sizeof(TPM_OWNER_SET_DISABLE_RQU), &dwRCVal);
		SAFE_CALLOC(psOwnerSetDisableRsp, sizeof(TPM_OWNER_SET_DISABLE_RSP), &dwRCVal);

		psOwnerSetDisableRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
		psOwnerSetDisableRqu->dwParamSize = dwSwitchEndian32(dwOwnerSetDisableRquSize);
		psOwnerSetDisableRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_OwnerSetDisable);
		psOwnerSetDisableRqu->bDisableState = bDisableState;
		psOwnerSetDisableRqu->dwAuthHandle = dwSwitchEndian32(dwAuthHandle);
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psOwnerSetDisableRqu->sNonceOdd.nonce[i] = (BYTE) i;
		psOwnerSetDisableRqu->bContinueAuthSession = bContinueAuthSession;
		memcpy(&(psOwnerSetDisableRqu->sOwnerAuth), psOwnerAuth, sizeof(TPM_AUTHDATA));

		// Fill pbInParamDigest buffer according to OIAP
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerSetDisable >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerSetDisable >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerSetDisable >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerSetDisable);
		pbInParamDigest[i++] = (BYTE) (bDisableState);

		// Create SHA-1 hash from the input parameters according to OIAP
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Fill HMAC input buffer according to OIAP
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(psOwnerSetDisableRqu->sNonceOdd), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = psOwnerSetDisableRqu->bContinueAuthSession;

		// Create HMAC for authenticated TPM command according to OIAP
		dwRCVal = HMAC_Func(pbHmacInput,
				    wHmacInputSize, (BYTE *) psOwnerAuth, psOwnerSetDisableRqu->sOwnerAuth.authdata);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psOwnerSetDisableRqu,
					    dwOwnerSetDisableRquSize,
					    (BYTE *) psOwnerSetDisableRsp, &dwOwnerSetDisableRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psOwnerSetDisableRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;
		// Copy result from the command response structure to the output argument
		memcpy(psNonceEven, &psOwnerSetDisableRsp->sNonceEven, sizeof(TPM_NONCE));
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psOwnerSetDisableRqu);	// Free command request structure
	SAFE_FREE(psOwnerSetDisableRsp);	// Free command response structure

	DetLogToFile("<- TPM_OwnerSetDisable\n\n");

	return dwRCVal;
}

/*++
TPM_SetTempDeactivated

Description:
Transmits the TPM command TPM_SetTempDeactivated

Arguments:
[in]		TPM_AUTHHANDLE      dwAuthHandle		The authorization session handle used for owner authentication.
[in/out]	TPM_NONCE           *psNonceEven        Nonce generated by system associated with authHandle
[in]		BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]		TPM_AUTHDATA		*psOperatorAuth     The authorization session digest for inputs and owner authentication.
                                                    HMAC key: ownerAuth.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/
UINT32 TPM_SetTempDeactivated(TPM_AUTHHANDLE dwAuthHandle,
			      TPM_NONCE * psNonceEven, BYTE bContinueAuthSession, TPM_AUTHDATA * psOperatorAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the OIAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	// Temporary data buffers
	UINT32 dwSetTempDeactivatedRquSize = 0;
	UINT32 dwSetTempDeactivatedRspSize = 0;
	TPM_SET_TEMP_DEACTIVATED_RQU *psSetTempDeactivatedRqu = NULL;
	TPM_SET_TEMP_DEACTIVATED_RSP *psSetTempDeactivatedRsp = NULL;

	DetLogToFile("\n-> TPM_SetTempDeactivated\n");

	do {
		// with authorization
		if (dwAuthHandle) {
			// Initialize temporary data buffers for HMAC calculation according to the authorization
			wInParamDigestSize = sizeof(TPM_COMMAND_CODE);
			wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
			SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
			SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

			dwSetTempDeactivatedRquSize = sizeof(TPM_SET_TEMP_DEACTIVATED_RQU);
			dwSetTempDeactivatedRspSize = sizeof(TPM_SET_TEMP_DEACTIVATED_RSP);
			SAFE_CALLOC(psSetTempDeactivatedRqu, dwSetTempDeactivatedRquSize, &dwRCVal);
			SAFE_CALLOC(psSetTempDeactivatedRsp, dwSetTempDeactivatedRspSize, &dwRCVal);

			psSetTempDeactivatedRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
			psSetTempDeactivatedRqu->dwParamSize = dwSwitchEndian32(dwSetTempDeactivatedRquSize);
			psSetTempDeactivatedRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SetTempDeactivated);
			psSetTempDeactivatedRqu->dwAuthHandle = dwSwitchEndian32(dwAuthHandle);
			for (i = 0; i < sizeof(TPM_NONCE); i++)
				psSetTempDeactivatedRqu->sNonceOdd.nonce[i] = (BYTE) i;
			psSetTempDeactivatedRqu->bContinueAuthSession = bContinueAuthSession;

			// Fill pbInParamDigest buffer according to authorization
			i = 0;
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetTempDeactivated >> 24);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetTempDeactivated >> 16);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetTempDeactivated >> 8);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetTempDeactivated);

			// Create SHA-1 hash from the input parameters according to authorization
			dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
			if (dwRCVal != RC_SUCCESS)
				break;

			// Fill HMAC input buffer according to authorization
			i = HASH_LEN;
			memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			memcpy(&(pbHmacInput[i]), &(psSetTempDeactivatedRqu->sNonceOdd), sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			pbHmacInput[i++] = psSetTempDeactivatedRqu->bContinueAuthSession;

			// Create HMAC for authenticated TPM command according to authorization
			dwRCVal = HMAC_Func(pbHmacInput,
					    wHmacInputSize,
					    (BYTE *) psOperatorAuth, psSetTempDeactivatedRqu->sOperatorAuth.authdata);
			if (dwRCVal != RC_SUCCESS)
				break;

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psSetTempDeactivatedRqu,
						    dwSetTempDeactivatedRquSize,
						    (BYTE *) psSetTempDeactivatedRsp, &dwSetTempDeactivatedRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psSetTempDeactivatedRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;
			dwRCVal = RC_SUCCESS;
			memcpy(psNonceEven, &psSetTempDeactivatedRsp->sNonceEven, sizeof(TPM_NONCE));
		} else		// !dwAuthHandle: without authorization
		{
			dwSetTempDeactivatedRquSize = sizeof(TPM_TAG) + sizeof(UINT32) + sizeof(TPM_COMMAND_CODE);
			dwSetTempDeactivatedRspSize = sizeof(TPM_SET_TEMP_DEACTIVATED_RSP);
			SAFE_CALLOC(psSetTempDeactivatedRqu, dwSetTempDeactivatedRquSize, &dwRCVal);
			SAFE_CALLOC(psSetTempDeactivatedRsp, dwSetTempDeactivatedRspSize, &dwRCVal);

			psSetTempDeactivatedRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
			psSetTempDeactivatedRqu->dwParamSize = dwSwitchEndian32(dwSetTempDeactivatedRquSize);
			psSetTempDeactivatedRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SetTempDeactivated);

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psSetTempDeactivatedRqu,
						    dwSetTempDeactivatedRquSize,
						    (BYTE *) psSetTempDeactivatedRsp, &dwSetTempDeactivatedRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psSetTempDeactivatedRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;
			dwRCVal = RC_SUCCESS;
		}
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);	// Free command request structure
	SAFE_FREE(pbHmacInput);	// Free command response structure
	SAFE_FREE(psSetTempDeactivatedRqu);	// Free command request structure
	SAFE_FREE(psSetTempDeactivatedRsp);	// Free command response structure

	DetLogToFile("<- TPM_SetTempDeactivated\n\n");

	return dwRCVal;
}

/*++
TPM_SetOperatorAuth

Description:
Transmits the TPM command TPM_SetOperatorAuth

Arguments:
[in]		TPM_SECRET		psOwnerAuth         The operator AuthData

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/
UINT32 TPM_SetOperatorAuth(TPM_AUTHDATA * psOperatorAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	// Temporary data buffers
	UINT32 dwSetOperatorAuthRspSize = sizeof(TPM_SIMPLE_CMD_RSP);
	TPM_SET_OPERATOR_AUTH_RQU *psSetOperatorAuthRqu = NULL;
	TPM_SIMPLE_CMD_RSP *psSetOperatorAuthRsp = NULL;

	DetLogToFile("\n-> TPM_SetOperatorAuth\n");

	do {
		SAFE_CALLOC(psSetOperatorAuthRqu, sizeof(TPM_SET_OPERATOR_AUTH_RQU), &dwRCVal);
		SAFE_CALLOC(psSetOperatorAuthRsp, sizeof(TPM_SIMPLE_CMD_RSP), &dwRCVal);

		psSetOperatorAuthRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psSetOperatorAuthRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SET_OPERATOR_AUTH_RQU));
		psSetOperatorAuthRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SetOperatorAuth);
		memcpy(&(psSetOperatorAuthRqu->sOperatorAuth), psOperatorAuth, sizeof(TPM_AUTHDATA));

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSetOperatorAuthRqu,
					    sizeof(TPM_SET_OPERATOR_AUTH_RQU),
					    (BYTE *) psSetOperatorAuthRsp, &dwSetOperatorAuthRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psSetOperatorAuthRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;

	} while (FALSE);

	SAFE_FREE(psSetOperatorAuthRqu);	// Free command request structure
	SAFE_FREE(psSetOperatorAuthRsp);	// Free command response structure

	DetLogToFile("<- TPM_SetOperatorAuth\n\n");

	return dwRCVal;
}

/*++
TPM_TakeOwnership

Description:
Transmits the TPM command TPM_TakeOwnership

Arguments:
[in]		UINT32				dwEncOwnerAuthSize  The size of the encOwnerAuth field
[in]		BYTE				*pbEncOwnerAuth     The owner AuthData encrypted with PUBEK
[in]		UINT32				dwEncSrkAuthSize    The size of the encSrkAuth field
[in]		BYTE				*pbEncSrkAuth       The SRK AuthData encrypted with PUBEK
[in]		TPM_KEY				*psSrkParams        Structure containing all parameters of new SRK.
[in]		TPM_AUTHHANDLE		dwAuthHandle        The authorization session handle used for this command
[in/out]	TPM_NONCE			*psNonceEven        Even nonce previously generated by TPM to cover inputs
[in]		BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]        TPM_AUTHDATA		*psOwnerAuth        Authorization session digest for input params.
[in/out]    UINT32				*pdwKeySize         Size of structure containing all parameters of new SRK.
[out]       BYTE				*psSrkPub           Structure containing all parameters of new SRK.

Structure containing all parameters of new SRK

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TPM_TakeOwnership(UINT32 dwEncOwnerAuthSize,
			 BYTE * pbEncOwnerAuth,
			 UINT32 dwEncSrkAuthSize,
			 BYTE * pbEncSrkAuth,
			 TPM_KEY * psSrkParams,
			 TPM_AUTHHANDLE dwAuthHandle,
			 TPM_NONCE * psNonceEven,
			 BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth, UINT32 * pdwKeySize, BYTE * psSrkPub)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the OIAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwTakeOwnerRspSize = 0;
	TPM_TAKE_OWNER_RQU *psTakeOwnerRqu = NULL;
	TPM_TAKE_OWNER_RSP *psTakeOwnerRsp = NULL;
	char *pbRsp = NULL;

	DetLogToFile("\n-> TPM_TakeOwnership\n");

	do {
		// Initialize temporary data buffers for HMAC calculation according to the authorization
		// The SHA-1 input uses (14 + 2*KEY_LEN) Bytes + the size of the SRK parameter structure
		wInParamDigestSize = sizeof(TPM_COMMAND_CODE) +
		    sizeof(TPM_PROTOCOL_ID) + 2 * sizeof(UINT32) + 2 * KEY_LEN + sizeof(TPM_KEY_TKOWN_RQU);
		// The HMAC input uses (HASH_LEN + 2*sizeof(TPM_NONCE) + 1) Bytes
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Initialize the command structures
		dwTakeOwnerRspSize = sizeof(TPM_TAKE_OWNER_RSP);
		SAFE_CALLOC(psTakeOwnerRqu, sizeof(TPM_TAKE_OWNER_RQU), &dwRCVal);
		SAFE_CALLOC(psTakeOwnerRsp, sizeof(TPM_TAKE_OWNER_RSP), &dwRCVal);

		psTakeOwnerRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
		psTakeOwnerRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_TAKE_OWNER_RQU));
		psTakeOwnerRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_TakeOwnership);
		psTakeOwnerRqu->wProtocolID = wSwitchEndian16(TPM_PID_OWNER);
		psTakeOwnerRqu->dwEncOwnerAuthSize = dwSwitchEndian32(KEY_LEN);
		memcpy(psTakeOwnerRqu->abEncOwnerAuth, pbEncOwnerAuth, KEY_LEN);
		psTakeOwnerRqu->dwEncSrkAuthSize = dwSwitchEndian32(KEY_LEN);
		memcpy(psTakeOwnerRqu->abEncSrkAuth, pbEncSrkAuth, KEY_LEN);
		memcpy(&(psTakeOwnerRqu->sSrkParams), psSrkParams, sizeof(TPM_KEY_TKOWN_RQU));
		psTakeOwnerRqu->dwAuthHandle = dwSwitchEndian32(dwAuthHandle);
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psTakeOwnerRqu->sNonceOdd.nonce[i] = (BYTE) i;
		psTakeOwnerRqu->bContinueAuthSession = 0;

		// Fill pbInParamDigest buffer according to authorization
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_TakeOwnership >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_TakeOwnership >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_TakeOwnership >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_TakeOwnership);
		pbInParamDigest[i++] = (BYTE) (TPM_PID_OWNER >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_PID_OWNER);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN >> 24);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN >> 16);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN >> 8);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN & 0xFF);
		memcpy(&(pbInParamDigest[i]), pbEncOwnerAuth, KEY_LEN);
		i += KEY_LEN;
		pbInParamDigest[i++] = (BYTE) (KEY_LEN >> 24);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN >> 16);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN >> 8);
		pbInParamDigest[i++] = (BYTE) (KEY_LEN & 0xFF);
		memcpy(&(pbInParamDigest[i]), pbEncSrkAuth, KEY_LEN);
		i += KEY_LEN;
		memcpy(&(pbInParamDigest[i]), psSrkParams, sizeof(TPM_KEY_TKOWN_RQU));

		// Create SHA-1 hash from the input parameters according to authorization
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Fill HMAC input buffer according to authorization
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(psTakeOwnerRqu->sNonceOdd), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i] = psTakeOwnerRqu->bContinueAuthSession;

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psOwnerAuth, psTakeOwnerRqu->sOwnerAuth.authdata);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psTakeOwnerRqu,
					    sizeof(TPM_TAKE_OWNER_RQU), (BYTE *) psTakeOwnerRsp, &dwTakeOwnerRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psTakeOwnerRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwKeySize = 0;
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result length to the output argument
		if (*pdwKeySize < dwSwitchEndian32(psTakeOwnerRsp->sSrkPub.pubKey.keyLength)) {
			dwRCVal = RC_E_BUFFER2SMALL; // No data if return buffer is too small
			break;
		}
		*pdwKeySize = dwSwitchEndian32(psTakeOwnerRsp->sSrkPub.pubKey.keyLength);

		// Copy result from the command response structure to the output argument
		memcpy(psSrkPub, &(psTakeOwnerRsp->sSrkPub.pubKey.key), (size_t) (*pdwKeySize));
		pbRsp = (char *)&(psTakeOwnerRsp->sSrkPub.pubKey.key);	// TPM_KEY sSrkPub;
		pbRsp += *pdwKeySize;
		pbRsp += (long)*(pbRsp);	// add value of encSize;
		pbRsp += sizeof(UINT32);	// UINT32   encSize;
		// Here we are at: TPM_NONCE                            sNonceEven;
		memcpy(psNonceEven, pbRsp, sizeof(TPM_NONCE));
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwKeySize = 0;
	}

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psTakeOwnerRqu);	// Free command request structure
	SAFE_FREE(psTakeOwnerRsp);	// Free command response structure

	DetLogToFile("<- TPM_TakeOwnership\n\n");

	return dwRCVal;
}

/*++
TPM_OwnerClear

Description:
Transmits the TPM command TPM_OwnerClear

Arguments:
[in]		TPM_AUTHHANDLE      dwAuthHandle		The authorization session handle used for owner authentication.
[in/out]	TPM_NONCE           *psNonceEven        Even nonce previously generated by TPM to cover inputs
[in]		BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]		TPM_AUTHDATA		*psOwnerAuth        The authorization session digest for inputs and owner authentication.
                                                    HMAC key: ownerAuth.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/
UINT32 TPM_OwnerClear(TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		      BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the authorization
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwOwnerClearRquSize = 0;
	UINT32 dwOwnerClearRspSize = 0;
	TPM_OWNER_CLEAR_RQU *psOwnerClearRqu = NULL;
	TPM_OWNER_CLEAR_RSP *psOwnerClearRsp = NULL;

	DetLogToFile("\n-> TPM_OwnerClear\n");

	do {
		// Initialize temporary data buffers for HMAC calculation according to the authorization
		wInParamDigestSize = sizeof(TPM_COMMAND_CODE);
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		dwOwnerClearRquSize = sizeof(TPM_OWNER_CLEAR_RQU);
		dwOwnerClearRspSize = sizeof(TPM_OWNER_CLEAR_RSP);
		SAFE_CALLOC(psOwnerClearRqu, dwOwnerClearRquSize, &dwRCVal);
		SAFE_CALLOC(psOwnerClearRsp, dwOwnerClearRspSize, &dwRCVal);

		psOwnerClearRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
		psOwnerClearRqu->dwParamSize = dwSwitchEndian32(dwOwnerClearRquSize);
		psOwnerClearRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_OwnerClear);
		psOwnerClearRqu->dwAuthHandle = dwSwitchEndian32(dwAuthHandle);
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			psOwnerClearRqu->sNonceOdd.nonce[i] = (BYTE) i;
		psOwnerClearRqu->bContinueAuthSession = bContinueAuthSession;

		// Fill pbInParamDigest buffer according to authorization
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerClear >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerClear >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerClear >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_OwnerClear);

		// Create SHA-1 hash from the input parameters according to authorization
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Fill HMAC input buffer according to authorization
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(psOwnerClearRqu->sNonceOdd), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = psOwnerClearRqu->bContinueAuthSession;

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psOwnerAuth, psOwnerClearRqu->sOwnerAuth.authdata);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psOwnerClearRqu,
					    dwOwnerClearRquSize, (BYTE *) psOwnerClearRsp, &dwOwnerClearRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psOwnerClearRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;
		// Copy result from the command response structure to the output argument
		memcpy(psNonceEven, &(psOwnerClearRsp->sNonceEven), sizeof(TPM_NONCE));
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psOwnerClearRqu);	// Free command request structure
	SAFE_FREE(psOwnerClearRsp);	// Free command response structure

	DetLogToFile("<- TPM_OwnerClear\n\n");

	return dwRCVal;
}

/*++
TSC_PhysicalPresence

Description:
Transmits the TPM command TSC_PhysicalPresence

Arguments:
[in]	UINT16	wCmdFunc	Subordinate function of the command

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 TSC_PhysicalPresence(UINT16 wPhysicalPresence)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	TSC_PHYSICAL_PRESENCE_RQU *psPhysPresRqu = NULL;
	TSC_PHYSICAL_PRESENCE_RSP *psPhysPresRsp = NULL;
	UINT32 dwPhysPresRspSize = 0;

	DetLogToFile("\n-> TSC_PhysicalPresence: ");
	switch (wPhysicalPresence) {
	case TPM_PHYSICAL_PRESENCE_LOCK:
		DetLogToFile("\"Lock\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_PRESENT:
		DetLogToFile("\"Present\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_NOTPRESENT:
		DetLogToFile("\"Not Present\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_CMD_ENABLE:
		DetLogToFile("\"Command Enable\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_HW_ENABLE:
		DetLogToFile("\"Hardware Enable\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_LIFETIME_LOCK:
		DetLogToFile("\"Lifetime Lock\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_CMD_DISABLE:
		DetLogToFile("\"Command Disable\"\n");
		break;
	case TPM_PHYSICAL_PRESENCE_HW_DISABLE:
		DetLogToFile("\"Hardware Disable\"\n");
		break;
	default:
		return dwRCVal;
	}

	do {
		// Initialize the command structures
		SAFE_CALLOC(psPhysPresRqu, sizeof(TSC_PHYSICAL_PRESENCE_RQU), &dwRCVal);
		SAFE_CALLOC(psPhysPresRsp, sizeof(TSC_PHYSICAL_PRESENCE_RSP), &dwRCVal);
		dwPhysPresRspSize = sizeof(TSC_PHYSICAL_PRESENCE_RSP);

		psPhysPresRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psPhysPresRqu->dwParamSize = dwSwitchEndian32(sizeof(TSC_PHYSICAL_PRESENCE_RQU));
		psPhysPresRqu->dwOrdinal = dwSwitchEndian32(TSC_ORD_PhysicalPresence);
		psPhysPresRqu->wPhysicalPresence = wSwitchEndian16(wPhysicalPresence);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psPhysPresRqu,
					    sizeof(TSC_PHYSICAL_PRESENCE_RQU), (BYTE *) psPhysPresRsp, &dwPhysPresRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psPhysPresRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal == TPM_SUCCESS)
			dwRCVal = RC_SUCCESS;
	} while (FALSE);

	SAFE_FREE(psPhysPresRqu);	// Free command request structure
	SAFE_FREE(psPhysPresRsp);	// Free command response structure

	DetLogToFile("<- TSC_PhysicalPresence: ");
	switch (wPhysicalPresence) {
	case TPM_PHYSICAL_PRESENCE_LOCK:
		DetLogToFile("\"Lock\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_PRESENT:
		DetLogToFile("\"Present\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_NOTPRESENT:
		DetLogToFile("\"Not Present\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_CMD_ENABLE:
		DetLogToFile("\"Command Enable\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_HW_ENABLE:
		DetLogToFile("\"Hardware Enable\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_LIFETIME_LOCK:
		DetLogToFile("\"Lifetime Lock\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_CMD_DISABLE:
		DetLogToFile("\"Command Disable\"\n\n");
		break;
	case TPM_PHYSICAL_PRESENCE_HW_DISABLE:
		DetLogToFile("\"Hardware Disable\"\n\n");
	}

	return dwRCVal;
}

/*++
TPM_SetCapability

Description:
Transmits the TPM command TPM_SetCapability

Arguments:
[in]		TPM_CAPABILITY_AREA	dwCapArea           Partition of capabilities to be set
[in]		UINT32				dwSubCapSize        Size of subCap parameter
[in]		BYTE				*abSubCap           Further definition of information
[in]		UINT32              dwSetValueSize      The size of the value to set
[in]		BYTE                *abSetValue         The value to set
[in]		TPM_AUTHHANDLE		dwAuthHandle        The authorization session handle used for owner authentication.
[in/out]	TPM_NONCE			*psNonceEven        Even nonce previously generated by TPM to cover inputs
[in]		BYTE				bContinueAuthSession    The continue use flag for the authorization session handle
[in]		TPM_AUTHDATA		*psOwnerAuth        Authorization. HMAC key: owner.usageAuth.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/
UINT32 TPM_SetCapability(TPM_CAPABILITY_AREA dwCapArea, UINT32 dwSubCapSize, BYTE * abSubCap, UINT32 dwSetValueSize, BYTE * abSetValue, TPM_AUTHHANDLE dwAuthHandle,	// If NULL command executes un-authorized
			 TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wNonceOdd = 0;
	UINT16 wOwnerAuth = 0;

	// Temporary data buffers for HMAC calculation according to the OIAP
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	// Temporary data buffers
	UINT32 dwSetCapabilityRquSize = 0;
	UINT32 dwSetCapabilityRspSize = 0;
	TPM_SET_CAPABILITY_RQU *psSetCapabilityRqu = NULL;
	TPM_SET_CAPABILITY_RSP *psSetCapabilityRsp = NULL;

	DetLogToFile("\n-> TPM_SetCapability\n");

	do {
		// with authorization
		if (dwAuthHandle) {
			// Initialize temporary data buffers for HMAC calculation according to the OIAP
			wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) +
						       sizeof(TPM_CAPABILITY_AREA) +
						       sizeof(UINT32) + dwSubCapSize + sizeof(UINT32) + dwSetValueSize);
			// The HMAC input uses (HASH_LEN + 2 * sizeof(TPM_NONCE) + 1) Bytes
			wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
			SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
			SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);
			// Initialize the command structures
			// Structure definition minus two times byte array but plus real dw...Size fields from input
			dwSetCapabilityRquSize =
			    sizeof(TPM_SET_CAPABILITY_RQU) + dwSubCapSize + dwSetValueSize - 2 * sizeof(BYTE);
			dwSetCapabilityRspSize = sizeof(TPM_SET_CAPABILITY_RSP);
			SAFE_CALLOC(psSetCapabilityRqu, dwSetCapabilityRquSize, &dwRCVal);
			SAFE_CALLOC(psSetCapabilityRsp, dwSetCapabilityRspSize, &dwRCVal);

			psSetCapabilityRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
			psSetCapabilityRqu->dwParamSize = dwSwitchEndian32(dwSetCapabilityRquSize);
			psSetCapabilityRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SetCapability);
			psSetCapabilityRqu->dwCapArea = dwSwitchEndian32(dwCapArea);
			psSetCapabilityRqu->dwSubCapSize = dwSwitchEndian32(dwSubCapSize);
			memcpy(psSetCapabilityRqu->abSubCap, abSubCap, dwSubCapSize);
			i = (UINT16)dwSubCapSize;
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize >> 24);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize >> 16);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize >> 8);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize);
			memcpy(&(psSetCapabilityRqu->abSubCap[i]), abSetValue, dwSetValueSize);
			i += (UINT16)dwSetValueSize;
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwAuthHandle >> 24);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwAuthHandle >> 16);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwAuthHandle >> 8);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwAuthHandle);
			wNonceOdd = i;
			for (i = 0; i < sizeof(TPM_NONCE); i++)
				psSetCapabilityRqu->abSubCap[wNonceOdd + i] = (BYTE) i;
			i = wNonceOdd + i;
			psSetCapabilityRqu->abSubCap[i++] = bContinueAuthSession;
			wOwnerAuth = i;

			// Fill pbInParamDigest buffer according to authorization
			i = 0;
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetCapability >> 24);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetCapability >> 16);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetCapability >> 8);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_SetCapability);
			pbInParamDigest[i++] = (BYTE) (dwCapArea >> 24);
			pbInParamDigest[i++] = (BYTE) (dwCapArea >> 16);
			pbInParamDigest[i++] = (BYTE) (dwCapArea >> 8);
			pbInParamDigest[i++] = (BYTE) (dwCapArea);
			pbInParamDigest[i++] = (BYTE) (dwSubCapSize >> 24);
			pbInParamDigest[i++] = (BYTE) (dwSubCapSize >> 16);
			pbInParamDigest[i++] = (BYTE) (dwSubCapSize >> 8);
			pbInParamDigest[i++] = (BYTE) (dwSubCapSize);
			memcpy(&(pbInParamDigest[i]), abSubCap, dwSubCapSize);
			i += (UINT16)dwSubCapSize;
			pbInParamDigest[i++] = (BYTE) (dwSetValueSize >> 24);
			pbInParamDigest[i++] = (BYTE) (dwSetValueSize >> 16);
			pbInParamDigest[i++] = (BYTE) (dwSetValueSize >> 8);
			pbInParamDigest[i++] = (BYTE) (dwSetValueSize);
			memcpy(&(pbInParamDigest[i]), abSetValue, dwSetValueSize);
			//i += dwSetValueSize; //dead increment

			// Create SHA-1 hash from the input parameters according to authorization
			dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
			if (dwRCVal != RC_SUCCESS)
				break;

			// Fill HMAC input buffer according to authorization
			i = HASH_LEN;
			memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			memcpy(&(pbHmacInput[i]), &(psSetCapabilityRqu->abSubCap[wNonceOdd]), sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			pbHmacInput[i++] = bContinueAuthSession;

			// Create HMAC for authenticated TPM command according to authorization
			dwRCVal = HMAC_Func(pbHmacInput,
					    wHmacInputSize,
					    (BYTE *) psOwnerAuth, &(psSetCapabilityRqu->abSubCap[wOwnerAuth]));
			if (dwRCVal != RC_SUCCESS)
				break;

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psSetCapabilityRqu,
						    dwSetCapabilityRquSize,
						    (BYTE *) psSetCapabilityRsp, &dwSetCapabilityRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psSetCapabilityRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;

			dwRCVal = RC_SUCCESS;
			// Copy result length to the output argument
			memcpy(psNonceEven, &psSetCapabilityRsp->sNonceEven, sizeof(TPM_NONCE));
		} else		// !dwAuthHandle: without authorization
		{
			// Initialize the command structures
			dwSetCapabilityRquSize = sizeof(TPM_TAG) +
			    sizeof(UINT32) +
			    sizeof(TPM_COMMAND_CODE) +
			    sizeof(TPM_CAPABILITY_AREA) + sizeof(UINT32) + dwSubCapSize + sizeof(UINT32) + dwSetValueSize;
			dwSetCapabilityRspSize = sizeof(TPM_SET_CAPABILITY_RSP);
			SAFE_CALLOC(psSetCapabilityRqu, dwSetCapabilityRquSize, &dwRCVal);
			SAFE_CALLOC(psSetCapabilityRsp, dwSetCapabilityRspSize, &dwRCVal);

			psSetCapabilityRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
			psSetCapabilityRqu->dwParamSize = dwSwitchEndian32(dwSetCapabilityRquSize);
			psSetCapabilityRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_SetCapability);
			psSetCapabilityRqu->dwCapArea = dwSwitchEndian32(dwCapArea);
			psSetCapabilityRqu->dwSubCapSize = dwSwitchEndian32(dwSubCapSize);
			memcpy(psSetCapabilityRqu->abSubCap, abSubCap, dwSubCapSize);
			i = (UINT16)dwSubCapSize;
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize >> 24);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize >> 16);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize >> 8);
			psSetCapabilityRqu->abSubCap[i++] = (BYTE) (dwSetValueSize);
			memcpy(&(psSetCapabilityRqu->abSubCap[i]), abSetValue, dwSetValueSize);
			//i += dwSetValueSize; //dead assignment

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psSetCapabilityRqu,
						    dwSetCapabilityRquSize,
						    (BYTE *) psSetCapabilityRsp, &dwSetCapabilityRspSize);
			if (dwRCVal != RC_SUCCESS)
				break;

			dwRCVal = dwSwitchEndian32(psSetCapabilityRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS)
				break;

			dwRCVal = RC_SUCCESS;
		}
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psSetCapabilityRqu);	// Free command request structure
	SAFE_FREE(psSetCapabilityRsp);	// Free command response structure

	DetLogToFile("<- TPM_SetCapability\n\n");

	return dwRCVal;
}

/*++
TPM_Seal

Description:
Transmits the TPM command TPM_Seal

Arguments:
[in]		TPM_KEY_HANDLE      dwKeyHandle         Handle of a loaded key that can perform seal operations.
[in]        TPM_ENCAUTH         *psEncAuth          The encrypted AuthData for the sealed data.
[in]		UINT32              dwPcrInfoSize       The size of the pcrInfo parameter. If 0 there are no PCR registers in use
[in]        TPM_PCR_INFO        *psPcrInfo          The PCR selection information. The caller MAY use TPM_PCR_INFO_LONG.
[in]        UINT32              dwInDataSize        The size of the inData parameter
[in]        BYTE                *pbInData           The data to be sealed to the platform and any specified PCRs
[in]		TPM_AUTHHANDLE		dwAuthHandle        The authorization session handle used for keyHandle authorization.
                                                    Must be an OSAP session for this command.
[in/out]	TPM_NONCE			*psNonceEven		Nonce generated by TPM for the Auth. Session
[in]		BYTE				bContinueAuthSession    Ignored
[in]		TPM_AUTHDATA		*pbPubAuth          The authorization session digest for inputs and keyHandle. HMAC key:
                                                    key.usageAuth.
[in/out]	UINT32              *pdwSealedDataSize  The size of Encrypted, integrity-protected data object that is the result of the
                                                    TPM_Seal operation.
[out]		TPM_STORED_DATA     *psSealedData       Encrypted, integrity-protected data object that is the result of the
                                                    TPM_Seal operation.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/

UINT32 TPM_Seal(TPM_KEY_HANDLE dwKeyHandle, TPM_ENCAUTH * psEncAuth, UINT32 dwPcrInfoSize, TPM_PCR_INFO * psPcrInfo, UINT32 dwInDataSize, BYTE * pbInData, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		BYTE bContinueAuthSession,
		TPM_AUTHDATA * psPubAuth, UINT32 * pdwSealedDataSize, TPM_STORED_DATA * psSealedData)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wNonceOdd = 0;
	UINT16 wPubAuth = 0;
	UINT16 wOffset = 0;

	// Temporary data buffers for HMAC calculation according to the authorization
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwSealRquSize = 0;
	UINT32 dwSealRspSize = 0;
	TPM_SEAL_RQU *psSealRqu = NULL;
	char *pbRqu = NULL;
	TPM_SEAL_RSP *psSealRsp = NULL;
	BYTE *pbData = NULL;
	UINT32 dwHelp = 0;
	BYTE *pbNonce = NULL;
	UINT32 dwRspSize = 0;

	DetLogToFile("\n-> TPM_Seal\n");

	do {
		// Initialize temporary data buffers for HMAC calculation according to the authorization
		wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) +
					       sizeof(TPM_ENCAUTH) +
					       sizeof(UINT32) + dwPcrInfoSize + sizeof(UINT32) + dwInDataSize);
		// The HMAC input uses (HASH_LEN + 2 * sizeof(TPM_NONCE) + 1) Bytes
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);
		// Initialize the command structures
		dwSealRquSize = sizeof(TPM_SEAL_RQU) + dwPcrInfoSize - sizeof(TPM_PCR_INFO) + dwInDataSize - 1;
		// memory allocation for seal response
		dwSealRspSize = sizeof(TPM_SEAL_RSP) - sizeof(TPM_STORED_DATA) + DEFAULT_BUFFERSIZE;
		SAFE_CALLOC(psSealRqu, dwSealRquSize, &dwRCVal);
		SAFE_CALLOC(psSealRsp, dwSealRspSize, &dwRCVal);

		psSealRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
		psSealRqu->dwParamSize = dwSwitchEndian32(dwSealRquSize);
		psSealRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_Seal);
		psSealRqu->dwKeyHandle = dwSwitchEndian32(dwKeyHandle);
		memcpy(&(psSealRqu->sEncAuth), psEncAuth, sizeof(TPM_ENCAUTH));
		psSealRqu->dwPcrInfoSize = dwSwitchEndian32(dwPcrInfoSize);

		// Switch TPM_PCR_INFO
		memcpy(&(psSealRqu->sPcrInfo), psPcrInfo, dwPcrInfoSize);
		SwitchEndian16ByteArray((BYTE *) & (psSealRqu->sPcrInfo.pcrSelection.sizeOfSelect));
		pbRqu = (char *)&psSealRqu->sPcrInfo;
		wOffset = (UINT16)dwPcrInfoSize;
		pbRqu[wOffset++] = (BYTE) (dwInDataSize >> 24);
		pbRqu[wOffset++] = (BYTE) (dwInDataSize >> 16);
		pbRqu[wOffset++] = (BYTE) (dwInDataSize >> 8);
		pbRqu[wOffset++] = (BYTE) (dwInDataSize);
		memcpy(&(pbRqu[wOffset]), pbInData, dwInDataSize);
		wOffset += (UINT16)dwInDataSize;
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 24);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 16);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 8);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle);
		wNonceOdd = wOffset;
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			pbRqu[wNonceOdd + i] = (BYTE) i;
		wOffset += sizeof(TPM_NONCE);
		pbRqu[wOffset++] = bContinueAuthSession;
		wPubAuth = wOffset;

		// Fill pbInParamDigest buffer according to authorization
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Seal >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Seal >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Seal >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Seal);
		memcpy(&(pbInParamDigest[i]), psEncAuth, sizeof(TPM_ENCAUTH));
		i += sizeof(TPM_ENCAUTH);
		pbInParamDigest[i++] = (BYTE) (dwPcrInfoSize >> 24);
		pbInParamDigest[i++] = (BYTE) (dwPcrInfoSize >> 16);
		pbInParamDigest[i++] = (BYTE) (dwPcrInfoSize >> 8);
		pbInParamDigest[i++] = (BYTE) (dwPcrInfoSize);
		memcpy(&(pbInParamDigest[i]), psPcrInfo, dwPcrInfoSize);
		i += (UINT16)dwPcrInfoSize;
		pbInParamDigest[i++] = (BYTE) (dwInDataSize >> 24);
		pbInParamDigest[i++] = (BYTE) (dwInDataSize >> 16);
		pbInParamDigest[i++] = (BYTE) (dwInDataSize >> 8);
		pbInParamDigest[i++] = (BYTE) (dwInDataSize);
		memcpy(&(pbInParamDigest[i]), pbInData, dwInDataSize);
		//i += dwInDataSize; //Dead assignment

		// Create SHA-1 hash from the input parameters according to authorization
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Fill HMAC input buffer according to authorization
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(pbRqu[wNonceOdd]), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = bContinueAuthSession;

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psPubAuth, &(pbRqu[wPubAuth]));
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psSealRqu, dwSealRquSize, (BYTE *) psSealRsp, &dwSealRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psSealRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwSealedDataSize = 0;	// No data if return buffer is too small
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		// sizeof(variable sealedData) = sizeof(whole telegram) - sizeof(fixed rest of telegram)
		dwRspSize = dwSwitchEndian32(psSealRsp->dwParamSize) -
		    sizeof(TPM_TAG) -
		    sizeof(UINT32) - sizeof(TPM_RESULT) - sizeof(TPM_NONCE) - sizeof(BYTE) - sizeof(TPM_AUTHDATA);

		if (*pdwSealedDataSize < dwRspSize) {
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		} else
			*pdwSealedDataSize = dwRspSize;

		pbData = (BYTE *) & (psSealRsp->sSealedData);

		// Differentiate between TPM_STORED_DATA and TPM_STORED_DATA12
		if (!(pbData[0] == 1 && pbData[1] == 1 && pbData[2] == 0 && pbData[3] == 0)) {
			// it is a TPM_STORED_DATA12 -> endian convert structure tag and entity type.
			// otherwise it is a TPM_STORED_DATA and doesn't have to be converted
			SwitchEndian16ByteArray((BYTE *) & (pbData[0]));
			SwitchEndian16ByteArray((BYTE *) & (pbData[2]));
		}
		// Base Offset
		wOffset = sizeof(TPM_STRUCT_VER);

		// sSealedData.sealInfoSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));

		// calculate offset for sealInfo
		dwHelp = pbData[wOffset] |
		    (pbData[wOffset + 1] << 8) | (pbData[wOffset + 2] << 16) | (pbData[wOffset + 3] << 24);

		// add offset for sealInfoSize
		wOffset += sizeof(UINT32);

		// add offset for sealInfo
		wOffset += (UINT16)dwHelp;

		// sSealedData.encDataSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));

		// copy endian converted response to output buffer
		memcpy(psSealedData, &(psSealRsp->sSealedData), *pdwSealedDataSize);

		// copy even nonce from field after sealed data to output parameter
		// Remark: Do not write the following two lines in one or you'll get an pointer arithmetic error
		pbNonce = (BYTE *) & (psSealRsp->sSealedData);
		pbNonce += *pdwSealedDataSize;
		memcpy(psNonceEven, pbNonce, sizeof(TPM_NONCE));
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwSealedDataSize = 0;
	}

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psSealRqu);	// Free command request structure
	SAFE_FREE(psSealRsp);	// Free command response structure

	DetLogToFile("<- TPM_Seal\n\n");

	return dwRCVal;
}

/*++
TPM_Unseal

Description:
Transmits the TPM command TPM_Unseal

Arguments:
[in]		TPM_KEY_HANDLE      dwParentHandle      Handle of a loaded key that can unseal the data.
[in]        UINT32              *psInDataSize       The Size of he encrypted data generated by TPM_Seal.
[in]        TPM_STORED_DATA     *psInData           The encrypted data generated by TPM_Seal.
[in]		TPM_AUTHHANDLE      dwAuthHandle        The authorization session handle used for parentHandle.
[in/out]    TPM_NONCE           *psAuthNonceEven    Nonce generated by system associated with authHandle
[in]        BYTE                bContinueAuthSession    The continue use flag for the authorization session handle
[in]        TPM_AUTHDATA		*psParentAuth       The authorization session digest for inputs and parentHandle. HMAC
                                                    key: parentKey.usageAuth.
[in]        TPM_AUTHHANDLE		dwDataAuthHandle    The authorization session handle used to authorize inData.
[in/out]    TPM_NONCE			*psDataNonceEven    Nonce generated by system associated with entityAuthHandle
[in]        BYTE                bContinueDataSession    Continue usage flag for dataAuthHandle.
[in]        TPM_AUTHDATA        *psDataAuth         The authorization session digest for the encrypted entity. HMAC key:
                                                    entity.usageAuth.

[in/out]    UINT32              *pdwSecretSize      The used size of the output area for secret
[out]		BYTE                *pbSecret           Decrypted data that had been sealed

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/04/23
--*/
UINT32 TPM_Unseal(TPM_KEY_HANDLE dwParentHandle, UINT32 dwInDataSize, TPM_STORED_DATA * psInData, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		  BYTE bContinueAuthSession, TPM_AUTHDATA * psParentAuth, TPM_AUTHHANDLE dwDataAuthHandle, TPM_NONCE * psDataNonceEven,	// I/O, incoming dataLastNonceEven, outgoing nonceEven
		  BYTE bContinueDataSession, TPM_AUTHDATA * psDataAuth, UINT32 * pdwSecretSize, BYTE * pbSecret)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wOffset = 0;
	UINT16 wNonceOdd = 0;
	UINT16 wParentAuth = 0;
	UINT16 wDataNonceOdd = 0;
	UINT16 wDataAuth = 0;

	// Temporary data buffers for HMAC calculation according to the authorization
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwUnsealRquSize = 0;
	UINT32 dwUnsealRspSize = 0;
	TPM_UNSEAL_RQU *psUnsealRqu = NULL;
	char *pbRqu = NULL;
	TPM_UNSEAL_RSP *psUnsealRsp = NULL;
	UINT32 dwHelp = 0;
	UINT32 dwRspSize = 0;

	DetLogToFile("\n-> TPM_Unseal\n");

	do {
		if (dwInDataSize == 0) {
			// TPM_Unseal without InData makes no sense
			dwRCVal = RC_E_INVALID_PARAM;
			break;
		}
		// Initialize temporary data buffers for HMAC calculation according to the authorization
		wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) + dwInDataSize);
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Initialize the command structures
		dwUnsealRquSize = sizeof(TPM_UNSEAL_RQU) - sizeof(TPM_STORED_DATA) + dwInDataSize;
		// memory allocation for unseal response
		dwUnsealRspSize = sizeof(TPM_UNSEAL_RSP) - sizeof(BYTE) + DEFAULT_BUFFERSIZE;
		SAFE_CALLOC(psUnsealRqu, dwUnsealRquSize, &dwRCVal);
		SAFE_CALLOC(psUnsealRsp, dwUnsealRspSize, &dwRCVal);

		psUnsealRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH2_COMMAND);
		psUnsealRqu->dwParamSize = dwSwitchEndian32(dwUnsealRquSize);
		psUnsealRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_Unseal);
		psUnsealRqu->dwParentHandle = dwSwitchEndian32(dwParentHandle);

		memcpy(&(psUnsealRqu->sInData), psInData, dwInDataSize);
		pbRqu = (char *)&(psUnsealRqu->sInData);

		// Differentiate between TPM_STORED_DATA and TPM_STORED_DATA12
		if (!(pbRqu[0] == 1 && pbRqu[1] == 1 && pbRqu[2] == 0 && pbRqu[3] == 0)) {
			// it is a TPM_STORED_DATA12 -> endian convert structure tag and entity type.
			// otherwise it is a TPM_STORED_DATA and doesn't have to be converted
			SwitchEndian16ByteArray((BYTE *) & (pbRqu[0]));
			SwitchEndian16ByteArray((BYTE *) & (pbRqu[2]));
		}
		// Switch TPM_STORED_DATA
		wOffset = sizeof(TPM_STRUCT_VER);

		// sInData.sealInfoSize
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));

		// Now big endian
		dwHelp = (pbRqu[wOffset] << 24) |
		    (pbRqu[wOffset + 1] << 16) | (pbRqu[wOffset + 2] << 8) | (pbRqu[wOffset + 3]);
		// step over sealInfoSize
		wOffset += sizeof(UINT32);
		// Step over sealInfo
		wOffset += (UINT16)dwHelp;

		// sInData.encDataSize
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));

		pbRqu = (char *)&(psUnsealRqu->sInData);
		wOffset = (UINT16)dwInDataSize;
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 24);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 16);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 8);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle);
		wNonceOdd = wOffset;
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			pbRqu[wNonceOdd + i] = (BYTE) i;
		wOffset += sizeof(TPM_NONCE);

		pbRqu[wOffset++] = bContinueAuthSession;
		wParentAuth = wOffset;

		memcpy(&(pbRqu[wOffset]), psParentAuth, sizeof(TPM_AUTHDATA));
		wOffset += sizeof(TPM_AUTHDATA);
		pbRqu[wOffset++] = (BYTE) (dwDataAuthHandle >> 24);
		pbRqu[wOffset++] = (BYTE) (dwDataAuthHandle >> 16);
		pbRqu[wOffset++] = (BYTE) (dwDataAuthHandle >> 8);
		pbRqu[wOffset++] = (BYTE) (dwDataAuthHandle);
		wDataNonceOdd = wOffset;
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			pbRqu[wDataNonceOdd + i] = (BYTE) i + 20;
		wOffset += sizeof(TPM_NONCE);
		pbRqu[wOffset++] = bContinueDataSession;
		wDataAuth = wOffset;

		// Fill pbInParamDigest buffer according to authorization
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Unseal >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Unseal >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Unseal >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_Unseal);
		memcpy(&(pbInParamDigest[i]), &(psUnsealRqu->sInData), dwInDataSize);
		//i += dwInDataSize; //Dead assignment

		// Create SHA-1 hash from the input parameters according to authorization
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Fill HMAC input buffer according to authorization
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psAuthNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(pbRqu[wNonceOdd]), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = bContinueAuthSession;

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psParentAuth, &(pbRqu[wParentAuth]));
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Re-use parentAuth in pbHmacInput for dataAuth
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psDataNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(pbRqu[wDataNonceOdd]), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = bContinueDataSession;

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psDataAuth, &(pbRqu[wDataAuth]));
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psUnsealRqu, dwUnsealRquSize, (BYTE *) psUnsealRsp, &dwUnsealRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psUnsealRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwSecretSize = 0;
			break;
		}
		dwRCVal = RC_SUCCESS;

		// sizeof(variable secret) = sizeof(whole telegram) - sizeof(fixed rest of telegram)
		dwRspSize = dwSwitchEndian32(psUnsealRsp->dwParamSize) - sizeof(TPM_TAG) - sizeof(UINT32) -	// paramSize
		    sizeof(TPM_RESULT) - sizeof(UINT32) -	// secretSize
		    sizeof(TPM_NONCE) -	// nonceEven
		    sizeof(BYTE) -	// continueAuthSession
		    sizeof(TPM_AUTHDATA) -	// resAuth
		    sizeof(TPM_NONCE) -	// dataNonceEven
		    sizeof(BYTE) -	// continueDataSession
		    sizeof(TPM_AUTHDATA);	// dataAuth

		if (*pdwSecretSize < dwRspSize) {
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		}
		// Copy result from the command response structure to the output argument
		*pdwSecretSize = dwSwitchEndian32(psUnsealRsp->dwSecretSize);
		memcpy(pbSecret, psUnsealRsp->abSecret, *pdwSecretSize);
		// copy from field after secret data
		memcpy(psAuthNonceEven, &(psUnsealRsp->abSecret) + *pdwSecretSize, sizeof(TPM_NONCE));
		// copy from field after secret data, nonce, bool and authdata: dataNonceEven
		memcpy(psDataNonceEven, &(psUnsealRsp->abSecret) + *pdwSecretSize + sizeof(TPM_NONCE) +
		       sizeof(BYTE) + sizeof(TPM_AUTHDATA), sizeof(TPM_NONCE));
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwSecretSize = 0;
	}

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psUnsealRqu);	// Free command request structure
	SAFE_FREE(psUnsealRsp);	// Free command response structure

	DetLogToFile("<- TPM_Unseal\n\n");

	return dwRCVal;
}

/*++
TPM_CreateWrapKey

Description:
Transmits the TPM command TPM_CreateWrapKey

Arguments:
[in]		TPM_KEY_HANDLE      dwParentHandle      Handle of a loaded key that can perform key wrapping.
[in]        TPM_ENCAUTH         *psDataUsageAuth    Encrypted usage AuthData for the sealed data.
[in]		TPM_ENCAUTH         *psDataMigrationAuth    Encrypted migration AuthData for the sealed data.
[in]        UINT32              dwKeyInfoSize       The size of information about key to be created
[in]        TPM_KEY             *psKeyInfo          Information about key to be created, pubkey.keyLength and
                                                    keyInfo.encData elements are 0. MAY be TPM_KEY12
[in]        TPM_AUTHHANDLE      dwAuthHandle        parent key authorization. Must be an OSAP session.
[in/out]    TPM_NONCE			*psAuthNonceEven    Even nonce previously generated by TPM to cover inputs
[in]		TPM_AUTHDATA		*psPubAuth          The authorization session digest for inputs and keyHandle. HMAC key:
                                                    key.usageAuth.
[in/out]    UINT32              *pdwWrappedKeySize  The size of the TPM_KEY structure which includes the public and encrypted private
                                                    key.
[out]       TPM_KEY             *psWrappedKey       The TPM_KEY structure which includes the public and encrypted private
                                                    key. MAY be TPM_KEY12

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/

UINT32 TPM_CreateWrapKey(TPM_KEY_HANDLE dwParentHandle, TPM_ENCAUTH * psDataUsageAuth, TPM_ENCAUTH * psDataMigrationAuth, UINT32 dwKeyInfoSize, TPM_KEY * psKeyInfo, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 TPM_AUTHDATA * psPubAuth, UINT32 * pdwWrappedKeySize, TPM_KEY * psWrappedKey)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wNonceOdd = 0;
	UINT16 wPubAuth = 0;
	UINT16 wOffset = 0;

	// Temporary data buffers for HMAC calculation according to the authorization
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwCreateWrapKeyRquSize = 0;
	UINT32 dwCreateWrapKeyRspSize = 0;
	TPM_CREATE_WRAP_KEY_RQU *psCreateWrapKeyRqu = NULL;
	char *pbData = NULL;
	TPM_CREATE_WRAP_KEY_RSP *psCreateWrapKeyRsp = NULL;
	BYTE *pbNonce = NULL;
	UINT32 dwHelp = 0;
	UINT32 dwRspSize = 0;

	DetLogToFile("\n-> TPM_CreateWrapKey\n");

	do {
		// Initialize temporary data buffers for HMAC calculation according to the authorization
		wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) + 2 * sizeof(TPM_ENCAUTH) + dwKeyInfoSize);
		// The HMAC input uses (HASH_LEN + 2 * sizeof(TPM_NONCE) + 1) Bytes
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

		// Initialize the command structures
		dwCreateWrapKeyRquSize = sizeof(TPM_CREATE_WRAP_KEY_RQU) - sizeof(TPM_KEY) + dwKeyInfoSize;
		// memory allocation for response (default size)
		dwCreateWrapKeyRspSize = sizeof(TPM_CREATE_WRAP_KEY_RSP) - sizeof(TPM_KEY) + DEFAULT_BUFFERSIZE;
		SAFE_CALLOC(psCreateWrapKeyRqu, dwCreateWrapKeyRquSize, &dwRCVal);
		SAFE_CALLOC(psCreateWrapKeyRsp, dwCreateWrapKeyRspSize, &dwRCVal);

		psCreateWrapKeyRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
		psCreateWrapKeyRqu->dwParamSize = dwSwitchEndian32(dwCreateWrapKeyRquSize);
		psCreateWrapKeyRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_CreateWrapKey);
		psCreateWrapKeyRqu->dwParentHandle = dwSwitchEndian32(dwParentHandle);
		memcpy(&(psCreateWrapKeyRqu->sDataUsageAuth), psDataUsageAuth, sizeof(TPM_ENCAUTH));
		memcpy(&(psCreateWrapKeyRqu->sDataMigrationAuth), psDataMigrationAuth, sizeof(TPM_ENCAUTH));
		memcpy(&(psCreateWrapKeyRqu->sKeyInfo), psKeyInfo, dwKeyInfoSize);

		pbData = (char *)&(psCreateWrapKeyRqu->sKeyInfo);
		// Switch TPM_KEY

		// Differentiate between TPM_KEY and TPM_KEY12
		if (!(pbData[0] == 1 && pbData[1] == 1 && pbData[2] == 0 && pbData[3] == 0)) {
			// it is a TPM_KEY12 -> endian convert structure tag.
			// otherwise it is a TPM_KEY and doesn't have to be converted
			SwitchEndian16ByteArray((BYTE *) & (pbData[0]));
		}
		// Step over ver
		wOffset = sizeof(TPM_STRUCT_VER);
		// keyUsage
		SwitchEndian16ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_KEY_USAGE);
		// keyFlags
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_KEY_FLAGS);
		// Step over authDataUsage
		wOffset += sizeof(TPM_AUTH_DATA_USAGE);
		// algorithmParms.algorithmID
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_ALGORITHM_ID);
		// algorithmParms.encScheme
		SwitchEndian16ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_ENC_SCHEME);
		// algorithmParms.sigScheme
		SwitchEndian16ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_SIG_SCHEME);
		// algorithmParms.parmSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.keyLength
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.numPrimes
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.exponentSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		// Step over algorithmParms.parms.exponent
		// Now big endian
		dwHelp = (pbData[wOffset] << 24) |
		    (pbData[wOffset + 1] << 16) | (pbData[wOffset + 2] << 8) | (pbData[wOffset + 3]);
		wOffset += sizeof(UINT32);
		// Step over exponent
		wOffset += (UINT16)dwHelp;
		// PCRInfoSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		// Step over PCRInfo
		// Now big endian
		dwHelp = (pbData[wOffset] << 24) |
		    (pbData[wOffset + 1] << 16) | (pbData[wOffset + 2] << 8) | (pbData[wOffset + 3]);
		wOffset += sizeof(UINT32);
		// Step over PCRInfo
		wOffset += (UINT16)dwHelp;
		// pubKey.keyLength
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		// Step over pubKey.key
		// Now big endian
		dwHelp = (pbData[wOffset] << 24) |
		    (pbData[wOffset + 1] << 16) | (pbData[wOffset + 2] << 8) | (pbData[wOffset + 3]);
		wOffset += sizeof(UINT32);
		// Step over key
		wOffset += (UINT16)dwHelp;
		// encSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));

		wOffset = (UINT16)dwKeyInfoSize;
		pbData[wOffset++] = (BYTE) (dwAuthHandle >> 24);
		pbData[wOffset++] = (BYTE) (dwAuthHandle >> 16);
		pbData[wOffset++] = (BYTE) (dwAuthHandle >> 8);
		pbData[wOffset++] = (BYTE) (dwAuthHandle);
		wNonceOdd = wOffset;
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			pbData[wNonceOdd + i] = (BYTE) i;
		wOffset += sizeof(TPM_NONCE);
		pbData[wOffset++] = FALSE;	// bContinueAuthSession ignored
		wPubAuth = wOffset;

		// Fill pbInParamDigest buffer according to authorization
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_CreateWrapKey >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_CreateWrapKey >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_CreateWrapKey >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_CreateWrapKey);
		memcpy(&(pbInParamDigest[i]), psDataUsageAuth, sizeof(TPM_ENCAUTH));
		i += sizeof(TPM_ENCAUTH);
		memcpy(&(pbInParamDigest[i]), psDataMigrationAuth, sizeof(TPM_ENCAUTH));
		i += sizeof(TPM_ENCAUTH);
		memcpy(&(pbInParamDigest[i]), &(psCreateWrapKeyRqu->sKeyInfo), dwKeyInfoSize);
		//i += dwKeyInfoSize; //Dead increment

		// Create SHA-1 hash from the input parameters according to authorization
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
		// Fill HMAC input buffer according to authorization
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psAuthNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(pbData[wNonceOdd]), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = FALSE;	// bContinueAuthSession

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psPubAuth, &(pbData[wPubAuth]));
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psCreateWrapKeyRqu,
					    dwCreateWrapKeyRquSize, (BYTE *) psCreateWrapKeyRsp, &dwCreateWrapKeyRspSize);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psCreateWrapKeyRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwWrappedKeySize = 0;
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result from the command response structure to the output argument
		// sizeof(variable wrappedKey) = sizeof(whole telegram) - sizeof(fixed rest of telegram)
		dwRspSize = dwSwitchEndian32(psCreateWrapKeyRsp->dwParamSize) -
		    sizeof(TPM_TAG) -
		    sizeof(UINT32) - sizeof(TPM_RESULT) - sizeof(TPM_NONCE) - sizeof(BYTE) - sizeof(TPM_AUTHDATA);

		if (*pdwWrappedKeySize < dwRspSize) {
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		} else
			*pdwWrappedKeySize = dwRspSize;

		pbData = (char *)&(psCreateWrapKeyRsp->sWrappedKey);
		// Switch TPM_KEY
		// Differentiate between TPM_KEY and TPM_KEY12
		if (!(pbData[0] == 1 && pbData[1] == 1 && pbData[2] == 0 && pbData[3] == 0)) {
			// it is a TPM_KEY12 -> endian convert structure tag.
			// otherwise it is a TPM_KEY and doesn't have to be converted
			SwitchEndian16ByteArray((BYTE *) & (pbData[0]));
		}
		// Step over ver
		wOffset = sizeof(TPM_STRUCT_VER);
		// keyUsage
		SwitchEndian16ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_KEY_USAGE);
		// keyFlags
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_KEY_FLAGS);
		// Step over authDataUsage
		wOffset += sizeof(TPM_AUTH_DATA_USAGE);
		// algorithmParms.algorithmID
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_ALGORITHM_ID);
		// algorithmParms.encScheme
		SwitchEndian16ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_ENC_SCHEME);
		// algorithmParms.sigScheme
		SwitchEndian16ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(TPM_SIG_SCHEME);
		// algorithmParms.parmSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.keyLength
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.numPrimes
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.exponentSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		// Step over algorithmParms.parms.exponent
		// Now little endian
		dwHelp = (pbData[wOffset]) |
		    (pbData[wOffset + 1] << 8) | (pbData[wOffset + 2] << 16) | (pbData[wOffset + 3] << 24);
		wOffset += sizeof(UINT32);
		// Step over exponent
		wOffset += (UINT16)dwHelp;
		// PCRInfoSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		// Step over PCRInfo
		// Now little endian
		dwHelp = (pbData[wOffset]) |
		    (pbData[wOffset + 1] << 8) | (pbData[wOffset + 2] << 16) | (pbData[wOffset + 3] << 24);
		wOffset += sizeof(UINT32);
		// Step over PCRInfo
		wOffset += (UINT16)dwHelp;
		// pubKey.keyLength
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));
		// Step over pubKey.key
		// Now little endian
		dwHelp = (pbData[wOffset]) |
		    (pbData[wOffset + 1] << 8) | (pbData[wOffset + 2] << 16) | (pbData[wOffset + 3] << 24);
		wOffset += sizeof(UINT32);
		// Step over key
		wOffset += (UINT16)dwHelp;
		// encSize
		SwitchEndian32ByteArray((BYTE *) & (pbData[wOffset]));

		memcpy(psWrappedKey, &(psCreateWrapKeyRsp->sWrappedKey), *pdwWrappedKeySize);
		// Do not write the following two lines in one or you'll get an pointer arithmetic error
		pbNonce = (BYTE *) & (psCreateWrapKeyRsp->sWrappedKey);
		pbNonce += *pdwWrappedKeySize;
		memcpy(psAuthNonceEven, &(psCreateWrapKeyRsp->sWrappedKey), sizeof(TPM_NONCE));
	} while (FALSE);

	DetLogToFile("<- TPM_CreateWrapKey\n\n");

	if (dwRCVal != RC_SUCCESS) {
		*pdwWrappedKeySize = 0;
	}

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psCreateWrapKeyRqu);	// Free command request structure
	SAFE_FREE(psCreateWrapKeyRsp);	// Free command response structure

	return dwRCVal;
}

/*++
TPM_LoadKey2

Description:
Transmits the TPM command TPM_LoadKey2

Arguments:
[in]		TPM_KEY_HANDLE      dwParentHandle      Handle of a loaded key that can perform key wrapping.
[in]		UINT32              dwInKeySize         Size of incoming key structure, both encrypted private and clear public portions.
[in]        TPM_KEY             *psInKey            Incoming key structure, both encrypted private and clear public portions.
[in]        TPM_AUTHHANDLE      dwAuthHandle        The authorization session handle used for parentHandle authorization
[in/out]    TPM_NONCE			*psAuthNonceEven    Even nonce previously generated by TPM to cover inputs
[in]		BYTE				bContinueAuthSession    The continue use flag for the authorization session handle
[in]		TPM_AUTHDATA		*psKeyUsageAuth     The authorization session digest for inputs and parentHandle.
[out]       TPM_KEY_HANDLE      pdwInKeyHandle      Internal TPM handle where decrypted key was loaded.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/

UINT32 TPM_LoadKey2(TPM_KEY_HANDLE dwParentHandle, UINT32 dwInKeySize, TPM_KEY * psInKey, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		    BYTE bContinueAuthSession, TPM_AUTHDATA * psKeyUsageAuth, TPM_KEY_HANDLE * pdwInKeyHandle)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;
	UINT16 wNonceOdd = 0;
	UINT16 wParentAuth = 0;
	UINT16 wOffset = 0;

	// Temporary data buffers for HMAC calculation according to the authSession
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwLoadKey2RquSize = 0;
	UINT32 dwLoadKey2RspSize = 0;
	TPM_LOAD_KEY_2_RQU *psLoadKey2Rqu = NULL;
	char *pbRqu = NULL;
	TPM_LOAD_KEY_2_RSP *psLoadKey2Rsp = NULL;
	UINT32 dwHelp = 0;

	DetLogToFile("\n-> TPM_LoadKey2\n");

	do {
		// Initialize temporary data buffers for HMAC calculation according to the authSession
		wInParamDigestSize = (UINT16) (sizeof(TPM_COMMAND_CODE) + dwInKeySize);
		// The HMAC input uses (HASH_LEN + 2 * sizeof(TPM_NONCE) + 1) Bytes
		wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
		SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
		SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);
		// Initialize the command structures
		dwLoadKey2RquSize = max(sizeof(TPM_LOAD_KEY_2_RQU), sizeof(TPM_LOAD_KEY_2_RQU) - sizeof(TPM_KEY) + dwInKeySize);
		dwLoadKey2RspSize = sizeof(TPM_LOAD_KEY_2_RSP);
		SAFE_CALLOC(psLoadKey2Rqu, dwLoadKey2RquSize, &dwRCVal);
		SAFE_CALLOC(psLoadKey2Rsp, dwLoadKey2RspSize, &dwRCVal);

		psLoadKey2Rqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
		psLoadKey2Rqu->dwParamSize = dwSwitchEndian32(dwLoadKey2RquSize);
		psLoadKey2Rqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_LoadKey2);
		psLoadKey2Rqu->dwParentHandle = dwSwitchEndian32(dwParentHandle);
		memcpy(&(psLoadKey2Rqu->sInKey), psInKey, dwInKeySize);
		pbRqu = (char *)&(psLoadKey2Rqu->sInKey);

		// Switch TPM_KEY
		// Differentiate between TPM_KEY and TPM_KEY12
		if (!(pbRqu[0] == 1 && pbRqu[1] == 1 && pbRqu[2] == 0 && pbRqu[3] == 0)) {
			// it is a TPM_KEY12 -> endian convert structure tag.
			// otherwise it is a TPM_KEY and doesn't have to be converted
			SwitchEndian16ByteArray((BYTE *) & (pbRqu[0]));
		}
		// Step over ver
		wOffset = sizeof(TPM_STRUCT_VER);
		// keyUsage
		SwitchEndian16ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(TPM_KEY_USAGE);
		// keyFlags
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(TPM_KEY_FLAGS);
		// Step over authDataUsage
		wOffset += sizeof(TPM_AUTH_DATA_USAGE);
		// algorithmParms.algorithmID
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(TPM_ALGORITHM_ID);
		// algorithmParms.encScheme
		SwitchEndian16ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(TPM_ENC_SCHEME);
		// algorithmParms.sigScheme
		SwitchEndian16ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(TPM_SIG_SCHEME);
		// algorithmParms.parmSize
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.keyLength
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.numPrimes
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		wOffset += sizeof(UINT32);
		// algorithmParms.parms.exponentSize
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		// Step over algorithmParms.parms.exponent
		// Now big endian
		dwHelp = (pbRqu[wOffset] << 24) |
		    (pbRqu[wOffset + 1] << 16) | (pbRqu[wOffset + 2] << 8) | (pbRqu[wOffset + 3]);
		wOffset += sizeof(UINT32);
		// Step over exponent
		wOffset += (UINT16)dwHelp;
		// PCRInfoSize
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		// Step over PCRInfo
		// Now big endian
		dwHelp = (pbRqu[wOffset] << 24) |
		    (pbRqu[wOffset + 1] << 16) | (pbRqu[wOffset + 2] << 8) | (pbRqu[wOffset + 3]);
		wOffset += sizeof(UINT32);
		// Step over PCRInfo
		wOffset += (UINT16)dwHelp;
		// pubKey.keyLength
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));
		// Step over pubKey.key
		// Now big endian
		dwHelp = (pbRqu[wOffset] << 24) |
		    (pbRqu[wOffset + 1] << 16) | (pbRqu[wOffset + 2] << 8) | (pbRqu[wOffset + 3]);
		wOffset += sizeof(UINT32);
		// Step over key
		wOffset += (UINT16)dwHelp;
		// encSize
		SwitchEndian32ByteArray((BYTE *) & (pbRqu[wOffset]));

		wOffset = (UINT16)dwInKeySize;
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 24);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 16);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle >> 8);
		pbRqu[wOffset++] = (BYTE) (dwAuthHandle);
		wNonceOdd = wOffset;
		for (i = 0; i < sizeof(TPM_NONCE); i++)
			pbRqu[wNonceOdd + i] = (BYTE) i;
		wOffset += sizeof(TPM_NONCE);
		pbRqu[wOffset++] = bContinueAuthSession;
		wParentAuth = wOffset;

		// Fill pbInParamDigest buffer according to authorization
		i = 0;
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_LoadKey2 >> 24);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_LoadKey2 >> 16);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_LoadKey2 >> 8);
		pbInParamDigest[i++] = (BYTE) (TPM_ORD_LoadKey2);
		memcpy(&(pbInParamDigest[i]), &(psLoadKey2Rqu->sInKey), dwInKeySize);
		//i += dwInKeySize; //dead increment

		// Create SHA-1 hash from the input parameters according to authorization
		dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
		if (dwRCVal != RC_SUCCESS)
			break;

		// Fill HMAC input buffer according to authorization
		i = HASH_LEN;
		memcpy(&(pbHmacInput[i]), psAuthNonceEven, sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		memcpy(&(pbHmacInput[i]), &(pbRqu[wNonceOdd]), sizeof(TPM_NONCE));
		i += sizeof(TPM_NONCE);
		pbHmacInput[i++] = bContinueAuthSession;

		// Create HMAC for authenticated TPM command according to authorization
		dwRCVal = HMAC_Func(pbHmacInput, wHmacInputSize, (BYTE *) psKeyUsageAuth, &(pbRqu[wParentAuth]));
		if (dwRCVal != RC_SUCCESS)
			break;

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psLoadKey2Rqu,
					    dwLoadKey2RquSize, (BYTE *) psLoadKey2Rsp, &dwLoadKey2RspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psLoadKey2Rsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;

		dwRCVal = RC_SUCCESS;
		// Copy result from the command response structure to the output argument
		*pdwInKeyHandle = dwSwitchEndian32(psLoadKey2Rsp->dwInKeyHandle);
		memcpy(psAuthNonceEven, &(psLoadKey2Rsp->sNonceEven), sizeof(TPM_NONCE));
	} while (FALSE);

	SAFE_FREE(pbInParamDigest);	// Free HMAC input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psLoadKey2Rqu);	// Free command request structure
	SAFE_FREE(psLoadKey2Rsp);	// Free command response structure

	DetLogToFile("<- TPM_LoadKey2\n\n");

	return dwRCVal;
}

/*++
TPM_GetPubKey

Description:
Transmits the TPM command TPM_GetPubKey

Arguments:
[in]		TPM_KEY_HANDLE      dwKeyHandle         TPM handle of key.
[in]		TPM_AUTHDATA		*dwAuthHandle       The authorization session handle used for keyHandle authorization.
[in/out]    TPM_NONCE			*psAuthNonceEven    Even nonce previously generated by TPM to cover inputs
[in]		BYTE				bContinueAuthSession    The continue use flag for the authorization session handle
[in]		TPM_AUTHDATA		*psKeyAuth          Authorization HMAC key: key.usageAuth.
[in/out]    UINT32              *pdwPubKeySize      The size of public portion of key in keyHandle.
[out]       TPM_KEY             *psPubKey           Public portion of key in keyHandle.

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2008/03/03
--*/

UINT32 TPM_GetPubKey(TPM_KEY_HANDLE dwKeyHandle, TPM_AUTHHANDLE dwAuthHandle,	// If NULL command executes un-authorized
		     TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		     BYTE bContinueAuthSession, TPM_AUTHDATA * psKeyAuth, UINT32 * pdwPubKeySize, TPM_PUBKEY * psPubKey)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT16 i = 0;

	// Temporary data buffers for HMAC calculation according to the authorization
	UINT16 wInParamDigestSize = 0;
	BYTE *pbInParamDigest = NULL;
	UINT16 wHmacInputSize = 0;
	BYTE *pbHmacInput = NULL;

	UINT32 dwGetPubKeyRquSize = 0;
	UINT32 dwGetPubKeyRspSize = 0;
	TPM_GET_PUB_KEY_RQU *psGetPubKeyRqu = NULL;
	TPM_GET_PUB_KEY_RSP *psGetPubKeyRsp = NULL;
	BYTE *pbNonce = NULL;
	BYTE *pbHelp = NULL;
	UINT32 dwHelp = 0;
	UINT32 dwRspSize = 0;

	DetLogToFile("\n-> TPM_GetPubKey\n");

	do {
		if (dwAuthHandle)	// authorized
		{
			// Initialize temporary data buffers for HMAC calculation according to the authorization
			wInParamDigestSize = sizeof(TPM_COMMAND_CODE);
			// The HMAC input uses (HASH_LEN + 2 * sizeof(TPM_NONCE) + 1) Bytes
			wHmacInputSize = HASH_LEN + 2 * sizeof(TPM_NONCE) + 1;
			SAFE_CALLOC(pbInParamDigest, wInParamDigestSize, &dwRCVal);
			SAFE_CALLOC(pbHmacInput, wHmacInputSize, &dwRCVal);

			// Initialize the command structures
			dwGetPubKeyRquSize = sizeof(TPM_GET_PUB_KEY_RQU);
			// memory allocation for response field (default size)
			dwGetPubKeyRspSize = sizeof(TPM_GET_PUB_KEY_RSP) - sizeof(TPM_PUBKEY) + DEFAULT_BUFFERSIZE;
			SAFE_CALLOC(psGetPubKeyRqu, dwGetPubKeyRquSize, &dwRCVal);
			SAFE_CALLOC(psGetPubKeyRsp, dwGetPubKeyRspSize, &dwRCVal);

			psGetPubKeyRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_AUTH1_COMMAND);
			psGetPubKeyRqu->dwParamSize = dwSwitchEndian32(dwGetPubKeyRquSize);
			psGetPubKeyRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_GetPubKey);
			psGetPubKeyRqu->dwKeyHandle = dwSwitchEndian32(dwKeyHandle);
			psGetPubKeyRqu->dwAuthHandle = dwSwitchEndian32(dwAuthHandle);
			for (i = 0; i < sizeof(TPM_NONCE); i++)
				psGetPubKeyRqu->sNonceOdd.nonce[i] = (BYTE) i;
			psGetPubKeyRqu->bContinueAuthSession = bContinueAuthSession;

			// Fill pbInParamDigest buffer according to authorization
			i = 0;
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_GetPubKey >> 24);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_GetPubKey >> 16);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_GetPubKey >> 8);
			pbInParamDigest[i++] = (BYTE) (TPM_ORD_GetPubKey);

			// Create SHA-1 hash from the input parameters according to authorization
			dwRCVal = SHA1_Func(pbInParamDigest, wInParamDigestSize, pbHmacInput);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}
			// Fill HMAC input buffer according to authorization
			i = HASH_LEN;
			memcpy(&(pbHmacInput[i]), psAuthNonceEven, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			memcpy(&(pbHmacInput[i]), psGetPubKeyRqu->sNonceOdd.nonce, sizeof(TPM_NONCE));
			i += sizeof(TPM_NONCE);
			// The TPM ignores this parameter
			pbHmacInput[i++] = FALSE;	// bContinueAuthSession

			// Create HMAC for authenticated TPM command according to authorization
			dwRCVal = HMAC_Func(pbHmacInput,
					    wHmacInputSize, (BYTE *) psKeyAuth, (BYTE *) & (psGetPubKeyRqu->sKeyAuth));
			if (dwRCVal != RC_SUCCESS) {
				break;
			}
			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psGetPubKeyRqu,
						    dwGetPubKeyRquSize, (BYTE *) psGetPubKeyRsp, &dwGetPubKeyRspSize);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwRCVal = dwSwitchEndian32(psGetPubKeyRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS) {
				*pdwPubKeySize = 0;
				break;
			}
			dwRCVal = RC_SUCCESS;

			// sizeof(variable PubKey) = sizeof(whole telegram) - sizeof(fixed rest of telegram)
			dwRspSize = dwSwitchEndian32(psGetPubKeyRsp->dwParamSize) - sizeof(TPM_TAG) -	// tag
			    sizeof(UINT32) -	// paramSize
			    sizeof(TPM_RESULT) -	// returnCode
			    sizeof(TPM_NONCE) -	// nonceEven
			    sizeof(BYTE) -	// continueAuthSession
			    sizeof(TPM_AUTHDATA);	// resAuth

			if (*pdwPubKeySize < dwRspSize) {
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			} else
				// Copy result from the command response structure to the output argument
				*pdwPubKeySize = dwRspSize;

			// Switch TPM_PUBKEY
			pbHelp = (BYTE *) & (psGetPubKeyRsp->sPubKey);
			i = 0;
			// algorithmParms.algorithmID
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(TPM_ALGORITHM_ID);
			// algorithmParms.encScheme
			SwitchEndian16ByteArray(&pbHelp[i]);
			i += sizeof(TPM_ENC_SCHEME);
			// algorithmParms.sigScheme
			SwitchEndian16ByteArray(&pbHelp[i]);
			i += sizeof(TPM_SIG_SCHEME);
			// algorithmParms.parmSize
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(UINT32);
			// parms.keyLength
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(UINT32);
			// parms.numPrimes
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(UINT32);
			// parms.exponentSize
			SwitchEndian32ByteArray(&pbHelp[i]);
			// step over exponent
			// Now big endian
			dwHelp = (pbHelp[i] << 24) | (pbHelp[i + 1] << 16) | (pbHelp[i + 2] << 8) | (pbHelp[i + 3]);
			i += sizeof(UINT32);
			i += (UINT16)dwHelp;
			// pubKey.keyLength
			SwitchEndian32ByteArray(&pbHelp[i]);

			memcpy(psPubKey, &(psGetPubKeyRsp->sPubKey), *pdwPubKeySize);
			// Do not write the following two lines in one or you'll get an pointer arithmetic error
			pbNonce = (BYTE *) & (psGetPubKeyRsp->sPubKey);
			pbNonce += *pdwPubKeySize;
			memcpy(psAuthNonceEven, pbNonce, sizeof(TPM_NONCE));
		} else		// unauthorized
		{
			// Initialize the command structures
			dwGetPubKeyRquSize = sizeof(TPM_TAG) +
			    sizeof(UINT32) + sizeof(TPM_COMMAND_CODE) + sizeof(TPM_KEY_HANDLE);
			// memory allocation for response field (default size)
			dwGetPubKeyRspSize = sizeof(TPM_GET_PUB_KEY_RSP) - sizeof(TPM_PUBKEY) + DEFAULT_BUFFERSIZE;
			SAFE_CALLOC(psGetPubKeyRqu, dwGetPubKeyRquSize, &dwRCVal);
			SAFE_CALLOC(psGetPubKeyRsp, dwGetPubKeyRspSize, &dwRCVal);

			psGetPubKeyRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
			psGetPubKeyRqu->dwParamSize = dwSwitchEndian32(dwGetPubKeyRquSize);
			psGetPubKeyRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_GetPubKey);
			psGetPubKeyRqu->dwKeyHandle = dwSwitchEndian32(dwKeyHandle);

			// Send command request and receive command response
			dwRCVal = TDDL_TransmitData((BYTE *) psGetPubKeyRqu,
						    dwGetPubKeyRquSize, (BYTE *) psGetPubKeyRsp, &dwGetPubKeyRspSize);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwRCVal = dwSwitchEndian32(psGetPubKeyRsp->dwReturnCode);	// Return TPM result
			if (dwRCVal != TPM_SUCCESS) {
				*pdwPubKeySize = 0;
				break;
			}
			dwRCVal = RC_SUCCESS;

			// sizeof(variable PubKey) = sizeof(whole telegram) - sizeof(fixed rest of telegram)
			dwRspSize = dwSwitchEndian32(psGetPubKeyRsp->dwParamSize) - sizeof(TPM_TAG) -	// tag
			    sizeof(UINT32) -	// paramSize
			    sizeof(TPM_RESULT);	// returnCode

			if (*pdwPubKeySize < dwRspSize) {
				dwRCVal = RC_E_BUFFER2SMALL;
				break;
			} else
				// Copy result from the command response structure to the output argument
				*pdwPubKeySize = dwRspSize;

			// Switch TPM_PUBKEY
			pbHelp = (BYTE *) & (psGetPubKeyRsp->sPubKey);
			i = 0;
			// algorithmParms.algorithmID
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(TPM_ALGORITHM_ID);
			// algorithmParms.encScheme
			SwitchEndian16ByteArray(&pbHelp[i]);
			i += sizeof(TPM_ENC_SCHEME);
			// algorithmParms.sigScheme
			SwitchEndian16ByteArray(&pbHelp[i]);
			i += sizeof(TPM_SIG_SCHEME);
			// algorithmParms.parmSize
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(UINT32);
			// parms.keyLength
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(UINT32);
			// parms.numPrimes
			SwitchEndian32ByteArray(&pbHelp[i]);
			i += sizeof(UINT32);
			// parms.exponentSize
			SwitchEndian32ByteArray(&pbHelp[i]);
			// step over exponent
			// Now big endian
			dwHelp = (pbHelp[i] << 24) | (pbHelp[i + 1] << 16) | (pbHelp[i + 2] << 8) | (pbHelp[i + 3]);
			i += sizeof(UINT32);
			i += (UINT16)dwHelp;
			// pubKey.keyLength
			SwitchEndian32ByteArray(&pbHelp[i]);

			memcpy(psPubKey, &(psGetPubKeyRsp->sPubKey), *pdwPubKeySize);
		}
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwPubKeySize = 0;
	}

	DetLogToFile("<- TPM_GetPubKey\n\n");

	SAFE_FREE(pbInParamDigest);	// Free SHA-1 input buffer
	SAFE_FREE(pbHmacInput);	// Free HMAC input buffer
	SAFE_FREE(psGetPubKeyRqu);	// Free command request structure
	SAFE_FREE(psGetPubKeyRsp);	// Free command response structure

	return dwRCVal;
}

/*++
TPM_FlushSpecific

Description:
Transmits the TPM command TPM_FlushSpecific

Arguments:
[in]    TPM_HANDLE              dwHandle            The handle of the item to flush
[in]	TPM_RESOURCE_TYPE       dwResourceType      The type of resource that is being flushed

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H. Obermeier	2007/03/10
--*/
UINT32 TPM_FlushSpecific(TPM_HANDLE dwHandle, TPM_RESOURCE_TYPE dwResourceType)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwFlushSpecificRquSize = 0;
	UINT32 dwFlushSpecificRspSize = 0;
	TPM_FLUSH_SPECIFIC_RQU *psFlushSpecificRqu = NULL;
	TPM_SIMPLE_CMD_RSP *psFlushSpecificRsp = NULL;

	DetLogToFile("\n-> TPM_FlushSpecific\n");

	do {
		// Initialize the command structures
		dwFlushSpecificRquSize = sizeof(TPM_FLUSH_SPECIFIC_RQU);
		dwFlushSpecificRspSize = sizeof(TPM_SIMPLE_CMD_RSP);
		SAFE_CALLOC(psFlushSpecificRqu, dwFlushSpecificRquSize, &dwRCVal);
		SAFE_CALLOC(psFlushSpecificRsp, dwFlushSpecificRspSize, &dwRCVal);

		psFlushSpecificRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psFlushSpecificRqu->dwParamSize = dwSwitchEndian32(dwFlushSpecificRquSize);
		psFlushSpecificRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_FlushSpecific);
		psFlushSpecificRqu->dwHandle = dwSwitchEndian32(dwHandle);
		psFlushSpecificRqu->dwResourceType = dwSwitchEndian32(dwResourceType);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psFlushSpecificRqu,
					    dwFlushSpecificRquSize, (BYTE *) psFlushSpecificRsp, &dwFlushSpecificRspSize);
		if (dwRCVal != RC_SUCCESS)
			break;

		dwRCVal = dwSwitchEndian32(psFlushSpecificRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS)
			break;
		dwRCVal = RC_SUCCESS;

	} while (FALSE);

	SAFE_FREE(psFlushSpecificRqu);	// Free command request structure
	SAFE_FREE(psFlushSpecificRsp);	// Free command response structure

	DetLogToFile("<- TPM_FlushSpecific\n\n");

	return dwRCVal;
}

/*++
TPM_GetTicks

Description:
Transmits the TPM command TPM_GetTicks

Arguments:
[in/out]	UINT32              *pdwCurrentTicksSize    size of the psCurrentTicks parameter
[out]	    TPM_CURRENT_TICKS   *psCurrentTicks         The current time held in the TPM

Return Value:
	Return					Meaning
	======					=======
	RC_SUCCESS				operation completed successfully
	RC_E_FAILURE			operation failed
	RC_E_BUFFER2SMALL		buffer size insufficient
	RC_E_INVALID_DATA		TPM sent corrupted data
	RC_E_INVALID_PARAM		wrong parameters
	RC_E_NAKRECEIVED		TPM received corrupted data
	RC_E_NO_MEMORY			not enough memory in Heap available
	RC_E_TIMEOUT			timeout
	RC_E_WTXABORT			command not sent because maximum number of waiting cycles is exceeded
	RC_E_WTXRECEIVED		TPM received WTX request
	<TPM error return code>

Author:		H.Obermeier     2007/03/10
--*/
UINT32 TPM_GetTicks(UINT32 * pdwCurrentTicksSize, TPM_CURRENT_TICKS * psCurrentTicks)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	UINT32 dwGetTicksRspSize = 0;
	TPM_SIMPLE_CMD_RQU *psGetTicksRqu = NULL;
	TPM_GET_TICKS_RSP *psGetTicksRsp = NULL;

	DetLogToFile("\n-> TPM_GetTicks\n");

	do {
		// Initialize the command structures
		dwGetTicksRspSize = sizeof(TPM_GET_TICKS_RSP);
		SAFE_CALLOC(psGetTicksRqu, sizeof(TPM_SIMPLE_CMD_RQU), &dwRCVal);
		SAFE_CALLOC(psGetTicksRsp, dwGetTicksRspSize, &dwRCVal);

		psGetTicksRqu->wTag = wSwitchEndian16(TPM_TAG_RQU_COMMAND);
		psGetTicksRqu->dwParamSize = dwSwitchEndian32(sizeof(TPM_SIMPLE_CMD_RQU));
		psGetTicksRqu->dwOrdinal = dwSwitchEndian32(TPM_ORD_GetTicks);

		// Send command request and receive command response
		dwRCVal = TDDL_TransmitData((BYTE *) psGetTicksRqu,
					    sizeof(TPM_SIMPLE_CMD_RQU), (BYTE *) psGetTicksRsp, &dwGetTicksRspSize);

		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = dwSwitchEndian32(psGetTicksRsp->dwReturnCode);	// Return TPM result
		if (dwRCVal != TPM_SUCCESS) {
			*pdwCurrentTicksSize = 0;
			break;
		}
		dwRCVal = RC_SUCCESS;

		// Copy result length to the output argument
		if (*pdwCurrentTicksSize < sizeof(TPM_CURRENT_TICKS)) {
			dwRCVal = RC_E_BUFFER2SMALL;
			break;
		}
		// Copy results from the command response structure to the output arguments
		*pdwCurrentTicksSize = sizeof(TPM_CURRENT_TICKS);

		psGetTicksRsp->sCurrentTime.tag = wSwitchEndian16(psGetTicksRsp->sCurrentTime.tag);
		// TPM_UINT64                   currentTicks;
		SwitchEndian64ByteArray((TPM_UINT64 *) & (psGetTicksRsp->sCurrentTime.currentTicks.bUINT64));
		psGetTicksRsp->sCurrentTime.tickRate = wSwitchEndian16(psGetTicksRsp->sCurrentTime.tickRate);
		memcpy(psCurrentTicks, &(psGetTicksRsp->sCurrentTime), sizeof(TPM_CURRENT_TICKS));
	} while (FALSE);

	if (dwRCVal != RC_SUCCESS) {
		*pdwCurrentTicksSize = 0;
	}

	SAFE_FREE(psGetTicksRqu);	// Free command request structure
	SAFE_FREE(psGetTicksRsp);	// Free command response structure

	DetLogToFile("<- TPM_GetTicks\n\n");

	return dwRCVal;
}
