/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	FileIO.c

Description:	Implementation of the file I\O help routines

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#include "FileIO.h"
#include "ProgFunc.h"
#include "Console.h"
#ifdef linux
#include "LibFunc.h"
#endif

/*++
Bin2Asc

Description:
Convert a binary representated value into the corresponding ASCII string 

Arguments:
[in]	BYTE * pbBuffer Binary data value
[in]	UINT32 wBufferLen length of binary buffer
[out]	BYTE * pbAsciBuffer
[out] UINTN  AscBufferLen length of ASCII buffer

Return Value:
	none

Author:		Christopher Unterweger 2012/03/27
--*/
void Bin2Asc(BYTE * pbBuffer, UINT32 wBufferLen, BYTE * pbAsciBuffer, UINT32 AscBufferLen)
{
	UINT32 i;
	
	// Convert input data from binary to hexadecimal format and insert separation commas
	for (i = 0; i < AscBufferLen; i++) {
		if ((i + 1) % 3) {
			// Split Byte value to upper and lower Nibble
			if (i % 3)
				pbAsciBuffer[i] = (pbBuffer[i / 3] & 0x0f);	// (i+2) % 3 == 0 (e. g. 1, 4,...)
			else
				pbAsciBuffer[i] = (pbBuffer[i / 3] >> 4);	// i % 3 == 0 (e. g. 0, 3,...)

			// Convert each binary value to a hexadecimal value
			if (pbAsciBuffer[i] <= 9)
				pbAsciBuffer[i] += 0x30;
			else
				pbAsciBuffer[i] += 0x37;
		} else {
			// Insert blank spaces
			pbAsciBuffer[i] = ' ';	// (i+1) % 3 == 0 (e. g. 2, 5,...)
		}
	}
}

/*++
Asc2Bin

Description:
Convert an ASCII representated string into the corresponding binary value

Arguments:
[in]	char	*pbString	ASCII data string
[out]	UINT32	*pdwValue	Binary data value

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INVALID_PARAM	parameter not acceptable

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 Asc2Bin(char *pbString, UINT32 * pdwValue)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	BYTE AssumeDecimal = FALSE;
	UINT16 len;

	do {
		len = (UINT16) strlen(pbString);
		if (len == 0 || len > 8) {
			dwRCVal = RC_E_INVALID_PARAM;
			break;
		}
		if (strcspn(pbString, "abcdefhxABCDEFHX") == len)	// If none of these characters occur,
			AssumeDecimal = TRUE;	// a decimal value is assumed

		if (pbString[1] == 'x' || pbString[1] == 'X')	// If hexadecimal prefix '0x' occurs,
		{		// then skip it
			pbString += 2;
			len -= 2;
		}

		if (pbString[len - 1] == 'h' || pbString[len - 1] == 'H')	// If hexadecimal suffix 'h'
			len--;	// occurs, then skip it

		*pdwValue = 0;
		dwRCVal = RC_SUCCESS;

		if (AssumeDecimal)
			while (len) {
				if ((*pbString < 0x30) || (*pbString > 0x39)) {
					dwRCVal = RC_E_INVALID_PARAM;
					break;
				}
				*pdwValue = (*pdwValue) * 10 + ((*pbString++) - 0x30);
				len--;
		} else
			while (len) {
				if ((*pbString >= 0x30) && (*pbString <= 0x39))
					*pdwValue = (*pdwValue) * 0x10 + ((*pbString++) - 0x30);
				else if ((*pbString >= 0x41) && (*pbString <= 0x46))
					*pdwValue = (*pdwValue) * 0x10 + ((*pbString++) - 0x37);
				else if ((*pbString >= 0x61) && (*pbString <= 0x66))
					*pdwValue = (*pdwValue) * 0x10 + ((*pbString++) - 0x57);
				else {
					dwRCVal = RC_E_INVALID_PARAM;
					break;
				}
				len--;
			}
	} while (FALSE);

	return dwRCVal;
}

/*++
GetCfgString

Description:
Read the value of the desired config key name

Arguments:
[in]	char	*pbFileName		Pointer to name of file
[in]	char	*pbSectionName	Pointer to name of section
[in]	char	*pbStringName	Pointer to name of string
[out]	UINT32	*pdwSize		Pointer to buffer size
[out]	BYTE	*pbBuffer		Pointer to buffer

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INV_FILE_SPEC	file or path not found

Author:		Viktor Wallner	2013/02/14
--*/
UINT32 GetCfgString(char *pbFileName, char *pbSectionName, char *pbStringName, UINT32 * pdwSize, BYTE * pbBuffer)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	void *pvFileHandle = NULL;
	char *pcLineBuffer = NULL;
	char *pcCompareBuffer = NULL;
	UINT32 dwLineBufferSize = 512;
	UINT32 dwLineLength = 0;
	BOOL bInRightSection = FALSE;
	UINT32 dwStringNameLength = 0;
	UINT32 i = 0;

	do {
		dwRCVal = FileOpen(pbFileName, &pvFileHandle, FILE_READ);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwStringNameLength = (UINT32)strlen(pbStringName);

		SAFE_CALLOC(pcLineBuffer, dwLineBufferSize, &dwRCVal);
		SAFE_CALLOC(pcCompareBuffer, dwStringNameLength+1, &dwRCVal);

		do {
			dwRCVal = FileReadLine(pvFileHandle, pcLineBuffer, dwLineBufferSize, &dwLineLength);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwRCVal = RC_E_FAILURE;
			if (dwLineLength > 0) {
				if (pcLineBuffer[0] == '[' && pcLineBuffer[dwLineLength-1] == ']') {
					bInRightSection = (strcasecmp(pbSectionName, pcLineBuffer) == 0);
				}
				else if (bInRightSection) {
					memcpy(pcCompareBuffer, pcLineBuffer, dwStringNameLength);
					pcCompareBuffer[dwStringNameLength] = '\0';

					if (strcasecmp(pbStringName, pcCompareBuffer) == 0) {
						i = dwStringNameLength;
						// jump over whitespaces
						while(++i < dwLineLength && (pcLineBuffer[i] == ' ' || pcLineBuffer[i] == '\t'));
						// check for =
						if (pcLineBuffer[i] != '=') {	
							dwRCVal = RC_E_SYNTAXERROR;
						}
						// jump over whitespaces
						while(++i < dwLineLength && (pcLineBuffer[i] == ' ' || pcLineBuffer[i] == '\t'));
						// we're at our value (might be empty!)
						*pdwSize = min(dwLineLength - i, MAX_VAL_LEN);
						memcpy(pbBuffer, pcLineBuffer + i, *pdwSize);
						pbBuffer[(*pdwSize)] = '\0';
						dwRCVal = RC_SUCCESS;
						break;
					}
				}
			}
		} while (!FileEOF(pvFileHandle));

	} while (FALSE);

	FileClose(&pvFileHandle);
	SAFE_FREE(pcLineBuffer);	
	SAFE_FREE(pcCompareBuffer);	

	return dwRCVal;
}

/*++
GetCfgBinaryValue

Description:
Read the value of the desired config key name and convert it to a binary value

Arguments:
[in]	char	*pbFileName		Pointer to name of file
[in]	char	*pbSectionName	Pointer to name of section
[in]	char	*pbStringName	Pointer to name of string
[out]	UINT32	*pdwValue		Pointer to the binary value read from the config file

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INV_FILE_SPEC	file or path not found

Author:		Viktor Wallner	2013/02/14
--*/
UINT32 GetCfgBinaryValue(char *pbFileName, char *pbSectionName, char *pbStringName, UINT32 *pdwValue) {
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT32 pdwSize = 0;
	BYTE abStrValue[MAX_VAL_LEN];

	dwRCVal = GetCfgString(pbFileName, pbSectionName, pbStringName, &pdwSize, abStrValue);
	if (dwRCVal == RC_SUCCESS) {
		dwRCVal = Asc2Bin((char*)abStrValue, pdwValue);
	}

	return dwRCVal;
}

/*++
ReadBufferFromHexFile

Description:
Read content of a file into the supplied buffer

Arguments:
[in]	char	*pcFileName		Pointer to name of file
[out]	BYTE	*pbBuffer		Pointer to buffer
[in]	UINT16	*pwBufferLen	Pointer to buffer size

Return value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_FILE_EMPTY		file is empty
	RC_E_FILE2LARGE		file is too large
	RC_E_INV_FILE_SPEC	file or path not found

Author:		Viktor Wallner	2013/02/14
--*/
UINT32 ReadBufferFromHexFile(char *pcFileName, BYTE *pbBuffer, UINT16 *pwBufferLen)
{
	UINT32 dwRCVal = RC_SUCCESS;
	void* pvFileHandle = NULL;
	BYTE* pbReadBuffer = NULL;
	UINT32 wReadBufferSize = 256;
	UINT32 wBytesRead = 0;
	UINT32 i = 0;
	
	BYTE bCurrentByte = 0;	
	UINT16 wNibbleCount = 0, wTxBufferSize = 0;
	BOOL bInLineComment = FALSE, bInBlockComment = FALSE, bFinishByte = FALSE;
	BYTE bCache[3];

	do {
		wTxBufferSize = *pwBufferLen;
		*pwBufferLen = 0;

		// Open File
		dwRCVal = FileOpen(pcFileName, &pvFileHandle, FILE_READ);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		// Allocate memory for our read buffer
		SAFE_CALLOC(pbReadBuffer, wReadBufferSize, &dwRCVal); 

		bCache[0] = bCache[1] = bCache[2] = 0;
		do {
			// Read file and fill our read buffer
			dwRCVal = FileRead(pvFileHandle, pbReadBuffer, wReadBufferSize, &wBytesRead);
			if (dwRCVal != RC_SUCCESS || wBytesRead == 0) {
				break;
			}

			// Process read buffer
			for(i = 0; i < wBytesRead; i++) {
				bCache[2] = bCache[1];
				bCache[1] = bCache[0];
				bCache[0] = pbReadBuffer[i];
				bFinishByte = FALSE;

				// check if it's the start of a comment
				// the check for bCache[2] != '*' is necessary so we dont miss the first char
				// following the end of a block comment e.g. we would miss the C in >>/* block comment */C1 00<<
				if (bCache[1] == '/' && bCache[2] != '*' &&!bInBlockComment && !bInLineComment) {	
					if (bCache[0] == '/') { // Line Comment
						bInLineComment = TRUE;
					}
					else if (bCache[0] == '*') { // Block Comment
						bInBlockComment = TRUE;
					}
					else {
						dwRCVal = RC_E_SYNTAXERROR;
						break;
					}
					bFinishByte = TRUE;
				}
				else if (bCache[0] == '\n' || bCache[0] == '\r') { // Line Ending
					bInLineComment = FALSE;
					bFinishByte = TRUE;
				}
				else if (bCache[1] == '*' && bCache[0] == '/' && bInBlockComment) { // End of Block Comment
					bInBlockComment = FALSE;
					continue;
				}
				else if (bInBlockComment || bInLineComment) { // Comment -> All chars allowed
					continue;
				}
				else if (bCache[0] == ' ' || bCache[0] == '\t') { // Whitespace
					bFinishByte = TRUE;
				}
				else if (bCache[0] >= '0' && bCache[0] <= '9') {
					bCurrentByte = bCurrentByte << 4 | (bCache[0] - 0x30);
					wNibbleCount++;
				}
				else if (bCache[0] >= 'A' && bCache[0] <= 'F') {
					bCurrentByte = bCurrentByte << 4 | (bCache[0] - 0x37);
					wNibbleCount++;
				}
				else if (bCache[0] >= 'a' && bCache[0] <= 'f') {
					bCurrentByte = bCurrentByte << 4 | (bCache[0] - 0x57);
					wNibbleCount++;
				}				
				else if (bCache[0] != '/') {
					dwRCVal = RC_E_SYNTAXERROR;
					break;
				}

				// Add the current byte to the output buffer
				if (wNibbleCount == 2 || (wNibbleCount > 0 && bFinishByte)) {
					if (*pwBufferLen < wTxBufferSize) {
						pbBuffer[(*pwBufferLen)++] = bCurrentByte;
						bCurrentByte = 0;
						wNibbleCount = 0;
					}
					else {
						dwRCVal = RC_E_FILE2LARGE;
						break;
					}
				}
			}
			if (dwRCVal != RC_SUCCESS) {
				break;
			}
		} while(TRUE);
	} while (FALSE);

	if (dwRCVal == RC_SUCCESS && *pwBufferLen == 0) {
		dwRCVal = RC_E_FILE_EMPTY;
	}

	if (pvFileHandle != NULL) {
		FileClose(&pvFileHandle);
	}

	SAFE_FREE(pbReadBuffer);

	return dwRCVal;
}

/*++
WriteBuffer2HexFile

Description:
Write content of the supplied buffer into a file

Arguments:
[in]	char	*pbFileName		Pointer to name of file
[out]	BYTE	*pbBuffer		Pointer to buffer
[in]	UINT16	*pwBufferLen	Pointer to buffer size

Return value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INV_FILE_SPEC	file or path not found
	RC_E_NODISKSPC		not enough disk space is available
	RC_E_NO_MEMORY		not enough memory in Heap available

Author:		Markus Schmoelzer	2007/02/23
--*/
UINT32 WriteBuffer2HexFile(char *pbFileName, BYTE * pbBuffer, UINT16 wBufferLen)
{
	UINT32 dwRCVal = RC_SUCCESS;
	BYTE *pbASCIIBuffer = NULL;
	UINT16 wASCIIBufferLen = 0;
	void* pvFileHandle = NULL;

	do {
		// Widen buffer length to the size needed for hexadecimal instead of binary data
		wASCIIBufferLen = wBufferLen * 3 - 1;

		// Open temporary buffer for hexadecimal data
		SAFE_CALLOC(pbASCIIBuffer, wASCIIBufferLen, &dwRCVal);

		Bin2Asc(pbBuffer, wBufferLen, pbASCIIBuffer, wASCIIBufferLen);

		dwRCVal = FileOpen(pbFileName, &pvFileHandle, FILE_WRITE|FILE_CLEAR);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = FileWrite(pvFileHandle, pbASCIIBuffer, wASCIIBufferLen);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

	} while (FALSE);

	FileClose(&pvFileHandle);

	SAFE_FREE(pbASCIIBuffer);

	return dwRCVal;
}

/************************************************************************************
								File handlers
 ************************************************************************************/
void OpenLogFile(char *filename)
{
	UINT32 dwRCVal;
	
	dwRCVal = FileOpen(filename, &pvLogFileHandle, FILE_WRITE | FILE_CLEAR);

	if (dwRCVal != RC_SUCCESS) {
		ConsoleWritef("Can't open log file \"%s\"!\n", filename);
	}
}

//-------------------------------------------------------------------------------
void CloseLogFile(char *filename)
{

	FileClose(&pvLogFileHandle);
	pvLogFileHandle = NULL;

	ConsoleWritef("\nLog file \"%s\" saved\n", filename);
}

//-------------------------------------------------------------------------------

UINT32 SaveToFile(char *pcFileName, BYTE * pbData, UINT32 dwDataLen, BYTE wMode)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	BYTE *pbASCIIBuffer = NULL;
	BYTE *pbWriteBuffer = NULL;
	UINT32 dwWriteBufferLen = 0;
	void *pvFileHandle = NULL;	

	do {
		dwRCVal = FileOpen(pcFileName, &pvFileHandle, FILE_WRITE|FILE_CLEAR);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		if (wMode == MD_HEX) {
			 // in hex, we have dwDataLen*3-1 chars, as the hex values are separated by a spaces
			dwWriteBufferLen = dwDataLen * 3 - 1;
			SAFE_CALLOC(pbASCIIBuffer, dwWriteBufferLen, &dwRCVal);
			Bin2Asc(pbData, dwDataLen, pbASCIIBuffer, dwWriteBufferLen);
			pbWriteBuffer = pbASCIIBuffer;
		}
		else {
			dwWriteBufferLen = dwDataLen;
			pbWriteBuffer = pbData;
		}

		dwRCVal = FileWrite(pvFileHandle, pbWriteBuffer, dwWriteBufferLen);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
	} while (FALSE);

	FileClose(&pvFileHandle);

	SAFE_FREE(pbASCIIBuffer);

	return dwRCVal;
}

/*++
FileOpen

Description:
Opens a file and returns the file handle in the out argument **ppvFileAndle

Arguments:
[in]	char * pbFileName		Pointer to name of file
[out]	void **ppvFileHandle	Pointer to the file handle
[in]	UINT16 wFileFlags	    Open Mode (FILE_READ, FILE_WRITE, FILE_CLEAR, FILE_APPEND)

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_INV_FILE_SPEC	file or path not found

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileOpen(char *pcFileName, void **ppvFileHandle, UINT16 wFileFlags)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT32 dwFileSize = 0;

	#ifdef UEFI_X64
	EFI_STATUS Status;
	CHAR16 *pwFileName;
	UINT64 qwOpenMode = 0;
		
	do {
		SAFE_CALLOC(pwFileName, (AsciiStrSize(pcFileName)+1)*sizeof(CHAR16), &dwRCVal);
		AsciiStrToUnicodeStr(pcFileName, pwFileName);

		if (ShellIsDirectory(pwFileName) == EFI_SUCCESS) {
			dwRCVal = RC_E_INV_FILE_SPEC;
			break;
		}

		if (ShellIsFile(pwFileName) != EFI_SUCCESS && wFileFlags & FILE_WRITE) {
			qwOpenMode |= EFI_FILE_MODE_CREATE;
		}
		else if (wFileFlags & FILE_CLEAR) {
			if (ShellOpenFileByName(pwFileName, ppvFileHandle, EFI_FILE_MODE_WRITE|EFI_FILE_MODE_READ|EFI_FILE_MODE_CREATE, 0) == EFI_SUCCESS) {
				ShellDeleteFile(ppvFileHandle);
			}
			qwOpenMode |= EFI_FILE_MODE_CREATE;
		}

		qwOpenMode = qwOpenMode | ((wFileFlags & FILE_WRITE) ? EFI_FILE_MODE_WRITE|EFI_FILE_MODE_READ : EFI_FILE_MODE_READ);		
		Status = ShellOpenFileByName(pwFileName, ppvFileHandle, qwOpenMode, 0);
		switch(Status) {
			case EFI_SUCCESS:
				dwRCVal = RC_SUCCESS;
				break;
			case EFI_NOT_FOUND:
				dwRCVal = RC_E_INV_FILE_SPEC;
				break;
			default:
				dwRCVal = RC_E_FAILURE;
		}
	} while (FALSE);

	SAFE_FREE(pwFileName);
	#else	
	*ppvFileHandle = NULL;
	if (wFileFlags & FILE_WRITE) {
		if (!(wFileFlags & FILE_CLEAR)) { // try to open an existing file without discarding its content
			*ppvFileHandle = fopen(pcFileName, "r+b");
		}
		if (*ppvFileHandle == NULL) { // open an existing file and discard all content or create a new file
			*ppvFileHandle = fopen(pcFileName, "w+b");
		}
	}
	else { // open the file read-only
		*ppvFileHandle = fopen(pcFileName, "rb");
	}
	
	if (*ppvFileHandle != NULL) {
		dwRCVal = RC_SUCCESS;
	}
	else {
		dwRCVal = RC_E_INV_FILE_SPEC;
	}
	#endif

	if (dwRCVal != RC_SUCCESS) {
		*ppvFileHandle = 0;
	}
	else if ((wFileFlags & FILE_APPEND)) {
		// set the file position to the end of the file
		dwRCVal = FileGetSize(*ppvFileHandle, &dwFileSize);
		if (dwRCVal != RC_SUCCESS) {
			dwRCVal = FileClose(ppvFileHandle);
		}
		else {
			FileSetPosition(*ppvFileHandle, dwFileSize);
		}
	}

	return dwRCVal;
}

/*++
FileClose

Description:
Closes a file

Arguments:
[int]	void  **pvFileHandle	Pointer to the file handle

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileClose(void **ppvFileHandle)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	if (*ppvFileHandle != NULL)
	{
		#ifdef UEFI_X64
		if (ShellCloseFile(ppvFileHandle) == EFI_SUCCESS) {
			dwRCVal = RC_SUCCESS;
		}
		#else
		if (fclose((FILE*)*ppvFileHandle) == 0) {
			dwRCVal = RC_SUCCESS;
		}
		#endif
	}

	*ppvFileHandle = NULL;

	return dwRCVal;
}

/*++
FileGetSize

Description:
Gets the size of a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[out]	UINT32 *pdwFileSize	    Pointer to the file size

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileGetSize(void *pvFileHandle, UINT32 *pdwFileSize)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	#ifdef UEFI_X64
	UINT64 qwFileSize = 0;
	if (pvFileHandle != NULL && ShellGetFileSize(pvFileHandle, &qwFileSize) == EFI_SUCCESS)
	{
		*pdwFileSize = (UINT32)qwFileSize;
		dwRCVal = RC_SUCCESS;
	}
	#else
	do {
		long qwCurrentPosition;
		if (pvFileHandle != NULL) {
			qwCurrentPosition = ftell((FILE*)pvFileHandle);
			if (fseek((FILE*)pvFileHandle, 0, SEEK_END) != 0) {	
				break;
			}
			*pdwFileSize = (UINT32)ftell((FILE*)pvFileHandle);
			if (*pdwFileSize < 0) {
				break;			
			}
			if (fseek((FILE*)pvFileHandle, qwCurrentPosition, SEEK_SET) == 0) {
				dwRCVal = RC_SUCCESS;
			}
		}
	} while (FALSE);
	#endif

	if (dwRCVal != RC_SUCCESS) {		
		*pdwFileSize = 0;
	}

	return dwRCVal;
}

/*++
FileGetPosition

Description:
Gets the current position in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[out]	UINT32 *pdwFilePosition	Pointer to the current position in the file

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileGetPosition(void *pvFileHandle, UINT32 *pdwFilePosition)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	#ifdef UEFI_X64
	UINT64 qwFilePosition = 0;
	if (pvFileHandle != NULL && ShellGetFilePosition(pvFileHandle, &qwFilePosition) == EFI_SUCCESS){
		*pdwFilePosition = (UINT32)qwFilePosition;
		dwRCVal = RC_SUCCESS;
	}
	#else
	long qwFilePosition = -1;

	if (pvFileHandle != NULL) {
		qwFilePosition = (UINT32)ftell((FILE*)pvFileHandle);
		if (qwFilePosition >= 0) {
			*pdwFilePosition = (UINT32)qwFilePosition;
			dwRCVal = RC_SUCCESS;
		}
	}
	#endif

	if (dwRCVal != RC_SUCCESS) {
		*pdwFilePosition = 0;
	}

	return dwRCVal;
}

/*++
FileSetPosition

Description:
Sets the position in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[in]	UINT32  qwFilePosition	The position to set

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileSetPosition(void *pvFileHandle, UINT32 qwFilePosition)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	#ifdef UEFI_X64
	if (pvFileHandle != NULL && ShellSetFilePosition(pvFileHandle, (UINT64)qwFilePosition) == EFI_SUCCESS){
		dwRCVal = RC_SUCCESS;
	}
	#else
	if (pvFileHandle != NULL && fseek((FILE*)pvFileHandle, (long)qwFilePosition, SEEK_SET) == 0) {	
		dwRCVal = RC_SUCCESS;
	}
	#endif

	return dwRCVal;
}

/*++
FileRead

Description:
Reads a porition of data from the current position in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[out]	BYTE   *pbBuffer		Pointer to the read buffer
[in]	UINT32  pwBufferLen		Size of the read buffer
[out]	UINT32 *pwBytesRead		Pointer to the number of bytes successfully read from the file

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileRead(void *pvFileHandle, BYTE *pbBuffer, UINT32 pwBufferLen, UINT32 *pwBytesRead)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	#ifdef UEFI_X64
	UINT32 qwFileSize = 0;
	UINT32 qwFilePosition = 0;
	UINTN dwBytesCount;
	BYTE* pbEFIBuffer = NULL;

	if (pvFileHandle != NULL) {
		do {
			// UEFI somehow always reads till the end of the file, so we have to mimic
			// the behaviour of reading just the number of bytes specified by pwBufferLen
			// (or till the end of the file)
			dwRCVal = FileGetSize(pvFileHandle, &qwFileSize);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			dwRCVal = FileGetPosition(pvFileHandle, &qwFilePosition);
			if (dwRCVal != RC_SUCCESS) {
				break;
			}

			SAFE_CALLOC(pbEFIBuffer, qwFileSize - qwFilePosition, &dwRCVal);

			dwBytesCount = min(pwBufferLen, qwFileSize - qwFilePosition);
		
			if (ShellReadFile(pvFileHandle, &dwBytesCount, pbEFIBuffer) != EFI_SUCCESS) {
				dwRCVal = RC_E_FAILURE;
				break;
			}
			// dwBytesCount contains the number of bytes read from the file
			if (dwBytesCount < pwBufferLen) {
				*pwBytesRead = (UINT16)dwBytesCount;
			}
			else {
				*pwBytesRead = pwBufferLen;
				qwFilePosition += *pwBytesRead;
				if (ShellSetFilePosition(pvFileHandle, qwFilePosition) != EFI_SUCCESS) {
					dwRCVal = RC_E_FAILURE;
					break;
				}
			}
			// copy the bytes read to the real buffer limited to the correct number of bytes
			memcpy(pbBuffer, pbEFIBuffer, *pwBytesRead);
		} while (FALSE);
	}

	SAFE_FREE(pbEFIBuffer);
	#else
	if (pvFileHandle != NULL) {
		*pwBytesRead = (UINT32)fread(pbBuffer, 1, pwBufferLen, (FILE *)pvFileHandle);
		if (!ferror((FILE*)pvFileHandle)) {		
			dwRCVal = RC_SUCCESS;
		}
	}
	#endif

	if (dwRCVal != RC_SUCCESS) {
		*pwBytesRead = 0;
	}

	return dwRCVal;
}

/*++
FileReadLine

Description:
Reads the next file in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[out]	char   *pcBuffer		Pointer to the read buffer
[in]	UINT32  pwBufferLen		Size of the read buffer
[out]	UINT32 *pwLineLength	Pointer to the number of characters successfully read from the file

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileReadLine(void *pvFileHandle, char *pcBuffer, UINT32 pwBufferLen, UINT32 *pwLineLength)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	UINT32 dwFilePosition = 0;
	BYTE* pbReadBuffer = NULL;
	UINT32 dwReadBufferSize = 256;
	UINT32 dwBytesRead = 0;
	UINT32 dwBytesProcessed = 0;
	UINT32 i = 0;
	BYTE bCurrentByte = 0;
	BYTE bNextByte = 0;	
	BOOL bLineEndFound = FALSE;

	do {		
		// safe the current file position
		dwRCVal = FileGetPosition(pvFileHandle, &dwFilePosition);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		SAFE_CALLOC(pbReadBuffer, dwReadBufferSize, &dwRCVal);
		*pwLineLength = 0;

		do {

			dwRCVal = FileRead(pvFileHandle, pbReadBuffer, dwReadBufferSize, &dwBytesRead);
			if (dwRCVal != RC_SUCCESS || dwBytesRead == 0) {
				break;
			}

			for (i = 0; i < dwBytesRead; i++) {				
				bCurrentByte = pbReadBuffer[i];
				bNextByte = (i < dwBytesRead - 1) ? pbReadBuffer[i+1] : 0;

				if (bCurrentByte == '\r' || bCurrentByte == '\n' ) {
					if ((bNextByte == '\r' || bNextByte == '\n') && bCurrentByte != bNextByte) {
						dwBytesProcessed++;
					}
					dwBytesProcessed++;
					bLineEndFound = TRUE;
					break;
				}
				else
				{
					if (*pwLineLength < pwBufferLen - 1) {
						pcBuffer[(*pwLineLength)++] = bCurrentByte;					
						dwBytesProcessed++;
					} else {
						dwRCVal = RC_E_INSUFFICIENT_BUFFER;
						break;
					}
				}				
			}

			if (dwRCVal != RC_SUCCESS || bLineEndFound) {
				break;
			}
		} while (!FileEOF(pvFileHandle));

		pcBuffer[(*pwLineLength)] = '\0';

		FileSetPosition(pvFileHandle, dwFilePosition + dwBytesProcessed);

	} while (FALSE);	

	SAFE_FREE(pbReadBuffer);

	return dwRCVal;
}

/*++
FileReadAll

Description:
Opens a file, reads all content and finally closes the file.

Arguments:
[in]	char   *pbFileName		Pointer to the name of file
[out]	char   *pcBuffer		Pointer to the read buffer
[in]	UINT32  pwBufferLen		Size of the read buffer
[out]	UINT32 *pwLineLength	Pointer to the number of characters successfully read from the file

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileReadAll(char *pcFileName, BYTE *pbBuffer, UINT32 pwBufferLen, UINT32 *pwBytesRead)
{
	UINT32 dwRCVal = RC_E_FAILURE;
	void *pvFileHandle = NULL;

	do {
		dwRCVal = FileOpen(pcFileName, &pvFileHandle, FILE_READ);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}

		dwRCVal = FileRead(pvFileHandle, pbBuffer, pwBufferLen, pwBytesRead);
		if (dwRCVal != RC_SUCCESS) {
			break;
		}
	} while (FALSE);

	FileClose(&pvFileHandle);

	return dwRCVal;
}

/*++
FileWrite

Description:
Writes data to the current position in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[int]	BYTE   *pbBuffer		Pointer to the read buffer
[in]	UINT32  dwBufferLen		Size of the read buffer

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_NODISKSPC		not enough free space to complete the write action

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileWrite(void *pvFileHandle, BYTE *pbBuffer, UINT32 dwBufferLen)
{
	UINT32 dwRCVal = RC_E_FAILURE;

	#ifdef UEFI_X64
	UINTN dwBytesWritten = 0;
	EFI_STATUS wStatus = 0;

	if (pvFileHandle != NULL) {
		dwBytesWritten = dwBufferLen;
		wStatus = ShellWriteFile(pvFileHandle, &dwBytesWritten, pbBuffer);
		switch(wStatus) {
			case EFI_SUCCESS:
				dwRCVal = RC_SUCCESS;
				break;
			case EFI_VOLUME_FULL:
				dwRCVal = RC_E_NODISKSPC;
				break;
			default:
				dwRCVal = RC_E_FAILURE;
		}
	}
	#else
	size_t szWrittenBytes;

	if (pvFileHandle != NULL) {
		szWrittenBytes = fwrite(pbBuffer, 1, dwBufferLen, (FILE*)pvFileHandle);	
		if (szWrittenBytes < dwBufferLen) {
			dwRCVal = RC_E_NODISKSPC;
		}
		else
		{
			dwRCVal = RC_SUCCESS;
		}

		fflush((FILE*)pvFileHandle);
	}
	#endif

	return dwRCVal;
}

/*++
FileWriteString

Description:
Writes a string to the current position in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[in]	char   *pcString		Pointer to the string

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_NODISKSPC		not enough free space to complete the write action

Author:		Viktor Wallner 2013/02/14
--*/
UINT32 FileWriteString(void *pvFileHandle, char *pcString) {
	UINT32 dwRCVal = RC_E_FAILURE;
	char* pcStart = NULL;
	char* pcPos = NULL;
	UINT32 dwLength = 0;

	pcStart = pcString;
	dwLength = (UINT32)strlen(pcString);

	while(pcString < pcStart + dwLength) {
		pcPos = strchr(pcString, '\n');

		if (pcPos == NULL) {
			pcPos = pcStart + dwLength;
		}

		dwRCVal = FileWrite(pvFileHandle, (BYTE*)pcString, (UINT32)(pcPos - pcString));
		if (dwRCVal != RC_SUCCESS || pcPos == pcStart + dwLength) {
			break;
		}
		if (pcPos > pcStart && *(pcPos-1) == '\r') {
			dwRCVal = FileWrite(pvFileHandle, (BYTE*)"\n", 1);
		}
		else {
			dwRCVal = FileWrite(pvFileHandle, (BYTE*)"\r\n", 2);
		}
		
		if (dwRCVal != RC_SUCCESS) {
			break;
		}		
		pcString = pcPos + 1;		
	}

	return dwRCVal;
}

/*++
FileWriteStringf

Description:
Writes a formatted string to the current position in a file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle
[in]	char   *pcFormat		String format
[in]	...						optional arguments

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_NODISKSPC		not enough free space to complete the write action

Author:		Viktor Wallner 2013/02/21
--*/
UINT32 FileWriteStringf(void *pvFileHandle, char *pcFormat, ...) {
	UINT32 dwRCVal = RC_E_FAILURE;
	va_list pcArguments;

	do {
		va_start(pcArguments, pcFormat);
		dwRCVal = FileWriteStringvf(pvFileHandle, pcFormat, pcArguments);
		va_end(pcArguments);

	} while ( FALSE );

	return dwRCVal;
}

/*++
FileWriteStringvf

Description:
Writes a formatted string to the current position in a file, using a va_list

Arguments:
[in]	void	*pvFileHandle	Pointer to the file handle
[in]	char	*pcFormat		String format
[in]	va_list	 pcArguments	arguments

Return Value:
	Return				Meaning
	======				=======
	RC_SUCCESS			operation completed successfully
	RC_E_FAILURE		operation failed
	RC_E_NODISKSPC		not enough free space to complete the write action

Author:		Viktor Wallner 2013/02/21
--*/
UINT32 FileWriteStringvf(void *pvFileHandle, char *pcFormat, va_list pcArguments) {
	UINT32 dwRCVal = RC_E_FAILURE;
	char *pcBuffer = NULL;
	UINT32 dwBufferSize;

	do {
		if (strchr(pcFormat, '%') != NULL) {
			dwBufferSize = GetFormattedBufferSizev(pcFormat, pcArguments);
			SAFE_CALLOC(pcBuffer, dwBufferSize, &dwRCVal);
			FormatStringv(pcBuffer, dwBufferSize, pcFormat, pcArguments);
			dwRCVal = FileWriteString(pvFileHandle, pcBuffer);
		}
		else {
			dwRCVal = FileWriteString(pvFileHandle, pcFormat);
		}
	} while ( FALSE );

	SAFE_FREE(pcBuffer);

	return dwRCVal;
}

/*++
FileEOF

Description:
Returns true if the current position in a file points to the end of the file

Arguments:
[in]	void   *pvFileHandle	Pointer to the file handle

Return Value:
	Return				Meaning
	======				=======
	TRUE				The files current position points to the end of the file
	FALSE				The files current position does not point to the end of the file

Author:		Viktor Wallner 2013/02/14
--*/
BOOL FileEOF(void *pvFileHandle)
{
	#ifdef UEFI_X64
		UINT32 qwFilePosition = 0;
		UINT32 qwFileSize = 0;

		FileGetSize(pvFileHandle, &qwFileSize);
		FileGetPosition(pvFileHandle, &qwFilePosition);

		return qwFilePosition >= qwFileSize;
	#else
		int c;
		c = fgetc((FILE*)pvFileHandle); // peek for EOL
		ungetc(c, (FILE*)pvFileHandle); // ungetc doesn't alter the stream if c is EOL
		return feof((FILE*) pvFileHandle) ? TRUE : FALSE;
	#endif
}