#define NT_PORT_REGISTERED
#define NT_PORT_USER_NAME	"Infineon Technologies"
#define NT_PORT_KEY			196560
#define MEMACC_REGISTERED
#define MEMACC_USER_NAME	"Infineon Technologies"
#define MEMACC_KEY			217665711
