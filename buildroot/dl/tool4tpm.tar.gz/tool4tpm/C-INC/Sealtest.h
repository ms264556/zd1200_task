/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Sealtest.h

Description:	Header file for the TPM Sealtest

Author:			Georg Rankl	2009/03/16

Environment:	16-Bit/DOS, 32-Bit/Windows, 32-Bit/Linux

Revision History:

Notes:

--*/

#ifndef __SEALTEST_H__
#define __SEALTEST_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

// Perform a Sealtest
extern UINT32 TPMSealTest(void);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __SEALTEST_H__
