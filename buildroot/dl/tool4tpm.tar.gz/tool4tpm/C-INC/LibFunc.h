/*++

Copyright (c) 2012	Infineon Technologies AG

Module Name:	FileIO.h

Description:	Header file for the file I/O help routines

Author:		Peter Huewe 2012/07/26

Environment:	32/64 Bit Linux

Revision History:

Notes:

--*/

#ifndef __LIBFUNC_H__
#define __LIBFUNC_H__
int is_regfile (char * pbFileName);
int is_dir (char * pbFileName);
#endif
