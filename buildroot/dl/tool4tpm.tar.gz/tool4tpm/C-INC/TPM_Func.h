/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Func.h

Description:	Header file for the TPM control functions

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TPM_FUNC_H__
#define __TPM_FUNC_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

// user defined value for NV indexed access
#define USER_DEF_INDEX 0x20000004

extern BOOL bNegativeTest;

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

// Create the Endorsement Key Pair
UINT32 CreateEndorsementKeyPair(void);

// Read the Endorsement Key Certificate
UINT32 ReadEKCertificate(BYTE * pCert, UINT32 * pdwCertSize);

// Send the content from CmdFile to the TPM and receive the response into RspFile
UINT32 GetTPMCmdFromFile(char *pcCmdFileName, char *pcRspFileName);

// Perform a SHA-1 digest
UINT32 SHA1test(UINT32 dwHashDataSize, BYTE * pbHashData, BYTE * pbHashValue);
UINT32 SHA1Complete(UINT32 dwHashDataSize, BYTE * pbHashData, BYTE * pbHashValue);

// This capability terminates a pending SHA-1 calculation and EXTENDS the result into a
// Platform Configuration Register using a SHA-1 hash process.
UINT32 SHA1CompleteExtend(void);

// Show TPM1.1 info and capabilities
UINT32 ShowTPM11info(void);

// Show TPM1.2 info and capabilities
UINT32 ShowTPM12info(void);

// Provide a configurable TPM status check function
UINT32 FlagCheck(char *pcFlagCheckFileName);

// Perform a test of the TPM step-by-step or continuous
UINT32 TestTPM(BYTE bTestType);

// The TPM owner sets the PERMANENT disable flag
UINT32 OwnerSetDisable(void);

// This command allows the operator of the platform to deactivate the TPM until the next boot
// of the platform.
UINT32 SetTempDeactivated(BOOL bWithAuth);

// This command allows the setting of the operator AuthData value.
UINT32 SetOperatorAuth(void);

// Take TPM Ownership with owner password from config file
UINT32 TakeOwnership(void);

// The OwnerClear command performs the clear operation under Owner authentication.
UINT32 OwnerClear(void);

// This command sets values in the TPM.
UINT32 SetCapability(BOOL bWithAuth);

// The SEAL operation allows software to explicitly state the future trusted configuration
// that the platform must be in for the secret to be revealed.
UINT32 Seal(void);

// The TPM_Unseal operation will reveal TPM_Seal'ed data only if it was encrypted on this
// platform and the current configuration (as defined by the named PCR contents) is the one
// named as qualified to decrypt it.
UINT32 Unseal(void);

// The TPM_CreateWrapKey command both generates and creates a secure storage bundle for
// asymmetric keys.
UINT32 CreateWrapKey(void);

// The TPM_LoadKey2 function loads the
// key into the TPM for further use.
UINT32 LoadKey2(void);

// The owner of a key may wish to obtain the public key value from a loaded key.
UINT32 GetPubKey(BOOL bWithAuth);

// This adds a new measurement to a PCR
UINT32 Extend(void);

// This adds a new measurement to a PCR
UINT32 PCRRead(void);

// For PCR with the pcrReset attribute set to TRUE, this command resets the PCR back to the
// default value, this mimics the actions of TPM_Init.
UINT32 PCR_Reset(void);

// The TPM_OSAP command creates the authorization session handle, the shared secret and
// generates nonceEven and nonceEvenOSAP.
UINT32 OSAP(void);

// This establishes the space necessary for the indicated index.
UINT32 NV_DefineSpace(BOOL bWithAuth);

// This command writes the value to a defined area.
UINT32 NV_WriteValue(BOOL bWithAuth);

// Read a value from the NV store. This command uses owner authentication.
UINT32 NV_ReadValue(void);

// TPM_FlushSpecific flushes from the TPM a specific handle.
UINT32 FlushSpecific(void);

// This command returns the current tick count of the TPM.
UINT32 GetTicks(void);

// Gets if the TPM owner is set
BOOL IsTPMOwned(void);

// Gets if the TPM is enabled
BOOL IsTPMEnabled(void);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TPM_FUNC_H__
