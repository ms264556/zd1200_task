/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Stru.h

Description:	Definition of the TPM structures according to TCG Main Specification Version 1.2

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TPM_STRU_H__
#define __TPM_STRU_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "TPM_Type.h"

// Maximum sizes for dynamic command response structure elements
// (Values are arbitrary and may be changed if necessary.)
#define ST_EL_BIG_SZ	100
#define ST_EL_SML_SZ	50

#pragma pack(push, 1)

// Structure definitions ========================================================================
typedef struct tdUINT64 {
	BYTE bUINT64[8];
} TPM_UINT64;

//-------------------------------------------------------------------
typedef struct tdTPM_STRUCT_VER {
	BYTE major;
	BYTE minor;
	BYTE revMajor;
	BYTE revMinor;
} TPM_STRUCT_VER;

//-------------------------------------------------------------------
typedef struct tdTPM_VERSION {
	TPM_VERSION_BYTE major;
	TPM_VERSION_BYTE minor;
	BYTE revMajor;
	BYTE revMinor;
} TPM_VERSION;

//-------------------------------------------------------------------
typedef struct tdTPM_DIGEST {
	BYTE digest[20];
} TPM_DIGEST;

typedef TPM_DIGEST TPM_CHOSENID_HASH;
typedef TPM_DIGEST TPM_COMPOSITE_HASH;
typedef TPM_DIGEST TPM_DIRVALUE;
typedef TPM_DIGEST TPM_HMAC;
typedef TPM_DIGEST TPM_PCRVALUE;
typedef TPM_DIGEST TPM_AUDITDIGEST;
typedef TPM_DIGEST TPM_DAA_TPM_SEED;
typedef TPM_DIGEST TPM_DAA_CONTEXT_SEED;

//-------------------------------------------------------------------
typedef struct tdTPM_NONCE {
	BYTE nonce[20];
} TPM_NONCE;

//-------------------------------------------------------------------
typedef struct tdTPM_AUTHDATA {
	BYTE authdata[20];
} TPM_AUTHDATA;

typedef TPM_AUTHDATA TPM_SECRET;
typedef TPM_AUTHDATA TPM_ENCAUTH;

//-------------------------------------------------------------------
typedef struct tdTPM_KEY_HANDLE_LIST {
	UINT16 loaded;
	TPM_KEY_HANDLE handle[1];	// size_is(loaded)
} TPM_KEY_HANDLE_LIST;

//-------------------------------------------------------------------
typedef struct tdTPM_CHANGEAUTH_VALIDATE {
	TPM_SECRET newAuthSecret;	// new auth. data for target entity
	TPM_NONCE n1;		// a nonce to enable the caller
} TPM_CHANGEAUTH_VALIDATE;

//-------------------------------------------------------------------
// Public Endorsement Key length in Bytes
#define KEY_LEN	256		// IMPORTANT: KEY_LEN is NOT a max value, but the RSA-2048 key length!

typedef struct tdTPM_STORE_PUBKEY {
	UINT32 keyLength;
	BYTE key[KEY_LEN];	// actually: size_is(keyLength)
} TPM_STORE_PUBKEY;

//-------------------------------------------------------------------
typedef struct tdTPM_RSA_KEY_PARMS {
	UINT32 keyLength;
	UINT32 numPrimes;
	UINT32 exponentSize;
//      BYTE    exponent[]; empty for exponent = 2^16+1 // actually: size_is(exponentSize)
} TPM_RSA_KEY_PARMS;

//-------------------------------------------------------------------
typedef struct tdTPM_KEY_PARMS {
	TPM_ALGORITHM_ID algorithmID;
	TPM_ENC_SCHEME encScheme;
	TPM_SIG_SCHEME sigScheme;
	UINT32 parmSize;
	TPM_RSA_KEY_PARMS parms;	// only for RSA-2048! actually: BYTE* parms; size_is(parmSize)
} TPM_KEY_PARMS;

//-------------------------------------------------------------------
typedef struct tdTPM_PUBKEY {
	TPM_KEY_PARMS algorithmParms;
	TPM_STORE_PUBKEY pubKey;
} TPM_PUBKEY;

//-------------------------------------------------------------------
typedef struct tdTPM_MIGRATIONKEYAUTH {
	TPM_PUBKEY migrationKey;
	TPM_MIGRATE_SCHEME migrationScheme;
	TPM_DIGEST digest;
} TPM_MIGRATIONKEYAUTH;

//-------------------------------------------------------------------
typedef struct tdTPM_COUNTER_VALUE {
	TPM_STRUCTURE_TAG tag;
	BYTE label[4];
	TPM_ACTUAL_COUNT counter;
} TPM_COUNTER_VALUE;

//-------------------------------------------------------------------
typedef struct tdTPM_SIGN_INFO {
	TPM_STRUCTURE_TAG tag;
	BYTE fixed[4];
	TPM_NONCE replay;
	UINT32 dataLen;
	BYTE data[1];		// size_is(dataLen)
} TPM_SIGN_INFO;

//-------------------------------------------------------------------
typedef struct tdTPM_MSA_COMPOSITE {
	UINT32 MSAlist;
	TPM_DIGEST migAuthDigest[1];	// actually: TPM_DIGEST[] migAuthDigest[];
} TPM_MSA_COMPOSITE;

//-------------------------------------------------------------------
typedef struct tdTPM_CMK_AUTH {
	TPM_DIGEST migrationAuthorityDigest;
	TPM_DIGEST destinationKeyDigest;
	TPM_DIGEST sourceKeyDigest;
} TPM_CMK_AUTH;

//-------------------------------------------------------------------
typedef struct tdTPM_SELECT_SIZE {
	BYTE major;
	BYTE minor;
	UINT16 reqSize;
} TPM_SELECT_SIZE;

//-------------------------------------------------------------------
typedef struct tdTPM_CMK_MIGAUTH {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST msaDigest;
	TPM_DIGEST pubKeyDigest;
} TPM_CMK_MIGAUTH;

//-------------------------------------------------------------------
typedef struct tdTPM_CMK_SIGTICKET {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST verKeyDigest;
	TPM_DIGEST signedData;
} TPM_CMK_SIGTICKET;

//-------------------------------------------------------------------
typedef struct tdTPM_CMK_MA_APPROVAL {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST migrationAuthorityDigest;
} TPM_CMK_MA_APPROVAL;

//-------------------------------------------------------------------
typedef struct tdTPM_PERMANENT_FLAGS {
	TPM_STRUCTURE_TAG tag;
	BYTE disable;		// actually: BOOL value using 1 Byte of memory
	BYTE ownership;		// actually: BOOL value using 1 Byte of memory
	BYTE deactivated;	// actually: BOOL value using 1 Byte of memory
	BYTE readPubek;		// actually: BOOL value using 1 Byte of memory
	BYTE disableOwnerClear;	// actually: BOOL value using 1 Byte of memory
	BYTE allowMaintenance;	// actually: BOOL value using 1 Byte of memory
	BYTE physicalPresenceLifetimeLock;	// actly.: BOOL value using 1 Byte of memory
	BYTE physicalPresenceHWEnable;	// actually: BOOL value using 1 Byte of memory
	BYTE physicalPresenceCMDEnable;	// actually: BOOL value using 1 Byte of memory
	BYTE CEKPUsed;		// actually: BOOL value using 1 Byte of memory
	BYTE TPMpost;		// actually: BOOL value using 1 Byte of memory
	BYTE TPMpostLock;	// actually: BOOL value using 1 Byte of memory
	BYTE FIPS;		// actually: BOOL value using 1 Byte of memory
	BYTE bOperator;		// actually: BOOL value using 1 Byte of memory
	BYTE enableRevokeEK;	// actually: BOOL value using 1 Byte of memory
	BYTE nvLocked;		// actually: BOOL value using 1 Byte of memory
	BYTE readSRKPub;	// actually: BOOL value using 1 Byte of memory
	BYTE tpmEstablished;	// actually: BOOL value using 1 Byte of memory
	BYTE maintenanceDone;	// actually: BOOL value using 1 Byte of memory
} TPM_PERMANENT_FLAGS;

//-------------------------------------------------------------------
typedef struct tdTPM_PERMANENT_FLAGS_12_103 {
	TPM_STRUCTURE_TAG tag;
	BYTE disable;		// actually: BOOL value using 1 Byte of memory
	BYTE ownership;		// actually: BOOL value using 1 Byte of memory
	BYTE deactivated;	// actually: BOOL value using 1 Byte of memory
	BYTE readPubek;		// actually: BOOL value using 1 Byte of memory
	BYTE disableOwnerClear;	// actually: BOOL value using 1 Byte of memory
	BYTE allowMaintenance;	// actually: BOOL value using 1 Byte of memory
	BYTE physicalPresenceLifetimeLock;	// actly.: BOOL value using 1 Byte of memory
	BYTE physicalPresenceHWEnable;	// actually: BOOL value using 1 Byte of memory
	BYTE physicalPresenceCMDEnable;	// actually: BOOL value using 1 Byte of memory
	BYTE CEKPUsed;		// actually: BOOL value using 1 Byte of memory
	BYTE TPMpost;		// actually: BOOL value using 1 Byte of memory
	BYTE TPMpostLock;	// actually: BOOL value using 1 Byte of memory
	BYTE FIPS;		// actually: BOOL value using 1 Byte of memory
	BYTE bOperator;		// actually: BOOL value using 1 Byte of memory
	BYTE enableRevokeEK;	// actually: BOOL value using 1 Byte of memory
	BYTE nvLocked;		// actually: BOOL value using 1 Byte of memory
	BYTE readSRKPub;	// actually: BOOL value using 1 Byte of memory
	BYTE tpmEstablished;	// actually: BOOL value using 1 Byte of memory
	BYTE maintenanceDone;	// actually: BOOL value using 1 Byte of memory
	BYTE disableFullDALogicInfo;	// actually: BOOL value using 1 Byte of memory
} TPM_PERMANENT_FLAGS_12_103;

//-------------------------------------------------------------------
typedef struct tdTPM_STCLEAR_FLAGS {
	TPM_STRUCTURE_TAG tag;
	BYTE deactivated;	// actually: BOOL value using 1 Byte of memory
	BYTE disableForceClear;	// actually: BOOL value using 1 Byte of memory
	BYTE physicalPresence;	// actually: BOOL value using 1 Byte of memory
	BYTE physicalPresenceLock;	// actually: BOOL value using 1 Byte of memory
	BYTE bGlobalLock;	// actually: BOOL value using 1 Byte of memory
} TPM_STCLEAR_FLAGS;

//-------------------------------------------------------------------
typedef struct tdTPM_STANY_FLAGS {
	TPM_STRUCTURE_TAG tag;	// actually: BOOL value using 1 Byte of memory
	BYTE postInitialise;
	TPM_MODIFIER_INDICATOR localityModifier;
	BYTE transportExclusive;	// actually: BOOL value using 1 Byte of memory
	BYTE TOSPresent;	// actually: BOOL value using 1 Byte of memory
} TPM_STANY_FLAGS;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_SELECTION11 {
	UINT16 sizeOfSelect;
	BYTE pcrSelect[2];	// 16 PCRs available -> 2 Bytes; actually: size_is(sizeOfSelect)
} TPM_PCR_SELECTION11;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_SELECTION12 {
	UINT16 sizeOfSelect;
	BYTE pcrSelect[3];	// 24 PCRs available -> 3 Bytes; actually: size_is(sizeOfSelect)
} TPM_PCR_SELECTION12;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_INFO {
	TPM_PCR_SELECTION11 pcrSelection;
	TPM_COMPOSITE_HASH digestAtRelease;
	TPM_COMPOSITE_HASH digestAtCreation;
} TPM_PCR_INFO;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_INFO_SHORT {
	TPM_PCR_SELECTION12 pcrSelection;
	TPM_LOCALITY_SELECTION localityAtRelease;
	TPM_COMPOSITE_HASH digestAtRelease;
} TPM_PCR_INFO_SHORT;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_INFO_LONG {	// Only V12!
	TPM_STRUCTURE_TAG tag;
	TPM_LOCALITY_SELECTION localityAtCreation;
	TPM_LOCALITY_SELECTION localityAtRelease;
	TPM_PCR_SELECTION12 creationPCRSelection;
	TPM_PCR_SELECTION12 releasePCRSelection;
	TPM_COMPOSITE_HASH digestAtCreation;
	TPM_COMPOSITE_HASH digestAtRelease;
} TPM_PCR_INFO_LONG;

//-------------------------------------------------------------------
typedef struct tdTPM_KEY {
	TPM_STRUCT_VER ver;
	TPM_KEY_USAGE keyUsage;
	TPM_KEY_FLAGS keyFlags;
	TPM_AUTH_DATA_USAGE authDataUsage;
	TPM_KEY_PARMS algorithmParms;
	UINT32 PCRInfoSize;
//      BYTE*                                   PCRInfo; empty for unbound keys // actually: size_is(PCRInfoSize)
	TPM_STORE_PUBKEY pubKey;
	UINT32 encSize;
	BYTE encData[ST_EL_BIG_SZ];	// size_is(encSize)
} TPM_KEY;

typedef TPM_KEY TPM_DELEGATE_KEY;

//-------------------------------------------------------------------
typedef struct tdTPM_KEY12 {
	TPM_STRUCTURE_TAG tag;
	UINT16 fill;
	TPM_KEY_USAGE keyUsage;
	TPM_KEY_FLAGS keyFlags;
	TPM_AUTH_DATA_USAGE authDataUsage;
	TPM_KEY_PARMS algorithmParms;
	UINT32 PCRInfoSize;
	TPM_PCR_INFO_LONG PCRInfo;	// actually: BYTE* PCRInfo;
	TPM_STORE_PUBKEY pubKey;
	UINT32 encDataSize;
	BYTE encData[1];	// size_is(encDataSize)
} TPM_KEY12;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_ATTRIBUTES {
	BYTE pcrReset;		// actually: BOOL value using 1 Byte of memory
	TPM_LOCALITY_SELECTION pcrExtendLocal;
	TPM_LOCALITY_SELECTION pcrResetLocal;
} TPM_PCR_ATTRIBUTES;

//-------------------------------------------------------------------
typedef struct tdTPM_FAMILY_LABEL {
	BYTE label;
} TPM_FAMILY_LABEL;

typedef UINT32 TPM_FAMILY_FLAGS;

//-------------------------------------------------------------------
typedef struct tdTPM_FAMILY_TABLE_ENTRY {
	TPM_STRUCTURE_TAG tag;
	TPM_FAMILY_LABEL familyLabel;
	TPM_FAMILY_ID familyID;
	TPM_FAMILY_VERIFICATION verificationCount;
	TPM_FAMILY_FLAGS flags;
} TPM_FAMILY_TABLE_ENTRY;

//-------------------------------------------------------------------
typedef struct tdTPM_FAMILY_TABLE_ENTRY_SHORT {
	TPM_FAMILY_LABEL familyLabel;
	TPM_FAMILY_ID familyID;
	TPM_FAMILY_VERIFICATION verificationCount;
	TPM_FAMILY_FLAGS flags;
} TPM_FAMILY_TABLE_ENTRY_SHORT;

//-------------------------------------------------------------------
typedef struct tdTPM_FAMILY_TABLE {
	TPM_FAMILY_TABLE_ENTRY_SHORT FamTableRow[TPM_NUM_FAMILY_TABLE_ENTRY_MIN];
} TPM_FAMILY_TABLE;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATIONS {
	TPM_STRUCTURE_TAG tag;
	UINT32 delegateType;
	UINT32 per1;
	UINT32 per2;
} TPM_DELEGATIONS;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_LABEL {
	BYTE label;
} TPM_DELEGATE_LABEL;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_PUBLIC {
	TPM_STRUCTURE_TAG tag;
	TPM_DELEGATE_LABEL rowLabel;
	TPM_PCR_INFO_SHORT pcrInfo;
	TPM_DELEGATIONS permissions;
	TPM_FAMILY_ID familyID;	// If family id is zero complete row is invalid
	TPM_FAMILY_VERIFICATION verificationCount;
} TPM_DELEGATE_PUBLIC;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_TABLE_ROW {
	TPM_STRUCTURE_TAG tag;
	TPM_DELEGATE_PUBLIC pub;
	TPM_SECRET authValue;
} TPM_DELEGATE_TABLE_ROW;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_TABLE {
	TPM_DELEGATE_TABLE_ROW delRow[TPM_NUM_DELEGATE_TABLE_ENTRY_MIN];
} TPM_DELEGATE_TABLE;

//-------------------------------------------------------------------
typedef struct tdTPM_PERMANENT_DATA {
	TPM_STRUCTURE_TAG tag;
	BYTE revMajor;
	BYTE revMinor;
	TPM_NONCE tpmProof;
	TPM_NONCE ekReset;
	TPM_SECRET ownerAuth;
	TPM_SECRET operatorAuth;
	TPM_DIRVALUE authDIR[1];
	TPM_PUBKEY manuMaintPub;
	TPM_KEY endorsementKey;
	TPM_KEY srk;
	TPM_KEY contextKey;
	TPM_KEY delegateKey;
	TPM_COUNTER_VALUE auditMonotonicCounter;
	TPM_COUNTER_VALUE monotonicCounter[TPM_MIN_COUNTERS];
	TPM_PCR_ATTRIBUTES pcrAttrib[TPM_NUM_PCR];
	BYTE ordinalAuditStatus[1];	// actually: BYTE ordinalAuditStatus[];
	BYTE rngState[1];	// actually: BYTE* rngState;
	TPM_FAMILY_TABLE familyTable;
	TPM_DELEGATE_TABLE delegateTable;
	UINT32 maxNVBufSize;
	UINT32 lastFamilyID;
	UINT32 noOwnerNVWrite;
	TPM_CMK_DELEGATE restrictDelegate;
	TPM_DAA_TPM_SEED tpmDAASeed;
	TPM_NONCE daaProof;
	TPM_KEY daaBlobKey;
} TPM_PERMANENT_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_STCLEAR_DATA {
	TPM_STRUCTURE_TAG tag;
	TPM_NONCE contextNonceKey;
	TPM_COUNT_ID countID;
	UINT32 ownerReference;
	BYTE disableResetLock;	// actually: BOOL value using 1 Byte of memory
	TPM_PCRVALUE PCR[TPM_NUM_PCR];
} TPM_STCLEAR_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_SEALED_DATA {
	TPM_PAYLOAD_TYPE payload;
	TPM_SECRET authData;
	TPM_NONCE tpmProof;
	TPM_DIGEST storedDigest;
	UINT32 dataSize;
	BYTE Data[1];		// size_is(dataSize)
} TPM_SEALED_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_STORED_DATA {
	TPM_STRUCT_VER ver;
	UINT32 sealInfoSize;
	BYTE sealInfo[1];	// size_is(sealInfoSize)
	UINT32 encDataSize;
	TPM_SEALED_DATA encData;	// size_is(encDataSize)
} TPM_STORED_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_STORED_DATA12 {
	TPM_STRUCTURE_TAG tag;
	TPM_ENTITY_TYPE et;
	UINT32 sealInfoSize;
	TPM_PCR_INFO_LONG sealInfo;	// size_is(sealInfoSize)
	UINT32 encDataSize;
	TPM_SEALED_DATA encData;	// size_is(encDataSize)
} TPM_STORED_DATA12;

//-------------------------------------------------------------------
typedef struct tdTPM_SYMMETRIC_KEY {
	TPM_ALGORITHM_ID algID;	// identifier of the symmetric key
	TPM_ENC_SCHEME encScheme;	// used for encryption operation
	UINT16 size;		// size of data parameter in bytes
	BYTE Data[1];		// symmetric key data;  // size_is(size)
} TPM_SYMMETRIC_KEY;

//-------------------------------------------------------------------
typedef struct tdTPM_BOUND_DATA {
	TPM_STRUCT_VER ver;	// Version number defined in section 4.5
	TPM_PAYLOAD_TYPE payload;	// this shall be the value TPM_PT_BIND
	BYTE payloadData[1];	// the bound data       // actually: BYTE[] payloadData;
} TPM_BOUND_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_SYMMETRIC_KEY_PARMS {
	UINT32 keyLength;
	UINT32 blockSize;
	UINT32 ivSize;
	BYTE IV[1];		// size_is(ivSize)
} TPM_SYMMETRIC_KEY_PARMS;

//-------------------------------------------------------------------
typedef struct tdTPM_STORE_PRIVKEY {
	UINT32 keyLength;
	BYTE key[1];		// size_is(keyLength)
} TPM_STORE_PRIVKEY;

//-------------------------------------------------------------------
typedef struct tdTPM_STORE_ASYMKEY {	// pos  len                     total
	TPM_PAYLOAD_TYPE payload;	// 0    1                       1
	TPM_SECRET usageAuth;	// 1    20                      21
	TPM_SECRET migrationAuth;	// 21   20                      41
	TPM_DIGEST pubDataDigest;	// 41   20                      61
	TPM_STORE_PRIVKEY privKey;	// 61   132-151         193-214
} TPM_STORE_ASYMKEY;

//-------------------------------------------------------------------
typedef struct tdTPM_MIGRATE_ASYMKEY {	// pos  len                     total
	TPM_PAYLOAD_TYPE payload;	// 0    1                       1
	TPM_SECRET usageAuth;	// 1    20                      21
	TPM_DIGEST pubDataDigest;	// 21   20                      41
	UINT32 partPrivKeyLen;	// 41   4                       45
	BYTE partPrivKey[1];	// 45   112-127         157-172 // size_is(partPrivKeyLen)
} TPM_MIGRATE_ASYMKEY;

//-------------------------------------------------------------------
typedef struct tdTPM_CERTIFY_INFO {
	TPM_STRUCT_VER version;
	TPM_KEY_USAGE keyUsage;
	TPM_KEY_FLAGS keyFlags;
	TPM_AUTH_DATA_USAGE authDataUsage;
	TPM_KEY_PARMS algorithmParms;
	TPM_DIGEST pubkeyDigest;
	TPM_NONCE Data;
	BYTE parentPCRStatus;	// actually: BOOL value using 1 Byte of memory
	UINT32 PCRInfoSize;
	TPM_PCR_INFO PCRInfo;	// size_is(pcrInfoSize)
} TPM_CERTIFY_INFO;

//-------------------------------------------------------------------
typedef struct tdTPM_CERTIFY_INFO2 {
	TPM_STRUCTURE_TAG tag;
	BYTE fill;
	TPM_PAYLOAD_TYPE payloadType;
	TPM_KEY_USAGE keyUsage;
	TPM_KEY_FLAGS keyFlags;
	TPM_AUTH_DATA_USAGE authDataUsage;
	TPM_KEY_PARMS algorithmParms;
	TPM_DIGEST pubkeyDigest;
	TPM_NONCE Data;
	BYTE parentPCRStatus;	// actually: BOOL value using 1 Byte of memory
	UINT32 PCRInfoSize;
	TPM_PCR_INFO_SHORT PCRInfo;	// size_is(pcrInfoSize)
	UINT32 migrationAuthoritySize;
	BYTE migrationAuthority[1];	// size_is(migrationAuthoritySize)
} TPM_CERTIFY_INFO2;

//-------------------------------------------------------------------
typedef struct tdTPM_QUOTE_INFO {
	TPM_STRUCT_VER version;
	BYTE fixed[4];
	TPM_COMPOSITE_HASH digestValue;
	TPM_NONCE externalData;
} TPM_QUOTE_INFO;

//-------------------------------------------------------------------
typedef struct tdTPM_QUOTE_INFO2 {
	TPM_STRUCTURE_TAG tag;
	BYTE fixed[4];
	TPM_NONCE externalData;
	TPM_PCR_INFO_SHORT infoShort;
} TPM_QUOTE_INFO2;

//-------------------------------------------------------------------
typedef struct tdTPM_EK_BLOB {
	TPM_STRUCTURE_TAG tag;
	TPM_EK_TYPE ekType;
	UINT32 blobSize;
	BYTE blob[1];		// size_is(blobSize)
} TPM_EK_BLOB;

//-------------------------------------------------------------------
typedef struct tdTPM_EK_BLOB_ACTIVATE {
	TPM_STRUCTURE_TAG tag;
	TPM_SYMMETRIC_KEY sessionKey;
	TPM_DIGEST idDigest;
	TPM_PCR_INFO_SHORT pcrInfo;
} TPM_EK_BLOB_ACTIVATE;

//-------------------------------------------------------------------
typedef struct tdTPM_EK_BLOB_AUTH {
	TPM_STRUCTURE_TAG tag;
	TPM_SECRET authValue;
} TPM_EK_BLOB_AUTH;

//-------------------------------------------------------------------
typedef struct tdTPM_IDENTITY_CONTENTS {
	TPM_STRUCT_VER ver;
	UINT32 ordinal;
	TPM_CHOSENID_HASH labelPrivCADigest;
	TPM_PUBKEY identityPubKey;
} TPM_IDENTITY_CONTENTS;

//-------------------------------------------------------------------
typedef struct tdTPM_ASYM_CA_CONTENTS {
	TPM_SYMMETRIC_KEY sessionKey;
	TPM_DIGEST idDigest;
} TPM_ASYM_CA_CONTENTS;

//-------------------------------------------------------------------
typedef struct tdTPM_TRANSPORT_PUBLIC {
	TPM_STRUCTURE_TAG tag;
	TPM_TRANSPORT_ATTRIBUTES transAttributes;
	TPM_ALGORITHM_ID algID;
	TPM_ENC_SCHEME encScheme;
} TPM_TRANSPORT_PUBLIC;

//-------------------------------------------------------------------
typedef struct tdTPM_TRANSPORT_INTERNAL {
	TPM_STRUCTURE_TAG tag;
	TPM_AUTHDATA authData;
	TPM_TRANSPORT_PUBLIC tranPublic;
	TPM_TRANSHANDLE transHandle;
	TPM_NONCE transNonceEven;
	TPM_DIGEST transDigest;
} TPM_TRANSPORT_INTERNAL;

//-------------------------------------------------------------------
typedef struct tdTPM_CURRENT_TICKS {
	TPM_STRUCTURE_TAG tag;
	TPM_UINT64 currentTicks;
	UINT16 tickRate;
	TPM_NONCE tickNonce;
} TPM_CURRENT_TICKS;

//-------------------------------------------------------------------
typedef struct tdTPM_TRANSPORT_LOG_IN {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST parameters;
	TPM_DIGEST pubKeyHash;
} TPM_TRANSPORT_LOG_IN;

//-------------------------------------------------------------------
typedef struct tdTPM_TRANSPORT_LOG_OUT {
	TPM_STRUCTURE_TAG tag;
	TPM_CURRENT_TICKS currentTicks;
	TPM_DIGEST parameters;
	TPM_MODIFIER_INDICATOR locality;
} TPM_TRANSPORT_LOG_OUT;

//-------------------------------------------------------------------
typedef struct tdTPM_TRANSPORT_AUTH {
	TPM_STRUCTURE_TAG tag;
	TPM_AUTHDATA authData;
} TPM_TRANSPORT_AUTH;

//-------------------------------------------------------------------
typedef struct tdTPM_AUDIT_EVENT_IN {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST inputParms;
	TPM_COUNTER_VALUE auditCount;
} TPM_AUDIT_EVENT_IN;

//-------------------------------------------------------------------
typedef struct tdTPM_AUDIT_EVENT_OUT {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST outputParms;
	TPM_COUNTER_VALUE auditCount;
} TPM_AUDIT_EVENT_OUT;

//-------------------------------------------------------------------
typedef struct tdTPM_CONTEXT_BLOB {
	TPM_STRUCTURE_TAG tag;
	TPM_RESOURCE_TYPE resourceType;
	TPM_HANDLE handle;
	BYTE label[16];
	UINT32 contextCount;
	TPM_DIGEST blobIntegrity;
	UINT32 additionalSize;
	BYTE additionalData[1];	// size_is(additionalSize)
	UINT32 sensitiveSize;
	BYTE sensitiveData[1];	// size_is(sensitiveSize)
} TPM_CONTEXT_BLOB;

//-------------------------------------------------------------------
typedef struct tdTPM_CONTEXT_SENSITIVE {
	TPM_STRUCTURE_TAG tag;
	TPM_NONCE contextNonce;
	UINT32 internalSize;
	BYTE internalData[1];	// size_is(internalSize)
} TPM_CONTEXT_SENSITIVE;

//-------------------------------------------------------------------
typedef struct tdTPM_NV_ATTRIBUTES {
	TPM_STRUCTURE_TAG tag;
	UINT32 attributes;
} TPM_NV_ATTRIBUTES;

//-------------------------------------------------------------------
typedef struct tdTPM_NV_DATA_PUBLIC {
	TPM_STRUCTURE_TAG tag;
	TPM_NV_INDEX nvIndex;
	TPM_PCR_INFO_SHORT pcrInfoRead;
	TPM_PCR_INFO_SHORT pcrInfoWrite;
	TPM_NV_ATTRIBUTES permission;
	BYTE bReadSTClear;	// actually: BOOL value using 1 Byte of memory
	BYTE bWriteSTClear;	// actually: BOOL value using 1 Byte of memory
	BYTE bWriteDefine;	// actually: BOOL value using 1 Byte of memory
	UINT32 dataSize;
} TPM_NV_DATA_PUBLIC;

//-------------------------------------------------------------------
typedef struct tdTPM_NV_DATA_SENSITIVE {
	TPM_STRUCTURE_TAG tag;
	TPM_NV_DATA_PUBLIC pubInfo;
	TPM_AUTHDATA authValue;
	BYTE data[1];		// size_is(dataSize)
} TPM_NV_DATA_SENSITIVE;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_SENSITIVE {
	TPM_STRUCTURE_TAG tag;
	TPM_SECRET authValue;
} TPM_DELEGATE_SENSITIVE;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_OWNER_BLOB {
	TPM_STRUCTURE_TAG tag;
	TPM_DELEGATE_PUBLIC pub;
	TPM_DIGEST integrityDigest;
	UINT32 additionalSize;
	BYTE additionalArea[1];	// size_is(additionalSize)
	UINT32 sensitiveSize;
	BYTE sensitiveArea[1];	// size_is(sensitiveSize)
} TPM_DELEGATE_OWNER_BLOB;

//-------------------------------------------------------------------
typedef struct tdTPM_DELEGATE_KEY_BLOB {
	TPM_STRUCTURE_TAG tag;
	TPM_DELEGATE_PUBLIC pub;
	TPM_DIGEST integrityDigest;
	TPM_DIGEST pubKeyDigest;
	UINT32 additionalSize;
	BYTE additionalArea[1];	// size_is(additionalSize)
	UINT32 sensitiveSize;
	BYTE sensitiveArea[1];	// size_is(sensitiveSize)
} TPM_DELEGATE_KEY_BLOB;

//-------------------------------------------------------------------
typedef struct tdTPM_CAP_VERSION_INFO {
	TPM_STRUCTURE_TAG tag;
	TPM_VERSION version;
	UINT16 specLevel;
	BYTE specLetter;
	BYTE tpmVendorID[4];
	UINT16 vendorSpecificSize;
	BYTE vendorSpecific[ST_EL_SML_SZ];	// size_is(vendorSpecificSize)
} TPM_CAP_VERSION_INFO;

//-------------------------------------------------------------------
typedef struct tdTPM_DAA_ISSUER {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST DAA_digest_R0;
	TPM_DIGEST DAA_digest_R1;
	TPM_DIGEST DAA_digest_S0;
	TPM_DIGEST DAA_digest_S1;
	TPM_DIGEST DAA_digest_n;
	TPM_DIGEST DAA_digest_gamma;
	BYTE DAA_generic_q[26];
} TPM_DAA_ISSUER;

//-------------------------------------------------------------------
typedef struct tdTPM_DAA_TPM {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST DAA_digestIssuer;
	TPM_DIGEST DAA_digest_v0;
	TPM_DIGEST DAA_digest_v1;
	TPM_DIGEST DAA_rekey;
	UINT32 DAA_count;
} TPM_DAA_TPM;

//-------------------------------------------------------------------
typedef struct tdTPM_DAA_CONTEXT {
	TPM_STRUCTURE_TAG tag;
	TPM_DIGEST DAA_digestContext;
	TPM_DIGEST DAA_digest;
	TPM_DAA_CONTEXT_SEED DAA_contextSeed;
	BYTE DAA_scratch[256];
	BYTE DAA_stage;
} TPM_DAA_CONTEXT;

//-------------------------------------------------------------------
typedef struct tdTPM_DAA_JOINDATA {
	BYTE DAA_join_u0[128];
	BYTE DAA_join_u1[138];
	TPM_DIGEST DAA_digest_n0;
} TPM_DAA_JOINDATA;

//-------------------------------------------------------------------
typedef struct tdTPM_DAA_SENSITIVE {
	TPM_STRUCTURE_TAG tag;
	UINT32 internalSize;
	BYTE internalData[1];	// size_is(internalSize)
} TPM_DAA_SENSITIVE;

//-------------------------------------------------------------------
typedef struct tdTPM_DAA_BLOB {
	TPM_STRUCTURE_TAG tag;
	TPM_RESOURCE_TYPE resourceType;
	BYTE label[16];
	TPM_DIGEST blobIntegrity;
	UINT32 additionalSize;
	BYTE additionalArea[1];	// size_is(additionalSize)
	UINT32 sensitiveSize;
	TPM_DAA_SENSITIVE sensitiveArea;	// size_is(sensitiveSize)
} TPM_DAA_BLOB;

// Infineon specific structures =================================================================

//-------------------------------------------------------------------
typedef struct tdIFX_FIELDUPGRADEINFO {
	BYTE infoVersion;
	BYTE chipVersion[4];
	TPM_VERSION ver;
	BYTE date[3];
	UINT16 maxDataSize;
	UINT16 romCRC;
	BYTE keyInfoKTTP;
	BYTE keyInfoSig;
	UINT16 flagsFieldUpgrade;
} IFX_FIELDUPGRADEINFO;

//-------------------------------------------------------------------
typedef struct tdIFX_FIELDUPGRADEINFO2 {
	BYTE		bootloaderVersion[12];
	UINT32		firmwareVersion;
	UINT32		bootloaderstatus;
	BYTE		firmwarepackage[12];
} IFX_FIELDUPGRADEINFO2;

//-------------------------------------------------------------------
typedef struct tdTPM_INFO_STRUCTURE {
	UINT16 wTPM_IO_BaseAdr;
	UINT16 wTPMConfigAdr;
	BYTE bTPMIrqNr;
	BYTE bTPMIrqCtrl;
	BYTE bTPMBwtTimeOut;
	BYTE bTPMCwtTimeOut;
	BYTE bTPMLocality;
	UINT16 wTPMStartupType;
	BYTE bTPMDoStartup;
} TPM_INFO_STRUCTURE;

//-------------------------------------------------------------------
typedef struct tdTDDL_CAP {
	// Version info
	TPM_STRUCT_VER Ver_Drv;
	TPM_STRUCT_VER Ver_Fw;
	BYTE FwDate[3];
	UINT16 wROMCRC;
	// Property info
	BYTE Size_Manufacturer;
	BYTE Manufacturer[30];
	BYTE Size_ModuleType;
	BYTE ModuleType[41];
	UINT16 wIFSD;
	BYTE GlobalState;
} TDDL_CAP;

//-------------------------------------------------------------------
typedef struct tdTPM_CAP {
	BYTE abFWVers[4];
	BYTE abFWDate[3];
	BYTE abROMCRC[2];
} TPM_CAP;

//-------------------------------------------------------------------
// Read_TPM_FID structures
typedef struct tdTPM_RD_FID_RQU {
	BYTE bVERS;
	BYTE bCHA;
	UINT32 dwLEN;
	BYTE bCLA;
	BYTE bINS;
	BYTE bDLNG;
	BYTE bDATA;
} TPM_RD_FID_RQU;

typedef struct tdTPM_RD_FID_RSP {
	BYTE bVERS;
	BYTE bCHA;
	UINT32 dwLEN;
	BYTE bCARC;
	BYTE bAPRC;
	BYTE bDLNG;
	BYTE abDATA[MAX_FID_INFO_SIZE];
} TPM_RD_FID_RSP;

//-------------------------------------------------------------------
// Adapted key structure for TPM_TakeOwnership with empty key
typedef struct tdTPM_STORE_PUBKEY_TO_RQU {
	UINT32 keyLength;
} TPM_STORE_PUBKEY_TO_RQU;

// Adapted key parameter structure for TPM_TakeOwnership
typedef struct tdTPM_KEY_TO_RQU {
	TPM_STRUCT_VER ver;
	TPM_KEY_USAGE keyUsage;
	TPM_KEY_FLAGS keyFlags;
	TPM_AUTH_DATA_USAGE authDataUsage;
	TPM_KEY_PARMS algorithmParms;
	UINT32 PCRInfoSize;
	TPM_STORE_PUBKEY_TO_RQU pubKey;
	UINT32 encSize;
} TPM_KEY_TKOWN_RQU;

//-------------------------------------------------------------------
// PC Client Specific Implementation Specification Version 1.2 Revision 1.00
#define MAX_CERT_SIZE	2048	// Maximum size for the EK Certificate

typedef struct tdTPM_STORED_CERT {
	TPM_STRUCTURE_TAG tag;
	TPM_CERT_TYPE certType;
	UINT16 certSize;
	UINT16 longTag;
	BYTE Cert[MAX_CERT_SIZE];
} TPM_STORED_CERT;

// Obsolete or invalid structures ===============================================================

/*
typedef struct tdTPM_SESSION_DATA {
// ...vendor specific
} TPM_SESSION_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_PCR_COMPOSITE { 
	TPM_PCR_SELECTION	select;
	UINT32				valueSize;
	TPM_PCRVALUE		pcrValue[1];				// size_is(valueSize)
} TPM_PCR_COMPOSITE;

//-------------------------------------------------------------------
typedef struct tdTPM_STANY_DATA {
	TPM_STRUCTURE_TAG	tag;
	TPM_NONCE			contextNonceSession;
	TPM_DIGEST			auditDigest ;
	TPM_CURRENT_TICKS	currentTicks;
	UINT32				contextCount;
	UINT32				contextList[TPM_MIN_SESSION_LIST];
	TPM_SESSION_DATA	sessions[TPM_MIN_SESSIONS];
//	TPM_DAA_ISSUER		DAA_issuerSettings;	// DAA additions
//	TPM_DAA_TPM			DAA_tpmSpecific;	// DAA additions
//	TPM_DAA_CONTEXT		DAA_session;		// DAA additions
//	TPM_DAA_JOINDATA	DAA_joinSession;	// DAA additions
} TPM_STANY_DATA;

//-------------------------------------------------------------------
typedef struct tdTPM_KEY_NOPCR {
	TPM_VERSION				ver;
	TPM_KEY_USAGE			keyUsage;
	TPM_KEY_FLAGS			keyFlags;
	TPM_AUTH_DATA_USAGE		authDataUsage;
	TPM_KEY_PARMS			algorithmParms;
	UINT32					PCRInfoSize;
	TPM_STORE_PUBKEY		pubKey;
	UINT32					encSize;
	BYTE					encData[1];				// size_is(encSize)
} TPM_KEY_NOPCR;

//-------------------------------------------------------------------
typedef struct tdTPM_CERTIFY_INFO2_1 {
	TPM_STRUCTURE_TAG		tag;
	BYTE					fill;
	TPM_PAYLOAD_TYPE		payloadType;
	TPM_KEY_USAGE			keyUsage;
	TPM_KEY_FLAGS			keyFlags;
	TPM_AUTH_DATA_USAGE		authDataUsage;
	TPM_KEY_PARMS			algorithmParms;
	TPM_DIGEST				pubkeyDigest;
	TPM_NONCE				Data;
	BYTE					parentPCRStatus;		// actually: BOOL value using 1 Byte of memory
	UINT32					PCRInfoSize;
	UINT32					migrationAuthoritySize;
	TPM_DIGEST				migrationAuthority;		// size_is(migrationAuthoritySize)
} TPM_CERTIFY_INFO2_1;

//-------------------------------------------------------------------
typedef struct tdTPM_CONTEXT_SENSITIVE_INT {
	TPM_STRUCTURE_TAG	tag;
	BYTE				RandomValue[8];
	TPM_NONCE			contextNonce;
	TPM_DIGEST			digest;
	UINT16				unExactSize;
	BYTE				ContextBlob[1];
} TPM_CONTEXT_SENSITIVE_INT, *PTPM_CONTEXT_SENSITIVE_INT;

//-------------------------------------------------------------------
typedef struct tdTPM_KEY_PARMS_MGF {
	TPM_ALGORITHM_ID	algorithmID;
	TPM_ENC_SCHEME		encScheme;
	TPM_SIG_SCHEME		sigScheme;
	UINT32				parmSize;
} TPM_KEY_PARMS_MGF;

//-------------------------------------------------------------------
typedef union tdUTPM_VERSION_TAG12 {
	TPM_VERSION		tpmVersion;
	TPM_TAG_V12		tpmTagV12;
} UTPM_VERSION_TAG12, *PUTPM_VERSION_TAG12;

//-------------------------------------------------------------------
typedef union tdTPM_UPCR_INFO {
	TPM_PCR_INFO		pcrInfo;
	TPM_PCR_INFO_LONG	pcrInfoLong;
} TPM_UPCR_INFO, *PTPM_UPCR_INFO;

//-------------------------------------------------------------------
typedef union tdTPM_DELEGATE_BLOB {
	TPM_DELEGATE_OWNER_BLOB		ownerBlob;
	TPM_DELEGATE_KEY_BLOB		keyBlob;
} TPM_DELEGATE_BLOB;
*/

#pragma pack(pop)

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TPM_STRU_H__
