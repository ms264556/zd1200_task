/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Globals.h

Description:	Header file for all global definitions

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __GLOBALS_H__
#define __GLOBALS_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "TPM_Defi.h"
#include "TPM_Erro.h"
#include "TPM_Stru.h"

#ifdef UEFI_X64
#include <Library/ShellLib.h>			// because file access
#include <Library/MemoryAllocationLib.h>	// because of FreePool
#include <Library/BaseMemoryLib.h>		// because of MemCopy
#include "C8String.h"
#include <Library/PrintLib.h>			// because of AsciiVSPrint
#else
#ifndef linux
#include <conio.h>
#endif // linux
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#endif // UEFI_X64

#include "ProgInfo.h"

//---------------------------------------------------------------
// General definitions
#define SLEEP_TIME_US 100	/* This is the time value to sleep between retries. Default 1000us=1ms */
#define SLEEP_TIME_US_BURSTCOUNT 10
#define SLEEP_TIME_US_CR 10
#ifdef UEFI_X64
#define PLATFORM			"UEFI"
#ifdef GCC
typedef UINTN size_t; 
#endif
#define printf				AsciiPrint
#define memcpy				CopyMem
#define memcmp				(int)CompareMem
#define malloc(x)			AllocateZeroPool(x)
#define calloc(n, s)		AllocateZeroPool(n*s)
#define free(x)				FreePool(x)
#define memset(x, y, z)		SetMem(x, z, y)
#define CHAR_SPACE			0x0020
#define CHAR_SLASH			0x002F
#define CHAR_ASTERISK		0x002A
#define strcmp				AsciiStrCmp
#define strlen				AsciiStrLen
#define strstr				AsciiStrStr
#define strchr				c8strchr
#define strncat				AsciiStrnCat
#define strcat				AsciiStrCat
#define EOF					(-1)
#define va_list				VA_LIST
#define va_start			VA_START
#define va_end				VA_END
#define va_arg				VA_ARG
#define va_copy				VA_COPY
#else
#ifdef linux
#define PLATFORM            "Linux"
#ifdef __arm__
#define USE_DRIVER	2	/* 2= Use TPM Driver, currently only option on arm*/
#else
#define USE_DRIVER	0	/* 0=Userspace Driver, 1= Use Mem/IO Driver, 2= Use TPM Driver */
#endif
#define TTY_ACCESS	0	/* 0=Target platform has own keyboard/screen */
				/* 1=Target platform is accessed over TTY only (evaluation boards) */
#define DISABLE_SLEEPS 0	// should all sleeps be skipped, this may make tool4tpm instable (but extremly fast)
//COMPAT Defines
#define getch getchar
#define UINT64 unsigned long
#else
#ifdef WIN32			//--------WIN32-----------
#ifdef WIN64
#define PLATFORM			"W64"
#else
#define PLATFORM			"W32"
#endif
//COMPAT Defines
#define strcasecmp			_stricmp
#define kbhit				_kbhit
#define getch				_getch
#define va_copy(dest, src)	(dest = src)
#else //--------DOS-------------
//COMPAT Defines
#define PLATFORM			"DOS"
#define strcasecmp			stricmp
#define UINT64				unsigned long
#endif //-------DOS/WIN----------
#endif //--------linux--------
#endif //--------UEFI--------

#define ATTENDED			0
#define UNATTENDED			1

#define ON					TRUE
#define OFF					FALSE

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#ifdef _MSC_VER
#define Pragma(x)					__pragma(x)
#else
#define	Pragma(x)					_Pragma(#x)
#endif

#ifndef GCC
#define DISABLE_WARNING(x)		Pragma(warning(disable : x))
#define RESTORE_WARNING(x)		Pragma(warning(default : x))
#define DISABLE_OPTIMIZATION	Pragma(optimize("", off))
#define ENABLE_OPTIMIZATION		Pragma(optimize("", on))
#define UNOPTIMIZED
#else
#define DISABLE_WARNING(x)
#define RESTORE_WARNING(x)
#define DISABLE_OPTIMIZATION
#define ENABLE_OPTIMIZATION
#define UNOPTIMIZED				__attribute ((optimize ("O0")))
#endif

#define TAB_WIDTH				8

// Maximum number of errors
#define MAX_ERRORS 3

// Maximum number of characters per config value in the config file (incl. null-termination!)
#define MAX_VAL_LEN			30

// Definitions for output target and mode
#define TG_FILE				11
#define TG_SCREEN			12
#define TG_BOTH				13
#define MD_HEX				21
#define MD_STR				22
#define MD_BIN				23

#define FILE_READ			0x00
#define FILE_WRITE			0x01
#define FILE_CLEAR			0x02
#define FILE_APPEND			0x04
//---------------------------------------------------------------
// Global SHA-1 and RSA definitions

#define HASH_LEN		20	// Hash length (Do NOT change, since it is fixed for SHA-1!)
#define MAX_HASH_DATA	960

// SHA-1 test vector
#define SHA1_TEST_VALUE											\
{																\
	0x22, 0x0F, 0x53, 0x4F, 0xC4, 0x20, 0x62, 0xF5, 0xBD, 0x72,	\
	0x12, 0xAC, 0x99, 0x0A, 0xAE, 0xC2, 0x0E, 0x7F, 0x83, 0xFF	\
}

// Storage Root Key hash value
#define SRK_HASH	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }

//---------------------------------------------------------------
// General return codes

#define RC_SUCCESS					0	// General success return code

// General error return codes
// don't modify already defined or skipped error codes!
#define RC_E_BASE					(10000)
#define RC_E_FAILURE				(RC_E_BASE + 1)		// Unspecified error
#define RC_E_INVALID_PARAM			(RC_E_BASE + 2)		// Invalid parameter specified
#define RC_E_TIMEOUT				(RC_E_BASE + 3)		// Maximum waiting time ran down
#define RC_E_BUFFER2SMALL			(RC_E_BASE + 4)		// Buffer size insufficient
#define RC_E_NAKRECEIVED			(RC_E_BASE + 5)		// TPM received corrupted data
#define RC_E_WTXRECEIVED			(RC_E_BASE + 6)		// TPM received WTX request
#define RC_E_INVALID_DATA			(RC_E_BASE + 7)		// TPM sent corrupted data
// skipped on purpose				(RC_E_BASE + 8)
#define RC_E_NOT_READY				(RC_E_BASE + 9)		// Device is not ready
#define RC_E_FILE_EMPTY				(RC_E_BASE + 10)	// No data in file
// skipped on purpose				(RC_E_BASE + 11)
#define RC_E_NO_MEMORY				(RC_E_BASE + 12)	// No more memory available
#define RC_E_NODISKSPC				(RC_E_BASE + 13)	// No space on disk left
#define RC_E_INV_FILE_SPEC			(RC_E_BASE + 14)	// File or path not found
#define RC_E_FILE2LARGE				(RC_E_BASE + 15)	// File is too big to complete operation
// skipped on purpose				(RC_E_BASE + 16)
#define	RC_E_WTXABORT				(RC_E_BASE + 17)	// Command not sent because maximum number of waiting cycles is exceeded
// skipped on purpose				(RC_E_BASE + 18)-(RC_E_BASE + 21)
#define RC_E_HASOWNER				(RC_E_BASE + 22)	// TPM has an Owner
#define RC_E_DISABLED				(RC_E_BASE + 23)	// TPM is disabled
// skipped on purpose				(RC_E_BASE + 24)-(RC-E-BASE + 28)
#define RC_E_LOCALITY_NOT_ACTIVE	(RC_E_BASE + 29)	// The requested Locality is not active
#define RC_E_TPM_TRANSMIT_DATA		(RC_E_BASE + 30)	// The TPM indicates an error during transmission of the data
#define RC_E_TPM_RECEIVE_DATA		(RC_E_BASE + 31)	// The TPM indicates an error during reception of the data
#define RC_E_TPM_NO_DATA_AVAILABLE	(RC_E_BASE + 32)	// The TPM has no response available yet
// skipped on purpose				(RC_E_BASE + 33)
#define RC_E_LOCALITY_NOT_SUPPORTED	(RC_E_BASE + 34)	// The requested Locality isn't supported.
#define RC_E_BAD_PARAMETER			(RC_E_BASE + 35)	// One or more parameters are invalid
#define RC_E_COMPONENT_NOT_FOUND	(RC_E_BASE + 36)	// The requested TPM component was not found
#define RC_E_INSUFFICIENT_BUFFER	(RC_E_BASE + 37)	// The receive buffer is too small.

// Errorcodes RC_E_BASE + 38 - RC_E_BASE + 99 are reserved

// Continuing defining error codes from RC_E_BASE + 100
#define RC_E_SYNTAXERROR			(RC_E_BASE + 100)	// Invalid syntax of the input file
// *** add new error codes here ***

// General warning return codes
#define RC_W_BASE					20000
#define RC_W_TPM_CFG				(RC_W_BASE + 01)	// TPM is not configured to 4E!
#define RC_W_TPM_INACTIVE			(RC_W_BASE + 02)	// TPM is not activated
#define RC_W_CNF_IN_USE				(RC_W_BASE + 03)	// Config space already occupied
#define RC_W_GEN_IN_USE				(RC_W_BASE + 04)	// Decoder range already occupied

//---------------------------------------------------------------
// General TPM definitions

#define TPM1_1				0x06
#define TPM1_2				0x0B

// Locality definitions for acessing TPM
#define LOCALITY_0			0
#define LOCALITY_1			1
#define LOCALITY_2			2
#define LOCALITY_3			3
#define LOCALITY_4			4
#define LOCALITY_LEGACY		10
// The Locality Legacy causes I/O instead of Memory access.
// Do NOT change this value to the same value as for Locality 0, since Tool4TPM
// must be able to differentiate between Locality 0 and Locality Legacy.

//---------------------------------------------------------------
// Global variables

#ifdef UEFI_X64
INT32 InitialScreenMode;
#endif
void *pvLogFileHandle;			// Global log file I/O handle

BYTE bChipDetected;		// Used for identifying TPM
BYTE bDebug;			// Debug logging level

//---------------------------------------------------------------
// Global macros

// Escape key is pressed
#define CHAR_ESC						27
#define ESC_IS_PRESSED					(IsKeyPressed(CHAR_ESC))

// Secure memory (de)allocation
#define SAFE_FREE(x)					if (x) { free(x); x = NULL; }
#define CALLOC(x, size)					((x = calloc(1, size)) != NULL)
#define SAFE_CALLOC(x, size, ret)		if ((x = calloc(1, size)) == NULL) { (*ret) = RC_E_NO_MEMORY; break; }

// Show state of selected bit in specified byte
#define SHOWBIT(byte,bit) ((byte & bit) ? "1":"0")

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
#endif // __GLOBALS_H__
