/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	ProgFunc.h

Description:	Header file for the Tool4TPM functions

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __PROGFUNC_H__
#define __PROGFUNC_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

// Cast a little endian formated Word/Double Word to big endian or vice versa
UINT32 dwSwitchEndian32(UINT32 dwNumber);
UINT16 wSwitchEndian16(UINT16 wNumber);

// Convert little endian formated byte array to big endian or vice versa in place
void SwitchEndian16ByteArray(BYTE pbArray[2]);
void SwitchEndian32ByteArray(BYTE pbArray[4]);
void SwitchEndian64ByteArray(TPM_UINT64 * qwNum);

// Hex or String dump to file and/or screen
void Dump(BYTE target, BYTE mode, BYTE * data, UINT32 len);

// Print formatted data to screen (and to log file if log, detaillog or debug mode is on)
void Log(char *format, ...);

// Print formatted data exclusively to log file
void LogToFile(char *format, ...);

// Print formatted data exclusively to log file (if detaillog or debug mode is on)
void DetLogToFile(char *format, ...);

// Print formatted data exclusively to log file (if debug mode is on)
void DebugToFile(char *format, ...);

// Returns the buffer size needed to store the formatted string
UINT32 GetFormattedBufferSize(char *pcFormat, ...);

// Returns the buffer size needed to store the formatted string
UINT32 GetFormattedBufferSizev(char *pcFormat, va_list pcArguments);

// Formats a string
void FormatString(char *pcBuffer, UINT32 dwBufferSize, char *pcFormat, ...);

// Formats a string using an argument list
void FormatStringv(char *pcBuffer, UINT32 dwBufferSize, char *pcFormat, va_list pcArguments);

// Delay function
void Sleep_ms(UINT16 wTime);
void Sleep_us(UINT32 dwTime);

// Keyboard polling
char WaitForAnyKey(void);

// Set the log/debug level according to the specified value in the config file
void SetLoggingLevel(void);

// Get the console screen mode from config file
BYTE GetScreenMode(void);

#ifdef UEFI_I2C
// Set the I2C frequency [Hz] according to the specified value in the config file
void GetI2cSpeed(void);
#endif

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __PROGFUNC_H__
