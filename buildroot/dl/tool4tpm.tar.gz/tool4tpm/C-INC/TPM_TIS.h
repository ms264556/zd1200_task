/*++

Copyright (c) 2013  Infineon Technologies A.G.

Module Name:

	TPM_TIS.h	
	
Abstract:
	Provides all functions for TIS access on the Infineon TPM.

Author:

	Georg Rankl

Environment:

	Win32/Win64

Revision History:
	01		First revision

Notes:

	
--*/
#ifndef __TPM_TIS_H__
#define __TPM_TIS_H__

//--------------------------------------------------------------------
// defines

// Defines for Localities
#ifdef UEFI_I2C
#define TIS_BASE_ADDRESS 		0x00
#define TIS_LOCALITY0OFFSET 0x00
#define TIS_LOCALITY1OFFSET 0x10
#define TIS_LOCALITY2OFFSET 0x20
#define TIS_LOCALITY3OFFSET 0x30
#define TIS_LOCALITY4OFFSET 0x40
#define IFX_LOCALITY_MASK		0x70
#define IFX_LOCALITY_SHIFT	4	
#else
#define TIS_BASE_ADDRESS 0xFED40000
#define TIS_LOCALITY0OFFSET 0xFED40000
#define TIS_LOCALITY1OFFSET 0xFED41000
#define TIS_LOCALITY2OFFSET 0xFED42000
#define TIS_LOCALITY3OFFSET 0xFED43000
#define TIS_LOCALITY4OFFSET 0xFED44000
#endif

// Defines for the different Localities
#define TIS_LOCALITY_0				0x00
#define TIS_LOCALITY_1				0x01
#define TIS_LOCALITY_2				0x02
#define TIS_LOCALITY_3				0x03
#define TIS_LOCALITY_4				0x04

// TPM Interface Registers
#ifdef UEFI_I2C
#define TIS_TPM_ACCESS 				0x00
#define TIS_TPM_STS 				0x01
#define TIS_TPM_BURSTCOUNT			0x02
#define TIS_TPM_DATA_FIFO 			0x05
#define TIS_TPM_VID 				0x06
#define TIS_TPM_DID 				0x08
#define TIS_TPM_RID					0x0F
#define	IFX_TPM_BASE_ADDR			0x83
#define	IFX_TPM_MAX_SCL_FREQU		0x84
#define IFX_TPM_I2C_MAX_RX_SIZE		0x8A
#define IFX_TPM_I2C_MAX_TX_SIZE		0x8B
#define IFX_TPM_FOR_IFX_USE_1		0xA0
#define IFX_TPM_FOR_IFX_USE_2		0xA1
#define IFX_TPM_I2C_READ_FROM		0xB0	
#else
#define TIS_TPM_ACCESS 0x00000000
#define TIS_TPM_STS 0x00000018
#define TIS_TPM_BURSTCOUNT 0x00000019
#define TIS_TPM_DATA_FIFO 0x00000024
#define TIS_TPM_DID 0x00000F02
#define TIS_TPM_VID 0x00000F00
#define TIS_TPM_RID 0x00000F04
#endif

// Register Bits of the Access Register
#define TIS_TPM_ACCESS_VALID 0x80
#define TIS_TPM_ACCESS_ACTIVELOCALITY 0x20
#define TIS_TPM_ACCESS_BEENSEIZED 0x10
#define TIS_TPM_ACCESS_SEIZE 0x08
#define TIS_TPM_ACCESS_PENDINGREQUEST 0x04
#define TIS_TPM_ACCESS_REQUESTUSE 0x02
#define TIS_TPM_ACCESS_ESTABLISHEMENT 0x01

// Register Bits of the Status Register
#define TIS_TPM_STS_VALID 0x80
#define TIS_TPM_STS_CMDRDY 0x40
#define TIS_TPM_STS_GO 0x20
#define TIS_TPM_STS_AVAIL 0x10
#define TIS_TPM_STS_EXPECT 0x08
#define TIS_TPM_STS_RETRY 0x02

// Vendor and Device ID
#define TIS_TPM_VID_IFX 0x15D1
#define TIS_TPM_DID_TPM12 0x000B

// TIS-Timeouts, use default values only
#define TIMEOUT_A 750
#define TIMEOUT_B 2000
#define TIMEOUT_C 750
#define TIMEOUT_D 750
#define CMD_DURATION 120000	// Use 5 sec now until Short/Medium/Long is implemented

/*++
TIS_ReadRegister
   
Description:
   
Read the value of a TIS register
   
Arguments:
bLocality
wRegOffset
*pdwValue

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ReadRegister(BYTE bLocality, UINT16 wRegOffset, BYTE bRegSize, void *pValue);

/*++
TIS_WriteRegister
   
Description:
   
Write the value into a TIS register
   
Arguments:
bLocality
wRegOffset
bRegSize
dwValue

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_WriteRegister(BYTE bLocality, UINT16 wRegOffset, BYTE bRegSize, UINT32 dwValue);

/*++
TIS_ReadAccessRegister
   
Description:
   
Read the value from the Access register
   
Arguments:
bLocality
pbValue

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ReadAccessRegister(BYTE bLocality, BYTE * pbValue);

/*++
TIS_ReadStsRegister
   
Description:
   
Read the value from the Status register
   
Arguments:
bLocality
pbValue

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ReadStsRegister(BYTE bLocality, BYTE * pbValue);

/*++
TIS_WriteStsRegister
   
Description:
   
Writes the value into the Status register
   
Arguments:
bLocality
bValue

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_WriteStsRegister(BYTE bLocality, BYTE bValue);

/*++
TIS_IsAccessValid
   
Description:
   
Returns the value of TPM.ACCESS.VALID
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsAccessValid(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_IsActiveLocality
   
Description:
   
Returns the value of TPM.ACCESS.ACTIVE.LOCALITY
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsActiveLocality(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_ReleaseActiveLocality
   
Description:
   
Release the currently active locality
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ReleaseActiveLocality(BYTE bLocality);

/*++
TIS_IsSeized
   
Description:
   
Returns the value of TPM.ACCESS.BEEN.SEIZED
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsSeized(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_ClearBeenSeized
   
Description:
   
Clears TPM.ACCESS.BEEN.SEIZED
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ClearBeenSeized(BYTE bLocality);

/*++
TIS_Seize
   
Description:
   
Seize the TPM from a lower locality
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_Seize(BYTE bLocality);

/*++
TIS_IsPendingRequest
   
Description:
   
Returns the value of TPM.ACCESS.PENDING.REQUEST
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsPendingRequest(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_RequestUse
   
Description:
   
Requests ownership of the TPM
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_RequestUse(BYTE bLocality);

/*++
TIS_IsRequestUse
   
Description:
   
Returns the value of TPM.ACCESS.REQUEST.USE
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsRequestUse(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_IsEstablishement
   
Description:
   
Returns the value of TPM.ACCESS.TPM.ESTABLISHEMENT
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsEstablishement(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_GetBurstCount
   
Description:
   
Returns the value of TPM.STS.BURSTCOUNT
   
Arguments:
bLocality
*pwBurstCount

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_GetBurstCount(BYTE bLocality, UINT16 * pwBurstCount);

/*++
TIS_IsStsValid
   
Description:
   
Returns the value of TPM.STS.VALID
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsStsValid(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_IsCommandReady
   
Description:
   
Returns the value of TPM.STS.COMMAND.READY
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsCommandReady(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_Abort
   
Description:
   
Aborts the currently running action by writing 1 to Command Ready
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_Abort(BYTE bLocality);

/*++
TIS_Go
   
Description:
   
Lets the TPM execute a command
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_Go(BYTE bLocality);

/*++
TIS_IsDataAvailable
   
Description:
   
Returns the value of TPM.STS.DATA.AVAIL
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsDataAvailable(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_IsExpect
   
Description:
   
Returns the value of TPM.STS.EXPECT
   
Arguments:
bLocality
*pbFlag

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_IsExpect(BYTE bLocality, BOOL * pbFlag);

/*++
TIS_Retry
   
Description:
   
Lets the TPM repeat the last response
   
Arguments:
bLocality

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_Retry(BYTE bLocality);

/*++
TIS_GetVendorID
   
Description:
   
Reads the Vendor ID from the TPM
   
Arguments:
*pwVendorID

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_GetVendorID(UINT16 * pwVendorID);

/*++
TIS_GetDeviceID
   
Description:
   
Reads the Device ID from the TPM
   
Arguments:
*pwDeviceID

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_GetDeviceID(UINT16 * pwDeviceID);

/*++
TIS_GetRevisionID
   
Description:
   
Reads the Revision ID from the TPM
   
Arguments:
*pbRevisionID

Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_GetRevisionID(BYTE * pbRevisionID);

/*++
TIS_WriteByteLPC
   
Description:
   
Send one Byte to the TPM TIS data FIFO
   
Arguments:
bLocality
bByteToWrite	Byte to send
   
Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
	RC_E_FAILURE	Byte could not be written
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_WriteByteLPC(BYTE bLocality, BYTE bByteToWrite);

/*++
TIS_ReadByteLPC
   
Description:
   
Read one Byte from the TPM TIS data FIFO
   
Arguments:
bLocality
pbByteToRead	Byte to read
   
Return Value:
	Return			Meaning
	======			=======
	TDDL_SUCCESS	operation completed successfully.
	RC_E_FAILURE	Byte could not be written
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ReadByteLPC(BYTE bLocality, BYTE * pbByteToRead);

/*++
TIS_SendLPC
   
Description:
   
Send a data block to the TPM TIS port
   
Arguments:
bLocality
pbByteBuf		Buffer to send
wLen			Size of send buffer
   
Return Value:
	Return				Meaning
	======				=======
	TDDL_SUCCESS	operation completed successfully.
	RC_E_TIMEOUT		Timeout
	RC_E_INVALID_PARAM	Wrong parameters
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_SendLPC(BYTE bLocality, BYTE * pbByteBuf, UINT16 wLen);

/*++
TIS_ReadLPC
   
Description:
   
Read a data block from the TPM TIS port
   
Arguments:
bLocality
pbByteBuf		Buffer to receive
pwLen			Max Size of receive buffer/Actual size received
   
Return Value:
	Return				Meaning
	======				=======
	TDDL_SUCCESS	operation completed successfully.
	RC_E_TIMEOUT		Timeout
	RC_E_INVALID_PARAM	Wrong parameters
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_ReadLPC(BYTE bLocality, BYTE * pbByteBuf, UINT16 * pwLen);

/*++
TIS_TransceiveLPC
   
Description:
   
Sends the Tx Buffer to the TPM and returns the response
   
Arguments:
bLocality
pbTxBuffer		Buffer to send
wTxLen			Size of send buffer
pbRxBuffer		Buffer to receive
pwRxLen			Max Size of receive buffer/Actual size received
   
Return Value:
	Return				Meaning
	======				=======
	TDDL_SUCCESS	operation completed successfully.
	RC_E_TIMEOUT		Timeout
	RC_E_INVALID_PARAM	Wrong parameters
   
Author:
	Georg Rankl (ran) 11.01.2007
   
--*/
extern UINT32 TIS_TransceiveLPC(BYTE bLocality, BYTE * pbTxBuffer, UINT16 wTxLen, BYTE * pbRxBuffer, UINT16 * pwRxLen);

#endif //__TPM_TIS_H__
