/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Erro.h

Description:	Definition of the TPM error codes according to TCG Main Specification Version 1.2

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TPM_ERRO_H__
#define __TPM_ERRO_H__
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

// Start of the TPM error codes
#define TPM_IFX_BASE						0x00000000
#define TPM_IFX_NON_FATAL					0x00000800
#define TPM_IFX_NON_FATAL_INTERNAL			0x000000D0

// Successful completion of the operation
#define TPM_SUCCESS						TPM_IFX_BASE

// TPM fatal error codes
#define TPM_E_IFX_AUTHFAIL					(TPM_IFX_BASE + 1)	// Authentication failed
#define TPM_E_IFX_BADINDEX					(TPM_IFX_BASE + 2)	// The index to a PCR, DIR or other register is incorrect
#define TPM_E_IFX_BAD_PARAMETER				(TPM_IFX_BASE + 3)	// One or more parameter is bad
#define TPM_E_IFX_AUDITFAILURE				(TPM_IFX_BASE + 4)	// An operation completed successfully but the auditing of that operation failed
#define TPM_E_IFX_CLEAR_DISABLED			(TPM_IFX_BASE + 5)	// The clear disable flag is set and all clear operations now require physical access
#define TPM_E_IFX_DEACTIVATED				(TPM_IFX_BASE + 6)	// The TPM is deactivated
#define TPM_E_IFX_DISABLED					(TPM_IFX_BASE + 7)	// The TPM is disabled
#define TPM_E_IFX_DISABLED_CMD				(TPM_IFX_BASE + 8)	// The target command has been disabled
#define TPM_E_IFX_FAIL						(TPM_IFX_BASE + 9)	// The operation failed
#define TPM_E_IFX_BAD_ORDINAL				(TPM_IFX_BASE + 10)	// The ordinal was unknown or inconsistent
#define TPM_E_IFX_INSTALL_DISABLED			(TPM_IFX_BASE + 11)	// The ability to install an owner is disabled
#define TPM_E_IFX_INVALID_KEYHANDLE			(TPM_IFX_BASE + 12)	// The key handle presented was invalid
#define TPM_E_IFX_KEYNOTFOUND				(TPM_IFX_BASE + 13)	// The target key was not found
#define TPM_E_IFX_INAPPROPRIATE_ENC			(TPM_IFX_BASE + 14)	// Unacceptable encryption scheme
#define TPM_E_IFX_MIGRATEFAIL				(TPM_IFX_BASE + 15)	// Migration authorization failed
#define TPM_E_IFX_INVALID_PCR_INFO			(TPM_IFX_BASE + 16)	// PCR information could not be interpreted
#define TPM_E_IFX_NOSPACE					(TPM_IFX_BASE + 17)	// No room to load key
#define TPM_E_IFX_NOSRK						(TPM_IFX_BASE + 18)	// There is no SRK set
#define TPM_E_IFX_NOTSEALED_BLOB			(TPM_IFX_BASE + 19)	// An encrypted blob is invalid or was not created by this TPM
#define TPM_E_IFX_OWNER_SET					(TPM_IFX_BASE + 20)	// There is already an Owner
#define TPM_E_IFX_RESOURCES					(TPM_IFX_BASE + 21)	// The TPM has insufficient internal resources to perform the requested action
#define TPM_E_IFX_SHORTRANDOM				(TPM_IFX_BASE + 22)	// A random string was too short
#define TPM_E_IFX_SIZE						(TPM_IFX_BASE + 23)	// The TPM does not have the space to perform the operation
#define TPM_E_IFX_WRONGPCRVAL				(TPM_IFX_BASE + 24)	// The named PCR value does not match the current PCR value
#define TPM_E_IFX_BAD_PARAM_SIZE			(TPM_IFX_BASE + 25)	// The paramSize argument to the command has the incorrect value
#define TPM_E_IFX_SHA_THREAD				(TPM_IFX_BASE + 26)	// There is no existing SHA-1 thread
#define TPM_E_IFX_SHA_ERROR					(TPM_IFX_BASE + 27)	// The calculation is unable to proceed because the existing SHA-1 thread has already encountered an error
#define TPM_E_IFX_FAILEDSELFTEST			(TPM_IFX_BASE + 28)	// Self-test has failed and the TPM has shutdown
#define TPM_E_IFX_AUTH2FAIL					(TPM_IFX_BASE + 29)	// The authorization for the second key in a 2 key function failed authorization
#define TPM_E_IFX_BADTAG					(TPM_IFX_BASE + 30)	// The tag value sent to for a command is invalid
#define TPM_E_IFX_IOERROR					(TPM_IFX_BASE + 31)	// An IO error occurred transmitting information to the TPM
#define TPM_E_IFX_ENCRYPT_ERROR				(TPM_IFX_BASE + 32)	// The encryption process had a problem
#define TPM_E_IFX_DECRYPT_ERROR				(TPM_IFX_BASE + 33)	// The decryption process did not complete
#define TPM_E_IFX_INVALID_AUTHHANDLE		(TPM_IFX_BASE + 34)	// An invalid handle was used
#define TPM_E_IFX_NO_ENDORSEMENT			(TPM_IFX_BASE + 35)	// The TPM does not a EK installed
#define TPM_E_IFX_INVALID_KEYUSAGE			(TPM_IFX_BASE + 36)	// The usage of a key is not allowed
#define TPM_E_IFX_WRONG_ENTITYTYPE			(TPM_IFX_BASE + 37)	// The submitted entity type is not allowed
#define TPM_E_IFX_INVALID_POSTINIT			(TPM_IFX_BASE + 38)	// The command was received in the wrong sequence relative to TPM_Init and a subsequent TPM_Startup
#define TPM_E_IFX_INAPPROPRIATE_SIG			(TPM_IFX_BASE + 39)	// Signed data cannot include additional DER information
#define TPM_E_IFX_BAD_KEY_PROPERTY			(TPM_IFX_BASE + 40)	// The key properties in TPM_KEY_PARMs are not supported by this TPM
#define TPM_E_IFX_BAD_MIGRATION				(TPM_IFX_BASE + 41)	// The migration properties of this key are incorrect
#define TPM_E_IFX_BAD_SCHEME				(TPM_IFX_BASE + 42)	// The signature or encryption scheme for this key is incorrect or not permitted in this situation
#define TPM_E_IFX_BAD_DATASIZE				(TPM_IFX_BASE + 43)	// The size of the data (or blob) parameter is bad or inconsistent with the referenced key
#define TPM_E_IFX_BAD_MODE					(TPM_IFX_BASE + 44)	// A mode parameter is bad, such as capArea or subCapArea for TPM_GetCapability, physicalPresence parameter for TPM_PhysicalPresence, or migrationType for TPM_CreateMigrationBlob
#define TPM_E_IFX_BAD_PRESENCE				(TPM_IFX_BASE + 45)	// Either the physicalPresence or physicalPresenceLock bits have the wrong value
#define TPM_E_IFX_BAD_VERSION				(TPM_IFX_BASE + 46)	// The TPM cannot perform this version of the capability
#define TPM_E_IFX_NO_WRAP_TRANSPORT			(TPM_IFX_BASE + 47)	// The TPM does not allow for wrapped transport sessions
#define TPM_E_IFX_AUDITFAIL_UNSUCCESSFUL	(TPM_IFX_BASE + 48)	// TPM audit construction failed and the underlying command was returning a failure code also
#define TPM_E_IFX_AUDITFAIL_SUCCESSFUL		(TPM_IFX_BASE + 49)	// TPM audit construction failed and the underlying command was returning success
#define TPM_E_IFX_NOTRESETABLE				(TPM_IFX_BASE + 50)	// Attempt to reset a PCR register that does not have the resettable attribute
#define TPM_E_IFX_NOTLOCAL					(TPM_IFX_BASE + 51)	// Attempt to reset a PCR register that requires Locality and Locality modifier not part of command transport
#define TPM_E_IFX_BAD_TYPE					(TPM_IFX_BASE + 52)	// Make identity blob not properly typed
#define TPM_E_IFX_INVALID_RESOURCE			(TPM_IFX_BASE + 53)	// When saving context identified resource type does not match actual resource
#define TPM_E_IFX_NOTFIPS					(TPM_IFX_BASE + 54)	// The TPM is attempting to execute a command only available when in FIPS mode
#define TPM_E_IFX_INVALID_FAMILY			(TPM_IFX_BASE + 55)	// The command is attempting to use an invalid family ID
#define TPM_E_IFX_NO_NV_PERMISSION			(TPM_IFX_BASE + 56)	// The permission to manipulate the NV storage is not available
#define TPM_E_IFX_REQUIRES_SIGN				(TPM_IFX_BASE + 57)	// The operation requires a signed command
#define TPM_E_IFX_KEY_NOTSUPPORTED			(TPM_IFX_BASE + 58)	// Wrong operation to load an NV key
#define TPM_E_IFX_AUTH_CONFLICT				(TPM_IFX_BASE + 59)	// NV_LoadKey blob requires both owner and blob authorization
#define TPM_E_IFX_AREA_LOCKED				(TPM_IFX_BASE + 60)	// The NV area is locked and not writable
#define TPM_E_IFX_BAD_LOCALITY				(TPM_IFX_BASE + 61)	// The Locality is incorrect for the attempted operation
#define TPM_E_IFX_READ_ONLY					(TPM_IFX_BASE + 62)	// The NV area is read only and can't be written to
#define TPM_E_IFX_PER_NOWRITE				(TPM_IFX_BASE + 63)	// There is no protection on the write to the NV area
#define TPM_E_IFX_FAMILYCOUNT				(TPM_IFX_BASE + 64)	// The family count value does not match
#define TPM_E_IFX_WRITE_LOCKED				(TPM_IFX_BASE + 65)	// The NV area has already been written to
#define TPM_E_IFX_BAD_ATTRIBUTES			(TPM_IFX_BASE + 66)	// The NV area attributes conflict
#define TPM_E_IFX_INVALID_STRUCTURE			(TPM_IFX_BASE + 67)	// The structure tag and version are invalid or inconsistent
#define TPM_E_IFX_KEY_OWNER_CONTROL			(TPM_IFX_BASE + 68)	// The key is under control of the TPM Owner and can only be evicted by the TPM Owner
#define TPM_E_IFX_BAD_COUNTER				(TPM_IFX_BASE + 69)	// The counter handle is incorrect
#define TPM_E_IFX_NOT_FULLWRITE				(TPM_IFX_BASE + 70)	// The write is not a complete write of the area
#define TPM_E_IFX_CONTEXT_GAP				(TPM_IFX_BASE + 71)	// The gap between saved context counts is too large
#define TPM_E_IFX_MAXNVWRITES				(TPM_IFX_BASE + 72)	// The maximum number of NV writes without an owner has been exceeded
#define TPM_E_IFX_NOOPERATOR				(TPM_IFX_BASE + 73)	// No operator authorization value is set
#define TPM_E_IFX_RESOURCEMISSING			(TPM_IFX_BASE + 74)	// The resource pointed to by context is not loaded
#define TPM_E_IFX_DELEGATE_LOCK				(TPM_IFX_BASE + 75)	// The delegation administration is locked
#define TPM_E_IFX_DELEGATE_FAMILY			(TPM_IFX_BASE + 76)	// Attempt to manage a family other then the delegated family
#define TPM_E_IFX_DELEGATE_ADMIN			(TPM_IFX_BASE + 77)	// Delegation Management not enabled
#define TPM_E_IFX_TRANSPORT_NOTEXCLUSIVE	(TPM_IFX_BASE + 78)	// There was a command executed outside of an exclusive transport session
#define TPM_E_IFX_OWNER_CONTROL				(TPM_IFX_BASE + 79)	// Attempt to context save a owner evict controlled key
#define TPM_E_IFX_DAA_RESOURCES				(TPM_IFX_BASE + 80)	// The DAA command has no resource available to execute the command
#define TPM_E_IFX_DAA_INPUT_DATA0			(TPM_IFX_BASE + 81)	// The consistency check on DAA parameter inputData0 has failed
#define TPM_E_IFX_DAA_INPUT_DATA1			(TPM_IFX_BASE + 82)	// The consistency check on DAA parameter inputData1 has failed
#define TPM_E_IFX_DAA_ISSUER_SETTINGS		(TPM_IFX_BASE + 83)	// The consistency check on DAA_issuerSettings has failed
#define TPM_E_IFX_DAA_TPM_SETTINGS			(TPM_IFX_BASE + 84)	// The consistency check on DAA_tpmSpecific has failed
#define TPM_E_IFX_DAA_STAGE					(TPM_IFX_BASE + 85)	// The atomic process indicated by the submitted DAA command is not the expected process
#define TPM_E_IFX_DAA_ISSUER_VALIDITY		(TPM_IFX_BASE + 86)	// The issuer's validity check has detected an inconsistency
#define TPM_E_IFX_DAA_WRONG_W				(TPM_IFX_BASE + 87)	// The consistency check on w has failed
#define TPM_E_IFX_BAD_HANDLE				(TPM_IFX_BASE + 88)	// The handle is incorrect
#define TPM_E_IFX_NOCONTEXTSPACE			(TPM_IFX_BASE + 89)	// There is no room in the context list for additional contexts
#define TPM_E_IFX_BADCONTEXT				(TPM_IFX_BASE + 90)	// The context blob is invalid
#define TPM_E_IFX_TOOMANYCONTEXTS			(TPM_IFX_BASE + 91)	// There are too many contexts made for this owner
#define TPM_E_IFX_MA_TICKET_SIGNATURE		(TPM_IFX_BASE + 92)	// Migration authority signature validation failure
#define TPM_E_IFX_MA_DESTINATION			(TPM_IFX_BASE + 93)	// Migration destination not authenticated
#define TPM_E_IFX_MA_SOURCE					(TPM_IFX_BASE + 94)	// Migration source incorrect
#define TPM_E_IFX_MA_AUTHORITY				(TPM_IFX_BASE + 95)	// Incorrect migration authority

// TPM additional error codes
#define TPM_E_IFX_COMM_DATA_LOST			(TPM_IFX_BASE + 0xff01)	// A communications error with the TPM has been detected
#define TPM_E_IFX_UNSUPPORTED_FEATURE		(TPM_IFX_BASE + 0xff02)	// The TPM does not support the requested feature
#define TPM_E_IFX_PENDING					(TPM_IFX_BASE + 0xff03)	// The operation that was requested is pending completion
#define TPM_E_IFX_TIMEOUT					(TPM_IFX_BASE + 0xff04)	// The operation has timed out
#define TPM_E_IFX_ALREADY_OPENED			(TPM_IFX_BASE + 0xff05)	// The connection was already established
#define TPM_E_IFX_INSUFFICIENT_BUFFER		(TPM_IFX_BASE + 0xff06)	// Buffer was to small

#define TPM_E_IFX_NOT_READY					(TPM_IFX_BASE + 0xff08)	// The TPM is not ready to accept commands
#define TPM_E_IFX_CANCELLED					(TPM_IFX_BASE + 0xff09)	// The action was cancelled by request
#define TPM_E_IFX_UNKNOWN_TPM				(TPM_IFX_BASE + 0xff0a)	// The specified TPM is not recognized
#define TPM_E_IFX_NO_SERVICE				(TPM_IFX_BASE + 0xff0b)	// The TPS is not running
#define TPM_E_IFX_SERVICE_STOPPED			(TPM_IFX_BASE + 0xff0c)	// The TPS has shut down
#define TPM_E_IFX_UNEXPECTED				(TPM_IFX_BASE + 0xff0d)	// An unexpected TPM error has occurred
#define TPM_E_IFX_UNKNOWN_ERROR				(TPM_IFX_BASE + 0xff0e)	// An internal error has been detected, but the source is unknown
#define TPM_E_IFX_INTERNAL_ERROR			(TPM_IFX_BASE + 0xff0f)	// An internal SW error has been detected
#define TPM_E_IFX_OUTOFMEMORY				(TPM_IFX_BASE + 0xff10)	// Ran out of memory

// TPM non-fatal error codes
#define TPM_E_IFX_RETRY							(TPM_IFX_BASE + TPM_IFX_NON_FATAL)	// The TPM is too busy to respond to the command immediately, but the command could be...
#define TPM_E_IFX_RETRY_INTERNAL				(TPM_IFX_BASE + TPM_IFX_NON_FATAL_INTERNAL)	// ...resubmitted at a later time. The TPM MAY return TPM_E_IFX_RETRY for any command at any time.
#define TPM_E_IFX_NEEDS_SELFTEST				(TPM_IFX_BASE + TPM_IFX_NON_FATAL + 1)	// SelfTestFull has not been run
#define TPM_E_IFX_NEEDS_SELFTEST_INTERNAL		(TPM_IFX_BASE + TPM_IFX_NON_FATAL_INTERNAL + 1)
#define TPM_E_IFX_DOING_SELFTEST					(TPM_IFX_BASE + TPM_IFX_NON_FATAL + 2)	// The TPM is currently executing a full selftest
#define TPM_E_IFX_DOING_SELFTEST_INTERNAL			(TPM_IFX_BASE + TPM_IFX_NON_FATAL_INTERNAL + 2)
#define TPM_E_IFX_DEFEND_LOCK_RUNNING				(TPM_IFX_BASE + TPM_IFX_NON_FATAL + 3)	// The TPM is defending against dictionary attacks and is in some time-out period
#define TPM_E_IFX_DEFEND_LOCK_RUNNING_INTERNAL	(TPM_IFX_BASE + TPM_IFX_NON_FATAL_INTERNAL + 3)
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TPM_ERRO_H__
