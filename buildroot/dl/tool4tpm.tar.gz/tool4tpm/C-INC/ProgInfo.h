/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	ProgInfo.h

Description:	Header file containing information about this program

Author:			Viktor Wallner	2013/03/12

Environment:	16-Bit DOS, 32-Bit/64-Bit Windows, 32-Bit/64-Bit Linux/ARM, 64-Bit UEFI

Revision History:

Notes:

--*/

#ifndef __PROGINFO_H__
#define __PROGINFO_H__

//---------------------------------------------------------------
// Required definitions

#define PROGNAME			"Tool4TPM"

#ifdef UEFI_I2C
#define VERSION				"06.02.0.0-HPP"
#else
#define VERSION				"06.02.0.0"
#endif

#define LOG_FILE_NAME		"tool4tpm.log"
#define CFG_FILE_NAME		"tool4tpm.cfg"

//---------------------------------------------------------------
// File and data output definitions

#define B_EK_FILE_NAME		"PubEK.bin"
#define H_EK_FILE_NAME		"PubEK.hex"
#define B_SRK_FILE_NAME		"PubSRK.bin"
#define H_SRK_FILE_NAME		"PubSRK.hex"
#define CERT_FILE_NAME		"EK.cer"

#ifndef DOS
#define LOG_FILE_NAME0		"tool4tpm0.log"
#define LOG_FILE_NAME1		"tool4tpm1.log"
#define LOG_FILE_NAME2		"tool4tpm2.log"
#define LOG_FILE_NAME3		"tool4tpm3.log"
#define LOG_FILE_NAME4		"tool4tpm4.log"
#else
#define LOG_FILE_NAME0		"tool4tp0.log"
#define LOG_FILE_NAME1		"tool4tp1.log"
#define LOG_FILE_NAME2		"tool4tp2.log"
#define LOG_FILE_NAME3		"tool4tp3.log"
#define LOG_FILE_NAME4		"tool4tp4.log"
#endif

#define RSP_FILE_NAME		"response.txt"

//---------------------------------------------------------------
// Tool4TPM specific error return codes
// only use error codes from RC_E_BASE + 38 to RC_E_BASE + 99
// don't modify already defined error codes
#define RC_E_SEALTESTERROR			(RC_E_BASE + 41)	// Error during the Sealtest
// *** add new error codes here ***

//---------------------------------------------------------------
// Enumerator for the Tool4TPM operating modes

typedef enum tdT4T_MODE {
	MODE_AUTOMENU,
	MODE_COMMANDFILE,
	MODE_INTEGRATION,
	MODE_MENU,
	MODE_PRODUCTION,
	MODE_LOOPTEST,
	MODE_FLAGCHECK,
	MODE_SEALTEST,
	MODE_AUTOTEST
} T4T_MODE;

#endif // __PROGINFO_H__