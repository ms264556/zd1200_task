/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	ASN1pars.h

Description:	Header file for the Abstract Syntax Notation One parser

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __ASN1PARS_H__
#define __ASN1PARS_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

#define MAX_NUM_LEN					0x7FFFFFFF

#define V_ASN1_PRIVATE				0xc0
#define V_ASN1_CONSTRUCTED			0x20
#define V_ASN1_PRIMITIVE_TAG		0x1f
#define V_ASN1_PRIMATIVE_TAG		0x1f

#define V_ASN1_EOC					0
#define V_ASN1_BOOLEAN				1
#define V_ASN1_INTEGER				2
#define V_ASN1_NEG_INTEGER			(2 | V_ASN1_NEG)
#define V_ASN1_BIT_STRING			3
#define V_ASN1_OCTET_STRING			4
#define V_ASN1_NULL					5
#define V_ASN1_OBJECT				6
#define V_ASN1_OBJECT_DESCRIPTOR	7
#define V_ASN1_EXTERNAL				8
#define V_ASN1_REAL					9
#define V_ASN1_ENUMERATED			10
#define V_ASN1_NEG_ENUMERATED		(10 | V_ASN1_NEG)
#define V_ASN1_UTF8STRING			12
#define V_ASN1_SEQUENCE				16
#define V_ASN1_SET					17
#define V_ASN1_NUMERICSTRING		18
#define V_ASN1_PRINTABLESTRING		19
#define V_ASN1_T61STRING			20
#define V_ASN1_TELETEXSTRING		20
#define V_ASN1_VIDEOTEXSTRING		21
#define V_ASN1_IA5STRING			22
#define V_ASN1_UTCTIME				23
#define V_ASN1_GENERALIZEDTIME		24
#define V_ASN1_GRAPHICSTRING		25
#define V_ASN1_ISO64STRING			26
#define V_ASN1_VISIBLESTRING		26
#define V_ASN1_GENERALSTRING		27
#define V_ASN1_UNIVERSALSTRING		28
#define V_ASN1_BMPSTRING			30

long ASN1parser(unsigned char *pp, char **key, long len);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __ASN1PARS_H__
