/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TDDL.h

Description:	Header file for the TPM Device Driver Layer (TDDL)

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TDDL_H__
#define __TDDL_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

#define TPM_STARTUP_CLEAR {0x00,0xC1,0x00,0x00,0x00,0x0C,0x00,0x00,0x00,0x99,0x00,0x01}
#define TPM_STARTUP_STATE {0x00,0xC1,0x00,0x00,0x00,0x0C,0x00,0x00,0x00,0x99,0x00,0x02}
#define TPM_STARTUP_DECATIVATED {0x00,0xC1,0x00,0x00,0x00,0x0C,0x00,0x00,0x00,0x99,0x00,0x03}

// Connect to the TPM
UINT32 TDDL_Open(void);

// Disconnect from the TPM
UINT32 TDDL_Close(void);

// Perform loop test of LPC register
void LoopTest(UINT32 dwRegister, BYTE bData, UINT16 wNumber, BOOL bEvalResponse);

// Send the TPM Application Protocol Data Unit (APDU) to the TPM and return the response APDU
UINT32 TDDL_TransmitData(BYTE * pbTransmitBuf, UINT32 dwTransmitBufLen, BYTE * pbReceiveBuf, UINT32 * pdwReceiveBufLen);

// Return the requested capability of the TPM or the driver
UINT32 TDDL_GetCapability(UINT32 dwCapArea, UINT32 dwSubCap, BYTE * pbReceiveBuf, UINT32 * pdwReceiveBufLen);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TDDL_H__
