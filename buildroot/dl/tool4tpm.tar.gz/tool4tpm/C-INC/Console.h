/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Console.h

Description:	Header file for the screen control routines

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __CONSOLE_H__
#define __CONSOLE_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

#ifdef UEFI_X64
#include <Library/UefiBootServicesTableLib.h>	// because of gST, gBS
#include <Library/UefiLib.h>			// because of AsciiPrint
#include <Library/UefiApplicationEntryPoint.h>	// because of Exit
#include <Library/BaseLib.h>
int kbhit(void);
CHAR8 getch(void);
CHAR8 getCharForUEFIKey(EFI_INPUT_KEY Key);
#ifdef GCC
static inline void init_keyboard() { return; }
static inline void close_keyboard() { return; }
#else
static void init_keyboard() { return; }
static void close_keyboard() { return; }
#endif
#else
#ifndef DJGPP
#define VIDEOPAGE				*(BYTE _far *)0x0462L
#define SCRBUFF					0xB8000000L
#define SCREENROWS				( (*(char _far *)0x0484L) ? 1+(*(char _far *)0x0484L) : 25 )
#endif // DJGPP
#define SCREEN_BUFFER_SIZE_X	300
#define SCREEN_BUFFER_SIZE_Y	1000
#ifdef linux
#if TTY_ACCESS == 1
static inline int kbhit() {return 1;}
static inline void init_keyboard() { return; }
static inline void close_keyboard() { return; }
#else //TTY_ACCESS ==0
int kbhit();
void init_keyboard();
void close_keyboard();
#endif //TTY_ACCESS
#else //not linux
static void init_keyboard() { return; }
static void close_keyboard() { return; }
#endif //--------linux--------
#endif //--------UEFI_X64--------


// Initialize console
void InitConsole(BYTE b80x50mode);

// Clear screen
void ClrScr(void);

// Writes a formatted string to the console
void ConsoleWritef(char *pcFormat, ...);

// Writes a string to the console
void ConsoleWrite(char *pcString);

// Print the error message based on the error code
void PrintErrorMessage(UINT32 dwErrorCode);

// Returns a string message for a given error code
void ErrorCodeToMessage(UINT32 dwErrorCode, char *pcErrorMessage, UINT32 dwMaxLength);

// Optional function pointer to extend the ErrorCodeToMessage function
BOOL (*ErrorCodeToMessageEx)(UINT32 dwErrorCode, char *pcErrorMessage, UINT32 dwMaxLength);

// Returns a formatted error message for a given error code
void GetFormattedErrorMessage(UINT32 dwErrorCode, char *pcErrorMessage, UINT32 dwMaxLength, UINT32 dwIntend, UINT32 dwMaxCharsPerLine, BOOL bAddErrorCode);

// Flushes the input buffer.
void FlushInputBuffer(void);

// Waits for the user to press a key and returns the pressed key
char (*WaitForKeyHook)(void);
char WaitForKey(void);

// Checks if the given key is pressed
BOOL (*IsKeyPressedHook)(char cKey);
BOOL IsKeyPressed(char cKey);

// Prompts the user to enter a number
UINT32 (*PromptForNumberHook)(char *prompt, UINT32 *number);
UINT32 PromptForNumber(char *prompt, UINT32 *number) ;

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __CONSOLE_H__
