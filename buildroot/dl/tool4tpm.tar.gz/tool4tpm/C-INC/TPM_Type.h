/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Type.h

Description:	Definition of the TPM data types according to TCG Main Specification Version 1.2

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TPM_TYPE_H__
#define __TPM_TYPE_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#ifdef WIN32			//--------WIN32-----------
#include <windows.h>
#else //--------DOS/LINUX-------------

#ifdef UEFI_X64
//
#else
#define FALSE	0
#define TRUE	!FALSE
#endif

typedef unsigned char BOOL;
#ifdef linux
typedef unsigned int UINT32;
#else //DOS
#ifdef UEFI_X64

#else
typedef unsigned long UINT32;
#endif
#endif //-------DOS/WIN/LINUX----------
#endif
typedef unsigned char BYTE;
typedef unsigned short UINT16;

//-------------------------------------------------------------------
// TCG specific helper redefinitions
typedef UINT32 TPM_RESULT;	// the return code from a function

typedef UINT32 TPM_PCRINDEX;	// index to a PCR register
typedef UINT32 TPM_DIRINDEX;	// index to a DIR register
typedef UINT32 TPM_KEY_HANDLE;	// handle to a loaded key
typedef UINT32 TPM_AUTHHANDLE;	// handle to a authorization session
typedef UINT32 TPM_ENTITYHANDLE;	// handle to a TCPA entity, i.e. sealed data, key 
typedef UINT32 TSS_HASHHANDLE;	// handle to a hash session
typedef UINT32 TSS_HMACHANDLE;	// handle to a HMAC session
typedef UINT32 TPM_EVENTTYPE;	// type of PCR event
typedef UINT32 TPM_COMMAND_CODE;	// the command ordinal
typedef UINT32 TPM_ALGORITHM_ID;	// indicates the type of algorithm. See 4.23
typedef UINT32 TPM_CAPABILITY_AREA;	// identifies a TPM capability area
typedef UINT32 TPM_COUNT_ID;	// handle to a counter
typedef UINT32 TPM_ACTUAL_COUNT;
typedef UINT32 TPM_FAMILY_ID;
typedef UINT32 TPM_FAMILY_VERIFICATION;
typedef UINT32 TPM_DELEGATE_INDEX;	// section 19.10 TPM Spec. 1.2 rev 51
typedef UINT32 TPM_TRANSPORT_ATTRIBUTES;	// section 2.2.3 TPM Spec. 1.2 rev 52
typedef UINT32 TPM_TRANSHANDLE;
typedef UINT32 TPM_RESOURCE_TYPE;	// section 2.2.3 TPM Spec. 1.2 rev 52
typedef UINT32 TPM_HANDLE;
typedef UINT32 TPM_FAMILY_OPERATION;
typedef UINT32 TPM_KEY_FLAGS;
typedef UINT32 TPM_MODIFIER_INDICATOR;
typedef UINT32 TPM_NV_INDEX;
typedef UINT32 TPM_STARTUP_EFFECTS;
typedef UINT32 TPM_SYM_MODE;
typedef UINT32 TPM_CMK_RESTRICT_DELEGATE;
typedef UINT32 TPM_REDIT_COMMAND;
typedef UINT32 TPM_GPIO_ATTRIBUTES;
typedef UINT32 TPM_GPIO_BUS;
typedef UINT32 TPM_CMK_DELEGATE;

typedef UINT16 TPM_STRUCTURE_TAG;
typedef UINT16 TPM_KEY_USAGE;	// indicates the permitted usage of the key. See 4.16.6
typedef UINT16 TPM_PROTOCOL_ID;	// the protocol in use
typedef UINT16 TPM_ENC_SCHEME;	// the definition of the encryption scheme
typedef UINT16 TPM_SIG_SCHEME;	// the definition of the signature scheme
typedef UINT16 TPM_MIGRATE_SCHEME;	// the definition of the migration scheme
typedef UINT16 TPM_TAG;		// command tag identifier
typedef UINT16 TPM_ENTITY_TYPE;	// this specifies the types of entity that are supported by the TPM
typedef UINT16 TPM_STARTUP_TYPE;	// indicates the start state
typedef UINT16 TPM_PHYSICAL_PRESENCE;	// the definition of the migration scheme
typedef UINT16 TPM_EK_TYPE;	// the type of asymmetric encrypted structure in use by the endorsement key
typedef UINT16 TPM_CLOCK_TYPE;	// value indicating the type of TickCounter
typedef UINT16 TPM_PLATFORM_SPECIFIC;

typedef BYTE TPM_AUTH_DATA_USAGE;	// when is authorization required for an entity
typedef BYTE TPM_PAYLOAD_TYPE;
typedef BYTE TPM_LOCALITY_SELECTION;
typedef BYTE TPM_VERSION_BYTE;

//-------------------------------------------------------------------
// PC Client Specific Implementation Specification Version 1.2 Revision 1.00
typedef BYTE TPM_CERT_TYPE;

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TPM_TYPE_H__
