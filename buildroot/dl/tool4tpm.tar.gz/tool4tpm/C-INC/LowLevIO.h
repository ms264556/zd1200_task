/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	LowLevIO.h

Description:	Header file for the low level TPM communication

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __LOWLEVIO_H__
#define __LOWLEVIO_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

#ifdef linux
#define DEV_TPM_MEM "/dev/tpm-mem"
#define DEV_TPM_IO "/dev/tpm-io"
#define DEV_TPM_TPM "/dev/tpm0"

#define IOCTL_SETPORTADDR 1
#define IOCTL_SETMEMADDR 1
#endif //--------linux--------

//---------------------------------------------------------------

#ifdef UEFI_I2C
#include <Protocol/LoadedImage.h>
#include <Protocol/EfiShellInterface.h>
#include <Protocol/EfiShellParameters.h>
#include <Protocol/I2CBusIoEx.h>
#include <Library/UefiLib.h>
#include <Library/BaseLib.h>
#include <Library/UefiBootServicesTableLib.h>

#define I2C_TPM_ADR				0x40
#define IFX_TPM_I2C_READ_FROM		0xB0
#define I2C_SPEED_MAX     400000
#define I2C_SPEED_DEFAULT 400000
#define I2C_SPEED_MIN     20000
//time in us
#define LATE_ACK_RETRY	16
#define LATE_ACK_TIME	10000
#define I2C_GUARD_TIME	250

I2C_BUS_IO_EX_PROTOCOL *I2CBusIoEx;
UINT32 I2cSpeed = I2C_SPEED_DEFAULT; 

// Setup protocol for HPP I2C master
EFI_STATUS InitializeI2c_Ex(void);
// enable/disable sending of I2C_READ_FROM frame (0xB0 + SFR-Adr)
void SendFrame_I2cReadFrom(BOOL bValue);
// set I2C frequency
void SetI2cFrequency(UINT32 dwValue);
// Write I2C data (max 6 bytes = 1 SFR-Adr + 5 user data)
UINT32 HPP_WriteData(BYTE bSfrAddr, UINT16 bTxDataCount, BYTE *pbTxData);
// Read I2C data (max 4 bytes user data)
UINT32 HPP_ReadData(BYTE bSfrAddr, UINT16 wTxDataCount, BYTE *pbTxData);
#endif

//---------------------------------------------------------------

// Initialize the appropriate low level driver
void LowLevelInit(BYTE bLocality);

// Initialize the appropriate low level driver
void LowLevelUninit(BYTE bLocality);

//---------------------------------------------------------------

// Read a Byte from the specified port address
BYTE InpByte(UINT16 wPortAdr);

// Write a Byte to the specified port address
void OutByte(UINT16 wPortAdr, BYTE bPortValue);

// Read a Word from the specified port address
UINT16 InpWord(UINT16 wPortAdr);

// Write a Byte to the specified port address
void OutWord(UINT16 wPortAdr, UINT16 wPortValue);

// Read a DoubleWord from the specified port address
UINT32 InpDWord(UINT16 wPortAdr);

// Write a DoubleWord to the specified port address
void OutDWord(UINT16 wPortAdr, UINT32 dwPortValue);

//---------------------------------------------------------------

// Read a Byte from the specified memory address
BYTE MemAccessReadByte(UINT32 dwMemAddr);

// Write a Byte to the specified memory address
void MemAccessWriteByte(UINT32 dwMemAddr, BYTE bData);

// Read a Word from the specified memory address
UINT16 MemAccessReadWord(UINT32 dwMemAddr);

// Write a Word to the specified memory address
void MemAccessWriteWord(UINT32 dwMemAddr, UINT16 wData);

// Read a DoubleWord from the specified memory address
UINT32 MemAccessReadDWord(UINT32 dwMemAddr);

// Write a DoubleWord to the specified memory address
void MemAccessWriteDWord(UINT32 dwMemAddr, UINT32 dwData);

//---------------------------------------------------------------

// Direct transmit over TPM device driver
#if USE_DRIVER == 2
UINT32 TpmTransmit(BYTE * pbTransmitBuf,
                   UINT32 dwTransmitBufLen,
                   BYTE * pbReceiveBuf,
                   UINT32 * pdwReceiveBufLen);
#endif
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __LOWLEVIO_H__
