/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Defi.h

Description:	Definition of the TPM values according to TCG Main Specification Version 1.2

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TPM_DEFI_H__
#define __TPM_DEFI_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

// Default memory address for TPM device
#define TPM_DEFAULT_MEM_BASE	0xFED40000
#define TPM_DEFAULT_MEM_SIZE	0x5000

// Address offset definitions on TPM register space for Locality
#define TPM_ACCESS_0						(TPM_DEFAULT_MEM_BASE + 0x0000)

#define TPM_INT_ENABLE_0_00					(TPM_DEFAULT_MEM_BASE + 0x0008)
#define TPM_INT_ENABLE_0_01					(TPM_DEFAULT_MEM_BASE + 0x0009)
#define TPM_INT_ENABLE_0_02					(TPM_DEFAULT_MEM_BASE + 0x000A)
#define TPM_INT_ENABLE_0_03					(TPM_DEFAULT_MEM_BASE + 0x000B)

#define TPM_INT_VECTOR_0					(TPM_DEFAULT_MEM_BASE + 0x000C)

#define TPM_INT_STATUS_0_00					(TPM_DEFAULT_MEM_BASE + 0x0010)
#define TPM_INT_STATUS_0_01					(TPM_DEFAULT_MEM_BASE + 0x0011)
#define TPM_INT_STATUS_0_02					(TPM_DEFAULT_MEM_BASE + 0x0012)
#define TPM_INT_STATUS_0_03					(TPM_DEFAULT_MEM_BASE + 0x0013)

#define TPM_INTF_CAPABILITY_0_00			(TPM_DEFAULT_MEM_BASE + 0x0014)
#define TPM_INTF_CAPABILITY_0_01			(TPM_DEFAULT_MEM_BASE + 0x0015)
#define TPM_INTF_CAPABILITY_0_02			(TPM_DEFAULT_MEM_BASE + 0x0016)
#define TPM_INTF_CAPABILITY_0_03			(TPM_DEFAULT_MEM_BASE + 0x0017)

#define TPM_STS_0_00						(TPM_DEFAULT_MEM_BASE + 0x0018)
#define TPM_STS_0_01						(TPM_DEFAULT_MEM_BASE + 0x0019)
#define TPM_STS_0_02						(TPM_DEFAULT_MEM_BASE + 0x001A)

#define TPM_DATA_FIFO_0_00					(TPM_DEFAULT_MEM_BASE + 0x0024)
#define TPM_DATA_FIFO_0_01					(TPM_DEFAULT_MEM_BASE + 0x0025)
#define TPM_DATA_FIFO_0_02					(TPM_DEFAULT_MEM_BASE + 0x0026)
#define TPM_DATA_FIFO_0_03					(TPM_DEFAULT_MEM_BASE + 0x0027)

#define FIRST_LEGACY_ADDRESS_0				(TPM_DEFAULT_MEM_BASE + 0x0F80)
#define FIRST_LEGACY_ADDRESS_EXTENSION_0	(TPM_DEFAULT_MEM_BASE + 0x0F84)

//////////////////////////////////////////////////////////////////////
// Parameter List Tag Identifiers
#define TPM_TAG_RQU_COMMAND			0x00C1	// A command with no authentication
#define TPM_TAG_RQU_AUTH1_COMMAND	0x00C2	// An authenticated command with one authentication handle
#define TPM_TAG_RQU_AUTH2_COMMAND	0x00C3	// An authenticated command with two authentication handles
#define TPM_TAG_RSP_COMMAND			0x00C4	// A response from a command with no authentication
#define TPM_TAG_RSP_AUTH1_COMMAND	0x00C5	// An authenticated response with one authentication handle
#define TPM_TAG_RSP_AUTH2_COMMAND	0x00C6	// An authenticated response with two authentication handles

//////////////////////////////////////////////////////////////////////
// vendor specific
#define TPM_Vendor_Specific8	0x80
#define TPM_Vendor_Specific16	0x8000
#define TPM_Vendor_Specific32	0x80000000

//////////////////////////////////////////////////////////////////////
// TPM_KEY_USAGE
#define TPM_KEY_SIGNING		0x0010
#define TPM_KEY_STORAGE		0x0011
#define TPM_KEY_IDENTITY	0x0012
#define TPM_KEY_AUTHCHANGE	0x0013
#define TPM_KEY_BIND		0x0014
#define TPM_KEY_LEGACY		0x0015
#define TPM_KEY_MIGRATE		0x0016

//////////////////////////////////////////////////////////////////////
// TPM_AUTH_DATA_USAGE 
#define TPM_AUTH_NEVER			0x00
#define TPM_AUTH_ALWAYS			0x01
#define TPM_AUTH_PRIV_USE_ONLY	0x03

//////////////////////////////////////////////////////////////////////
// TPM_PAYLOAD_TYPE
#define TPM_PT_ASYM					0x01
#define TPM_PT_BIND					0x02
#define TPM_PT_MIGRATE				0x03
#define TPM_PT_MAINT				0x04
#define TPM_PT_SEAL					0x05
#define TPM_PT_MIGRATE_RESTRICTED	0x06
#define TPM_PT_MIGRATE_EXTERNAL		0x07
#define TPM_PT_CMK_MIGRATE			0x08

//////////////////////////////////////////////////////////////////////
// TPM_ENTITY_TYPE
#define TPM_ET_DAA				0x0000
#define TPM_ET_OIAP				0x0000
#define TPM_ET_TRANSPORT		0x0000

#define TPM_ET_KEYHANDLE		0x0001
#define TPM_ET_OWNER			0x0002
#define TPM_ET_DATA				0x0003
#define TPM_ET_SRK				0x0004
#define TPM_ET_KEY				0x0005
#define TPM_ET_REVOKE			0x0006
#define TPM_ET_DEL_OWNER_BLOB	0x0007
#define TPM_ET_DEL_ROW			0x0008
#define TPM_ET_DEL_KEY_BLOB		0x0009
#define TPM_ET_COUNTER			0x000A
#define TPM_ET_NV				0x000B
#define TPM_ET_KEYAES			0x000C
#define TPM_ET_KEYDES			0x000D
#define TPM_ET_OWNERAES			0x000E
#define TPM_ET_OWNERDES			0x000F
#define TPM_ET_KEYXOR			0x0010

#define TPM_ET_RESERVED_HANDLE	0x0040
#define	TPM_ET_PROGRAM			0x00FE

//////////////////////////////////////////////////////////////////////
// TPM_KEYHANDLE
#define TPM_KH_SRK			0x40000000
#define TPM_KH_OWNER		0x40000001
#define TPM_KH_REVOKE		0x40000002
#define TPM_KH_TRANSPORT	0x40000003
#define TPM_KH_OPERATOR		0x40000004
#define TPM_KH_ADMIN		0x40000005
#define TPM_KH_EK			0x40000006

//////////////////////////////////////////////////////////////////////
// TPM_STARTUP_TYPE values
#define TPM_ST_CLEAR		0x0001
#define TPM_ST_STATE		0x0002
#define TPM_ST_DEACTIVATED	0x0003

//////////////////////////////////////////////////////////////////////
// TPM_PROTOCOL_ID
#define TPM_PID_OIAP		0x0001
#define TPM_PID_OSAP		0x0002
#define TPM_PID_ADIP		0x0003
#define TPM_PID_ADCP		0x0004
#define TPM_PID_OWNER		0x0005
#define TPM_PID_DSAP		0x0006
#define TPM_PID_TRANSPORT	0x0007

//////////////////////////////////////////////////////////////////////
// Algorithm identifiers
#define TPM_ALG_RSA			0x00000001
#define TPM_ALG_DES			0x00000002
#define TPM_ALG_3DES		0x00000003
#define TPM_ALG_SHA			0x00000004
#define TPM_ALG_HMAC		0x00000005
#define TPM_ALG_AES128		0x00000006
#define TPM_ALG_MGF1		0x00000007
#define TPM_ALG_AES192		0x00000008
#define TPM_ALG_AES256		0x00000009
#define TPM_ALG_XOR			0x0000000A

//////////////////////////////////////////////////////////////////////
// TPM_PHYSICAL_PRESENCE
#define TPM_PHYSICAL_PRESENCE_LOCK				0x0004
#define TPM_PHYSICAL_PRESENCE_PRESENT			0x0008
#define TPM_PHYSICAL_PRESENCE_NOTPRESENT		0x0010
#define TPM_PHYSICAL_PRESENCE_CMD_ENABLE		0x0020
#define TPM_PHYSICAL_PRESENCE_HW_ENABLE			0x0040
#define TPM_PHYSICAL_PRESENCE_LIFETIME_LOCK		0x0080
#define TPM_PHYSICAL_PRESENCE_CMD_DISABLE		0x0100
#define TPM_PHYSICAL_PRESENCE_HW_DISABLE		0x0200

//////////////////////////////////////////////////////////////////////
// TPM_MIGRATE_SCHEME
#define TPM_MS_MIGRATE						0x0001
#define TPM_MS_REWRAP						0x0002
#define TPM_MS_MAINT						0x0003
#define TPM_MS_RESTRICT_MIGRATE				0x0004
#define TPM_MS_RESTRICT_APPROVE_DOUBLE		0x0005
#define TPM_MS_RESTRICT_MIGRATE_EXTERNAL	0x0006

//////////////////////////////////////////////////////////////////////
// TPM_CAPABILITY_AREA
#define TPM_CAP_ORD				0x00000001
#define TPM_CAP_ALG				0x00000002
#define TPM_CAP_PID				0x00000003
#define TPM_CAP_FLAG			0x00000004
#define TPM_CAP_PROPERTY		0x00000005
#define TPM_CAP_VERSION			0x00000006
#define TPM_CAP_KEY_HANDLE		0x00000007
#define TPM_CAP_CHECK_LOADED	0x00000008
#define TPM_CAP_SYM_MODE		0x00000009

#define TPM_CAP_KEY_STATUS		0x0000000C
#define TPM_CAP_NV_LIST			0x0000000D

#define TPM_CAP_MFR				0x00000010
#define TPM_CAP_NV_INDEX		0x00000011
#define TPM_CAP_TRANS_ALG		0x00000012

#define TPM_CAP_HANDLE			0x00000014
#define TPM_CAP_TRANS_ES		0x00000015

#define TPM_CAP_AUTH_ENCRYPT	0x00000017
#define TPM_CAP_SELECT_SIZE		0x00000018

#define TPM_CAP_VERSION_VAL		0x0000001A

//////////////////////////////////////////////////////////////////////
// Command ordinals
#define TPM_ORD_ActivateIdentity				0x0000007A
#define TPM_ORD_AuthorizeMigrationKey  			0x0000002B
#define TPM_ORD_CertifyKey						0x00000032
#define TPM_ORD_CertifyKey2						0x00000033
#define TPM_ORD_CertifySelfTest					0x00000052
#define TPM_ORD_ChangeAuth						0x0000000C
#define TPM_ORD_ChangeAuthAsymFinish			0x0000000F
#define TPM_ORD_ChangeAuthAsymStart				0x0000000E
#define TPM_ORD_ChangeAuthOwner					0x00000010
#define TPM_ORD_CMK_ApproveMA					0x0000001D
#define TPM_ORD_CMK_ConvertMigration			0x00000024
#define TPM_ORD_CMK_CreateBlob					0x0000001B
#define TPM_ORD_CMK_CreateKey					0x00000013
#define TPM_ORD_CMK_CreateTicket				0x00000012
#define TPM_ORD_CMK_SetRestrictions				0x0000001C
#define TPM_ORD_ContinueSelfTest				0x00000053
#define TPM_ORD_ConvertMigrationBlob			0x0000002A
#define TPM_ORD_CreateCounter					0x000000DC
#define TPM_ORD_CreateEndorsementKeyPair		0x00000078
#define TPM_ORD_CreateMaintenanceArchive		0x0000002C
#define TPM_ORD_CreateMigrationBlob   			0x00000028
#define TPM_ORD_CreateRevocableEK				0x0000007F
#define TPM_ORD_CreateWrapKey					0x0000001F
#define TPM_ORD_DAA_Join						0x00000029
#define TPM_ORD_DAA_Sign						0x00000031
#define TPM_ORD_Delegate_CreateKeyDelegation	0x000000D4
#define TPM_ORD_Delegate_CreateOwnerDelegation	0x000000D5
#define TPM_ORD_Delegate_LoadOwnerDelegation	0x000000D8
#define TPM_ORD_Delegate_Manage					0x000000D2
#define TPM_ORD_Delegate_ReadTable				0x000000DB
#define TPM_ORD_Delegate_UpdateVerification		0x000000D1
#define TPM_ORD_Delegate_VerifyDelegation		0x000000D6
#define TPM_ORD_DirRead							0x0000001A
#define TPM_ORD_DirWriteAuth					0x00000019
#define TPM_ORD_DisableForceClear				0x0000005E
#define TPM_ORD_DisableOwnerClear				0x0000005C
#define TPM_ORD_DisablePubekRead				0x0000007E
#define TPM_ORD_DSAP							0x00000011
#define TPM_ORD_EstablishTransport				0x000000E6
#define TPM_ORD_EvictKey						0x00000022
#define TPM_ORD_ExecuteTransport				0x000000E7
#define TPM_ORD_Extend							0x00000014
#define TPM_ORD_FieldUpgrade					0x000000AA
#define TPM_ORD_FlushSpecific					0x000000BA
#define TPM_ORD_ForceClear						0x0000005D
#define TPM_ORD_GetAuditDigest					0x00000085
#define TPM_ORD_GetAuditDigestSigned			0x00000086
#define TPM_ORD_GetAuditEvent					0x00000082
#define TPM_ORD_GetAuditEventSigned				0x00000083
#define TPM_ORD_GetCapability					0x00000065
#define TPM_ORD_GetCapabilityOwner				0x00000066
#define TPM_ORD_GetCapabilitySigned				0x00000064
#define TPM_ORD_GetOrdinalAuditStatus			0x0000008C
#define TPM_ORD_GetPubKey      					0x00000021
#define TPM_ORD_GetRandom	   					0x00000046
#define TPM_ORD_GetTestResult					0x00000054
#define TPM_ORD_GetTicks	   					0x000000F1
#define TPM_ORD_IncrementCounter				0x000000DD
#define TPM_ORD_Init							0x00000097
#define TPM_ORD_KeyControlOwner					0x00000023
#define TPM_ORD_KillMaintenanceFeature			0x0000002E
#define TPM_ORD_LoadAuthContext					0x000000B7
#define TPM_ORD_LoadContext	   					0x000000B9
#define TPM_ORD_LoadKey							0x00000020
#define TPM_ORD_LoadKey2						0x00000041
#define TPM_ORD_LoadKeyContext					0x000000B5
#define TPM_ORD_LoadMaintenanceArchive			0x0000002D
#define TPM_ORD_LoadManuMaintPub				0x0000002F
#define TPM_ORD_MakeIdentity					0x00000079
#define TPM_ORD_MigrateKey						0x00000025
#define TPM_ORD_NV_DefineSpace					0x000000CC
#define TPM_ORD_NV_ReadValue					0x000000CF
#define TPM_ORD_NV_ReadValueAuth				0x000000D0
#define TPM_ORD_NV_WriteValue					0x000000CD
#define TPM_ORD_NV_WriteValueAuth				0x000000CE
#define TPM_ORD_OIAP							0x0000000A
#define TPM_ORD_OSAP							0x0000000B
#define TPM_ORD_OwnerClear						0x0000005B
#define TPM_ORD_OwnerReadInternalPub			0x00000081
#define TPM_ORD_OwnerReadPubek					0x0000007D
#define TPM_ORD_OwnerSetDisable					0x0000006E
#define TPM_ORD_PCR_Reset						0x000000C8
#define TPM_ORD_PcrRead							0x00000015
#define TPM_ORD_PhysicalDisable					0x00000070
#define TPM_ORD_PhysicalEnable					0x0000006F
#define TPM_ORD_PhysicalSetDeactivated			0x00000072
#define TPM_ORD_Quote							0x00000016
#define TPM_ORD_Quote2							0x0000003E
#define TPM_ORD_ReadCounter						0x000000DE
#define TPM_ORD_ReadManuMaintPub				0x00000030
#define TPM_ORD_ReadPubek						0x0000007C
#define TPM_ORD_ReleaseCounter					0x000000DF
#define TPM_ORD_ReleaseCounterOwner				0x000000E0
#define TPM_ORD_ReleaseTransportSigned			0x000000E8
#define TPM_ORD_Reset							0x0000005A
#define TPM_ORD_ResetLockValue					0x00000040
#define TPM_ORD_RevokeTrust						0x00000080
#define TPM_ORD_SaveAuthContext					0x000000B6
#define TPM_ORD_SaveContext						0x000000B8
#define TPM_ORD_SaveKeyContext					0x000000B4
#define TPM_ORD_SaveState						0x00000098
#define TPM_ORD_Seal							0x00000017
#define TPM_ORD_Sealx							0x0000003D
#define TPM_ORD_SelfTestFull					0x00000050
#define TPM_ORD_SetCapability					0x0000003F
#define TPM_ORD_SetOperatorAuth					0x00000074
#define TPM_ORD_SetOrdinalAuditStatus			0x0000008D
#define TPM_ORD_SetOwnerInstall					0x00000071
#define TPM_ORD_SetOwnerPointer					0x00000075
#define TPM_ORD_SetRedirection					0x0000009A
#define TPM_ORD_SetTempDeactivated				0x00000073
#define TPM_ORD_SHA1Complete					0x000000A2
#define TPM_ORD_SHA1CompleteExtend				0x000000A3
#define TPM_ORD_SHA1Start						0x000000A0
#define TPM_ORD_SHA1Update						0x000000A1
#define TPM_ORD_Sign							0x0000003C
#define TPM_ORD_Startup							0x00000099
#define TPM_ORD_StirRandom						0x00000047
#define TPM_ORD_TakeOwnership					0x0000000D
#define TPM_ORD_Terminate_Handle				0x00000096
#define TPM_ORD_TickStampBlob					0x000000F2
#define TPM_ORD_UnBind							0x0000001E
#define TPM_ORD_Unseal							0x00000018
#define TSC_ORD_PhysicalPresence				0x4000000A
#define TSC_ORD_ResetEstablishmentBit			0x4000000B

// Masks
#define TPM_VENDOR_COMMAND			0x20000000	// Command is vendor specific
#define TPM_CONNECTION_COMMAND		0x40000000	// Command is connection related
#define TPM_UNPROTECTED_COMMAND		0x80000000	// Command is unprotected

//////////////////////////////////////////////////////////////////////
// Field Upgrade sub commands
#define TPM_FIELD_UPGRADE_INFO_REQUEST		0x10
#define TPM_FIELD_UPGRADE_INFO_REQUEST_2	0x11

//////////////////////////////////////////////////////////////////////
// Command purviews
#define TPM_MAIN		0x00
#define TPM_PC			0x01
#define TPM_PDA			0x02
#define TPM_CELLPHONE	0x03
#define TPM_SERVER		0x04

//////////////////////////////////////////////////////////////////////
// TPM_SIG_SCHEME
#define TPM_SS_NONE					0x0001
#define TPM_SS_RSASSAPKCS1v15_SHA1	0x0002
#define TPM_SS_RSASSAPKCS1v15_DER	0x0003
#define TPM_SS_RSASSAPKCS1v15_INFO	0x0004

//////////////////////////////////////////////////////////////////////
// TPM_ENC_SCHEME
#define TPM_ES_NONE					0x0001
#define TPM_ES_RSAESPKCSv15			0x0002
#define TPM_ES_RSAESOAEP_SHA1_MGF1	0x0003
#define TPM_ES_SYM_CNT				0x0004
#define TPM_ES_SYM_OFB				0x0005

//////////////////////////////////////////////////////////////////////
// Capability
#define TPM_CAP_PROP_PCR				0x00000101
#define TPM_CAP_PROP_DIR				0x00000102
#define TPM_CAP_PROP_MANUFACTURER		0x00000103
#define TPM_CAP_PROP_KEYS				0x00000104
#define TPM_CAP_PROP_MIN_COUNTER		0x00000107

#define TPM_CAP_FLAG_PERMANENT			0x00000108
#define TPM_CAP_FLAG_VOLATILE			0x00000109

#define TPM_CAP_PROP_AUTHSESS			0x0000010A
#define TPM_CAP_PROP_TRANSESS			0x0000010B
#define TPM_CAP_PROP_COUNTERS			0x0000010C
#define TPM_CAP_PROP_MAX_AUTHSESS		0x0000010D
#define TPM_CAP_PROP_MAX_TRANSESS		0x0000010E
#define TPM_CAP_PROP_MAX_COUNTERS		0x0000010F
#define TPM_CAP_PROP_MAX_KEYS			0x00000110
#define TPM_CAP_PROP_OWNER				0x00000111
#define TPM_CAP_PROP_CONTEXT			0x00000112
#define TPM_CAP_PROP_MAX_CONTEXT		0x00000113
#define TPM_CAP_PROP_FAMILYROWS			0x00000114
#define TPM_CAP_PROP_TIS_TIMEOUT		0x00000115
#define TPM_CAP_PROP_STARTUP_EFFECT		0x00000116
#define TPM_CAP_PROP_DELEGATE_ROW		0x00000117

#define TPM_CAP_PROP_DAA_MAX			0x00000119
#define TPM_CAP_PROP_SESSION_DAA		0x0000011A
#define TPM_CAP_PROP_CONTEXT_DIST		0x0000011B
#define TPM_CAP_PROP_DAA_INTERRUPT		0x0000011C
#define TPM_CAP_PROP_SESSIONS			0x0000011D
#define TPM_CAP_PROP_MAX_SESSIONS		0x0000011E
#define TPM_CAP_PROP_CMK_RESTRICTION	0x0000011F
#define TPM_CAP_PROP_DURATION			0x00000120

#define TPM_CAP_PROP_ACTIVE_COUNTER		0x00000122
#define TPM_CAP_PROP_MAX_NV_AVAILABLE	0x00000123
#define TPM_CAP_PROP_INPUT_BUFFER		0x00000124

//////////////////////////////////////////////////////////////////////
// Structure Tag
#define TPM_TAG_CONTEXTBLOB			0x0001	// TPM_CONTEXT_BLOB
#define TPM_TAG_CONTEXT_SENSITIVE	0x0002	// TPM_CONTEXT_SENSITIVE
#define TPM_TAG_CONTEXTPOINTER		0x0003	// TPM_CONTEXT_POINTER
#define TPM_TAG_CONTEXTLIST			0x0004	// TPM_CONTEXT_LIST
#define TPM_TAG_SIGNINFO			0x0005	// TPM_SIGN_INFO
#define TPM_TAG_PCR_INFO_LONG		0x0006	// TPM_PCR_INFO_LONG
#define TPM_TAG_PERSISTENT_FLAGS	0x0007	// TPM_PERSISTENT_FLAGS
#define TPM_TAG_VOLATILE_FLAGS		0x0008	// TPM_VOLATILE_FLAGS
#define TPM_TAG_PERSISTENT_DATA		0x0009	// TPM_PERSISTENT_DATA
#define TPM_TAG_VOLATILE_DATA		0x000A	// TPM_VOLATILE_DATA
#define TPM_TAG_SV_DATA				0x000B	// TPM_SV_DATA
#define TPM_TAG_EK_BLOB				0x000C	// TPM_EK_BLOB
#define TPM_TAG_EK_BLOB_AUTH		0x000D	// TPM_EK_BLOB_ACTIVATE
#define TPM_TAG_COUNTER_VALUE		0x000E	// TPM_COUNTER_VALUE
#define TPM_TAG_TRANSPORT_INTERNAL	0x000F	// TPM_TRANSPORT_INTERNAL
#define TPM_TAG_TRANSPORT_LOG_IN	0x0010	// TPM_TRANSPORT_LOG_IN
#define TPM_TAG_TRANSPORT_LOG_OUT	0x0011	// TPM_TRANSPORT_LOG_OUT
#define TPM_TAG_AUDIT_EVENT_IN		0x0012	// TPM_AUDIT_EVENT_IN
#define TPM_TAG_AUDIT_EVENT_OUT		0x0013	// TPM_AUDIT_EVENT_OUT
#define TPM_TAG_CURRENT_TICKS		0x0014	// TPM_CURRENT_TICKS
#define TPM_TAG_KEY					0x0015	// TPM_KEY
#define TPM_TAG_STORED_DATA12		0x0016	// TPM_STORED_DATA
#define TPM_TAG_NV_ATTRIBUTES		0x0017	// TPM_NV_ATTRIBUTES
#define TPM_TAG_NV_DATA_PUBLIC		0x0018	// TPM_NV_DATA_PUBLIC
#define TPM_TAG_NV_DATA_SENSITIVE	0x0019	// TPM_NV_DATA_SENSITIVE
#define TPM_TAG_DELEGATIONS			0x001A	// TPM_DELEGATIONS
#define TPM_TAG_DELEGATE_PUBLIC		0x001B	// TPM_DELEGATE_PUBLIC
#define TPM_TAG_DELEGATE_TABLE_ROW	0x001C	// TPM_DELEGATE_TABLE_ROW
#define TPM_TAG_TRANSPORT_AUTH		0x001D	// TPM_TRANSPORT_AUTH
#define TPM_TAG_TRANSPORT_PUBLIC	0x001E	// TPM_TRANSPORT_PUBLIC
#define TPM_TAG_PERMANENT_FLAGS		0x001F	// TPM_PERMANENT_FLAGS
#define TPM_TAG_STCLEAR_FLAGS		0x0020	// TPM_STCLEAR_FLAGS
#define TPM_TAG_STANY_FLAGS			0x0021	// TPM_STANY_FLAGS
#define TPM_TAG_PERMANENT_DATA		0x0022	// TPM_PERMANENT_DATA
#define TPM_TAG_STCLEAR_DATA		0x0023	// TPM_STCLEAR_DATA
#define TPM_TAG_STANY_DATA			0x0024	// TPM_STANY_DATA
#define TPM_TAG_FAMILY_TABLE_ENTRY	0x0025	// TPM_FAMILY_TABLE_ENTRY
#define TPM_TAG_DELEGATE_SENSITIVE	0x0026	// TPM_DELEGATE_SENSITIVE
#define TPM_TAG_DELG_KEY_BLOB		0x0027	// TPM_DELG_KEY_BLOB
#define TPM_TAG_KEY12				0x0028	// TPM_KEY12
#define TPM_TAG_CERTIFY_INFO2		0x0029	// TPM_CERTIFY_INFO2
#define TPM_TAG_DELEGATE_OWNER_BLOB	0x002A	// TPM_DELEGATE_OWNER_BLOB
#define TPM_TAG_EK_BLOB_ACTIVATE	0x002B	// TPM_EK_BLOB_ACTIVATE
#define TPM_TAG_DAA_BLOB			0x002C	// TPM_DAA_BLOB
#define TPM_TAG_DAA_CONTEXT			0x002D	// TPM_DAA_CONTEXT
#define TPM_TAG_DAA_ENFORCE			0x002E	// TPM_DAA_ENFORCE
#define TPM_TAG_DAA_ISSUER			0x002F	// TPM_DAA_ISSUER
#define TPM_TAG_CAP_VERSION_INFO	0x0030	// TPM_CAP_VERSION_INFO
#define TPM_TAG_DAA_SENSITIVE		0x0031	// TPM_DAA_SENSITIVE
#define TPM_TAG_DAA_TPM				0x0032	// TPM_DAA_TPM
#define TPM_TAG_CMK_MIGAUTH			0x0033	// TPM_CMK_MIGAUTH
#define TPM_TAG_CMK_SIGTICKET		0x0034	// TPM_CMK_SIGTICKET
#define TPM_TAG_CMK_MA_APPROVAL		0x0035	// TPM_CMK_MA_APPROVAL
#define TPM_TAG_QUOTE_INFO2			0x0036	// TPM_QUOTE_INFO2

#define TPM_TAG_STORED_CERT			0x0037	// TPM_TAG_STORED_CERT

#define TPM_TAG_VENDOR_DA_STATE_INFO	0x0800	// Dictionary Attack logic Tag
#define TPM_TAG_VENDOR_DA_MIN_VALUES	0x0801	// Dictionary Attack logic Tag
#define TPM_TAG_VENDOR_DA_POLICYTABLE	0x0802	// Dictionary Attack logic Tag

//////////////////////////////////////////////////////////////////////
// Family Table Defines
#define TPM_NUM_DELEGATE_TABLE_ENTRY_MIN	2
#define TPM_NUM_FAMILY_TABLE_ENTRY_MIN		8

#define TPM_MAX_FAMILY		8

//////////////////////////////////////////////////////////////////////
// TPM_FAMILY_OPERATION
#define TPM_FAMILY_CREATE		0x00000001
#define TPM_FAMILY_ENABLE		0x00000002
#define TPM_FAMILY_ADMIN		0x00000003
#define TPM_FAMILY_INVALIDATE	0x00000004

//////////////////////////////////////////////////////////////////////
// TPM_FAMILY_FLAG
#define TPM_FAMILY_FLAG_ENABLE		0x00000001
#define TPM_FAMILY_FLAG_ADMIN_LOCK	0x00000002

//////////////////////////////////////////////////////////////////////
// Owner Permission settings
#define TPM_DELEGATE_DAA_Sign						0
#define TPM_DELEGATE_Delegate_CreateOwnerDelegation	1
#define TPM_DELEGATE_Delegate_Manage				2
#define TPM_DELEGATE_ReleaseCounterOwner			3
#define TPM_DELEGATE_CreateCounter					4
#define TPM_DELEGATE_UpdateVerification				5
#define TPM_DELEGATE_FieldUpgrade					6
#define TPM_DELEGATE_SetRedirection					7
#define TPM_DELEGATE_DisablePubekRead				8
#define TPM_DELEGATE_OwnerReadPubek					9

#define TPM_DELEGATE_ActivateIdentity				10
#define TPM_DELEGATE_ActivateIdentity_OWNER_KEY		(10	+ 128)	// Exists in both owner and key delegation tables
#define TPM_DELEGATE_MakeIdentity					11
#define TPM_DELEGATE_MakeIdentity_OWNER_KEY			(11 + 128)	// Exists in both owner and key delegation tables

#define TPM_DELEGATE_OwnerSetDisable				13
#define TPM_DELEGATE_DisableForceClear				14
#define TPM_DELEGATE_DisableOwnerClear				15
#define TPM_DELEGATE_OwnerClear						16

#define TPM_DELEGATE_OwnerReadInteralPub			18
#define TPM_DELEGATE_KillMaintenanceFeature			19
#define TPM_DELEGATE_LoadMaintenanceArchive			20
#define TPM_DELEGATE_CreateMaintenanceArchive		21
#define TPM_DELEGATE_AuthorizeMigrationKey			22
#define TPM_DELEGATE_DAA_Join						23
#define TPM_DELEGATE_LoadOwnerDelegation			24

#define TPM_DELEGATE_CMK_CreateTicket				26

#define TPM_DELEGATE_DirWriteAuth					29
#define TPM_DELEGATE_SetOrdinalAuditStatus			30

#define TPM_DELEGATE_Reserved						255

#define TPM_DEL_OWNER_BITS	0x00000001
#define TPM_DEL_KEY_BITS	0x00000002

//////////////////////////////////////////////////////////////////////
// Key Permission settings
#define TPM_KEY_DELEGATE_LoadKey					0
#define TPM_KEY_DELEGATE_Seal						1
#define TPM_KEY_DELEGATE_Unseal						2
#define TPM_KEY_DELEGATE_Quote						3
#define TPM_KEY_DELEGATE_Unbind						4
#define TPM_KEY_DELEGATE_GetPubKey					5
#define TPM_KEY_DELEGATE_ChangeAuth					6
#define TPM_KEY_DELEGATE_CreateKeyDelegation		7
#define TPM_KEY_DELEGATE_ConvertMigrationBlob		8
#define TPM_KEY_DELEGATE_CreateMigrationBlob		9
#define TPM_KEY_DELEGATE_CMK_CreateBlob				10
#define TPM_KEY_DELEGATE_CreateWrapKey				11
#define TPM_KEY_DELEGATE_CertifyKey					12
#define TPM_KEY_DELEGATE_CertifyKey2				13
#define TPM_KEY_DELEGATE_Sign						14
#define TPM_KEY_DELEGATE_GetAuditDigestSigned		15
#define TPM_KEY_DELEGATE_ActivateIdentity			16
#define TPM_KEY_DELEGATE_MakeIdentity				17
#define TPM_KEY_DELEGATE_Sealx						18
#define TPM_KEY_DELEGATE_Quote2						19
#define TPM_KEY_DELEGATE_ReleaseTransportSigned		20
#define TPM_KEY_DELEGATE_EstablishTransport			21
#define TPM_KEY_DELEGATE_LoadKey2					22
#define TPM_KEY_DELEGATE_MigrateKey					23
#define TPM_KEY_DELEGATE_CMK_CreateKey				24
#define TPM_KEY_DELEGATE_ChangeAuthAsymFinish		25
#define TPM_KEY_DELEGATE_ChangeAuthAsymStart		26
#define TPM_KEY_DELEGATE_TickStampBlob				27
#define TPM_KEY_DELEGATE_CMK_ConvertMigration		28

//////////////////////////////////////////////////////////////////////
// TPM_TRANSPORT_ATTRIBUTES Definitions
#define TPM_TRANSPORT_ENCRYPT	0x00000001
#define	TPM_TRANSPORT_LOG		0x00000002
#define TPM_TRANSPORT_EXCLUSIVE	0x00000004

//////////////////////////////////////////////////////////////////////
// TPM_EK_TYPE Definitions
#define TPM_EK_TYPE_ACTIVATE	0x0001
#define TPM_EK_TYPE_AUTH		0x0002

//////////////////////////////////////////////////////////////////////
// TPM_RESOURCE_TYPE
#define TPM_RT_KEY			0x00000001
#define TPM_RT_AUTH			0x00000002
#define TPM_RT_HASH			0x00000003
#define TPM_RT_TRANS		0x00000004
#define TPM_RT_CONTEXT		0x00000005
#define TPM_RT_COUNTER		0x00000006
#define TPM_RT_DELEGATE		0x00000007
#define TPM_RT_DAA_TPM		0x00000008
#define TPM_RT_DAA_V0		0x00000009
#define TPM_RT_DAA_V1		0x0000000A

//////////////////////////////////////////////////////////////////////
// TPM_NV_INDEX
#define TPM_NV_INDEX0				0x00000000
#define TPM_NV_INDEX_D_BIT			0x10000000
#define TPM_NV_INDEX_DIR			0x10000001
#define TPM_NV_INDEX_LOCK			0xFFFFFFFF

// Reserved index values
#define TPM_NV_INDEX_GPIO_MASK		0x000000FF

#define TPM_NV_INDEX_TPM_CC			0x0000F001
#define TPM_NV_INDEX_PlatformCert	0x0000F002
#define TPM_NV_INDEX_Platform_CC	0x0000F003
#define TPM_NV_INDEX_TSS			0x000111xx	//      Reserved for TSS use
#define TPM_NV_INDEX_PC				0x000112xx	//      Reserved for PC Client use
#define TPM_NV_INDEX_SERVER			0x000113xx	//      reserved for Server use
#define TPM_NV_INDEX_MOBILE			0x000114xx	//      Reserved for mobile use
#define TPM_NV_INDEX_PERIPHERAL		0x000115xx	//      Reserved for peripheral use
#define TPM_NV_INDEX_GPIO			0x00011600	//      Reserved for GPIO pins
#define TPM_NV_INDEX_GPIO_0			0x00011600	//      Reserved for GPIO pins 0, i.e. GPIO-Express-00
#define TPM_NV_INDEX_GPIO_1			0x00011680	//      Reserved for GPIO pins 2
#define TPM_NV_INDEX_GPIO_2			0x00011681	//      Reserved for GPIO pins 3
#define TPM_NV_INDEX_GPIO_3			0x00011682	//      Reserved for GPIO pins 4
#define TPM_NV_INDEX_GROUP_RESV		0x0001xxxx	//      Reserved for TCG WG's
#define TPM_NV_INDEX_EKCert			0x1000F000	//      Set the D Bit Index

//////////////////////////////////////////////////////////////////////
// TPM_NV_ATTRIBUTES
#define TPM_NV_PER_READ_STCLEAR		0x80000000

#define TPM_NV_PER_PPWRITE			0x00000001
#define TPM_NV_PER_OWNERWRITE		0x00000002
#define TPM_NV_PER_AUTHWRITE		0x00000004

#define TPM_NV_PER_WRITEALL			0x00001000
#define TPM_NV_PER_WRITEDEFINE		0x00002000
#define TPM_NV_PER_WRITE_STCLEAR	0x00004000
#define TPM_NV_PER_GLOBALLOCK		0x00008000
#define TPM_NV_PER_PPREAD			0x00010000
#define TPM_NV_PER_OWNERREAD		0x00020000
#define TPM_NV_PER_AUTHREAD			0x00040000

//////////////////////////////////////////////////////////////////////
// TPM_CMK_DELEGATE values
#define TPM_CMK_DELEGATE_MIGRATE	0x08000000
#define TPM_CMK_RESERVED			0x0FFFFFFF
#define TPM_CMK_DELEGATE_LEGACY		0x10000000
#define TPM_CMK_DELEGATE_BIND		0x20000000
#define TPM_CMK_DELEGATE_STORAGE	0x40000000
#define TPM_CMK_DELEGATE_SIGNING	0x80000000

//////////////////////////////////////////////////////////////////////
// TPM_PERMANENT_FLAGS
#define TPM_PF_DISABLE							0x00000001	// Y    Onwer authorization or physical presence                                                        | TPM_OwnerSetDisable
															//                                                                                                                                                      | TPM_PhysicalEnable
															//                                                                                                                                                      | TPM_PhysicalDisable
#define TPM_PF_OWNERSHIP						0x00000002	// Y    No authorization. No ownerinstalled. Physical presence asserted         | TPM_SetOwnerInstall
#define TPM_PF_DEACTIVATED						0x00000003	// Y    No authorization, physical presence assertion                                           | TPM_PhysicalSetDeactivated
#define TPM_PF_READPUBEK						0x00000004	// Y    Owner authorization                                                                                                     | TPM_DisableReadPubEK
#define TPM_PF_DISABLEOWNERCLEAR				0x00000005	// Y    Owner authorization. Can only set to TRUE, FALSE invalid value
															//              After being set only ForceClear resets back to FALSE                            | TPM_DisableOwnerClear
#define TPM_PF_ALLOWMAINTENANCE					0x00000006	// Y    Owner authorization. Can only set to FALSE, TRUE invalid value
															//              After being set only changing TPM owner resets back to TRUE                     | TPM_KillMaintenanceFeature
#define TPM_PF_PHYSICALPRESENCELIFETIMELOCK		0x00000007	// N
#define TPM_PF_PHYSICALPRESENCEHWENABLE			0x00000008	// N
#define TPM_PF_PHYSICALPRESENCECMDENABLE		0x00000009	// N
#define TPM_PF_CEKPUSED							0x0000000A	// N
#define TPM_PF_TPMPOST							0x0000000B	// N
#define TPM_PF_TPMPOSTLOCK						0x0000000C	// N
#define TPM_PF_FIPS								0x0000000D	// N
#define TPM_PF_OPERATOR							0x0000000E	// N
#define TPM_PF_ENABLEREVOKEEK					0x0000000F	// N
#define TPM_PF_NV_LOCKED						0x00000010	// N
#define TPM_PF_READSRKPUB						0x00000011	// Y    Owner Authorization
#define TPM_PF_RESETESTABLISHMENTBIT			0x00000012	// Y    Owner Authorization                                                                                                     | TSC_ResetEstablishmentBit
#define TPM_PF_MAINTENANCEDONE					0x00000013	// N

//////////////////////////////////////////////////////////////////////
// TPM_PERMANENT_DATA
#define TPM_PD_REVMAJOR							0x00000001	// N
#define TPM_PD_REVMINOR							0x00000002	// N
#define TPM_PD_TPMPROOF							0x00000003	// N
#define TPM_PD_OWNERAUTH						0x00000004	// N
#define TPM_PD_OPERATORAUTH						0x00000005	// N
#define TPM_PD_MANUMAINTPUB						0x00000006	// N
#define TPM_PD_ENDORSEMENTKEY					0x00000007	// N
#define TPM_PD_SRK								0x00000008	// N
#define TPM_PD_DELEGATEKEY						0x00000009	// N
#define TPM_PD_CONTEXTKEY						0x0000000A	// N
#define TPM_PD_AUDITMONOTONICCOUNTER			0x0000000B	// N
#define TPM_PD_MONOTONICCOUNTER					0x0000000C	// N
#define TPM_PD_PCRATTRIB						0x0000000D	// N
#define TPM_PD_ORDINALAUDITSTATUS				0x0000000E	// N
#define TPM_PD_AUTHDIR							0x0000000F	// N
#define TPM_PD_RNGSTATE							0x00000010	// N
#define TPM_PD_FAMILYTABLE						0x00000011	// N
#define TPM_PD_DELEGATETABLE					0x00000012	// N
#define TPM_PD_EKRESET							0x00000013	// N
#define TPM_PD_MAXNVBUFSIZE						0x00000014	// N
#define TPM_PD_LASTFAMILYID						0x00000015	// N
#define TPM_PD_NOOWNERNVWRITE					0x00000016	// N
#define TPM_PD_RESTRICTDELEGATE					0x00000017	// Y    If TPM owner installed, owner authorization else physical
															//              presence assertion                                                                                                      | TPM_CMK_SetRestrictions
#define TPM_PD_TPMDAASEED						0x00000018	// N

#define TPM_MIN_COUNTERS			4	// The minimum number of counters is 4
#define TPM_NUM_PCR					16
#define TPM_MAX_NV_WRITE_NOOWNER	64	// Max writes to NV memory

//////////////////////////////////////////////////////////////////////
// TPM_STCLEAR_FLAGS
#define TPM_SF_DEACTIVATED						0x00000001	// N
#define TPM_SF_DISABLEFORCECLEAR				0x00000002	// Y    Not available when TPM deactivated or disabled                                          | TPM_DisableForceClear
#define TPM_SF_PHYSICALPRESENCE					0x00000003	// N
#define TPM_SF_PHYSICALPRESENCELOCK				0x00000004	// N
#define TPM_SF_BGLOBALLOCK						0x00000005	// N

//////////////////////////////////////////////////////////////////////
// TPM_STCLEAR_DATA
#define TPM_SD_CONTEXTNONCEKEY					0x00000001	// N
#define TPM_SD_COUNTID							0x00000002	// N
#define TPM_SD_OWNERREFERENCE					0x00000003	// N
#define TPM_SD_DISABLERESETLOCK					0x00000004	// N

//////////////////////////////////////////////////////////////////////
// TPM_STANY_FLAGS
#define TPM_AF_POSTINITIALISE					0x00000001	// N
#define TPM_AF_LOCALITYMODIFIER					0x00000002	// N
#define TPM_AF_TRANSPORTEXCLUSIVE				0x00000003	// N
#define TPM_AF_TOSPRESENT						0x00000004	// Y    Locality 3 or 4, can only set to FALSE

//////////////////////////////////////////////////////////////////////
// TPM_STANY_DATA
#define TPM_AD_CONTEXTNONCESESSION				0x00000001	// N
#define TPM_AD_AUDITDIGEST						0x00000002	// N
#define TPM_AD_CURRENTTICKS						0x00000003	// N
#define TPM_AD_CONTEXTCOUNT						0x00000004	// N
#define TPM_AD_CONTEXTLIST						0x00000005	// N
#define TPM_AD_SESSIONS							0x00000006	// N

#define TPM_MIN_SESSIONS		3
#define TPM_MIN_SESSION_LIST	16

//////////////////////////////////////////////////////////////////////
// Set_Capability Values
#define TPM_SET_PERM_FLAGS						0x00000001
#define	TPM_SET_PERM_DATA						0x00000002
#define	TPM_SET_STCLEAR_FLAGS					0x00000003
#define	TPM_SET_STCLEAR_DATA					0x00000004
#define	TPM_SET_STANY_FLAGS						0x00000005
#define	TPM_SET_STANY_DATA						0x00000006
#define	TPM_SET_VENDOR							0x00000007

//////////////////////////////////////////////////////////////////////
// DAA definitions
#define DAA_SIZE_NE					256	// Size in Bytes
#define DAA_SIZE_NT					20	// Size in Bytes
#define DAA_SIZE_r0					43	// Size in Bytes
#define DAA_SIZE_r1					43	// Size in Bytes
#define DAA_SIZE_r2					128	// Size in Bytes
#define DAA_SIZE_r3					168	// Size in Bytes
#define DAA_SIZE_r4					219	// Size in Bytes
#define DAA_SIZE_v0					128	// Size in Bytes
#define DAA_SIZE_v1					192	// Size in Bytes
#define DAA_SIZE_w					256	// Size in Bytes
#define DAA_SIZE_issuerModulus		256	// Size in Bytes
#define DAA_power0					104
#define DAA_power1					1024

//////////////////////////////////////////////////////////////////////
// PC Client Specific Implementation Specification Version 1.2 Revision 1.00
#define TPM_FULL_CERT	0x00
#define	TPM_SIG_CERT	0x01

//---------------------------------------------------------------
// Definitions for accessing TPM on the LPC Bus

// Default I/O addresses
#define	TPM_IO_BASE			0x4700	// IO Base Address
#define	TPM_CFG_BASE		0x004E	// Configuration Base Address
#define	TPM_CFG_BASE_ALT	0x002E	// Alternative Configuration Base Address

// Default waiting times
#define TPM_LPC_BWT			60	// Block Waiting Time in steps of 100ms
#define TPM_LPC_RWT			30	// Reset Waiting Time in steps of 100ms
#define TPM_LPC_CWT			6	// Character Waiting Time in steps of 100ms

// Definitions for common TPM flags
#define TPM_DAR_ACT			0x01	// Activate BIT for TPM
#define TPM_IRQ0			0x01	// Interrupt 0 select BIT
#define TPM_IRQ1			0x02	// Interrupt 1 select BIT
#define TPM_IRQ2			0x04	// Interrupt 2 select BIT
#define TPM_IRQ3			0x08	// Interrupt 3 select BIT
#define TPM_IRQ4			0x10	// Interrupt 4 select BIT
#define TPM_IRQ_MASK		0x1F	// Interrupt mask for TPM
#define TPM_IRQ_NUM			0x00	// Interrupt number
#define	TPM_IRQ_CTRL		0x02	// Interrupt control
#define TPM_ENABLE_CONFIG	0x55	// Enable mask for index/data register pair
#define TPM_DISABLE_CONFIG	0xAA	// Disable mask for index/data register pair

#define TPM_CONFIG_REG_POS1	0x4E	// Default config register position for TPM

// Definitions for TPM control byte
#define TPM_SIZE_LPC_HEADER	0x04	// Size (in bytes) of the LPC control header

#define TPM_DEFAULT_CONTROL	0x00	// Default control byte for LPC layer
#define TPM_DEFAULT_LPCVER	0x01	// Default version info for LPC layer

#define TPM_CTRL_DATA		0x04
#define TPM_CTRL_ABORT		0x08
#define TPM_CTRL_WTX		0x10	// TPM Control Wait Extend
#define TPM_CTRL_ERROR		0x20	// TPM Control Error
#define TPM_CTRL_CHAINING	0x80

// Definition for TPM error info byte
#define TPM_NAK				0x15	// Negative Acknowledge Byte

// Info Bytes for the Vendor Layer of the LPC communication protocol 
#define VEND_PROT_VERS		0x01	// Version
#define VEND_PROT_CHA_CTRL	0x07	// Channel for the control unit
#define VEND_PROT_CHA_TPM	0x0B	// Channel for the TPM
#define VEND_LAYER_SZ		6	// Vendor Layer Size in Bytes

// Instruction Bytes for Read FID
#define READ_DATA_CLA		0x05
#define READ_DATA_INS		0xF2
#define READ_FID_DATA_LEN	0x01
#define READ_FID_DATA_TAG	0x04

#define MAX_FID_INFO_SIZE	107	// Maximum size of the FID data structure

// Definitions for TPM Status Register
#define TPM_STAT_XFE		0x01	// Transmit FIFO empty BIT
#define TPM_STAT_LPA		0x02	// Indication BIT for LPC loop function
#define TPM_STAT_FOK		0x04	// Firmware OK BIT
#define TPM_STAT_TOK		0x08	// Selftest OK BIT
#define TPM_STAT_IRQA		0x40	// IRQ active
#define TPM_STAT_RDA		0x80	// Receive data available BIT
#define TPM_STAT			2	// TPM Status Register

// Address definitions for the standard configuration registers
#define TPM_LDN				0x07	// Logical Device Selection Register
#define TPM_ID1				0x20	// Chip Identification Register 1
#define TPM_ID2				0x21	// Chip Identification Register 2
#define TPM_CFGL			0x26	// Configuration Register position low
#define TPM_CFGH			0x27	// Configuration Register position high
#define TPM_DAR				0x30	// Device Activate Register
#define TPM_SEN				0x38	// Sync error enable (TPM1.2 only)
#define TPM_IOLIMH			0x60	// Lower limit(16Bit) for I/O address (high)
#define TPM_IOLIML			0x61	// Lower limit(16Bit) for I/O address (low)
#define TPM_IRQSEL			0x70	// Interrupt Configuration Register
#define TPM_IRTYPE			0x71	// Interrupt Control Register
#define TPM_IDVENL			0xF1	// Vendor ID low byte
#define TPM_IDVENH			0xF2	// Vendor ID high byte
#define TPM_IDPDL			0xF3	// Device ID low byte
#define TPM_IDPDH			0xF4	// Device ID high byte
#define TPM_RID				0xF5	// Revision ID

// Definitions for TPM Command Register
#define TPM_CMD_DIS			0x01	// Interrupt disable BIT
#define TPM_CMD_LP			0x02	// Close loop for LPC interface BIT
#define TPM_CMD_RES			0x04	// Reset BIT for TPM
#define TPM_CMD_IRQC		0x40	// Clear IRQ Bit

#define TPM_CMD				3	// TPM Command Register

// Definitions for TPM FIFO
#define TPM_WRFIFO			0	// TPM Write Register to FIFO
#define TPM_RDFIFO			1	// TPM Read Register for FIFO

// TPM1.1 DEVICE ID
#define TPM_ID1_INFO		0x06	// TPM identification info 1
#define TPM_ID2_INFO		0x00	// TPM identification info 2
// TPM1.2 DEVICE ID
#define TPM12_ID1_INFO		0x0B	// TPM1.2 identification info 1
#define TPM12_ID2_INFO		0x00	// TPM1.2 identification info 2

#define TPM_VENDOR_INFO_L	0xD1	// TPM vendor info low
#define TPM_VENDOR_INFO_H	0x15	// TPM vendor info high
// TPM1.1 DEVICE ID
#define TPM_DEVICE_INFO_L	0x06	// TPM device info low
#define TPM_DEVICE_INFO_H	0x00	// TPM device info high
// TPM1.2 DEVICE ID
#define TPM12_DEVICE_INFO_L	0x0B	// TPM device info low
#define TPM12_DEVICE_INFO_H	0x00	// TPM device info high

// Definitions for capability tags
#define TDDL_CAP_VERSION			0x0100
#define TDDL_CAP_VER_DRV			0x0101
#define TDDL_CAP_VER_FW				0x0102
#define TDDL_CAP_VER_FW_DATE		0x0103
#define TDDL_CAP_VER_ROM_CRC		0x0104
#define TDDL_CAP_PROPERTY			0x0200
#define TDDL_CAP_PROP_MANUFACTURER	0x0201
#define TDDL_CAP_PROP_MODULE_TYPE	0x0202
#define TDDL_CAP_PROP_GLOBAL_STATE	0x0203
#define TDDL_CAP_PROP_IFSD			0x0204

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TPM_DEFI_H__
