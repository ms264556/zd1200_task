/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	FileIO.h

Description:	Header file for the file I/O help routines

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __FILEIO_H__
#define __FILEIO_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#ifdef UEFI_X64
#include <Library/UefiLib.h>			// for CatSPrint
#include <Library/ShellLib.h>			// for file access
#include <Library/MemoryAllocationLib.h>	// for FreePool
#endif
#include "Globals.h"

// Convert a binary representated value into the corresponding ASCII string 
void Bin2Asc(BYTE * pbBuffer, UINT32 wBufferLen, BYTE * pbAsciBuffer, UINT32 AscBufferLen);

// Convert an ASCII representated string into the corresponding binary value
UINT32 Asc2Bin(char *pbString, UINT32 * pdwValue);

// Read the value of the desired config key name
UINT32 GetCfgString(char *pbFileName, char *pbSectionName, char *pbKeyName, UINT32 * pdwSize, BYTE * pbBuffer);

// Read the value of the desired config key name and convert it to a binary value
UINT32 GetCfgBinaryValue(char *pbFileName, char *pbSectionName, char *pbStringName, UINT32 *pdwValue) ;

// Read content of a file into the supplied buffer
UINT32 ReadBufferFromHexFile(char *pbFileName, BYTE * pbBuffer, UINT16 * pwBufferLen);

// Write content of the supplied buffer into a file
UINT32 WriteBuffer2HexFile(char *pcFileName, BYTE * pbBuffer, UINT16 wBufferLen);

// File handlers
void OpenLogFile(char *filename);
void CloseLogFile(char *pcLogFileName);
UINT32 SaveToFile(char *fname, BYTE * data, UINT32 len, BYTE mode);

// Opens a file
UINT32 FileOpen(char *pbFileName, void **vpfileHandle, UINT16 wFileFlags);

// Closes a file
UINT32 FileClose(void** pvFileHandle);

// Reads a block of data from a file
UINT32 FileRead(void* pvFileHandle, BYTE* pbBuffer, UINT32 pwBufferLen, UINT32* pwBytesRead);

// Reads a line from a file
UINT32 FileReadLine(void* pvFileHandle, char* pcBuffer, UINT32 pwBufferLen, UINT32* pwLineLength);

//Opens a file, reads all content and finally closes the file
UINT32 FileReadAll(char* pcFileName, BYTE* pbBuffer, UINT32 pwBufferLen, UINT32* pwBytesRead);

// Writes a block of data into a file
UINT32 FileWrite(void* pvFileHandle, BYTE* pbBuffer, UINT32 dwBufferLen);

// Writes a string to the current position in a file
UINT32 FileWriteString(void *pvFileHandle, char* pcString);

// Writes a formatted string to the current position in a file
UINT32 FileWriteStringf(void *pvFileHandle, char* pcFormat, ...);

// Writes a formatted string to the current position in a file, using a va_list
UINT32 FileWriteStringvf(void *pvFileHandle, char* pcFormat, va_list pcArguments);

// Gets the size of a file
UINT32 FileGetSize(void* pvFileHandle, UINT32* pqwFileSize);

// Gets the current position in a file
UINT32 FileGetPosition(void* pvFileHandle, UINT32* pqwFilePosition);

// Sets the current position in a file
UINT32 FileSetPosition(void* pvFileHandle, UINT32 qwFilePosition);

// Gets if the current position in a file points to the end of the file
BOOL FileEOF(void* pvFileHandle);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __FILEIO_H__
