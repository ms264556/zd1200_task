/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	LPC_Comm.h

Description:	Header file for the TPM communication protocol for LPC I/O access

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __LPC_COMM_H__
#define __LPC_COMM_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

// States of the Transceiver state machine
#define TRSCV_TX_DATA	0
#define TRSCV_RX_DATA	1
#define TRSCV_TIMEOUT	2
#define TRSCV_TX_NAK	3
#define TRSCV_TX_WTX	4
#define TRSCV_COMPLETE	5
#define TRSCV_ERROR		6
#define TRSCV_RETURN	7
#define	TRSCV_TX_ABORT	8

#define MAX_ERRORS		3

// Check the TPMs default configuration
UINT32 TPM_CheckDefaultConfig(UINT16 wTPMIndexReg);

// Enable/diable the index/data registers in TPM
void TPM_ON_OFF_Data(UINT16 wTPMIndexReg, BYTE bTPMAction);

// Set the I/O Base Address for TPM access
void TPM_Set_IO_BaseAdr(UINT16 wTPMIndexReg, UINT16 wTmpIOBase);

// Set the IRQ number for the TPM
void TPM_SetIRQ(UINT16 wTPMIndexReg, BYTE bIrqNr, BYTE bIrqCtrl);

// Activate or deactivate the TPM
void TPM_SetDAR(UINT16 wTPMIndexReg, BYTE bTPMAction);

// Write the flags into the TPM Command Register
UINT32 TPM_CMD_RegAccess(UINT16 wTPMIndexReg, BYTE bCmdFlags, BYTE bCMDAction);

// Clear all remaining data of the TPMs FIFO
UINT32 TPM_ClearFIFO(TPM_INFO_STRUCTURE * psTPMInfo);

// Read the Status Register of the TPM
BYTE TPM_ReadStatusReg(UINT16 wTPMIndexReg);

// Send the Tx Buffer to the TPM and return the response
UINT32 TPM_Transceive(TPM_INFO_STRUCTURE * psTPMInfo, BYTE * pbTxBuffer, UINT16 wTxLen, BYTE * pbRxBuffer, UINT16 * pwRxLen);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __LPC_COMM_H__
