/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Autotest.h

Description:	Header file for the file AutoTest routines

Author:			Harald Friedrich	2012/01/23

Environment:	any

Revision History:

Notes:

--*/

// referenced in automatic generated file TestCases.c
void TestRunnerInit( char * pcStartTestID );
void TestRunnerExit( void );

void PreconditionsStart( void );
void PreconditionTestFlags( char *pcFlagCheckFileName );
void PreconditionsEnd( void );

void TestMenu( char menKey, UINT32 dwExpVal );
void TestFlags( char *pcFlagCheckFileName );
void TestIfOwned( void );
void TestMethod( char *pDescription );
void HibernatePrompt( char * pNextTestCaseID );
void SetNumber( UINT32 number );

// public in automatic generated file TestCases.c
void AutoTest( int category );

// used in program
BOOL AutoTestIsRunning( void );
UINT32 GetNumber(char *pcPrompt, UINT32 *pdwNumber);

// public in Tool4TPM.c
void Tool4TPMexit( void );

// logging functions
void TestLogInit( char * _pcStartTestID );
void TestLogExit();
void TestLog(char* pcLog, ...);
void TestLogStartCase(char* pcDescription);
void TestLogEndCase(char cSymbol);
void TestLogTestMenu(char dwMenuCode, UINT32 dwExpVal, UINT32 dwRCVal);
void TestLogUpdateSummery();
void TestLogInitContinue();
void TestLogGetSummeryValue(char* pcBuffer, UINT32 dwBufferSize, char *pcValueName, UINT32 *pdwValue);

// end
