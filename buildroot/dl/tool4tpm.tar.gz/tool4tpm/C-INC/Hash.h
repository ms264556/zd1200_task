/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	Hash.h

Description:	Header file for the implementation of the SHA-1 and the HMAC

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

//////////////////////////////////////////////////////////////////
//									//
//								NOTES	//
//									//
// PROGRAM STRUCTURE							//
//	The parameter names and the computation schemes are		//
//	implemented according to FIPS PUB 198 and FIPS PUB 180-2.	//
//	Further information is available on:				//
//	http://www.itl.nist.gov/fipspubs/				//
//									//
// SHA-1 LENGTH LIMITATION						//
//	For some implementation reasons, the maximum input message	//
//	length is limited to 65463 Bytes. This restriction differs	//
//	from the SHA-1 specification, but is not considered to be	//
//	an effective limitation in this specific usecase.		//
//									//
// HMAC USABILITY LIMITATION						//
//	For some implementation reasons, the program's general		//
//	usability is limited because of fixed block, key and output	//
//	sizes and the applied hash algorithm. It is not intended to	//
//	use this program in other ways than here. Due to the		//
//	HMAC computation scheme and the SHA-1 message length		//
//	limitation, the maximum input message length of the HMAC is	//
//	limited to 65399 Bytes (65463 - 64 Bytes).			//
//									//
//////////////////////////////////////////////////////////////////

--*/

#ifndef __HASH_H__
#define __HASH_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

#define MAX_HMAC_INP_SZ		65399	// Maximum HMAC input message size (Do NOT increase!)
#define MAX_SHA1_INP_SZ		65463	// Maximum SHA-1 input message size (Do NOT increase!)

// Create a SHA-1 HMAC for the input text
UINT32 HMAC_Func(const BYTE * const pbInpMsg, UINT16 wInpSize, const BYTE bKey[HASH_LEN], BYTE bHMAC[HASH_LEN]);

// Create a SHA-1 hash for the input message
UINT32 SHA1_Func(const BYTE * const pbInpMsg, const UINT16 wInpSize, BYTE bSHA1[HASH_LEN]);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __HASH_H__
