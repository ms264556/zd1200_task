/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	RSA.h

Description:	Header file for the RSA public key encryption
				according to PKCS #1 v2.1 (RSAES EME-OAEP)

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

//////////////////////////////////////////////////////////////////
//									//
//								NOTES	//
//									//
//	PROGRAM STRUCTURE						//
//	The computation scheme is implemented according to		//
//	PKCS #1 v2.1, regarding the changes to be made to comply	//
//	the TCG Main Specification. Further information is		//
//	available on: http://www.rsasecurity.com/rsalabs/pkcs		//
//									//
//	PROGRAM LIMITATIONS						//
//	The maximum key length, i. e. the length of the modulus is	//
//	limited to 256 Bytes. The hash algorithm is fixed to the	//
//	SHA-1 providing a 20 Byte hash value. Thus, the maximum		//
//	input message size is limited to 214 Byte due to the		//
//	implemented padding scheme (see OAEP in PKCS #1 v2.1).		//
//									//
//	MASKING SEED OPTIONS						//
//	You can either pass your own specific masking seed (see		//
//	OAEP in PKCS #1 v2.1) to the RSA function or use the		//
//	integrated seed by passing NULL to it.				//
//									//
//////////////////////////////////////////////////////////////////

--*/

#ifndef	_RSA_H_
#define	_RSA_H_

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

#define EXPONENT	0x10001	// Public key exponent according to TCG main specification.
									// e could be changed to a non-standard value up to 2^32-1.

// This function module uses a specific data array type for long integer values. The predefined
// size of such data arrays is AA_LENGTH. This value must NOT be changed, otherwise all
// calculations will be wrong. The first array element contains the number of the following
// fields actually used for the stored long integer value. The array element order is little
// endian, i. e. the most significant 32 Bit part of the long integer value is stored in the last
// used array element. (The order of the Bytes in each array element is machine dependent, but
// regarding the programming rules that does not matter.)
#define	AA_LENGTH	65
#ifdef linux
typedef unsigned int AA_LONG;
#else
typedef unsigned long AA_LONG;
#endif
// RSA_Encrypt encrypts 'wInpLen' Bytes starting from address 'pbInput'.
// The caller must supply at least KEY_LEN Bytes in the parameter 'pwOutpLen'.
// The encrypted Bytes are stored at the address 'pbOutput'.
// The actual size of the output is passed back to the caller in 'pwOutpLen'.
// 'bPublicKey[KEY_LEN]' must be the public key Byte array of KEY_LEN Bytes.
UINT32 RSA_Encrypt(const BYTE * const pbInput,
		   const UINT16 wInpLen,
		   BYTE * const pbOutput, UINT16 * const pwOutpLen, const BYTE bPublicKey[KEY_LEN], BYTE bSeed[HASH_LEN]);

// Macros for long integer arithmetics ----------------------------------------------------------

#define LSHIFT(A,E,NBIT)	{(E) = (A) << (NBIT);}
#define RSHIFT(A,E,NBIT)	{(E) = (A) >> (NBIT);}

#define	AA_EQUAL0(num)		(!(num)[0])

#define	AA_TRANS(num, res) {				\
	const AA_LONG *n = (num);			\
	AA_LONG *rr = (res);				\
	long l = (long) *n;				\
	do {*rr++ = *n++;} while (--l >= 0);		\
}

/* E1 * 2^32 + E0 := (A01 * 2^16 + A00) * (B01 * 2^16 + B00) */

#define LMULT1(B,E1,E0) {				\
	UINT16	B00,B01;				\
	UINT32	H01,H10;				\
							\
	B00 = (UINT16) B;				\
	B01 = (UINT16)(B >> 16);			\
							\
	E0	= (UINT32)A00 * (UINT32)B00;		\
	H01	= (UINT32)A00 * (UINT32)B01;		\
	H10	= (UINT32)A01 * (UINT32)B00;		\
	E1	= (UINT32)A01 * (UINT32)B01;		\
	if ((E0 += (H01 << 16)) < (H01 << 16))		\
		E1++;					\
	if ((E0 += (H10 << 16)) < (H10 << 16))		\
		E1++;					\
	E1 += (H01 >> 16) + (H10 >> 16);		\
}

#define LMULT(A,B,E1,E0) {				\
	UINT16	A00,A01,B00,B01;			\
	UINT32	H01,H10;				\
							\
	A00 = (UINT16) A;				\
	A01 = (UINT16)(A >> 16);			\
	B00 = (UINT16) B;				\
	B01 = (UINT16)(B >> 16);			\
							\
	E0	= (UINT32)A00 * (UINT32)B00;		\
	H01	= (UINT32)A00 * (UINT32)B01;		\
	H10	= (UINT32)A01 * (UINT32)B00;		\
	E1	= (UINT32)A01 * (UINT32)B01;		\
	if ((E0 += (H01 << 16)) < (H01 << 16))		\
		E1++;					\
	if ((E0 += (H10 << 16)) < (H10 << 16))		\
		E1++;					\
	E1 += (H01 >> 16) + (H10 >> 16);		\
}

#define LSQUARE(A,E1,E0) {				\
	UINT16	A00,A01;				\
	UINT32	H01;					\
							\
	A00 = (UINT16) A;				\
	A01 = (UINT16)(A >> 16);			\
							\
	E0	= (UINT32)A00 * (UINT32)A00;		\
	H01	= (UINT32)A00 * (UINT32)A01;		\
	E1	= (UINT32)A01 * (UINT32)A01;		\
	if ((E0 += (H01 << 16)) < (H01 << 16))		\
		E1++;					\
	if ((E0 += (H01 << 16)) < (H01 << 16))		\
		E1++;					\
	E1 += ((H01 >> 16) << 1);			\
}

#define GETNBITS(N)							\
	if (N < modnbits) {						\
		n_bits = (BYTE)((exponent[1] >> (modnbits - N)) &	\
			mask[n-3]);					\
		modnbits -= N;						\
	}								\
	else if (N == modnbits) {					\
		n_bits = (BYTE)((exponent[1] >> (modnbits - N)) &	\
			mask[n-3]);					\
		modnbits = 32;						\
		getbits=0;						\
	}								\
	else {								\
		n_bits = (BYTE)(((exponent[1] << (N - modnbits)) |	\
			(exponent[0] >> (32 - N + modnbits))) &		\
			mask[n-3]);					\
		modnbits += (32 - N);					\
		getbits=0;						\
	}

// Function prototypes for long integer arithmetics ---------------------------------------------

// Computes "(number ** EXPONENT) % modul" and stores the "result"
char mexp(const AA_LONG * const number, AA_LONG * result, const AA_LONG * const module);

// Compares two AA_LONGs
char comp(const AA_LONG * number1, const AA_LONG * number2);

// Converts a BYTE array to an AA_LONG number
char auint82long(const BYTE * auint8, UINT16 len, AA_LONG * l);

// Converts an AA_LONG number to a BYTE array
char long2auint8(const AA_LONG l[], BYTE * auint8, UINT16 * const len);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif /* _RSA_H_ */
