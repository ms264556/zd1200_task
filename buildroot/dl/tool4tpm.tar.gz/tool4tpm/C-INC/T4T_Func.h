/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	ProgFunc.h

Description:	Header file for the Tool4TPM menu

Author:			Viktor Wallner	2013/03/12

Environment:	16-Bit DOS, 32-Bit/64-Bit Windows, 32-Bit/64-Bit Linux/ARM, 64-Bit UEFI

Revision History:

Notes:

--*/

#include "Globals.h"

#ifndef __T4T_FUNC_H__
#define __T4T_FUNC_H__

#define MENU_1_ENABLE_CMD_SET_PP			'1'
#define MENU_2_ENABLE_HARDWARE_SIGNAL_PP	'2'
#define MENU_3_SET_PP						'3'
#define MENU_4_CLEAR_PP						'4'
#define MENU_5_LOCK_PP						'5'
#define MENU_6_ENABLE_TPM					'6'
#define MENU_7_DISABLE_TPM					'7'
#define MENU_8_ACTIVATE_TPM					'8'
#define MENU_9_DEACTIVATE_TPM				'9'
#define MENU_C_CLEAR_OWNER_UNDER_PP 		'C'
#define MENU_O_TAKE_OWNER_WITH_PASSWORD		'O'
#define MENU_P_READ_PUBLIC_EK				'P'
#define MENU_E_READ_EK_CERTIFICATE			'E'
#define MENU_F_READ_COMPARE_PUBLIC_EKS		'F'
#define MENU_I_TPM_INFORMATION				'I'
#define MENU_T_FULL_SELFTEST				'T'
#define MENU_R_GET_TESTRESULTS				'R'
#define MENU_S_SHA1_TEST					'S'
#define MENU_A_READ_SHOW_TICKCOUNTER		'A'
#define MENU_B_SAFE_STATE_TO_NVM			'B'
#define MENU_G_GET_RANDOM_NUMBER			'G'
#define MENU_Q_Exit							'Q'

#ifdef TOOL4TPM_TEST
#define MENU_K_CREATE_EKS					'K'
#define MENU_m_SHA1_COMPLETE				'm'
#define MENU_x_SHA1_COMPLETE_EXTEND			'x'
#define MENU_U_TPM_STARTUP_CLEAR			'U'
#define MENU_L_TPM_CONTINUE_SELF_TEST		'L'
#define MENU_W_TPM_SET_OWNER_INSTALL_ON		'W'
#define MENU_N_TPM_SET_OWNER_INSTALL_OFF	'N'
#define MENU_D_TPM_OWNER_SET_DISABLE		'D'
#define MENU_M_TPM_TMP_DEACTIVATE_W_AUTH	'M'
#define MENU_Z_TPM_TMP_DEACTIVATE_WO_AUTH	'Z'
#define MENU_t_TPM_SET_OPERATOR_AUTH		't'
#define MENU_c_TPM_OWNER_CLEAR				'c'
#define MENU_b_TPM_RESET_ESTABLISHMENT_BIT	'b'
#define MENU_Y_TPM_SET_CAPABILITY_W_AUTH	'Y'
#define MENU_J_TPM_SET_CAPABILITY_WO_AUTH	'J'
#define MENU_s_TPM_SEAL_DATA				's'
#define MENU_u_TPM_UNSEAL_DATA				'u'
#define MENU_v_TPM_SEAL_TEST				'v'
#define MENU_a_TPM_CREATE_WRAP_KEY			'a'
#define MENU_l_TPM_LOAD_KEY_2				'l'
#define MENU_g_TPM_GET_PUBLIC_KEY_W_AUTH	'g'
#define MENU_p_TPM_GET_PUBLIC_KEY_WO_AUTH	'p'
#define MENU_X_TPM_EXTEND					'X'
#define MENU_r_TPM_PCR_READ					'r'
#define MENU_e_TPM_PCR_RESET				'e'
#define MENU_o_TPM_OSAP						'o'
#define MENU_d_TPM_DEFINE_SPACE_W_AUTH		'd'
#define MENU_h_TPM_DEFINE_SPACE_WO_AUTH		'h'
#define MENU_w_TPM_WRITE_VALUE_W_AUTH		'w'
#define MENU_y_TPM_WRITE_VALUE_WO_AUTH		'y'
#define MENU_z_TPM_READ_VALUE_W_AUTH		'z'
#define MENU_f_TPM_FLUSH_SPECIFIC			'f'
#define MENU_H_TOGGLE_POS_NEG_TEST			'H'
#endif

// Execute the menu driven TPM evaluation
UINT32 PollMenu(BYTE bCycle);

// Process the the select item in menu driven TPM evaluation
UINT32 MenuSelect(short cMenuSel, BYTE bCycle);

// Show the command menu of the program
void ShowMenu(void);

// Returns the string label for a given menu code
void MenuCodeToLabel(UINT32 dwMenuCode, char *pcMenuLabel, UINT32 dwMaxLength);

// Show the help text of the program
void ShowHelp(void);

BOOL T4T_ErrorCodeToMessage(UINT32 dwErrorCode, char *pcErrorMessage, UINT32 dwMaxLength);

#endif // __T4T_FUNC_H__
