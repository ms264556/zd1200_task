/*++

Copyright (c) 2013	Infineon Technologies AG

Module Name:	TPM_Cmds.h

Description:	Header file for the TPM commands

Author:			Markus Schmoelzer	2007/02/23

Environment:	16-Bit/DOS, 32-Bit/Windows

Revision History:

Notes:

--*/

#ifndef __TPM_CMDS_H__
#define __TPM_CMDS_H__

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#include "Globals.h"

// Default buffer size for response structures
#define DEFAULT_BUFFERSIZE   1024

#pragma pack(push, 1)

// TPM command and response structures ===========================================================
typedef struct tdTPM_AUTH_IN {
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession; // actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sOwnerAuth;
} TPM_AUTH_IN;

typedef struct tdTPM_AUTH_OUT {
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession; // actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_AUTH_OUT;


// TPM_11_ReadEKCert
typedef struct tdTPM_11_READ_EKCERT_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	BYTE bIndex;
	TPM_NONCE sNonce;
} TPM_11_READ_EKCERT_RQU;

typedef struct tdTPM_11_READ_EKCERT_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	BYTE bMaxIndex;
	TPM_DIGEST sDigest;
	UINT32 dwCertSize;
	BYTE abCert[MAX_CERT_SIZE];
} TPM_11_READ_EKCERT_RSP;

//-------------------------------------------------------------------
// TPM_FieldUpgradeInfoRequest
typedef struct tdTPM_FU_INFO_REQ_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	BYTE bSubCommand;
	UINT16 wInInfoRequestSize;
} TPM_FU_INFO_REQ_RQU;

typedef struct tdTPM_FU_INFO_REQ_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT16 wOutInfoRequestSize;
	IFX_FIELDUPGRADEINFO sOutInfoRequestData;
} TPM_FU_INFO_REQ_RSP;

//-------------------------------------------------------------------
// TPM_GetCapability
typedef struct tdTPM_GET_CAPABILITY_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_CAPABILITY_AREA dwCapArea;
	UINT32 dwSubCapSize;
	BYTE abSubCap[1];
} TPM_GET_CAPABILITY_RQU;

typedef struct tdTPM_GET_CAPABILITY_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT32 dwRespSize;
	BYTE abResp[1];
} TPM_GET_CAPABILITY_RSP;

//-------------------------------------------------------------------
// TPM_SetCapability
typedef struct tdTPM_SET_CAPABILITY_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_CAPABILITY_AREA dwCapArea;
	UINT32 dwSubCapSize;
	BYTE abSubCap[1];
	UINT32 dwSetValueSize;
	BYTE abSetValue[1];
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sOwnerAuth;
} TPM_SET_CAPABILITY_RQU;

typedef struct tdTPM_SET_CAPABILITY_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_SET_CAPABILITY_RSP;

//-------------------------------------------------------------------
// TPM_GetTestResult
typedef struct tdTPM_GET_TEST_RESULT_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT32 dwOutDataSize;
DISABLE_WARNING(4200)
	BYTE abOutData[0];	// outData currently uses 2 Bytes (do NOT change!)
RESTORE_WARNING(4200)
} TPM_GET_TEST_RESULT_RSP;

//-------------------------------------------------------------------
// TPM_NV_DefineSpace
typedef struct tdTPM_NV_DEFINE_SPACE_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_NV_DATA_PUBLIC sPubInfo;
	TPM_ENCAUTH sEncAuth;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_NV_DEFINE_SPACE_RQU;

typedef struct tdTPM_NV_DEFINE_SPACE_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_NV_DEFINE_SPACE_RSP;

//-------------------------------------------------------------------
// TPM_NV_WriteValue
typedef struct tdTPM_NV_WRITE_VALUE_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_NV_INDEX dwNvIndex;
	UINT32 dwOffset;
	UINT32 dwDataSize;
	BYTE abData[1];
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sAuthNonceOdd;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_NV_WRITE_VALUE_RQU;

typedef struct tdTPM_NV_WRITE_VALUE_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_NV_WRITE_VALUE_RSP;

//-------------------------------------------------------------------
// TPM_NV_ReadValue
typedef struct tdTPM_NV_READ_VALUE_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_NV_INDEX dwNvIndex;
	UINT32 dwOffset;
	UINT32 dwDataSize;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sAuthNonceOdd;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_NV_READ_VALUE_RQU;

typedef struct tdTPM_NV_READ_VALUE_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT32 dwDataSize;
	BYTE abData[1];
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_NV_READ_VALUE_RSP;

//-------------------------------------------------------------------
// TPM_OIAP
typedef struct tdTPM_OIAP_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceEven;
} TPM_OIAP_RSP;

//-------------------------------------------------------------------
// TPM_OSAP
typedef struct tdTPM_OSAP_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_ENTITY_TYPE wEntityType;
	UINT32 dwEntityValue;
	TPM_NONCE sNonceOddOSAP;
} TPM_OSAP_RQU;

typedef struct tdTPM_OSAP_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceEven;
	TPM_NONCE sNonceEvenOSAP;
} TPM_OSAP_RSP;

//-------------------------------------------------------------------
// TPM_SetOwnerInstall
typedef struct tdTPM_SET_OWNER_INSTALL_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	BYTE bState;		// actually: BOOL value using 1 Byte of memory
} TPM_SET_OWNER_INSTALL_RQU;

//-------------------------------------------------------------------
// TPM_OwnerSetDisable
typedef struct tdTPM_OWNER_SET_DISABLE_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	BYTE bDisableState;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_OWNER_SET_DISABLE_RQU;

typedef struct tdTPM_OWNER_SET_DISABLE_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sResAuth;
} TPM_OWNER_SET_DISABLE_RSP;

//-------------------------------------------------------------------
// TPM_SetTempDeactivated
typedef struct tdTPM_SET_TEMP_DEACTIVATED_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOperatorAuth;
} TPM_SET_TEMP_DEACTIVATED_RQU;

typedef struct tdTPM_SET_TEMP_DEACTIVATED_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sResAuth;
} TPM_SET_TEMP_DEACTIVATED_RSP;

//-------------------------------------------------------------------
// TPM_SetOperatorAuth
typedef struct tdTPM_SET_OPERATOR_AUTH_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_SECRET sOperatorAuth;
} TPM_SET_OPERATOR_AUTH_RQU;

//-------------------------------------------------------------------
// TPM_PhysicalSetDeactivated
typedef struct tdTPM_PHYS_SET_DEAC_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	BYTE bState;		// actually: BOOL value using 1 Byte of memory
} TPM_PHYS_SET_DEAC_RQU;

typedef struct tdTPM_PHYS_SET_DEAC_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
} TPM_PHYS_SET_DEAC_RSP;

//-------------------------------------------------------------------
// TPM_CreateEndorsementKeyPair
typedef struct tdTPM_CREATE_ENDORSEMENT_KEY_PAIR_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_NONCE sAntiReplay;
	TPM_KEY_PARMS sKeyInfo;
} TPM_CREATE_ENDORSEMENT_KEY_PAIR_RQU;

typedef struct tdTPM_CREATE_ENDORSEMENT_KEY_PAIR_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_PUBKEY sPubEndorsementKey;
	TPM_DIGEST sChecksum;
} TPM_CREATE_ENDORSEMENT_KEY_PAIR_RSP;

//-------------------------------------------------------------------
// TPM_ReadPubek
typedef struct tdTPM_READ_PUBEK_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_NONCE sAntiReplay;
} TPM_READ_PUBEK_RQU;

typedef struct tdTPM_READ_PUBEK_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_PUBKEY sPubEndorsementKey;
	TPM_DIGEST sChecksum;
} TPM_READ_PUBEK_RSP;

//-------------------------------------------------------------------
// TPM_SHA1Complete
typedef struct tdTPM_SHA1_CM_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	UINT32 dwHashDataSize;
	BYTE abHashData[1];
} TPM_SHA1_CM_RQU;

typedef struct tdTPM_SHA1_CM_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_DIGEST sHashValue;
} TPM_SHA1_CM_RSP;

//-------------------------------------------------------------------
// TPM_SHA1CompleteExtend
typedef struct tdTPM_SHA1_COMPLETE_EXTEND_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_PCRINDEX dwPcrNum;
	UINT32 dwHashDataSize;
	BYTE abHashData[1];
} TPM_SHA1_COMPLETE_EXTEND_RQU;

typedef struct tdTPM_SHA1_COMPLETE_EXTEND_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_DIGEST sHashValue;
	TPM_PCRVALUE sOutDigest;
} TPM_SHA1_COMPLETE_EXTEND_RSP;

//-------------------------------------------------------------------
// TPM_SHA1Start
typedef struct tdTPM_SHA1_ST_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT32 dwMaxNumBytes;
} TPM_SHA1_ST_RSP;

//-------------------------------------------------------------------
// TPM_SHA1Update
typedef struct tdTPM_SHA1_UP_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	UINT32 dwNumBytes;
	BYTE abHashData[1];
} TPM_SHA1_UP_RQU;

//-------------------------------------------------------------------
// TPM_GetRandom
typedef struct tdTPM_GET_RANDOM_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	UINT32 dwBytesRequested;
} TPM_GET_RANDOM_RQU;

typedef struct tdTPM_GET_RANDOM_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT32 dwRandomBytesSize;
	BYTE abRandomBytes[1];
} TPM_GET_RANDOM_RSP;

//-------------------------------------------------------------------
// TPM_SimpleCommmand
typedef struct tdTPM_SIMPLE_CMD_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
} TPM_SIMPLE_CMD_RQU;

typedef struct tdTPM_SIMPLE_CMD_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
} TPM_SIMPLE_CMD_RSP;

//-------------------------------------------------------------------
// TPM_Startup
typedef struct tdTPM_STARTUP_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_STARTUP_TYPE wStartupType;
} TPM_STARTUP_RQU;

typedef struct tdTPM_STARTUP_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
} TPM_STARTUP_RSP;

//-------------------------------------------------------------------
// TPM_SaveState
typedef struct tdTPM_SAVESTATE_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
} TPM_SAVESTATE_RQU;

typedef struct tdTPM_SAVESTATE_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
} TPM_SAVESTATE_RSP;

//-------------------------------------------------------------------
// TPM_TakeOwnership
typedef struct tdTPM_TAKE_OWNER_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_PROTOCOL_ID wProtocolID;
	UINT32 dwEncOwnerAuthSize;
	BYTE abEncOwnerAuth[KEY_LEN];
	UINT32 dwEncSrkAuthSize;
	BYTE abEncSrkAuth[KEY_LEN];
	TPM_KEY_TKOWN_RQU sSrkParams;	// Structure containing all parameters of new SRK. pubKey.keyLength & encSize are both 0.
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sOwnerAuth;
} TPM_TAKE_OWNER_RQU;

typedef struct tdTPM_TAKE_OWNER_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_KEY sSrkPub;	// Structure containing all parameters of new SRK. srkPub.encData is set to 0.
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_TAKE_OWNER_RSP;

//-------------------------------------------------------------------
// TPM_OwnerClear
typedef struct tdTPM_OWNER_CLEAR_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sOwnerAuth;
} TPM_OWNER_CLEAR_RQU;

typedef struct tdTPM_OWNER_CLEAR_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;
	TPM_AUTHDATA sResAuth;
} TPM_OWNER_CLEAR_RSP;

//-------------------------------------------------------------------
// TSC_PhysicalPresence
typedef struct tdTSC_PHYSICAL_PRESENCE_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_STARTUP_TYPE wPhysicalPresence;
} TSC_PHYSICAL_PRESENCE_RQU;

typedef struct tdTSC_PHYSICAL_PRESENCE_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
} TSC_PHYSICAL_PRESENCE_RSP;

//-------------------------------------------------------------------
// TPM_Seal
typedef struct tdTPM_SEAL_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_KEY_HANDLE dwKeyHandle;
	TPM_ENCAUTH sEncAuth;
	UINT32 dwPcrInfoSize;
	TPM_PCR_INFO sPcrInfo;
	UINT32 dwInDataSize;
	BYTE abInData[1];
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sKeyUsageAuth;
} TPM_SEAL_RQU;

typedef struct tdTPM_SEAL_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_STORED_DATA sSealedData;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_SEAL_RSP;

//-------------------------------------------------------------------
// TPM_Unseal
typedef struct tdTPM_UNSEAL_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_KEY_HANDLE dwParentHandle;
	TPM_STORED_DATA sInData;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sParentAuth;
	TPM_AUTHHANDLE dwDataAuthHandle;
	TPM_NONCE sDataNonceOdd;
	BYTE bContinueDataSession;
	TPM_AUTHDATA sDataAuth;
} TPM_UNSEAL_RQU;

typedef struct tdTPM_UNSEAL_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	UINT32 dwSecretSize;
	BYTE abSecret[1];
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
	TPM_NONCE sDataNonceEven;
	BYTE bContinueDataSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sDataAuth;
} TPM_UNSEAL_RSP;

//-------------------------------------------------------------------
// TPM_CreateWrapKey
typedef struct tdTPM_CREATE_WRAP_KEY_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_KEY_HANDLE dwParentHandle;
	TPM_ENCAUTH sDataUsageAuth;
	TPM_ENCAUTH sDataMigrationAuth;
	TPM_KEY sKeyInfo;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sPubAuth;
} TPM_CREATE_WRAP_KEY_RQU;

typedef struct tdTPM_CREATE_WRAP_KEY_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_KEY sWrappedKey;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_CREATE_WRAP_KEY_RSP;

//-------------------------------------------------------------------
// TPM_LoadKey2
typedef struct tdTPM_LOAD_KEY_2_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_KEY_HANDLE dwParentHandle;
	TPM_KEY sInKey;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sParentAuth;
} TPM_LOAD_KEY_2_RQU;

typedef struct tdTPM_LOAD_KEY_2_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_KEY_HANDLE dwInKeyHandle;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_LOAD_KEY_2_RSP;

//-------------------------------------------------------------------
// TPM_GetPubKey
typedef struct tdTPM_GET_PUB_KEY_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_KEY_HANDLE dwKeyHandle;
	TPM_AUTHHANDLE dwAuthHandle;
	TPM_NONCE sNonceOdd;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sKeyAuth;
} TPM_GET_PUB_KEY_RQU;

typedef struct tdTPM_GET_PUB_KEY_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_PUBKEY sPubKey;
	TPM_NONCE sNonceEven;
	BYTE bContinueAuthSession;	// actually: BOOL value using 1 Byte of memory
	TPM_AUTHDATA sResAuth;
} TPM_GET_PUB_KEY_RSP;

//-------------------------------------------------------------------
// TPM_Extend
typedef struct tdTPM_EXTEND_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_PCRINDEX dwPcrNum;
	TPM_DIGEST sInDigest;
} TPM_EXTEND_RQU;

typedef struct tdTPM_EXTEND_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_PCRVALUE sOutDigest;
} TPM_EXTEND_RSP;

//-------------------------------------------------------------------
// TPM_PCRRead
typedef struct tdTPM_PCR_READ_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_PCRINDEX pcrIndex;
} TPM_PCR_READ_RQU;

typedef struct tdTPM_PCR_READ_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_PCRVALUE sOutDigest;
} TPM_PCR_READ_RSP;

//-------------------------------------------------------------------
// TPM_PCR_Reset
typedef struct tdTPM_PCR_RESET_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_PCR_SELECTION12 sPcrSelection;
} TPM_PCR_RESET_RQU;

//-------------------------------------------------------------------
// TPM_FlushSpecific
typedef struct tdTPM_FLUSH_SPECIFIC_RQU {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_COMMAND_CODE dwOrdinal;
	TPM_HANDLE dwHandle;
	TPM_RESOURCE_TYPE dwResourceType;
} TPM_FLUSH_SPECIFIC_RQU;

//-------------------------------------------------------------------
// TPM_GetTicks
typedef struct tdTPM_GET_TICKS_RSP {
	TPM_TAG wTag;
	UINT32 dwParamSize;
	TPM_RESULT dwReturnCode;
	TPM_CURRENT_TICKS sCurrentTime;
} TPM_GET_TICKS_RSP;

#pragma pack(pop)

// TPM command functions =========================================================================

// TPM 1.1 command for reading the Endorsement Key Certificate
UINT32 TPM_11_ReadEKCert(BYTE bIndex, BYTE * pbMaxIndex, BYTE * pbCertPortion, UINT32 * pdwPortionLen);

// Transmits the TPM command TPM_FieldUpgradeInfoRequest
UINT32 TPM_FieldUpgradeInfoRequest(IFX_FIELDUPGRADEINFO * psFUInfo);

// Transmits the TPM command TPM_FieldUpgradeInfoRequest2
UINT32 TPM_FieldUpgradeInfoRequest2( IFX_FIELDUPGRADEINFO2 *psFUInfo2 );

// Transmits the TPM command TPM_GetCapability
UINT32 TPM_GetCapability(TPM_CAPABILITY_AREA wCapArea,
			 UINT32 dwSubCapSize, BYTE * pbSubCap, UINT32 * pdwResultSize, BYTE * pbResult);

// Transmits the TPM command TPM_GetTestResult
UINT32 TPM_GetTestResult(UINT32 * pdwOutDataSize, BYTE * pbOutData);

// Transmits the TPM command TPM_NV_DefineSpace
UINT32 TPM_NV_DefineSpace(UINT32 dwPubInfoSize, TPM_NV_DATA_PUBLIC * psPubInfo, TPM_ENCAUTH * psEncAuth, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			  BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth);

// Transmits the TPM command TPM_NV_WriteValue
UINT32 TPM_NV_WriteValue(TPM_NV_INDEX dwNvIndex, UINT32 dwOffset, UINT32 dwDataSize, BYTE * pbData, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth);

// Transmits the TPM command TPM_NV_ReadValue
UINT32 TPM_NV_ReadValue(TPM_NV_INDEX dwIndex, UINT32 dwOffset, UINT32 * pdwDataSize, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			BOOL bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth, BYTE * pbData);

// Transmits the TPM command TPM_OIAP
UINT32 TPM_OIAP(TPM_AUTHHANDLE * pdwAHandle, TPM_NONCE * psNonceEven);

// Transmits the TPM command TPM_OSAP
UINT32 TPM_OSAP(TPM_ENTITY_TYPE wEntityType,
		UINT32 dwEntityValue,
		TPM_NONCE * psNonceOddOSAP,
		TPM_AUTHHANDLE * pdwAuthHandle, TPM_NONCE * psNonceEven, TPM_NONCE * psNonceEvenOSAP);

// Transmits the TPM command TPM_SetOwnerInstall
UINT32 TPM_SetOwnerInstall(BYTE bState);

// Transmits the TPM command TPM_PhysicalSetDeactivated
UINT32 TPM_PhysicalSetDeactivated(BYTE bState);

// Transmits the TPM command TPM_CreateEndorsementKeyPair
UINT32 TPM_CreateEndorsementKeyPair(UINT32 dwKeyInfoSize,
				    TPM_KEY_PARMS * psKeyInfo, UINT32 * pdwKeySize, TPM_PUBKEY * pPubEndorsementKey);

// Transmits the TPM command TPM_ReadPubek
UINT32 TPM_ReadPubek(UINT32 * pdwKeyLen, BYTE * pKey);

// Transmits the TPM command TPM_Extend
UINT32 TPM_Extend(TPM_PCRINDEX dwPcrNum, TPM_DIGEST * psInDigest, TPM_PCRVALUE * psOutDigest);

// Transmits the TPM command TPM_PCRRead
UINT32 TPM_PCRRead(TPM_PCRINDEX dwPcrIndex, TPM_PCRVALUE * psOutDigest);

// Transmits the TPM command TPM_PCR_Reset
UINT32 TPM_PCR_Reset(UINT32 dwPCRSelectionSize, TPM_PCR_SELECTION12 * psPcrSelection);

// Transmits the TPM command TPM_SHA1Complete
UINT32 TPM_SHA1Complete(UINT32 dwHashDataSize, BYTE * pbHashData, BYTE * pbHashValue);

// Transmits the TPM command TPM_SHA1Start
UINT32 TPM_SHA1Start(UINT32 * pdwMaxBlockSize);

// Transmits the TPM command TPM_SHA1Update
UINT32 TPM_SHA1Update(UINT32 dwHashDataSize, BYTE * pbHashData);

// Transmits the TPM command TPM_SHA1CompleteExtend
UINT32 TPM_SHA1CompleteExtend(TPM_PCRINDEX dwPcrNum,
			      UINT32 dwHashDataSize,
			      BYTE * pbHashData, TPM_DIGEST * psHashValue, TPM_PCRVALUE * psOutDigest);

// TPM_GetRandom returns the next bytesRequested bytes from the random number
// generator to the caller.
UINT32 TPM_GetRandom(UINT32 * pdwBytesRequested, BYTE * pbRandomBytes);

// Transmits simple TPM commands (TPM_PhysicalEnable, TPM_PhysicalDisable, TPM_ForceClear,... )
UINT32 TPM_SimpleCommand(UINT32 dwOrdinal);

// Transmits the TPM command TPM_Startup
UINT32 TPM_Startup(UINT16 wStartupType);

// Transmits the TPM command TPM_SaveState
UINT32 TPM_SaveState(void);

// Transmits the TPM command TPM_OwnerSetDisable
UINT32 TPM_OwnerSetDisable(BYTE bDisableState, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			   BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth);

// Transmits the TPM command TPM_SetTempDeactivated
UINT32 TPM_SetTempDeactivated(TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceOdd,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			      BYTE bContinueAuthSession, TPM_AUTHDATA * psOperatorAuth);

// Transmits the TPM command TPM_SetOperatorAuth
UINT32 TPM_SetOperatorAuth(TPM_AUTHDATA * psOperatorAuth);

// Transmits the TPM command TPM_OwnerClear
UINT32 TPM_OwnerClear(TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceOdd,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		      BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth);

// Transmits the TPM command TPM_TakeOwnership
UINT32 TPM_TakeOwnership(UINT32 dwEncOwnerAuthSize, BYTE * pbEncOwnerAuth, UINT32 dwEncSrkAuthSize, BYTE * pbEncSrkAuth, TPM_KEY * psSrkParams, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth, UINT32 * pdwKeySize, BYTE * psSrkPub);

// Transmits the TPM command TSC_PhysicalPresence
UINT32 TSC_PhysicalPresence(UINT16 wPhysicalPresence);

// Transmits the TPM command TPM_SetCapability
UINT32 TPM_SetCapability(TPM_CAPABILITY_AREA dwCapArea, UINT32 dwSubCapSize, BYTE * abSubCap, UINT32 dwSetValueSize, BYTE * abSetValue, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 BYTE bContinueAuthSession, TPM_AUTHDATA * psOwnerAuth);

// Transmits the TPM command TPM_Seal
UINT32 TPM_Seal(TPM_KEY_HANDLE dwKeyHandle, TPM_ENCAUTH * psEncAuth, UINT32 dwPcrInfoSize, TPM_PCR_INFO * psPcrInfo, UINT32 dwInDataSize, BYTE * pbInData, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		BYTE bContinueAuthSession,
		TPM_AUTHDATA * psKeyUsageAuth, UINT32 * pdwSealedDataSize, TPM_STORED_DATA * psSealedData);

// Transmits the TPM command TPM_Unseal
UINT32 TPM_Unseal(TPM_KEY_HANDLE dwParentHandle, UINT32 dwInDataSize, TPM_STORED_DATA * psInData, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		  BYTE bContinueAuthSession, TPM_AUTHDATA * psParentAuth, TPM_AUTHHANDLE dwDataAuthHandle, TPM_NONCE * psDataNonceEven,	// I/O, incoming dataLastNonceEven, outgoing nonceEven
		  BYTE bContinueDataSession, TPM_AUTHDATA * psDataAuth, UINT32 * pdwOutDataSize, BYTE * pbOutData);

// Transmits the TPM command TPM_CreateWrapKey
UINT32 TPM_CreateWrapKey(TPM_KEY_HANDLE dwParentHandle, TPM_ENCAUTH * psDataUsageAuth, TPM_ENCAUTH * psDataMigrationAuth, UINT32 dwKeyInfoSize, TPM_KEY * psKeyInfo, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
			 TPM_AUTHDATA * psPubAuth, UINT32 * pdwWrappedKeySize, TPM_KEY * psWrappedKey);

// Transmits the TPM command TPM_LoadKey2
UINT32 TPM_LoadKey2(TPM_KEY_HANDLE dwParentHandle, UINT32 dwInKeySize, TPM_KEY * psInKey, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		    BYTE bContinueAuthSession, TPM_AUTHDATA * psKeyUsageAuth, TPM_KEY_HANDLE * pdwInKeyHandle);

// Transmits the TPM command TPM_GetPubKey
UINT32 TPM_GetPubKey(TPM_KEY_HANDLE dwKeyHandle, TPM_AUTHHANDLE dwAuthHandle, TPM_NONCE * psAuthNonceEven,	// I/O, incoming authLastNonceEven, outgoing nonceEven
		     BYTE bContinueAuthSession, TPM_AUTHDATA * psKeyAuth, UINT32 * pdwPubKeySize, TPM_PUBKEY * psPubKey);

// Transmits the TPM command TPM_FlushSpecific
UINT32 TPM_FlushSpecific(TPM_HANDLE dwHandle, TPM_RESOURCE_TYPE dwResourceType);

// Transmits the TPM command TPM_GetTicks
UINT32 TPM_GetTicks(UINT32 * pdwCurrentTicksSize, TPM_CURRENT_TICKS * psCurrentTicks);

//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

#endif // __TPM_CMDS_H__
