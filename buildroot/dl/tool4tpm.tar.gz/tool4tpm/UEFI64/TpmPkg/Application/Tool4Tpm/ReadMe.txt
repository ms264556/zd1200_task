--------------------------------------------------------------------------------
             Infineon TPM Software-Tool "TOOL4TPM" for UEFI (64bit)
                            Infineon Technologies AG

All information in this document is Copyright (c)2013 Infineon Technologies AG.
All rights reserved.
--------------------------------------------------------------------------------
################################################################################
########                      SOURCE CODE VERSION                      #########
################################################################################
--------------------------------------------------------------------------------

Contents:

1. Welcome
1.1 Export Restrictions
1.2 Prerequisites
1.2.1 Linux
1.2.2 Windows
1.3 Contents of the package
1.4 Installation
1.4.1 Linux
1.4.2 Windows

2. Usage of "TOOL4TPM"

3. If you have questions

4. Release Info
4.1 About this Release
4.2 New Features, Fixes and Improvements
4.3 Known Bugs and Limitations

================================================================================

1. Welcome

Welcome to the source code version of the Infineon TPM Software-Tool "TOOL4TPM". 

For a detailed description of the tool itself please refer to the ReadMe.txt of
the binary version of the tool.
The source code version is intended for adaption of the tool functionality to
individual requirements not yet considered by the standard version.

For further information about TCG (Trusted Computing Group):
http://www.trustedcomputinggroup.org


1.1 Export Restrictions
IMPORTANT NOTE:
The Software does have export restrictions and has to be
handled carefully.
Export from Europe (Germany) is categorized as 
 ALNR: 5D992 
 ECCN: N
Please contact your export control officer for more information.


		
1.2 Prerequisites
You can either use a Linux or Windows environment to build tool4tpm for UEFI.
Please see the corresponding subchapters for more details.


1.2.1	Linux
- PC compatible platforms
- Suse Linux 10.3 (Kernel 2.6.22) or Ubuntu 10.04
- Compiler GCC 4.4
- iASL Compiler
- Root user privileges to install and run the software


1.2.2	Windows
- Windows Developer Kit
- Microsoft Visual Studio 2008/2010
- iASL Compiler


1.3 Contents of Package
- TOOL4TPM-Conf Directory
  Directory which contains all project files required to build and debug the
  UEFI version of the Tool4TPM
- ./C-SRC
  Directory which contains all source code files to build the TOOL4TPM.
- ./C-INC
  Directory which contains all include files to build the TOOL4TPM.


1.4 Installation

1.4.1 Linux

****** Preparation******************************************************************************
- Dowload and install iAsl Compiler
- Download and install the UDK Package  

http://sourceforge.net/apps/mediawiki/tianocore/index.php?title=UDK2010
Alternatives via Subversion: 
https://edk2.svn.sourceforge.net/svnroot/edk2/branches/UDK2010.SR1: r13452
http://edk2-fatdriver2.svn.sourceforge.net/svnroot/edk2-fatdriver2/trunk/FatPkg 

For installation guidelines follow the instructions in 
- http://sourceforge.net/apps/mediawiki/tianocore/index.php?title=UDK2010.SR1.UP1_How-to-Build
and therein.

- If not already installed download and install GCC 4.4
*************************************************************************************************

- Build the UDK project
- If the build of the UDK was successful, replace the files of the Conf directory with the config
  files of the \TOOL4TPM_6.02.0.0_Source\UEFI\Conf directory.
- Move the \TOOL4TPM_6.02.0.0_Source\UEFI\TpmPkg which contains the TPM project files into your workspace.
- Build the project



1.4.2 Windows
****** Preparation*******************************************************************************
- Dowload and install iAsl Compiler
http://www.acpica.org/downloads/Version_20070508.php
- Download and install the UDK Package  
- Download and install the Windows Developer Kit (WDK)
http://sourceforge.net/apps/mediawiki/tianocore/index.php?title=UDK2010
Alternatives via Subversion: 
https://edk2.svn.sourceforge.net/svnroot/edk2/branches/UDK2010.SR1: r13452
http://edk2-fatdriver2.svn.sourceforge.net/svnroot/edk2-fatdriver2/trunk/FatPkg 

For installation guidelines follow the instructions in 
- http://sourceforge.net/apps/mediawiki/tianocore/index.php?title=UDK2010.SR1.UP1_How-to-Build
and therein.

- If not already installed download and install Visual Studio 2008 or Visual Studio 2010.
*************************************************************************************************

- Build the UDK project
- If the build of the UDK was successful, replace the files of the Conf directory with the config
  files of the TOOL4TPM-Conf Directory
- Copy the \TOOL4TPM_6.02.0.0_Source\C-SRC and \TOOL4TPM_6.02.0.0_Source\C-INC folders to \TOOL4TPM_6.02.0.0_Source\UEFI\TpmPkg\Application\Tool4Tpm folder
- Move the \TOOL4TPM_6.02.0.0_Source\UEFI\TpmPkg which contains the TPM project files into your workspace.
- Build the project


2. Usage of "TOOL4TPM"
Please refer to the ReadMe.txt of the binary version of the tool.


3. If you have questions

If you have any questions or problems, please contact your local Infineon representative. 

Further information is available under http://www.infineon.com/tpm


4. Release Info

4.1 About this Release
This is version 6.02.0.0. This version is a general release.
This Tool4TPM version was tested on a EFI Shell (64bit) version 2.00[4.637]

4.2 New Features, Fixes and Improvements
See Changelog.txt for details.

4.3 Known Bugs and Limitations
- None
