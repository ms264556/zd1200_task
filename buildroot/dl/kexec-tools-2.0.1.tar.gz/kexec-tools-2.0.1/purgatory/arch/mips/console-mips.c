#include <purgatory.h>
void putchar(int ch)
{
	/* Nothing for now */
}
