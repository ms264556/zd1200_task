#include <purgatory.h>
#include "purgatory-ppc.h"

void setup_arch(void)
{
	/* Nothing for now */
}

/* This function can be used to execute after the SHA256 verification. */
void post_verification_setup_arch(void)
{
	/* Nothing for now */
}
