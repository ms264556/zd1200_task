#include <stdio.h>
#include <stdlib.h>

int
main()
{
   FILE *fp;

   fp = fopen("/tmp/junkjunk", "w");
   fprintf(fp,"xxx");
   fclose(fp);
   exit(0);
}
